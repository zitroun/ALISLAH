from pathlib import Path
root=Path(__file__).resolve().parents[1]
html=(root/'app/src/main/assets/index.html').read_text(encoding='utf-8')
assert 'id="dashboard"' not in html
assert 'data-go="dashboard"' not in html
assert 'bubblePreferencesPanel' in html
assert 'js/bubble-settings.js' in html
assert 'id="tcRunAll"' not in html
print('Dashboard removal and relocated bubble settings: PASS')
