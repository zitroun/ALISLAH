package dz.alislah.app

/** Conservative Arabic command matcher for actions that can be executed entirely on-device. */
object OfflineCommandRouter {
    enum class Type { OPEN_TAB, READ_ZAD, STOP_ADHAN, STOP_ASSISTANT, MOVE_BUBBLE_LEFT }
    data class Command(val type: Type, val value: String = "")

    fun parse(raw: String): Command? {
        val t = raw.lowercase(java.util.Locale.forLanguageTag("ar"))
            .replace(Regex("[ًٌٍَُِّْـ]"), "")
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي')
            .replace(Regex("[،,.!?؟؛:]+"), " ")
            .replace(Regex("\\s+"), " ").trim()
        if (t.isBlank()) return null
        if (listOf("اغلق الاذان", "اوقف الاذان", "اسكت الاذان", "اوقف صوت الاذان", "اطفئ الاذان", "اقفل الاذان").any { t.contains(it) }) return Command(Type.STOP_ADHAN)
        if (listOf("اوقف صوت المساعد", "اسكت المساعد", "اوقف القراءة", "اقطع صوت المساعد").any { t.contains(it) }) return Command(Type.STOP_ASSISTANT)
        if ((t.contains("الفقاعة") || t.contains("فقاعة")) && (t.contains("اليسار") || t.contains("يسار") || t.contains("اليسري") || t.contains("يسري"))) return Command(Type.MOVE_BUBBLE_LEFT)
        if ((t.contains("اقرا") || t.contains("اقرالي") || t.contains("اقرأ")) && (t.contains("الزاد") || t.contains("زادك") || t.contains("اليوم"))) return Command(Type.READ_ZAD)
        if ((t.contains("افتح") || t.contains("افتحي") || t.contains("اذهب") || t.contains("انتقل") || t.contains("انقل") || t.contains("روح")) && (t.contains("الصلاة") || t.contains("المواقيت"))) return Command(Type.OPEN_TAB, "prayer")
        if ((t.contains("افتح") || t.contains("افتحي") || t.contains("اذهب") || t.contains("انتقل") || t.contains("انقل") || t.contains("روح")) && (t.contains("المهام") || t.contains("المهمة"))) return Command(Type.OPEN_TAB, "tasks")
        if ((t.contains("افتح") || t.contains("افتحي") || t.contains("اذهب") || t.contains("انتقل") || t.contains("انقل") || t.contains("روح")) && t.contains("العادات")) return Command(Type.OPEN_TAB, "habits")
        if ((t.contains("افتح") || t.contains("افتحي") || t.contains("اذهب") || t.contains("انتقل") || t.contains("انقل") || t.contains("روح")) && (t.contains("الاسرة") || t.contains("الأسرة") || t.contains("العائلة"))) return Command(Type.OPEN_TAB, "family")
        if ((t.contains("افتح") || t.contains("افتحي") || t.contains("اذهب") || t.contains("انتقل") || t.contains("انقل") || t.contains("روح")) && (t.contains("الزاد") || t.contains("زادك"))) return Command(Type.OPEN_TAB, "more")
        if ((t.contains("افتح") || t.contains("افتحي") || t.contains("اذهب") || t.contains("انتقل") || t.contains("انقل") || t.contains("روح")) && (t.contains("المساعد") || t.contains("المحادثة"))) return Command(Type.OPEN_TAB, "assistant")
        if ((t.contains("افتح") || t.contains("افتحي") || t.contains("اذهب") || t.contains("انتقل") || t.contains("انقل") || t.contains("روح")) && (t.contains("الإعدادات") || t.contains("الاعدادات"))) return Command(Type.OPEN_TAB, "settings")
        if ((t.contains("افتح") || t.contains("اذهب") || t.contains("انتقل") || t.contains("روح")) && (t.contains("القبلة") || t.contains("قبلة"))) return Command(Type.OPEN_TAB, "qibla")
        if ((t.contains("افتح") || t.contains("اذهب") || t.contains("انتقل") || t.contains("روح")) && (t.contains("التقويم") || t.contains("المواعيد"))) return Command(Type.OPEN_TAB, "calendar")
        if ((t.contains("افتح") || t.contains("اذهب") || t.contains("انتقل") || t.contains("روح")) && (t.contains("التقارير") || t.contains("التقرير"))) return Command(Type.OPEN_TAB, "report")
        if ((t.contains("افتح") || t.contains("اذهب") || t.contains("انتقل") || t.contains("روح")) && (t.contains("العبادات") || t.contains("العبادة"))) return Command(Type.OPEN_TAB, "worship")
        if ((t.contains("افتح") || t.contains("اذهب") || t.contains("انتقل") || t.contains("روح")) && (t.contains("الأذكار") || t.contains("الاذكار"))) return Command(Type.OPEN_TAB, "adhkar")
        return null
    }
}
