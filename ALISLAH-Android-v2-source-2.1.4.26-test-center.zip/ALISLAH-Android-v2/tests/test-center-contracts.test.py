from pathlib import Path
root = Path(__file__).resolve().parents[1]
js = (root / 'app/src/main/assets/js/test-center.js').read_text(encoding='utf-8')
html = (root / 'app/src/main/assets/index.html').read_text(encoding='utf-8')
bubble = (root / 'app/src/main/java/dz/alislah/app/FloatingBubbleService.kt').read_text(encoding='utf-8')
assert js.count("{id:'") == 14, 'Expected exactly 14 feature categories'
for item in ['tcRunAll', 'tcCopy', 'tcCopyErrors', 'tcNewFeatures', 'tcHistory', 'tcCategories']:
    assert item in html, f'Missing test center UI element: {item}'
for state in ['فشلت', 'تعذر الاختبار', 'معتمدة', 'جديدة', 'قيد التجربة']:
    assert state in js, f'Missing test status: {state}'
assert 'navigator.clipboard.writeText' in js and 'document.execCommand(\'copy\')' in js
assert 'alislah_test_center_v1' in js
assert 'testcenter' in bubble and 'اختبار الميزات' in bubble
assert 'BubbleAction("🧪", "اختبار الميزات", "testcenter"' in bubble
assert 'window.ALI?.tab?.(\'testcenter\')' in bubble
assert 'newFeatures' in js and '2.1.4.25' in js
assert "versionCode 56" in (root / 'app/build.gradle').read_text(encoding='utf-8')
assert "versionName '2.1.4.26'" in (root / 'app/build.gradle').read_text(encoding='utf-8')
print('Test center contracts: PASS (14 categories, real component probes, manual verification states, persistent report and copy actions)')
