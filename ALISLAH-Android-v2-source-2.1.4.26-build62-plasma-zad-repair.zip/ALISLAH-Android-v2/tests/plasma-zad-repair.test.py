from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/dz/alislah/app/FloatingBubbleService.kt').read_text()
assert 'Organic liquid-plasma masses' in s
assert 'PlasmaActionTextView' in s
assert 'Traveling plasma beads' in s
assert 'runOverlayJs("document.getElementById(\'contentRead\')?.click();")' in s
assert 'handler.postDelayed({ hideAssistantOverlay() }, 350L)' in s
print('PASS: main liquid plasma renderer, animated side orbs, flowing orbit beads, and automatic floating-bubble zad read path')
