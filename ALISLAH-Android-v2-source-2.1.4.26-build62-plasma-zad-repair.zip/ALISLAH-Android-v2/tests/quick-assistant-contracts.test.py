from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
service = (ROOT / "app/src/main/java/dz/alislah/app/FloatingBubbleService.kt").read_text(encoding="utf-8")
main = (ROOT / "app/src/main/java/dz/alislah/app/MainActivity.kt").read_text(encoding="utf-8")
quick = (ROOT / "app/src/main/java/dz/alislah/app/QuickAsk.kt").read_text(encoding="utf-8")
client = (ROOT / "app/src/main/java/dz/alislah/app/AssistantClient.kt").read_text(encoding="utf-8")
html = (ROOT / "app/src/main/assets/index.html").read_text(encoding="utf-8")
dashboard = (ROOT / "app/src/main/assets/js/dashboard.js").read_text(encoding="utf-8")

assert "showQuickAsk()" in service and '"ask" -> showQuickAsk()' in service
assert "startQuickAskVoice()" in service and '"ar-DZ"' in service
assert "putExtra(\"prefillText\"" in service and "prefillText" in main
assert "AssistantClient.ask" in quick and "onSpeak" in quick
assert "connectTimeout = 10_000" in client and "readTimeout = 30_000" in client
assert "MAX_REPLY_BYTES" in client and "isAllowedEndpoint" in client
assert "bubbleHideGames" in html and "bubbleHideGames" in dashboard
assert "setHideBubbleInFullscreen" in main and "requestUsagePermission" in main
assert "FullscreenRules.shouldHide" in service and "ForegroundTracker.currentPackage" in service
assert "versionCode 62" in (ROOT / "app/build.gradle").read_text(encoding="utf-8")
assert not list((ROOT / "app/src/main").rglob("*.onnx"))
assert not list((ROOT / "app/src/main").rglob("*.tflite"))
print("Quick assistant and fullscreen-bubble contracts passed")
