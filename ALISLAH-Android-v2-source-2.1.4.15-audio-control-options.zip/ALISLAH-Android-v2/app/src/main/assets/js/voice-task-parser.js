(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.ALISLAHVoiceTaskParser = api;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';
  const digitMap = {'٠':'0','١':'1','٢':'2','٣':'3','٤':'4','٥':'5','٦':'6','٧':'7','٨':'8','٩':'9','۰':'0','۱':'1','۲':'2','۳':'3','۴':'4','۵':'5','۶':'6','۷':'7','۸':'8','۹':'9'};
  const words = [
    ['الحادية عشرة|الحادي عشر|احدى عشر|احد عشر', 11],
    ['الثانية عشرة|الثاني عشر|اثنتا عشرة|اثنا عشر', 12],
    ['الواحدة|واحده|واحد|واحدة|الأولى|الاولى', 1],
    ['الثانية|الثاني|اثنتين|اثنين', 2],
    ['الثالثة|الثالث|ثلاثة', 3],
    ['الرابعة|الرابع|اربعة|أربعة', 4],
    ['الخامسة|الخامس|خمسة', 5],
    ['السادسة|السادس|ستة', 6],
    ['السابعة|السابع|سبعة', 7],
    ['الثامنة|الثامن|ثمانية', 8],
    ['التاسعة|التاسع|تسعة', 9],
    ['العاشرة|العاشر|عشرة', 10]
  ];
  const hourWords = [];
  words.forEach(([forms, value]) => forms.split('|').forEach(word => hourWords.push([word, value])));
  const wordPattern = hourWords.map(([word]) => word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  const dayNames = {'الاحد':0,'الأحد':0,'الاثنين':1,'الإثنين':1,'الثلاثاء':2,'الاربعاء':3,'الأربعاء':3,'الخميس':4,'الجمعة':5,'السبت':6};
  const localDate = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const localTime = d => `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
  const normalize = value => String(value || '').replace(/[٠-٩۰-۹]/g, c => digitMap[c] || c).replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/[ًٌٍَُِّْٰـ]/g, '').toLowerCase();
  const numeric = value => /^\d+$/.test(value) ? Number(value) : (hourWords.find(([word]) => normalize(word) === normalize(value)) || [null, NaN])[1];

  function parse(input, nowValue) {
    const original = String(input || '').trim();
    const now = nowValue instanceof Date ? new Date(nowValue.getTime()) : new Date(nowValue || Date.now());
    if (!original) return {taskText:'', date:localDate(now), time:'', hasTime:false};
    const text = normalize(original);
    let date = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    let dateMatched = false;

    if (/بعد\s+غد|بعد\s+بكره/.test(text)) {
      date.setDate(date.getDate() + 2); dateMatched = true;
    } else if (/غدا|بكره|بكره/.test(text)) {
      date.setDate(date.getDate() + 1); dateMatched = true;
    } else if (/اليوم/.test(text)) {
      dateMatched = true;
    } else {
      const explicit = text.match(/(?:^|\s)(\d{1,2})[\/.-](\d{1,2})(?:[\/.-](\d{2,4}))?(?=\s|$)/);
      if (explicit) {
        const year = explicit[3] ? (Number(explicit[3]) < 100 ? 2000 + Number(explicit[3]) : Number(explicit[3])) : now.getFullYear();
        const candidate = new Date(year, Number(explicit[2])-1, Number(explicit[1]));
        if (candidate.getFullYear() === year && candidate.getMonth() === Number(explicit[2])-1 && candidate.getDate() === Number(explicit[1])) { date = candidate; dateMatched = true; }
      }
      if (!dateMatched) {
        for (const [name, weekday] of Object.entries(dayNames)) {
          if (text.includes(normalize(name))) {
            const delta = (weekday - date.getDay() + 7) % 7 || 7;
            date.setDate(date.getDate() + delta); dateMatched = true; break;
          }
        }
      }
    }

    let time = '';
    let timeMatched = false;
    let prayerPhraseMatched = false;
    const prayerMatch = text.match(/(?:بعد|عقب)\s*(?:(?:صلاه|الصلوه|اذان|الاذان)\s*)?(الفجر|الصبح|الظهر|العصر|المغرب|العشاء)/);
    if (prayerMatch) {
      const prayerKeys = {الفجر:'Fajr',الصبح:'Fajr',الظهر:'Dhuhr',العصر:'Asr',المغرب:'Maghrib',العشاء:'Isha'};
      const resolver = (typeof window !== 'undefined' && window.ALI_PRAYER_TASK_TIME) || (typeof globalThis !== 'undefined' && globalThis.ALI_PRAYER_TASK_TIME);
      const resolved = typeof resolver === 'function' ? resolver(prayerKeys[prayerMatch[1]], localDate(date), !dateMatched) : null;
      if (resolved && /^\d{4}-\d{2}-\d{2}$/.test(resolved.date || '') && /^\d{2}:\d{2}$/.test(resolved.time || '')) {
        const parts = resolved.date.split('-').map(Number);
        date = new Date(parts[0], parts[1]-1, parts[2]);
        time = resolved.time;
        timeMatched = true;
        dateMatched = true;
        prayerPhraseMatched = true;
      }
    }
    const relative = timeMatched ? null : text.match(/بعد\s+(نصف\s+ساعه|ساعه|ساعتين|\d+\s*(?:دقيقه|دقائق|ساعه|ساعات))/);
    if (relative) {
      let minutes = 0;
      if (relative[1].includes('نصف')) minutes = 30;
      else if (relative[1] === 'ساعه') minutes = 60;
      else if (relative[1] === 'ساعتين') minutes = 120;
      else {
        const amount = Number(relative[1].match(/\d+/)?.[0] || 0);
        minutes = /دقيق/.test(relative[1]) ? amount : amount * 60;
      }
      const future = new Date(now.getTime() + minutes * 60000);
      date = new Date(future.getFullYear(), future.getMonth(), future.getDate());
      time = localTime(future); timeMatched = true;
    } else if (!timeMatched) {
      const suffix = '(صباحا|صباح|الصباح|مساء|مساءا|المساء|ليلا|ليلًا)?';
      const prefixed = text.match(new RegExp('(?:على\\s+|عند\\s+)?(?:الساعه\\s*)(' + wordPattern + '|\\d{1,2})(?:\\s*[:.]\\s*(\\d{1,2}))?\\s*' + suffix));
      const numericWithPeriod = text.match(new RegExp('(?:على\\s+)?(\\d{1,2})(?:\\s*[:.]\\s*(\\d{1,2}))?\\s*(صباحا|صباح|الصباح|مساء|مساءا|المساء|ليلا|ليلًا)'));
      const explicitClock = text.match(/(?:^|\s)(\d{1,2})[:.](\d{2})(?=\s|$)/);
      const match = prefixed || numericWithPeriod || explicitClock;
      if (match) {
        const rawHour = prefixed ? match[1] : match[1];
        let hour = numeric(rawHour);
        let minute = Number(match[2] || 0);
        const period = normalize(match[3] || '');
        if (Number.isFinite(hour) && hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59) {
          if (/مساء|المساء|ليلا/.test(period) && hour < 12) hour += 12;
          if (/صباح|الصباح/.test(period) && hour === 12) hour = 0;
          if (hour <= 23) { time = `${String(hour).padStart(2,'0')}:${String(minute).padStart(2,'0')}`; timeMatched = true; }
        }
      }
    }

    let taskText = original
      .replace(/(?:بعد|عقب)\s*(?:(?:صلاة|الصلاة|اذان|الأذان)\s*)?(?:الفجر|الصبح|الظهر|العصر|المغرب|العشاء)/g, ' ')
      .replace(/(?:بعد\s+غد|بعد\s+بكرة|بعد\s+بكره|غدًا|غدا|بكرة|بكره|اليوم)/g, ' ')
      .replace(/(?:يوم\s+)?(?:الاحد|الأحد|الاثنين|الإثنين|الثلاثاء|الاربعاء|الأربعاء|الخميس|الجمعة|السبت)/g, ' ')
      .replace(/(?:على\s+|عند\s+)?(?:الساعة|الساعه)\s*(?:الحادية\s+عشرة|الحادي\s+عشر|احدى\s+عشر|احد\s+عشر|الثانية\s+عشرة|الثاني\s+عشر|اثنتا\s+عشرة|اثنا\s+عشر|الواحدة|واحده|واحد|واحدة|الأولى|الاولى|الثانية|الثاني|اثنتين|اثنين|الثالثة|الثالث|ثلاثة|الرابعة|الرابع|اربعة|أربعة|الخامسة|الخامس|خمسة|السادسة|السادس|ستة|السابعة|السابع|سبعة|الثامنة|الثامن|ثمانية|التاسعة|التاسع|تسعة|العاشرة|العاشر|عشرة|[\d٠-٩۰-۹]{1,2})(?:\s*[:.]\s*[\d٠-٩۰-۹]{1,2})?\s*(?:صباحًا|صباحا|صباح|الصباح|مساءً|مساءا|مساء|المساء|ليلًا|ليلا)?/g, ' ')
      .replace(/بعد\s+(?:نصف\s+ساعة|ساعة|ساعتين|[\d٠-٩۰-۹]+\s*(?:دقيقة|دقائق|ساعة|ساعات))/g, ' ')
      .replace(/[\d٠-٩۰-۹]{1,2}[:.][\d٠-٩۰-۹]{2}(?:\s*(?:صباحًا|صباحا|مساءً|مساءا|ليلا))?/g, ' ')
      .replace(/[\s،؛,:.؟!?-]+$/g, '').replace(/^[\s،؛,:.؟!?-]+/g, '').replace(/\s{2,}/g, ' ').trim();
    if (!taskText) taskText = original;
    return {taskText:taskText.slice(0,180), date:localDate(date), time, hasTime:timeMatched, hasDate:dateMatched};
  }
  return {parse};
});
