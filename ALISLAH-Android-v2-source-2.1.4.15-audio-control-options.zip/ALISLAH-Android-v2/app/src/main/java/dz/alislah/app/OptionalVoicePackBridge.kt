package dz.alislah.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/** IPC bridge to the separately installed, optional ALISLAH Mixer-TTS voice pack. */
object OptionalVoicePackBridge {
    const val PACKAGE_NAME = "dz.alislah.voicepack"
    private const val SERVICE_NAME = "dz.alislah.voicepack.VoicePackService"
    const val ACTION_SPEAK = "dz.alislah.voicepack.action.SPEAK"
    const val ACTION_STOP = "dz.alislah.voicepack.action.STOP"
    const val EXTRA_TEXT = "dz.alislah.voicepack.extra.TEXT"

    fun isInstalled(context: Context): Boolean = try {
        @Suppress("DEPRECATION")
        context.packageManager.getPackageInfo(PACKAGE_NAME, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    } catch (_: Exception) {
        false
    }

    fun speak(context: Context, text: String): Boolean {
        val clean = text.trim().take(700)
        if (clean.isBlank() || !isInstalled(context)) return false
        val intent = Intent(ACTION_SPEAK).apply {
            component = ComponentName(PACKAGE_NAME, SERVICE_NAME)
            putExtra(EXTRA_TEXT, clean)
        }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun stop(context: Context) {
        if (!isInstalled(context)) return
        val intent = Intent(ACTION_STOP).apply {
            component = ComponentName(PACKAGE_NAME, SERVICE_NAME)
        }
        try { context.startService(intent) } catch (_: Exception) { }
    }
}
