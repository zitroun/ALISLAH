package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.Context
import android.media.AudioAttributes
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.Surface
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.content.res.Configuration
import android.webkit.WebChromeClient
import android.webkit.PermissionRequest
import android.Manifest
import android.content.pm.PackageManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.view.WindowManager
import android.util.DisplayMetrics
import android.widget.TextView
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class FloatingBubbleService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f
    private var dragged = false
    private var downAt = 0L
    private var lastTapAt = 0L
    private var pendingMainTap: Runnable? = null
    private var mainLongPressRunnable: Runnable? = null
    private var mainLongPressTriggered = false
    private var speakingTapConsumed = false
    private var lastBubbleScreenWidth = 0
    private var lastBubbleScreenHeight = 0
    private var lastDisplayRotation = Surface.ROTATION_0
    private var lastConfigOrientation = Configuration.ORIENTATION_UNDEFINED
    // Keep independent anchor positions for portrait and landscape. Returning to an
    // orientation restores its saved edge/position instead of reusing rotated pixels.
    private var portraitAnchorXRatio: Float? = null
    private var portraitAnchorYRatio: Float? = null
    private var landscapeAnchorXRatio: Float? = null
    private var landscapeAnchorYRatio: Float? = null
    private var orbitRotation = 0.0
    private var closeButton: TextView? = null
    private var closeParams: WindowManager.LayoutParams? = null
    private var quickMenu: View? = null
    private var quickMenuParams: WindowManager.LayoutParams? = null
    private var tts: TextToSpeech? = null
    private var assistantRecognizer: SpeechRecognizer? = null
    private var assistantListening = false
    private var lastSpokenReply = ""
    private var networkArabicVoice: android.speech.tts.Voice? = null
    private var localArabicVoice: android.speech.tts.Voice? = null
    private var pendingFallbackText = ""
    private var fallbackAttempted = false
    private var ttsReady = false
    @Volatile private var assistantSpeaking = false
    private val pollReply = object : Runnable { override fun run() { speakLatestReply(); if (assistantPanel != null) handler.postDelayed(this, 1800L) } }
    private var assistantPanel: View? = null
    private var assistantWebView: WebView? = null
    private var activeOverlayCommand: String? = null
    private var overlayPageReady = false
    private val pendingOverlayScripts = ArrayDeque<String>()
    private var adhanPlaying = false
    private var adhanMuteBubble: TextView? = null
    private var adhanMuteParams: WindowManager.LayoutParams? = null
    private var assistantStopBubble: TextView? = null
    private var assistantStopParams: WindowManager.LayoutParams? = null
    @Volatile private var autoListenAfterSpeech = false
    private var currentReminderTitle = ""
    private var currentReminderText = ""
    private var reminderCardVisible = false
    private var reminderSpeechActive = false
    private var reminderCardView: LinearLayout? = null
    private var reminderCardParams: WindowManager.LayoutParams? = null
    private var reminderArrowView: TextView? = null
    private var reminderArrowParams: WindowManager.LayoutParams? = null
    private var reminderStopView: TextView? = null
    private var reminderStopParams: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private val assistantNoSpeechTimeout = Runnable {
        if (assistantListening) {
            assistantListening = false
            stopAssistantRecognizer()
            overlaySpeechStatus("انتهى الاستماع بعد 3 ثوانٍ دون كلام.")
        }
    }
    private val reshowBubble = Runnable { showBubble() }

    override fun onCreate() {
        super.onCreate()
        adhanPlaying = prefs().getBoolean("adhanPlaying", false)
        createChannel()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                configureAssistantVoice()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { handler.post { setAssistantSpeaking(true) } }
                    override fun onDone(utteranceId: String?) {
                        handler.post {
                            setAssistantSpeaking(false)
                            if (reminderSpeechActive) { reminderSpeechActive = false; reminderStopView?.visibility = View.GONE }
                            if (autoListenAfterSpeech && assistantPanel != null) {
                                autoListenAfterSpeech = false
                                handler.postDelayed({ if (assistantPanel != null && !assistantListening) startAssistantListening() }, 350L)
                            }
                        }
                        fallbackAttempted = false; pendingFallbackText = ""
                    }
                    override fun onError(utteranceId: String?) { handler.post { setAssistantSpeaking(false) }; retryWithLocalArabicVoice() }
                    override fun onError(utteranceId: String?, errorCode: Int) { handler.post { setAssistantSpeaking(false) }; retryWithLocalArabicVoice() }
                })
                if (pendingFallbackText.isNotBlank()) speak(pendingFallbackText)
            }
        }
        startForeground(4107, buildNotification())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) showBubble() else stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ANSWERED -> {
                handler.removeCallbacks(reshowBubble)
                // Do not tear down time-critical controls while adhan/reminder audio is active.
                if (adhanPlaying || reminderCardVisible || assistantSpeaking) {
                    hideQuickMenu()
                } else hideBubble()
            }
            ACTION_HIDE_PANEL -> hideAssistantOverlay()
            ACTION_START_ASSISTANT_LISTENING -> startAssistantListening()
            ACTION_STOP_ASSISTANT_LISTENING -> stopAssistantListening()
            ACTION_ASSISTANT_MIC_PERMISSION_RESULT -> {
                if (intent.getBooleanExtra(EXTRA_ASSISTANT_MIC_GRANTED, false)) startAssistantListening()
                else overlaySpeechStatus("لم يُمنح إذن الميكروفون. يمكنك تفعيله من إعدادات التطبيق.")
            }
            ACTION_STOP_SPEECH -> stopAssistantSpeech()
            ACTION_SPEAK_TEST -> speak("مرحبًا بك في الإصلاح. هذا اختبار لصوت المساعد العربي.")
            ACTION_SPEAK_TEXT -> speak(intent.getStringExtra(EXTRA_SPEAK_TEXT) ?: "")
            ACTION_ADHAN_STARTED -> {
                adhanPlaying = true
                // ACTION_ANSWERED can hide the main bubble without stopping this service.
                // Recreate the anchor before adding the temporary adhan control.
                ensureBubbleForTimedEvent()
                bubble?.invalidate()
                showAdhanMuteBubble()
            }
            ACTION_ADHAN_STOPPED -> { adhanPlaying = false; bubble?.invalidate(); hideAdhanMuteBubble() }
            ACTION_SHOW_REMINDER -> {
                val title = intent.getStringExtra(EXTRA_REMINDER_TITLE) ?: "تذكير الصلاة"
                val body = intent.getStringExtra(EXTRA_REMINDER_TEXT) ?: ""
                if (body.isNotBlank() && ensureBubbleForTimedEvent()) showPrayerReminder(title, body, true)
            }
            ACTION_SHOW_FOR_EVENT -> {
                handler.removeCallbacks(reshowBubble)
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) showFollowupOverlay()
            }
            else -> if (bubble == null && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))) showBubble()
        }
        return START_STICKY
    }

    /** Restore the anchor after an earlier ACTION_ANSWERED hid it; timed overlays depend on it. */
    private fun ensureBubbleForTimedEvent(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) return false
        val enabled = getSharedPreferences("alislah_native", MODE_PRIVATE).getBoolean("overlayEnabled", false)
        if (!enabled) return false
        if (bubble == null) showBubble()
        return bubble != null
    }

    private fun hideBubble() {
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        params = null
        hideCloseButton()
        hideQuickMenu()
        hideReminderViews()
        hideAdhanMuteBubble()
        hideAssistantStopBubble()
    }

    private fun hideQuickMenu() {
        quickMenu?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        quickMenu = null
        quickMenuParams = null
    }

    /** A separate, temporary mute bubble appears beside the main bubble only while adhan is playing. */
    private fun showAdhanMuteBubble() {
        if (!adhanPlaying || bubble == null) return
        val existing = adhanMuteBubble
        if (existing != null) { syncAdhanMuteBubble(); existing.visibility = View.VISIBLE; syncAssistantStopBubble(); return }
        val d = resources.displayMetrics.density
        val size = (42*d).toInt()
        val view = TextView(this).apply {
            text = "🔇"
            textSize = 19f
            gravity = Gravity.CENTER
            contentDescription = "إيقاف الأذان"
            setTextColor(Color.WHITE)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(176,48,43))
                setStroke((2*d).toInt().coerceAtLeast(1), Color.WHITE)
            }
            elevation = 24*d
            setOnClickListener { stopAdhanFromBubble() }
        }
        val lp = overlayWindowParams(size, size)
        try {
            windowManager.addView(view, lp)
            adhanMuteBubble = view
            adhanMuteParams = lp
            syncAdhanMuteBubble()
            syncAssistantStopBubble()
        } catch (_: Exception) {
            adhanMuteBubble = null
            adhanMuteParams = null
        }
    }

    private fun syncAdhanMuteBubble() {
        val view = adhanMuteBubble ?: return
        val lp = adhanMuteParams ?: return
        val main = bubble ?: return
        val d = resources.displayMetrics.density
        val (screenW, screenH) = realScreenSize()
        val location = IntArray(2)
        main.getLocationOnScreen(location)
        val centerY = location[1] + main.height/2
        val docked = (main as? MainBubbleView)?.dockedAtCamera == true
        val leftSide = (params?.x ?: 0) < 0
        val x = if (docked) location[0] + main.width + (6*d).toInt()
                else if (leftSide) location[0] + main.width + (6*d).toInt()
                else location[0] - lp.width - (6*d).toInt()
        lp.x = x.coerceIn(0, (screenW-lp.width).coerceAtLeast(0))
        lp.y = (centerY-lp.height/2).coerceIn(0, (screenH-lp.height).coerceAtLeast(0))
        try { windowManager.updateViewLayout(view, lp) } catch (_: Exception) { }
    }

    private fun hideAdhanMuteBubble() {
        adhanMuteBubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        adhanMuteBubble = null
        adhanMuteParams = null
        syncAssistantStopBubble()
    }

    /** Independent stop control for assistant speech; it never controls the adhan player. */
    private fun showAssistantStopBubble() {
        if (!assistantSpeaking || reminderSpeechActive || bubble == null) return
        if (assistantStopBubble != null) { syncAssistantStopBubble(); assistantStopBubble?.visibility = View.VISIBLE; return }
        val d = resources.displayMetrics.density
        val size = (42*d).toInt()
        val view = TextView(this).apply {
            text = "■"
            textSize = 17f
            gravity = Gravity.CENTER
            contentDescription = "إيقاف صوت المساعد"
            setTextColor(Color.WHITE)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(23, 107, 91))
                setStroke((2*d).toInt().coerceAtLeast(1), Color.WHITE)
            }
            elevation = 25*d
            setOnClickListener { stopAssistantSpeech() }
        }
        val lp = overlayWindowParams(size, size)
        try {
            windowManager.addView(view, lp)
            assistantStopBubble = view
            assistantStopParams = lp
            syncAssistantStopBubble()
        } catch (_: Exception) { assistantStopBubble = null; assistantStopParams = null }
    }

    private fun syncAssistantStopBubble() {
        val view = assistantStopBubble ?: return
        val lp = assistantStopParams ?: return
        val main = bubble ?: return
        val d = resources.displayMetrics.density
        val (screenW, screenH) = realScreenSize()
        val loc = IntArray(2); main.getLocationOnScreen(loc)
        val centerX = loc[0] + main.width/2
        val centerY = loc[1] + main.height/2
        val gap = (7*d).toInt()
        val bothControls = adhanMuteBubble?.visibility == View.VISIBLE
        if (bothControls) {
            lp.x = (centerX - lp.width/2).coerceIn(0, (screenW-lp.width).coerceAtLeast(0))
            lp.y = if (centerY < screenH/2) (loc[1] + main.height + gap).coerceIn(0, (screenH-lp.height).coerceAtLeast(0))
                   else (loc[1] - lp.height - gap).coerceIn(0, (screenH-lp.height).coerceAtLeast(0))
        } else {
            val left = if (centerX > screenW/2) loc[0] - lp.width - gap else loc[0] + main.width + gap
            lp.x = left.coerceIn(0, (screenW-lp.width).coerceAtLeast(0))
            lp.y = (centerY - lp.height/2).coerceIn(0, (screenH-lp.height).coerceAtLeast(0))
        }
        try { windowManager.updateViewLayout(view, lp) } catch (_: Exception) { }
    }

    private fun hideAssistantStopBubble() {
        assistantStopBubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        assistantStopBubble = null
        assistantStopParams = null
    }

    private fun overlayWindowParams(width: Int, height: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(
            width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.LEFT }
    }

    private fun showPrayerReminder(title: String, body: String, readAloud: Boolean) {
        if (body.isBlank()) return
        currentReminderTitle = title.take(100)
        currentReminderText = body.take(700)
        reminderCardVisible = true
        ensureReminderViews()
        reminderCardView?.visibility = View.VISIBLE
        reminderArrowView?.visibility = View.VISIBLE
        reminderArrowView?.text = "⌃"
        syncReminderOverlay(params)
        if (readAloud) {
            reminderSpeechActive = true
            reminderStopView?.visibility = View.VISIBLE
            speak("${currentReminderTitle}. ${currentReminderText}")
        }
    }

    private fun ensureReminderViews() {
        val d = resources.displayMetrics.density
        if (reminderCardView == null) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding((14*d).toInt(), (10*d).toInt(), (14*d).toInt(), (11*d).toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.WHITE)
                    cornerRadius = 18*d
                    setStroke((1.2f*d).toInt().coerceAtLeast(1), Color.rgb(190, 219, 207))
                }
                elevation = 22*d
                isClickable = true
            }
            val titleView = TextView(this).apply {
                textSize = 13f
                setTextColor(Color.rgb(23, 107, 91))
                typeface = Typeface.DEFAULT_BOLD
                text = currentReminderTitle
                maxLines = 1
            }
            val bodyView = TextView(this).apply {
                textSize = 14f
                setTextColor(Color.rgb(35, 53, 47))
                text = currentReminderText
                maxLines = 6
                ellipsize = android.text.TextUtils.TruncateAt.END
                setLineSpacing((2*d), 1f)
                setPadding(0, (5*d).toInt(), 0, 0)
            }
            card.addView(titleView)
            card.addView(bodyView)
            card.tag = Pair(titleView, bodyView)
            card.setOnTouchListener(object : View.OnTouchListener {
                var downX = 0f
                var downY = 0f
                var swiped = false
                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; swiped = false; return true }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = event.rawX - downX
                            val dy = event.rawY - downY
                            if (kotlin.math.abs(dx) > 18*d || kotlin.math.abs(dy) > 18*d) swiped = true
                            return true
                        }
                        MotionEvent.ACTION_UP -> {
                            val dx = event.rawX - downX
                            val dy = event.rawY - downY
                            if (swiped && (kotlin.math.abs(dx) > 48*d || kotlin.math.abs(dy) > 48*d)) {
                                hideReminderCardOnly()
                                return true
                            }
                            return false
                        }
                        MotionEvent.ACTION_CANCEL -> { swiped = false; return true }
                    }
                    return false
                }
            })
            reminderCardView = card
            reminderCardParams = overlayWindowParams((resources.displayMetrics.widthPixels - (24*d).toInt()).coerceAtMost((320*d).toInt()), WindowManager.LayoutParams.WRAP_CONTENT)
            try { windowManager.addView(card, reminderCardParams) } catch (_: Exception) { reminderCardView = null; reminderCardParams = null }
        }
        val tag = reminderCardView?.tag as? Pair<*, *>
        (tag?.first as? TextView)?.text = currentReminderTitle
        (tag?.second as? TextView)?.text = currentReminderText

        if (reminderArrowView == null) {
            val arrow = TextView(this).apply {
                text = if (reminderCardVisible) "⌃" else "⌄"
                textSize = 22f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                contentDescription = "فتح أو إخفاء تذكير الصلاة"
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    setCornerRadii(floatArrayOf(0f,0f,0f,0f,10*d,10*d,10*d,10*d))
                    setColor(Color.rgb(23,107,91))
                }
                elevation = 22*d
                setOnClickListener {
                    reminderCardVisible = !reminderCardVisible
                    reminderCardView?.visibility = if (reminderCardVisible) View.VISIBLE else View.GONE
                    text = if (reminderCardVisible) "⌃" else "⌄"
                    syncReminderOverlay(params)
                }
            }
            reminderArrowView = arrow
            reminderArrowParams = overlayWindowParams((42*d).toInt(), (30*d).toInt())
            try { windowManager.addView(arrow, reminderArrowParams) } catch (_: Exception) { reminderArrowView = null; reminderArrowParams = null }
        }

        if (reminderStopView == null) {
            val stop = TextView(this).apply {
                text = "■"
                textSize = 16f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                contentDescription = "إيقاف قراءة التذكير"
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(Color.rgb(176, 48, 43))
                    setStroke((1.5f*d).toInt().coerceAtLeast(1), Color.WHITE)
                }
                elevation = 24*d
                setOnClickListener { stopReminderSpeech() }
            }
            reminderStopView = stop
            reminderStopParams = overlayWindowParams((36*d).toInt(), (36*d).toInt())
            try { windowManager.addView(stop, reminderStopParams) } catch (_: Exception) { reminderStopView = null; reminderStopParams = null }
        }
        reminderCardView?.visibility = if (reminderCardVisible) View.VISIBLE else View.GONE
        reminderArrowView?.visibility = View.VISIBLE
        reminderStopView?.visibility = if (reminderSpeechActive) View.VISIBLE else View.GONE
    }

    private fun hideReminderCardOnly() {
        reminderCardVisible = false
        reminderCardView?.visibility = View.GONE
        // A swipe dismisses the whole floating reminder control, but never its library entry.
        reminderArrowView?.visibility = View.GONE
    }

    private fun setAssistantSpeaking(active: Boolean) {
        assistantSpeaking = active
        bubble?.let { (it as? MainBubbleView)?.setSpeaking(active) }
        if (active && !reminderSpeechActive) showAssistantStopBubble() else hideAssistantStopBubble()
    }

    private fun stopAssistantSpeech() {
        autoListenAfterSpeech = false
        pendingFallbackText = ""
        fallbackAttempted = true
        reminderSpeechActive = false
        try { assistantWebView?.evaluateJavascript("window.AlishlahNeuralVoice&&window.AlishlahNeuralVoice.stop()", null) } catch (_: Exception) { }
        try { tts?.stop() } catch (_: Exception) { }
        try { OptionalVoicePackBridge.stop(this) } catch (_: Exception) { }
        setAssistantSpeaking(false)
        reminderStopView?.visibility = View.GONE
    }

    private fun stopReminderSpeech() {
        pendingFallbackText = ""
        fallbackAttempted = true
        reminderSpeechActive = false
        try { assistantWebView?.evaluateJavascript("window.AlishlahNeuralVoice&&window.AlishlahNeuralVoice.stop()", null) } catch (_: Exception) { }
        try { tts?.stop() } catch (_: Exception) { }
        setAssistantSpeaking(false)
        reminderStopView?.visibility = View.GONE
    }

    private fun hideReminderViews() {
        reminderCardView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        reminderArrowView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        reminderStopView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        reminderCardView = null; reminderCardParams = null
        reminderArrowView = null; reminderArrowParams = null
        reminderStopView = null; reminderStopParams = null
    }

    /** Keep reminder controls attached to the actual rendered centre of the main orbital anchor. */
    private fun syncReminderOverlay(anchor: WindowManager.LayoutParams?) {
        val wm = try { windowManager } catch (_: Exception) { return }
        val main = bubble
        val a = anchor ?: params ?: return
        val d = resources.displayMetrics.density
        val (screenW, screenH) = realScreenSize()
        val location = IntArray(2)
        if (main != null && main.width > 0 && main.height > 0) main.getLocationOnScreen(location) else { location[0] = a.x; location[1] = a.y }
        val left = location[0]
        val top = location[1]
        val width = main?.width?.takeIf { it > 0 } ?: a.width
        val height = main?.height?.takeIf { it > 0 } ?: a.height
        val centerX = left + width/2
        val docked = (main as? MainBubbleView)?.dockedAtCamera == true
        val onLeft = centerX < screenW/2
        val arrowLp = reminderArrowParams
        val arrow = reminderArrowView
        if (arrowLp != null && arrow != null) {
            val arrowW = arrowLp.width
            val arrowH = arrowLp.height
            arrowLp.x = if (docked) centerX - arrowW/2 else if (onLeft) left + width - arrowW/2 else left - arrowW/2
            arrowLp.x = arrowLp.x.coerceIn(0, (screenW-arrowW).coerceAtLeast(0))
            arrowLp.y = (top + height - (2*d).toInt()).coerceIn(0, (screenH-arrowH).coerceAtLeast(0))
            try { wm.updateViewLayout(arrow, arrowLp) } catch (_: Exception) { }
        }
        val cardLp = reminderCardParams
        val card = reminderCardView
        if (cardLp != null && card != null) {
            val cardW = cardLp.width
            val measuredH = card.height.takeIf { it > 0 } ?: (150*d).toInt()
            cardLp.x = if (docked) centerX - cardW/2 else if (onLeft) (16*d).toInt() else screenW-cardW-(16*d).toInt()
            cardLp.x = cardLp.x.coerceIn(0, (screenW-cardW).coerceAtLeast(0))
            val below = top + height + (34*d).toInt()
            val above = top - measuredH - (12*d).toInt()
            cardLp.y = if (below + measuredH <= screenH - (8*d).toInt()) below else above.coerceAtLeast((8*d).toInt())
            try { wm.updateViewLayout(card, cardLp) } catch (_: Exception) { }
        }
        val stopLp = reminderStopParams
        val stop = reminderStopView
        if (stopLp != null && stop != null) {
            stopLp.x = (centerX - stopLp.width/2).coerceIn(0, (screenW-stopLp.width).coerceAtLeast(0))
            stopLp.y = if (docked) (top + (2*d).toInt()) else (top - stopLp.height + (3*d).toInt()).coerceAtLeast(0)
            try { wm.updateViewLayout(stop, stopLp) } catch (_: Exception) { }
        }
    }

    /** Read the rendered bubble position so the orbit follows its real on-screen centre, not stale window coordinates. */
    private fun anchorScreenCenter(anchor: WindowManager.LayoutParams): Pair<Float, Float> {
        val main = bubble
        if (main != null && main.width > 0 && main.height > 0) {
            val location = IntArray(2)
            main.getLocationOnScreen(location)
            return Pair(location[0] + main.width / 2f, location[1] + main.height / 2f)
        }
        return Pair(anchor.x + anchor.width / 2f, anchor.y + anchor.height / 2f)
    }

    private fun anchorCenterX(anchor: WindowManager.LayoutParams): Float = anchorScreenCenter(anchor).first
    private fun anchorCenterY(anchor: WindowManager.LayoutParams): Float = anchorScreenCenter(anchor).second

    private fun syncQuickMenuToAnchor(anchor: WindowManager.LayoutParams) {
        val menuLp = quickMenuParams ?: return
        val menu = quickMenu ?: return
        val (screenW, screenH) = realScreenSize()
        val x = (anchorCenterX(anchor).toInt() - menuLp.width / 2).coerceIn(-(menuLp.width / 2), screenW - (menuLp.width / 2))
        val y = (anchorCenterY(anchor).toInt() - menuLp.height / 2).coerceIn(-(menuLp.height / 2), screenH - (menuLp.height / 2))
        if (menuLp.x != x || menuLp.y != y) {
            menuLp.x = x; menuLp.y = y
            try { windowManager.updateViewLayout(menu, menuLp) } catch (_: Exception) { }
        }
    }

    private fun showQuickMenu(anchor: WindowManager.LayoutParams) {
        if (quickMenu != null) { hideQuickMenu(); return }
        val d = resources.displayMetrics.density
        val item = (52 * d).toInt()
        val radius = (94 * d).toInt()
        val size = (radius * 2 + item + 12*d).toInt()
        val menu = FrameLayout(this).apply {
            elevation = 24*d
            isClickable = true
            // Empty space inside the orbit is outside the side bubbles: close the group.
            setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                    hideQuickMenu()
                    true
                } else true
            }
        }
        // A continuous orbit guide sits behind the action bubbles. The screen edge clips
        // the off-screen half naturally, instead of hiding individual bubbles in code.
        val orbitTrack = object : View(this) {
            private val trackPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(105, 23, 107, 91)
                style = android.graphics.Paint.Style.STROKE
                strokeWidth = (2.2f * d).coerceAtLeast(1f)
            }
            override fun onDraw(canvas: android.graphics.Canvas) {
                super.onDraw(canvas)
                canvas.drawCircle(width / 2f, height / 2f, radius.toFloat(), trackPaint)
            }
        }
        menu.addView(orbitTrack, FrameLayout.LayoutParams(size, size))
        data class BubbleAction(val icon: String, val label: String, val command: String, val color: Int)
        val actions = listOf(
            BubbleAction("💬", "المساعد", "ask", Color.rgb(23,107,91)),
            BubbleAction("📋", "الخطة", "plan", Color.rgb(43,112,190)),
            BubbleAction("📊", "التحليل", "behavior", Color.rgb(117,76,175)),
            BubbleAction("⚙", "الإعدادات", "settings", Color.rgb(82,98,105)),
            BubbleAction("👨‍👩‍👧", "الأسرة", "family", Color.rgb(190,117,47)),
            BubbleAction("🕌", "الصلاة", "prayer", Color.rgb(16,130,100)),
            BubbleAction("✓", "العادات", "habits", Color.rgb(40,130,145)),
            BubbleAction("🔊", "صوت المساعد", "voice", Color.rgb(32,128,145)),
            BubbleAction("👁", "راحة العين", "eye", Color.rgb(55,125,119)),
            BubbleAction("✕", "إغلاق", "close", Color.rgb(190,55,55))
        )
        val buttons = mutableListOf<TextView>()
        actions.forEach { a ->
            val b = TextView(this).apply {
                text = a.icon; textSize = 21f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                contentDescription = a.label
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(a.color); setStroke((2*d).toInt(), Color.WHITE)
                }
                elevation = 8*d
                setOnClickListener {
                    hideQuickMenu()
                    if (a.command == "close") { prefs().edit().putBoolean("overlayEnabled", false).apply(); stopSelf() }
                    else showAssistantOverlay(a.command)
                }
            }
            buttons.add(b); menu.addView(b, FrameLayout.LayoutParams(item,item))
        }
        fun placeButtons(rotation: Double) {
            val centerX = size/2.0
            val centerY = size/2.0
            // All bubbles remain in the orbit. The overlay window itself is positioned
            // around the true main-bubble centre and is clipped by the physical screen edge.
            // This avoids abrupt visibility toggles and makes rotation visually continuous.
            buttons.forEachIndexed { i,b ->
                val angle = (-Math.PI/2.0) + (2.0*Math.PI * i/buttons.size) + rotation
                val x = (centerX + radius*kotlin.math.cos(angle) - item/2).toInt()
                val y = (centerY + radius*kotlin.math.sin(angle) - item/2).toInt()
                val lp = b.layoutParams as FrameLayout.LayoutParams
                lp.leftMargin=x; lp.topMargin=y; b.layoutParams=lp
                b.visibility = View.VISIBLE
            }
        }
        placeButtons(orbitRotation)
        // Rotate by the actual polar angle around the main bubble, not a dx/dy approximation.
        buttons.forEach { button ->
            var downAngle = 0f
            var downRotation = orbitRotation
            var sideDragged = false
            button.setOnTouchListener { v, ev ->
                val centerX = anchorCenterX(anchor)
                val centerY = anchorCenterY(anchor)
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sideDragged = false
                        downAngle = Math.toDegrees(kotlin.math.atan2((ev.rawY-centerY).toDouble(), (ev.rawX-centerX).toDouble())).toFloat()
                        downRotation = orbitRotation
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val nowAngle = Math.toDegrees(kotlin.math.atan2((ev.rawY-centerY).toDouble(), (ev.rawX-centerX).toDouble())).toFloat()
                        var delta = nowAngle - downAngle
                        if (delta > 180f) delta -= 360f
                        if (delta < -180f) delta += 360f
                        if (kotlin.math.abs(delta) > 5f) sideDragged = true
                        if (sideDragged) { orbitRotation = downRotation + Math.toRadians(delta.toDouble()); placeButtons(orbitRotation) }
                        true
                    }
                    MotionEvent.ACTION_UP -> { if (!sideDragged) v.performClick(); true }
                    MotionEvent.ACTION_CANCEL -> true
                    else -> true
                }
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        // Keep the overlay centre exactly on the main bubble, even when this means
        // a negative window coordinate. FLAG_LAYOUT_NO_LIMITS lets the display clip
        // the off-screen half naturally without shifting the orbit away from its anchor.
        val x = anchorCenterX(anchor).toInt() - size/2
        val y = anchorCenterY(anchor).toInt() - size/2
        val lp = WindowManager.LayoutParams(size,size,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply {
            gravity=Gravity.TOP or Gravity.LEFT; this.x=x; this.y=y
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            windowManager.addView(menu, lp)
            menu.setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_OUTSIDE || event.actionMasked == MotionEvent.ACTION_DOWN) {
                    hideQuickMenu()
                    true
                } else true
            }
            quickMenu = menu
            quickMenuParams = lp
            // Keep the main bubble above the menu window so it remains clickable.
            // Otherwise the transparent center of the menu window intercepts taps.
            bubble?.let { main ->
                val mainLp = params
                if (mainLp != null) {
                    try { windowManager.removeView(main) } catch (_: Exception) {}
                    try { windowManager.addView(main, mainLp) } catch (_: Exception) {}
                }
            }
        } catch (_: Exception) {}
    }

    private fun prefs() = getSharedPreferences("alislah_native", MODE_PRIVATE)

    /** Prefer a natural network Arabic voice; retain an installed offline Arabic voice as a real fallback. */
    private fun configureAssistantVoice() {
        val engine = tts ?: return
        try {
            val voices = engine.voices.orEmpty().filter { it.locale.language.equals("ar", true) }
            val wantedFemale = prefs().getString("assistantVoiceGender", "female") != "male"
            val hints = if (wantedFemale) listOf("female", "woman", "amira", "salma", "hoda", "laila", "sara") else listOf("male", "man", "ahmed", "hamza", "omar")
            fun score(v: android.speech.tts.Voice) = hints.any { v.name.contains(it, true) }
            networkArabicVoice = voices.filter { it.isNetworkConnectionRequired }
                .sortedWith(compareByDescending<android.speech.tts.Voice> { score(it) }.thenByDescending { it.quality }).firstOrNull()
            localArabicVoice = voices.filter { !it.isNetworkConnectionRequired }
                .sortedWith(compareByDescending<android.speech.tts.Voice> { score(it) }.thenByDescending { it.quality }).firstOrNull()
            // Network voice first for natural speech; if unavailable, use local Arabic immediately.
            val preferred = networkArabicVoice ?: localArabicVoice
            if (preferred != null) engine.voice = preferred else engine.language = Locale("ar")
            engine.setPitch(1.0f)
            engine.setSpeechRate(0.96f)
        } catch (_: Exception) {
            try { engine.language = Locale("ar"); engine.setPitch(1.0f) } catch (_: Exception) { }
        }
    }

    private fun speak(text: String) {
        val clean = text.trim().take(700)
        if (clean.isBlank()) return
        pendingFallbackText = clean
        fallbackAttempted = false
        if (!ttsReady) return
        configureAssistantVoice()
        val quranLike = clean.contains("﴿") || clean.contains("﴾") || clean.contains("سورة ") ||
            (clean.count { it in "ًٌٍَُِّْٰ" } >= 5 && clean.length >= 24)
        val speechText = if (quranLike) clean.replace("﴿", "، ").replace("﴾", "، ").replace("ۖ", "، ").replace("ۗ", "، ") else clean
        // The selected engine controls assistant speech and displayed Quran verses alike.
        // Gender selection applies only to the legacy Android TTS engine.
        val neuralEligible = prefs().getString("assistantVoiceEngine", "old") == "neural"
        val web = assistantWebView
        if (neuralEligible && web != null && overlayPageReady) {
            try {
                setAssistantSpeaking(true)
                web.evaluateJavascript("(function(){if(window.AlishlahNeuralVoice){window.AlishlahNeuralVoice.speak(" + org.json.JSONObject.quote(speechText) + ");return true;}return false;})()") { result ->
                    if (result != "true") handler.post { setAssistantSpeaking(false); speakWithAndroidTts(speechText, quranLike) }
                }
                return
            } catch (_: Exception) { setAssistantSpeaking(false) }
        }
        speakWithAndroidTts(speechText, quranLike)
    }

    private fun applyAssistantAudioAttributes() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val unified = prefs().getString("audioControlMode", "current") == "unified"
            val attrs = AudioAttributes.Builder()
                .setUsage(if (unified) AudioAttributes.USAGE_MEDIA else AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            try { tts?.setAudioAttributes(attrs) } catch (_: Exception) { }
        }
    }

    private fun speakWithAndroidTts(speechText: String, quranLike: Boolean) {
        try {
            applyAssistantAudioAttributes()
            tts?.setSpeechRate(if (quranLike) 0.78f else 0.96f)
            tts?.speak(speechText, TextToSpeech.QUEUE_FLUSH, null, "alislah_voice")
        } catch (_: Exception) { retryWithLocalArabicVoice() }
    }

    /** A failed/missing online voice never silences the assistant: retry once with offline Arabic TTS. */
    private fun retryWithLocalArabicVoice() {
        if (fallbackAttempted) return
        val text = pendingFallbackText
        val local = localArabicVoice
        if (text.isBlank() || local == null) return
        fallbackAttempted = true
        try {
            applyAssistantAudioAttributes()
            tts?.voice = local
            tts?.setPitch(1.0f)
            val quranLike = text.contains("﴿") || text.contains("﴾") || text.contains("سورة ") ||
                (text.count { it in "ًٌٍَُِّْٰ" } >= 5 && text.length >= 24)
            tts?.setSpeechRate(if (quranLike) 0.78f else 0.96f)
            val speechText = if (quranLike) text.replace("﴿", "، ").replace("﴾", "، ").replace("ۖ", "، ").replace("ۗ", "، ") else text
            tts?.speak(speechText, TextToSpeech.QUEUE_FLUSH, null, "alislah_voice_local_fallback")
        } catch (_: Exception) { }
    }

    private fun speakLatestReply() {
        val web = assistantWebView ?: return
        web.evaluateJavascript("(function(){var x=document.querySelector('#messages .bubble.assistant:last-child');return x?(x.innerText||x.textContent||''):''})()") { raw ->
            val value = try { org.json.JSONTokener(raw ?: "").nextValue() as? String ?: "" } catch (_: Exception) { "" }
            if (value.isNotBlank() && value != lastSpokenReply && !value.contains("أحاول الاتصال")) {
                lastSpokenReply = value
                if (prefs().getString("voiceMode", "both") != "text") { autoListenAfterSpeech = true; speak(value) }
            }
        }
    }

    private fun showCloseButton(anchor: WindowManager.LayoutParams) {
        if (closeButton != null) return
        val size = (38 * resources.displayMetrics.density).toInt()
        val xButton = TextView(this).apply {
            text = "×"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(180, 35, 24))
                setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
            }
            contentDescription = "إغلاق الفقاعة العائمة"
            setOnClickListener {
                getSharedPreferences("alislah_native", MODE_PRIVATE).edit().putBoolean("overlayEnabled", false).apply()
                handler.removeCallbacks(reshowBubble)
                stopSelf()
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val cp = WindowManager.LayoutParams(size, size, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (anchor.x + 42 * resources.displayMetrics.density).toInt()
            y = (anchor.y - 12 * resources.displayMetrics.density).toInt().coerceAtLeast(0)
        }
        try { windowManager.addView(xButton, cp); closeButton = xButton; closeParams = cp } catch (_: Exception) {}
    }

    private fun hideCloseButton() {
        closeButton?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        closeButton = null
        closeParams = null
    }

    /** Keeps the existing green bubble design while orienting its half-capsule to the selected display edge. */
    private inner class MainBubbleView(context: android.content.Context) : View(context) {
        // "circle" = half-clipped circle; top/bottom/left/right = edge-attached half-capsule.
        var capsuleEdge: String = "top"
        val dockedAtCamera: Boolean get() = capsuleEdge != "circle"
        private val fill = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(23, 107, 91)
            style = android.graphics.Paint.Style.FILL
        }
        private val stroke = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(75, 205, 165)
            style = android.graphics.Paint.Style.STROKE
            strokeWidth = (1.5f * resources.displayMetrics.density).coerceAtLeast(1f)
        }
        private val markPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = android.graphics.Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        private val wavePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            strokeWidth = (3.2f * resources.displayMetrics.density).coerceAtLeast(2f)
            strokeCap = android.graphics.Paint.Cap.ROUND
        }
        @Volatile private var speaking = false
        fun setSpeaking(active: Boolean) { speaking = active; postInvalidate() }
        override fun onDraw(canvas: android.graphics.Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            val d = resources.displayMetrics.density
            if (capsuleEdge == "circle") {
                val r = minOf(w, h) / 2f - stroke.strokeWidth
                canvas.drawCircle(w / 2f, h / 2f, r, fill)
                canvas.drawCircle(w / 2f, h / 2f, r, stroke)
                markPaint.textSize = 25f * d
            } else {
                val radius = minOf(w, h) / 2f
                val path = android.graphics.Path().apply {
                    when (capsuleEdge) {
                        "bottom" -> {
                            moveTo(radius, 0f); quadTo(0f, 0f, 0f, radius)
                            lineTo(0f, h); lineTo(w, h); lineTo(w, radius)
                            quadTo(w, 0f, w-radius, 0f); close()
                        }
                        "left" -> {
                            moveTo(0f, 0f); lineTo(w-radius, 0f)
                            quadTo(w, 0f, w, radius); lineTo(w, h-radius)
                            quadTo(w, h, w-radius, h); lineTo(0f, h); close()
                        }
                        "right" -> {
                            moveTo(radius, 0f); quadTo(0f, 0f, 0f, radius)
                            lineTo(0f, h-radius); quadTo(0f, h, radius, h)
                            lineTo(w, h); lineTo(w, 0f); close()
                        }
                        else -> { // top: straight edge is attached to the top of the display.
                            moveTo(0f, 0f); lineTo(w, 0f); lineTo(w, h-radius)
                            quadTo(w, h, w-radius, h); lineTo(radius, h)
                            quadTo(0f, h, 0f, h-radius); close()
                        }
                    }
                }
                canvas.drawPath(path, fill)
                canvas.drawPath(path, stroke)
                markPaint.textSize = 16f * d
            }
            if (speaking) {
                val centerX = w / 2f
                val centerY = h / 2f
                val count = 5
                val spacing = 7f * d
                val phase = android.os.SystemClock.uptimeMillis() / 115.0
                for (i in 0 until count) {
                    val wave = kotlin.math.abs(kotlin.math.sin(phase + i * 0.82))
                    val barHeight = (5f + wave.toFloat() * 13f) * d
                    val x = centerX + (i - (count - 1) / 2f) * spacing
                    canvas.drawLine(x, centerY - barHeight / 2f, x, centerY + barHeight / 2f, wavePaint)
                }
                postInvalidateDelayed(55L)
            } else {
                canvas.drawText("✦", w / 2f, h / 2f - (markPaint.ascent() + markPaint.descent()) / 2f, markPaint)
            }
        }
    }

    private data class NavigationBarGeometry(val edge: String, val inset: Int)

    /** Resolve the real navigation-bar edge; Android can move it to a landscape side on some devices. */
    private fun navigationBarGeometry(screenW: Int, screenH: Int): NavigationBarGeometry {
        fun dimension(name: String): Int {
            val id = resources.getIdentifier(name, "dimen", "android")
            return if (id == 0) 0 else try { resources.getDimensionPixelSize(id) } catch (_: Exception) { 0 }
        }
        fun systemBoolean(name: String): Boolean? {
            val id = resources.getIdentifier(name, "bool", "android")
            return if (id == 0) null else try { resources.getBoolean(id) } catch (_: Exception) { null }
        }
        val maxInset = (96 * resources.displayMetrics.density).toInt().coerceAtLeast(1)
        if (screenW <= screenH) {
            val inset = (dimension("navigation_bar_height").takeIf { it > 0 }
                ?: dimension("navigation_bar_height_landscape").takeIf { it > 0 }
                ?: (24 * resources.displayMetrics.density).toInt()).coerceIn(0, maxInset)
            return NavigationBarGeometry("bottom", inset)
        }
        val rotation = try { windowManager.defaultDisplay.rotation } catch (_: Exception) { Surface.ROTATION_90 }
        val canMove = systemBoolean("config_navBarCanMove") ?: false
        // On some OEM builds config_navBarCanMove is missing or reports the wrong value.
        // Compare real display size with app-usable size to detect a side navigation strip.
        val sideDifference = try {
            val real = DisplayMetrics(); val usable = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(real)
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getMetrics(usable)
            (real.widthPixels - usable.widthPixels).coerceAtLeast(0)
        } catch (_: Exception) { 0 }
        val heightDifference = try {
            val real = DisplayMetrics(); val usable = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(real)
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getMetrics(usable)
            (real.heightPixels - usable.heightPixels).coerceAtLeast(0)
        } catch (_: Exception) { 0 }
        val sideBarDetected = sideDifference >= (18 * resources.displayMetrics.density).toInt() &&
            sideDifference > heightDifference
        if ((canMove || sideBarDetected) && (rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270)) {
            val width = (sideDifference.takeIf { sideBarDetected && it > 0 }
                ?: dimension("navigation_bar_width").takeIf { it > 0 }
                ?: (24 * resources.displayMetrics.density).toInt()).coerceIn(0, maxInset)
            if (width > 0) {
                val edge = if (rotation == Surface.ROTATION_270) "left" else "right"
                return NavigationBarGeometry(edge, width)
            }
        }
        val landscapeHeight = dimension("navigation_bar_height_landscape").takeIf { it > 0 }
            ?: dimension("navigation_bar_height").takeIf { it > 0 }
            ?: (24 * resources.displayMetrics.density).toInt()
        return NavigationBarGeometry("bottom", landscapeHeight.coerceIn(0, maxInset))
    }

    /** Dock the main bubble to an edge, centring a half-circle on the system navigation-bar boundary. */
    private fun dockMainBubble(view: MainBubbleView, lp: WindowManager.LayoutParams, edge: String,
                               screenW: Int, screenH: Int, anchorX: Int, anchorY: Int) {
        val d = resources.displayMetrics.density
        val landscape = screenW > screenH
        val circle = (58 * d).toInt()
        val thickness = (52 * d).toInt()
        val capsuleLength = (90 * d).toInt()
        val navigation = navigationBarGeometry(screenW, screenH)
        val cutoutWidth = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try { windowManager.defaultDisplay.cutout?.boundingRects?.filter { it.width() > 0 && it.height() > 0 }?.maxByOrNull { it.width() * it.height() }?.width() ?: 0 } catch (_: Exception) { 0 }
        } else 0
        when (edge) {
            "top" -> {
                view.capsuleEdge = "top"
                lp.width = if (!landscape) (cutoutWidth + (24*d).toInt()).coerceIn((42*d).toInt(), (78*d).toInt()) + (30*d).toInt() else capsuleLength
                lp.height = thickness
                val center = if (!landscape) cameraCenterX(screenW) else anchorX
                lp.x = (center - lp.width/2).coerceIn(0, (screenW-lp.width).coerceAtLeast(0)); lp.y = 0
            }
            "left", "right" -> {
                if (landscape && navigation.edge == edge) {
                    // System navigation buttons occupy this side: align the bubble centre with
                    // the app/navigation boundary so exactly the exposed half remains tappable.
                    view.capsuleEdge = "circle"
                    lp.width = circle; lp.height = circle
                    val boundary = if (edge == "left") navigation.inset else screenW - navigation.inset
                    lp.x = boundary - circle/2
                    lp.y = (anchorY-circle/2).coerceIn(0, (screenH-circle).coerceAtLeast(0))
                } else if (landscape) {
                    view.capsuleEdge = edge
                    lp.width = thickness; lp.height = capsuleLength
                    lp.x = if (edge == "left") 0 else screenW - thickness
                    lp.y = (anchorY - capsuleLength/2).coerceIn(0, (screenH-capsuleLength).coerceAtLeast(0))
                } else {
                    view.capsuleEdge = "circle"
                    lp.width = circle; lp.height = circle
                    lp.x = if (edge == "left") -(circle/2) else screenW - circle/2
                    lp.y = (anchorY-circle/2).coerceIn(0, (screenH-circle).coerceAtLeast(0))
                }
            }
            else -> {
                view.capsuleEdge = "circle"
                lp.width = circle; lp.height = circle
                lp.x = (anchorX-circle/2).coerceIn(-(circle/2), (screenW-circle/2))
                val boundary = if (navigation.edge == "bottom") screenH - navigation.inset else screenH
                lp.y = boundary - circle/2
            }
        }
        view.requestLayout()
    }

    /** Height occupied by a bottom navigation bar; side bars are handled by navigationBarGeometry(). */
    private fun navigationBarBottomInset(screenW: Int, screenH: Int): Int {
        val navigation = navigationBarGeometry(screenW, screenH)
        return if (navigation.edge == "bottom") navigation.inset else 0
    }

    private fun edgeDistances(centerX: Float, centerY: Float, screenW: Int, screenH: Int): List<Pair<String, Float>> {
        val navigation = navigationBarGeometry(screenW, screenH)
        val leftBoundary = if (navigation.edge == "left") navigation.inset else 0
        val rightBoundary = if (navigation.edge == "right") screenW - navigation.inset else screenW
        val bottomBoundary = if (navigation.edge == "bottom") screenH - navigation.inset else screenH
        return listOf(
            "left" to kotlin.math.abs(centerX - leftBoundary),
            "right" to kotlin.math.abs(rightBoundary - centerX),
            "top" to kotlin.math.abs(centerY),
            "bottom" to kotlin.math.abs(bottomBoundary - centerY)
        )
    }

    private fun startVoiceTaskFromBubble() {
        hideQuickMenu()
        val launch = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("dz.alislah.app.extra.START_VOICE_TASK", true)
        }
        try { startActivity(launch) } catch (_: Exception) { mainLongPressTriggered = false }
    }

    private fun stopVoiceTaskFromBubble() {
        val stop = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("dz.alislah.app.extra.STOP_VOICE_TASK", true)
        }
        try { startActivity(stop) } catch (_: Exception) { }
    }

    /** Physical display bounds, not app-content bounds: status/navigation bars must not shift the camera anchor. */
    private fun realScreenSize(): Pair<Int, Int> {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        return Pair(metrics.widthPixels, metrics.heightPixels)
    }

    private fun cameraCenterX(screenWidth: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                // DisplayCutout coordinates are physical-display coordinates. Pair them with getRealMetrics().
                @Suppress("DEPRECATION")
                val cutout = windowManager.defaultDisplay.cutout
                val rect = cutout?.boundingRects
                    ?.filter { it.width() > 0 && it.height() > 0 }
                    ?.maxByOrNull { it.width() * it.height() }
                if (rect != null) return rect.centerX().coerceIn(0, screenWidth)
            } catch (_: Exception) { }
        }
        // Android 8.0/8.1 and devices without cutout metadata: use the physical screen centre.
        return screenWidth / 2
    }

    /** Resolve which landscape side contains the physical camera/display cutout. */
    private fun landscapeCameraEdge(screenW: Int, screenH: Int): String {
        if (screenW <= screenH || Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return "left"
        return try {
            @Suppress("DEPRECATION")
            val rect = windowManager.defaultDisplay.cutout?.boundingRects
                ?.filter { it.width() > 0 && it.height() > 0 }
                ?.maxByOrNull { it.width() * it.height() }
            if (rect == null) "left" else if (rect.centerX() < screenW / 2) "left" else "right"
        } catch (_: Exception) { "left" }
    }

    private fun rememberBubbleAnchor(orientation: Int, lp: WindowManager.LayoutParams, screenW: Int, screenH: Int) {
        if (screenW <= 0 || screenH <= 0) return
        val x = ((lp.x + lp.width / 2f) / screenW).coerceIn(0f, 1f)
        val y = ((lp.y + lp.height / 2f) / screenH).coerceIn(0f, 1f)
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            landscapeAnchorXRatio = x; landscapeAnchorYRatio = y
        } else if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            portraitAnchorXRatio = x; portraitAnchorYRatio = y
        }
    }

    private fun showBubble() {
        if (bubble != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        // Use the full physical display so the status bar cannot offset the cutout anchor.
        val (screenW, screenH) = realScreenSize()
        lastBubbleScreenWidth = screenW
        lastBubbleScreenHeight = screenH
        lastConfigOrientation = if (screenW > screenH) Configuration.ORIENTATION_LANDSCAPE else Configuration.ORIENTATION_PORTRAIT
        lastDisplayRotation = try { windowManager.defaultDisplay.rotation } catch (_: Exception) { Surface.ROTATION_0 }
        val circleSize = (58 * d).toInt()
        val cameraX = cameraCenterX(screenW)
        val cutoutWidth = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try { windowManager.defaultDisplay.cutout?.boundingRects?.maxByOrNull { it.width() * it.height() }?.width() ?: 0 } catch (_: Exception) { 0 }
        } else 0
        val opening = (cutoutWidth + (24 * d).toInt()).coerceIn((42*d).toInt(), (78*d).toInt())
        val dockWidth = opening + (30 * d).toInt()
        val dockHeight = (52 * d).toInt()
        val view = MainBubbleView(this).apply {
            capsuleEdge = "top"
            contentDescription = "فقاعة ALISLAH؛ أثناء تحدث المساعد اضغط لإيقاف الصوت، والضغط المطوّل للاستماع"
            elevation = 18 * d
            setSpeaking(assistantSpeaking)
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(dockWidth, dockHeight, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = (cameraX - dockWidth / 2).coerceIn(0, (screenW - dockWidth).coerceAtLeast(0))
            y = 0
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        // If the service starts while already in landscape, dock to the actual camera side,
        // not the top edge. The opposite side remains available as the same capsule shape.
        if (screenW > screenH) {
            val cameraSide = landscapeCameraEdge(screenW, screenH)
            dockMainBubble(view, lp, cameraSide, screenW, screenH,
                if (cameraSide == "left") 0 else screenW, screenH / 2)
        }
        rememberBubbleAnchor(lastConfigOrientation, lp, screenW, screenH)
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (assistantSpeaking) {
                        speakingTapConsumed = true
                        pendingMainTap?.let { handler.removeCallbacks(it) }
                        pendingMainTap = null
                        lastTapAt = 0L
                        stopAssistantSpeech()
                        return@setOnTouchListener true
                    }
                    speakingTapConsumed = false
                    dragged = false; mainLongPressTriggered = false
                    downAt = System.currentTimeMillis(); startX = lp.x; startY = lp.y; touchX = event.rawX; touchY = event.rawY
                    mainLongPressRunnable?.let { handler.removeCallbacks(it) }
                    val longPress = Runnable {
                        if (!dragged && bubble === v) {
                            mainLongPressTriggered = true
                            pendingMainTap?.let { handler.removeCallbacks(it) }
                            pendingMainTap = null
                            lastTapAt = 0L
                            startVoiceTaskFromBubble()
                        }
                    }
                    mainLongPressRunnable = longPress
                    handler.postDelayed(longPress, 650L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt(); val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) {
                        if (!dragged) mainLongPressRunnable?.let { handler.removeCallbacks(it) }
                        dragged = true
                        if (mainLongPressTriggered) {
                            stopVoiceTaskFromBubble()
                            mainLongPressTriggered = false
                        }
                    }
                    if (dragged) {
                        pendingMainTap?.let { handler.removeCallbacks(it) }
                        pendingMainTap = null
                        lastTapAt = 0L
                        val (currentW, currentH) = realScreenSize()
                        lp.x = (startX + dx).coerceIn(-(lp.width / 2), currentW - (lp.width / 2))
                        val bottomInset = navigationBarBottomInset(currentW, currentH)
                        lp.y = (startY + dy).coerceIn(0, (currentH-bottomInset-lp.height).coerceAtLeast(0))
                        try { windowManager.updateViewLayout(v, lp) } catch (_: Exception) {}
                        v.post { if (quickMenu != null) syncQuickMenuToAnchor(lp); syncReminderOverlay(lp); syncAdhanMuteBubble(); syncAssistantStopBubble() }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (speakingTapConsumed) { speakingTapConsumed = false; return@setOnTouchListener true }
                    mainLongPressRunnable?.let { handler.removeCallbacks(it) }
                    mainLongPressRunnable = null
                    if (mainLongPressTriggered) {
                        stopVoiceTaskFromBubble()
                        mainLongPressTriggered = false
                        dragged = false
                        lastTapAt = 0L
                        return@setOnTouchListener true
                    }
                    if (dragged) {
                        val (currentW, currentH) = realScreenSize()
                        val density = resources.displayMetrics.density
                        val centerX = lp.x + lp.width / 2
                        val centerY = lp.y + lp.height / 2
                        val distances = edgeDistances(centerX.toFloat(), centerY.toFloat(), currentW, currentH)
                        val edge = distances.minByOrNull { it.second }?.first ?: "left"
                        dockMainBubble(view, lp, edge, currentW, currentH, centerX, centerY)
                        rememberBubbleAnchor(if (currentW > currentH) Configuration.ORIENTATION_LANDSCAPE else Configuration.ORIENTATION_PORTRAIT, lp, currentW, currentH)
                        try { windowManager.updateViewLayout(v, lp) } catch (_: Exception) {}
                        v.post { if (quickMenu != null) syncQuickMenuToAnchor(lp); syncReminderOverlay(lp); syncAdhanMuteBubble(); syncAssistantStopBubble() }
                    } else if (assistantSpeaking) {
                        pendingMainTap?.let { handler.removeCallbacks(it) }
                        pendingMainTap = null
                        lastTapAt = 0L
                        stopAssistantSpeech()
                    } else {
                        val now = System.currentTimeMillis()
                        val doubleTapWindow = 320L
                        if (lastTapAt != 0L && now - lastTapAt <= doubleTapWindow) {
                            pendingMainTap?.let { handler.removeCallbacks(it) }
                            pendingMainTap = null
                            lastTapAt = 0L
                            hideQuickMenu()
                            openMainApp()
                        } else {
                            lastTapAt = now
                            val singleTap = Runnable {
                                if (lastTapAt == now) {
                                    if (quickMenu != null) hideQuickMenu() else showQuickMenu(lp)
                                    lastTapAt = 0L
                                }
                                pendingMainTap = null
                            }
                            pendingMainTap?.let { handler.removeCallbacks(it) }
                            pendingMainTap = singleTap
                            handler.postDelayed(singleTap, doubleTapWindow)
                        }
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (speakingTapConsumed) { speakingTapConsumed = false; return@setOnTouchListener true }
                    mainLongPressRunnable?.let { handler.removeCallbacks(it) }
                    mainLongPressRunnable = null
                    if (mainLongPressTriggered) stopVoiceTaskFromBubble()
                    mainLongPressTriggered = false
                    false
                }
                else -> false
            }
        }
        try {
            windowManager.addView(view, lp); bubble = view; params = lp
            if (adhanPlaying) showAdhanMuteBubble()
            if (assistantSpeaking && !reminderSpeechActive) showAssistantStopBubble()
            if (reminderCardVisible) { ensureReminderViews(); syncReminderOverlay(lp) }
        } catch (_: Exception) { stopSelf() }
    }

    private fun stopAdhanFromBubble() {
        adhanPlaying = false
        prefs().edit().putBoolean("adhanPlaying", false).apply()
        bubble?.invalidate()
        hideAdhanMuteBubble()
        try { startService(Intent(this, PrayerVoiceService::class.java).apply { action = PrayerVoiceService.ACTION_STOP }) } catch (_: Exception) { }
    }

    private fun openMainApp() {
        val launch = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        try { startActivity(launch) } catch (_: Exception) { }
    }

    private fun runOverlayJs(script: String) {
        val web = assistantWebView ?: return
        if (overlayPageReady) web.evaluateJavascript(script, null) else pendingOverlayScripts.addLast(script)
    }

    inner class OverlayNativeBridge {
        @JavascriptInterface fun getAppDataJson(): String = prefs().getString("alislah_app_data", "{}") ?: "{}"
        @JavascriptInterface fun saveAppDataJson(json: String) { if (json.length <= 2_000_000) prefs().edit().putString("alislah_app_data", json).apply() }
        @JavascriptInterface fun getEyeBreakContentCache(): String = prefs().getString("eyeBreakContentCache", "{}") ?: "{}"
        @JavascriptInterface fun saveEyeBreakContentCache(json: String) { if (json.length <= 1_000_000) prefs().edit().putString("eyeBreakContentCache", json).apply() }
        @JavascriptInterface fun getUsageStatsJson(): String = readOverlayUsageJson()
        @JavascriptInterface fun isBubbleOverlay(): Boolean = true
        @JavascriptInterface fun getAudioControlMode(): String = prefs().getString("audioControlMode", "current") ?: "current"
        @JavascriptInterface fun setAudioControlMode(mode: String) { prefs().edit().putString("audioControlMode", if (mode == "unified") "unified" else "current").apply(); handler.post { applyAssistantAudioAttributes() } }
        @JavascriptInterface fun setAssistantVoice(gender: String) { prefs().edit().putString("assistantVoiceGender", if (gender == "male") "male" else "female").apply(); handler.post { configureAssistantVoice() } }
        @JavascriptInterface fun setAssistantVoiceEngine(engine: String) { prefs().edit().putString("assistantVoiceEngine", if (engine == "old") "old" else "neural").apply() }
        @JavascriptInterface fun isMixerTtsInstalled(): Boolean = OptionalVoicePackBridge.isInstalled(this@FloatingBubbleService)
        @JavascriptInterface fun speakMixerTts(text: String) {
            handler.post {
                val clean = text.trim().take(700)
                if (clean.isBlank()) return@post
                val quranLike = clean.contains("﴿") || clean.contains("﴾") || clean.contains("سورة ") ||
                    (clean.count { it in "ًٌٍَُِّْٰ" } >= 5 && clean.length >= 24)
                val sentToPack = OptionalVoicePackBridge.speak(this@FloatingBubbleService, clean)
                val status = if (sentToPack) "تم إرسال النص إلى حزمة الصوت العصبي الاختيارية" else "حزمة الصوت العصبي غير مثبتة؛ سيُستخدم الصوت القديم"
                runOverlayJs("window.dispatchEvent(new CustomEvent('alislah:neural-voice',{detail:{ok:$sentToPack,detail:" + org.json.JSONObject.quote(status) + "}}));")
                if (!sentToPack) {
                    speakWithAndroidTts(clean.replace("﴿", "، ").replace("﴾", "، ").replace("ۖ", "، ").replace("ۗ", "، "), quranLike)
                }
            }
        }
        @JavascriptInterface fun stopMixerTts() { handler.post { OptionalVoicePackBridge.stop(this@FloatingBubbleService); try { tts?.stop() } catch (_: Exception) { } } }
        @JavascriptInterface fun stopAssistantSpeech() { handler.post { this@FloatingBubbleService.stopAssistantSpeech() } }
        @JavascriptInterface fun onNeuralSpeechResult(success: Boolean, detail: String) {
            if (!success) handler.post {
                val text = pendingFallbackText
                if (text.isNotBlank()) {
                    val quranLike = text.contains("﴿") || text.contains("﴾") || text.contains("سورة ") ||
                        (text.count { it in "ًٌٍَُِّْٰ" } >= 5 && text.length >= 24)
                    speakWithAndroidTts(if (quranLike) text.replace("﴿", "، ").replace("﴾", "، ").replace("ۖ", "، ").replace("ۗ", "، ") else text, quranLike)
                }
            }
        }
        @JavascriptInterface fun setAssistantVoiceMode(mode: String) { prefs().edit().putString("voiceMode", if (mode == "text" || mode == "voice" || mode == "both") mode else "both").apply() }
        @JavascriptInterface fun testAssistantVoice() { handler.post { speak("مرحبًا بك في الإصلاح. صوت المساعد يعمل الآن.") } }
        @JavascriptInterface fun playAdhanTest() { PrayerScheduler.playAdhan(this@FloatingBubbleService, "اختبار") }
        @JavascriptInterface fun stopAdhan() { handler.post { stopAdhanFromBubble() } }
        @JavascriptInterface fun syncPrayerPlan(itemsJson: String, enabled: Boolean) { PrayerScheduler.sync(this@FloatingBubbleService, itemsJson.take(700000), enabled) }
        @JavascriptInterface fun enableBackgroundQuestions(enabled: Boolean) {
            prefs().edit().putBoolean("backgroundQuestionsEnabled", enabled).putBoolean("backgroundQuestionsConfigured", true).apply()
            if (enabled) BackgroundScheduler.scheduleQuestion(this@FloatingBubbleService, System.currentTimeMillis()+4*60*60*1000L) else BackgroundScheduler.cancelQuestion(this@FloatingBubbleService)
        }
        @JavascriptInterface fun getNativeStatus(): String {
            val notifications = getSystemService(NotificationManager::class.java).areNotificationsEnabled()
            val overlay = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this@FloatingBubbleService)
            val power = getSystemService(android.os.PowerManager::class.java)
            return org.json.JSONObject().put("native", true).put("version", try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (_: Exception) { "" })
                .put("notifications", notifications).put("microphone", checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                .put("overlayEnabled", prefs().getBoolean("overlayEnabled", false)).put("overlayPermission", overlay)
                .put("usage", try { val ops = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager; ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == android.app.AppOpsManager.MODE_ALLOWED } catch (_: Exception) { false })
                .put("battery", power.isIgnoringBatteryOptimizations(packageName)).put("questions", prefs().getBoolean("backgroundQuestionsEnabled", false)).toString()
        }
        @JavascriptInterface fun requestNotificationPermission() { launchMainAppWithAction("requestNotifications") }
        @JavascriptInterface fun openBatterySettings() { handler.post { try { startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { launchMainApp() } } }
        @JavascriptInterface fun openAppSettings() { handler.post { try { startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { launchMainApp() } } }
        @JavascriptInterface fun requestUsagePermission() { handler.post { try { startActivity(Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS).apply { data = android.net.Uri.parse("package:$packageName"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }) } catch (_: Exception) { launchMainApp() } } }
        @JavascriptInterface fun configureEyeBreak(enabled: Boolean, minutes: Int, seconds: Int) {
            prefs().edit().putBoolean("eyeBreakServiceEnabled", enabled).putInt("eyeBreakMinutes", minutes.coerceIn(1,180)).putInt("eyeBreakSeconds", seconds.coerceIn(5,120)).apply()
            handler.post {
                if (!enabled) stopService(Intent(this@FloatingBubbleService, EyeBreakService::class.java))
                else if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this@FloatingBubbleService)) {
                    val i = Intent(this@FloatingBubbleService, EyeBreakService::class.java).putExtra("minutes", minutes).putExtra("seconds", seconds)
                    try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } catch (_: Exception) { launchMainApp() }
                } else launchMainApp()
            }
        }
        @JavascriptInterface fun enableEyeFilter() {
            prefs().edit().putBoolean("eyeFilterEnabled", true).apply()
            handler.post {
                if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this@FloatingBubbleService)) {
                    try { val i = Intent(this@FloatingBubbleService, EyeFilterService::class.java); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } catch (_: Exception) { launchMainApp() }
                } else launchMainApp()
            }
        }
        @JavascriptInterface fun disableEyeFilter() { prefs().edit().putBoolean("eyeFilterEnabled", false).apply(); handler.post { stopService(Intent(this@FloatingBubbleService, EyeFilterService::class.java)) } }
        @JavascriptInterface fun scheduleTaskReminder(id: String, title: String, atMillis: Long) { if (id.isNotBlank()) ReminderStore.schedule(this@FloatingBubbleService, id.take(120), title.take(180), atMillis) }
        @JavascriptInterface fun cancelTaskReminder(id: String) { if (id.isNotBlank()) ReminderStore.cancel(this@FloatingBubbleService, id.take(120)) }
        @JavascriptInterface fun assistantAnswered() {
            handler.post { handler.removeCallbacks(reshowBubble); hideBubble() }
        }
        @JavascriptInterface fun showBubbleForEvent() { handler.post { showFollowupOverlay() } }
        @JavascriptInterface fun isSpeechAvailable(): Boolean = android.speech.SpeechRecognizer.isRecognitionAvailable(this@FloatingBubbleService)
        @JavascriptInterface fun startAssistantListening() { handler.post { startAssistantListening() } }
        @JavascriptInterface fun stopAssistantListening() { handler.post { stopAssistantListening() } }
        @JavascriptInterface fun startListening() { launchMainAppWithAction("startListening") }
        @JavascriptInterface fun stopListening() { launchMainAppWithAction("stopListening") }
        @JavascriptInterface fun requestRuntimePermissions() { launchMainAppWithAction("requestRuntimePermissions") }
        @JavascriptInterface fun enableOverlay() { prefs().edit().putBoolean("overlayEnabled", true).apply(); handler.post { showBubble() } }
        @JavascriptInterface fun disableOverlay() { prefs().edit().putBoolean("overlayEnabled", false).apply(); stopSelf() }
        @JavascriptInterface fun saveBackup(filename: String, json: String) {
            if (json.length > 5_000_000) return
            prefs().edit().putString("overlay_backup_pending", json).putString("overlay_backup_name", filename.take(80)).apply()
            launchMainAppWithAction("saveBackup")
        }
    }

    private fun overlaySpeechStatus(message: String) {
        runOverlayJs("window.__alislahOverlaySpeechStatus && window.__alislahOverlaySpeechStatus(" + org.json.JSONObject.quote(message.take(220)) + ");")
    }

    private fun overlaySpeechPartial(text: String) {
        runOverlayJs("window.__alislahOverlaySpeechPartial && window.__alislahOverlaySpeechPartial(" + org.json.JSONObject.quote(text.take(1200)) + ");")
    }

    private fun startAssistantListening() {
        if (assistantPanel == null || assistantWebView == null) return
        if (!overlayPageReady) {
            handler.postDelayed({ if (assistantPanel != null && !assistantListening) startAssistantListening() }, 250L)
            return
        }
        if (assistantListening) {
            overlaySpeechStatus("🎙️ أستمع إليك الآن…")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            overlaySpeechStatus("اسمح لـ ALISLAH باستخدام الميكروفون لبدء المحادثة الصوتية.")
            launchMainAppWithAction("requestOverlayAssistantMic")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            overlaySpeechStatus("خدمة تحويل الكلام إلى نص غير متوفرة على هذا الجهاز. تحقق من خدمة التعرف الصوتي المثبتة.")
            return
        }
        try {
            stopAssistantRecognizer()
            val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            assistantRecognizer = recognizer
            assistantListening = true
            overlaySpeechStatus("🎙️ أستمع إليك… تحدث الآن")
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    handler.removeCallbacks(assistantNoSpeechTimeout)
                    handler.postDelayed(assistantNoSpeechTimeout, 3000L)
                    overlaySpeechStatus("🎙️ أنا أستمع إليك…")
                }
                override fun onBeginningOfSpeech() { handler.removeCallbacks(assistantNoSpeechTimeout); overlaySpeechStatus("🎙️ أستمع إلى حديثك…") }
                override fun onRmsChanged(rmsdB: Float) { }
                override fun onBufferReceived(buffer: ByteArray?) { }
                override fun onEndOfSpeech() { overlaySpeechStatus("جارٍ فهم كلامك…") }
                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (partial.isNotBlank()) { handler.removeCallbacks(assistantNoSpeechTimeout); overlaySpeechPartial(partial) }
                }
                override fun onEvent(eventType: Int, params: Bundle?) { }
                override fun onError(error: Int) {
                    handler.removeCallbacks(assistantNoSpeechTimeout)
                    assistantListening = false
                    val message = when (error) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "إذن الميكروفون غير متاح. اسمح به من إعدادات التطبيق."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "تعذر الاتصال بخدمة التعرف على الكلام. تحقق من الإنترنت أو خدمة الصوت المثبتة."
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "لم ألتقط كلامًا واضحًا. اضغط على فقاعة المساعد الجانبية وحاول مجددًا."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "خدمة التعرف الصوتي مشغولة. حاول بعد لحظة."
                        SpeechRecognizer.ERROR_CLIENT -> "حدث خطأ من جهة جلسة التعرف الصوتي (الرمز 5). أعد المحاولة، وإذا تكرر فتحقق من خدمة التعرف الصوتي الافتراضية في الهاتف."
                        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED -> "خدمة التعرف الصوتي لا تدعم العربية الجزائرية على هذا الجهاز. جرّب تحديث خدمة التعرف أو اختيار العربية المتاحة."
                        SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> "حزمة اللغة العربية غير متاحة حاليًا في خدمة التعرف الصوتي. تحقق من الإنترنت أو نزّل اللغة إن كان ذلك متاحًا."
                        else -> "توقف الاستماع (رمز $error). اضغط الميكروفون لإعادة المحاولة."
                    }
                    overlaySpeechStatus(if (error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) "انتهى الاستماع بعد 3 ثوانٍ من الصمت." else message)
                    stopAssistantRecognizer()
                }
                override fun onResults(results: Bundle?) {
                    handler.removeCallbacks(assistantNoSpeechTimeout)
                    assistantListening = false
                    val transcript = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                    if (transcript.isNotBlank()) {
                        overlaySpeechStatus("فهمت كلامك؛ أجهز الرد…")
                        runOverlayJs("window.__alislahOverlaySpeechResult && window.__alislahOverlaySpeechResult(" + org.json.JSONObject.quote(transcript.take(1200)) + ");")
                    } else overlaySpeechStatus("لم أتعرف على كلامك. اضغط الميكروفون وحاول مجددًا.")
                    stopAssistantRecognizer()
                }
            })
            val request = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-DZ")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-DZ")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
            }
            recognizer.startListening(request)
            handler.removeCallbacks(assistantNoSpeechTimeout)
            handler.postDelayed(assistantNoSpeechTimeout, 3000L)
        } catch (_: Exception) {
            assistantListening = false
            stopAssistantRecognizer()
            overlaySpeechStatus("تعذر تشغيل الميكروفون. تحقق من الإذن وخدمة التعرف الصوتي.")
        }
    }

    private fun stopAssistantListening() {
        handler.removeCallbacks(assistantNoSpeechTimeout)
        if (!assistantListening) {
            stopAssistantRecognizer()
            return
        }
        assistantListening = false
        try { assistantRecognizer?.stopListening() } catch (_: Exception) { }
        overlaySpeechStatus("توقف الاستماع. جارٍ إكمال تحويل الكلام…")
    }

    private fun stopAssistantRecognizer() {
        handler.removeCallbacks(assistantNoSpeechTimeout)
        try { assistantRecognizer?.cancel() } catch (_: Exception) { }
        try { assistantRecognizer?.destroy() } catch (_: Exception) { }
        assistantRecognizer = null
    }

    private fun launchMainAppWithAction(action: String) {
        handler.post {
            val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("overlayBridgeAction", action)
            try { startActivity(intent) } catch (_: Exception) { }
        }
    }

    private fun launchMainApp() {
        val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try { startActivity(intent) } catch (_: Exception) { }
    }

    private fun readOverlayUsageJson(): String {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        val allowed = appOps.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == android.app.AppOpsManager.MODE_ALLOWED
        val result = org.json.JSONObject().put("permission", allowed)
        val apps = org.json.JSONArray()
        if (allowed) {
            try {
                val manager = getSystemService(Context.USAGE_STATS_SERVICE) as android.app.usage.UsageStatsManager
                val calendar = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY,0); set(java.util.Calendar.MINUTE,0); set(java.util.Calendar.SECOND,0); set(java.util.Calendar.MILLISECOND,0) }
                val stats: List<android.app.usage.UsageStats> = manager.queryAndAggregateUsageStats(calendar.timeInMillis, System.currentTimeMillis())?.values?.toList() ?: emptyList()
                val grouped = stats.filter { it.totalTimeInForeground > 0 && it.packageName != packageName }
                    .groupBy { it.packageName }.map { (pkg, rows) -> pkg to rows.sumOf { it.totalTimeInForeground } }
                    .sortedByDescending { it.second }.take(20)
                for ((pkg, millis) in grouped) {
                    val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg,0)).toString() } catch (_: Exception) { pkg }
                    apps.put(org.json.JSONObject().put("packageName",pkg).put("name",label).put("minutes",(millis/60000.0).toInt()))
                }
            } catch (_: Exception) { }
        }
        return result.put("apps",apps).put("foreground",org.json.JSONObject().put("name","غير متاح").put("packageName","").put("approximate",true)).put("collectedAt",System.currentTimeMillis()).toString()
    }

    private fun showFollowupOverlay() {
        showBubble()
        if (assistantPanel == null) {
            showAssistantOverlay("followup")
        } else {
            assistantPanel?.visibility = View.VISIBLE
            handler.removeCallbacks(pollReply)
            handler.postDelayed(pollReply, 300L)
        }
    }

    private fun showAssistantOverlay(command: String = "ask") {
        hideQuickMenu()
        lastSpokenReply = ""
        if (assistantPanel != null) {
            assistantPanel?.visibility = View.VISIBLE
            if (activeOverlayCommand != command) {
                activeOverlayCommand = command
                // Keep the same WebView alive: switching side bubbles changes the view in-place,
                // avoiding a destroyed/recreated window, white flash, and overlapping overlays.
                val root = assistantPanel as? LinearLayout
                (root?.getChildAt(0) as? LinearLayout)?.let { bar ->
                    (bar.getChildAt(0) as? TextView)?.text = when (command) {
                        "prayer" -> "ALISLAH · الصلاة والأذان"
                        "plan" -> "ALISLAH · المهام والخطة"
                        "behavior" -> "ALISLAH · تحليل العادات"
                        "habits" -> "ALISLAH · العادات"
                        "family" -> "ALISLAH · الأسرة"
                        "settings" -> "ALISLAH · الإعدادات"
                        "voice" -> "ALISLAH · صوت المساعد"
                        "eye" -> "ALISLAH · راحة العين"
                        else -> "ALISLAH · المساعد الذكي"
                    }
                }
                // The ribbon belongs to the previous panel; hide it rather than show stale actions.
                root?.getChildAt(1)?.visibility = View.GONE
                val target = overlayTargetFor(command)
                runOverlayJs("window.__alislahOverlayTarget='$target';if(typeof tab==='function')tab('$target');else document.querySelectorAll('.view').forEach(x=>x.classList.toggle('active',x.id==='$target'))")
                handler.removeCallbacks(pollReply)
                if (target == "assistant" && command != "question") handler.postDelayed(pollReply, 700L)
            }
            if (command != "ask") { assistantListening = false; stopAssistantRecognizer() }
            if (command == "question") { autoListenAfterSpeech = true; speak("ما أكثر شيء يشغل وقتك الآن؟") }
            selectOverlaySection(command)
            if (command == "ask") handler.postDelayed({ startAssistantListening() }, 300L)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("openAssistant", true)
            }
            startActivity(launch)
            return
        }
        val density = resources.displayMetrics.density
        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val panelWidth = (screenWidth - 82 * density).toInt().coerceAtLeast((245 * density).toInt())
        val panelHeight = (screenHeight * 0.72f).toInt().coerceAtMost((screenHeight - 28 * density).toInt()).coerceAtLeast((360 * density).toInt())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            elevation = 18 * density
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = 18 * density
                setStroke((1 * density).toInt(), Color.rgb(220, 231, 226))
            }
            clipToOutline = true
            // Android delivers ACTION_OUTSIDE because the window watches outside touches.
            setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                    hideAssistantOverlay()
                    true
                } else false
            }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((12*density).toInt(), (5*density).toInt(), (8*density).toInt(), (5*density).toInt())
            setBackgroundColor(Color.rgb(23, 107, 91))
        }
        val title = TextView(this).apply {
            text = "ALISLAH · اسألي هنا"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, (44*density).toInt(), 1f)
        }
        val microphone = TextView(this).apply {
            text = "🎙"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = "بدء الاستماع للمساعد"
            layoutParams = LinearLayout.LayoutParams((44*density).toInt(), (44*density).toInt())
            setOnClickListener { startAssistantListening() }
        }
        val close = TextView(this).apply {
            text = "×"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = "إغلاق نافذة المساعد"
            layoutParams = LinearLayout.LayoutParams((44*density).toInt(), (44*density).toInt())
            setOnClickListener { hideAssistantOverlay() }
        }
        bar.addView(title); bar.addView(microphone); bar.addView(close); root.addView(bar)
        // A distinct tool ribbon belongs to the selected side bubble; the circular bubble layout remains unchanged.
        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((7*density).toInt(), (6*density).toInt(), (7*density).toInt(), (6*density).toInt())
            setBackgroundColor(Color.rgb(231, 242, 237))
        }
        fun addTool(label: String, js: String) {
            val button = TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(20, 91, 76))
                setPadding((8*density).toInt(), (8*density).toInt(), (8*density).toInt(), (8*density).toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.WHITE); cornerRadius = 11*density
                    setStroke((1*density).toInt(), Color.rgb(195, 219, 208))
                }
                setOnClickListener { runOverlayJs(js) }
            }
            tools.addView(button, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = (3*density).toInt(); marginEnd = (3*density).toInt()
            })
        }
        when (command) {
            "prayer" -> {
                title.text = "ALISLAH · الصلاة والأذان"
                addTool("تحديث المواقيت", "document.getElementById('prayerRefresh')?.click()")
                addTool("تشغيل/إيقاف الصوت", "document.getElementById('prayerAdhanEnabled')?.click()")
                addTool("اختبار الصوت", "document.getElementById('prayerAdhanTest')?.click()")
            }
            "plan" -> {
                title.text = "ALISLAH · المهام والخطة"
                addTool("المهام", "if(typeof tab==='function')tab('tasks')")
                addTool("إضافة مهمة", "document.getElementById('taskText')?.focus()")
                addTool("المساعد", "if(typeof tab==='function')tab('assistant')")
            }
            "behavior" -> {
                title.text = "ALISLAH · تحليل العادات"
                addTool("تحليل الآن", "document.getElementById('analyzeBehavior')?.click()")
                addTool("العادات", "if(typeof tab==='function')tab('habits')")
            }
            "habits" -> {
                title.text = "ALISLAH · العادات"
                addTool("إضافة عادة", "document.getElementById('habitText')?.focus()")
                addTool("تحليل", "if(typeof tab==='function')tab('behavior')")
            }
            "family" -> {
                title.text = "ALISLAH · الأسرة"
                addTool("المساعد", "if(typeof tab==='function')tab('assistant')")
                addTool("المهام", "if(typeof tab==='function')tab('tasks')")
            }
            "settings" -> {
                title.text = "ALISLAH · الإعدادات"
                addTool("حفظ الإعدادات", "document.getElementById('saveSettings')?.click()")
                addTool("الصلاة", "if(typeof tab==='function')tab('prayer')")
            }
            else -> {
                title.text = "ALISLAH · المساعد الذكي"
                addTool("سؤال جديد", "document.getElementById('chatText')?.focus()")
                addTool("الخطة", "if(typeof tab==='function')tab('tasks')")
                addTool("تحليل", "if(typeof tab==='function')tab('behavior')")
            }
        }
        root.addView(tools)
        overlayPageReady = false
        pendingOverlayScripts.clear()
        val web = WebView(this).apply {
            addJavascriptInterface(OverlayNativeBridge(), "AndroidUsage")
            addJavascriptInterface(object {
                @JavascriptInterface fun getAppDataJson(): String = prefs().getString("alislah_app_data", "{}") ?: "{}"
                @JavascriptInterface fun getEyeBreakContentCache(): String = prefs().getString("eyeBreakContentCache", "{}") ?: "{}"
                @JavascriptInterface fun saveAppDataJson(json: String) { if (json.length <= 2_000_000) prefs().edit().putString("alislah_app_data", json).apply() }
                @JavascriptInterface fun saveEyeBreakContentCache(json: String) { if (json.length <= 1_000_000) prefs().edit().putString("eyeBreakContentCache", json).apply() }
            }, "ALISLAHStore")
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    val hasAudio = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    if (hasAudio && request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else request.deny()
                }
            }
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    val script = """(function(){
                      document.querySelector('header.top')?.style.setProperty('display','none','important');
                      document.querySelector('.hero')?.style.setProperty('display','none','important');
                      document.querySelector('.stats')?.style.setProperty('display','none','important');
                      document.querySelector('.tabs')?.style.setProperty('display','none','important');
                      const target = window.__alislahOverlayTarget || 'assistant';
                      document.querySelectorAll('.view').forEach(x=>x.classList.toggle('active',x.id===target));
                      document.querySelectorAll('#alislahFloat,#alislahCheckin,.footer,#nativeOverlayControls').forEach(x=>x.style.display='none');
                      const app=document.querySelector('.app'); if(app){app.style.cssText='padding:0;margin:0;max-width:none;width:100%;';}
                      const chat=document.querySelector('#assistant .chat'); if(chat){chat.style.cssText='min-height:0;height:auto;padding:5px;margin:0;';}
                      const msgs=document.getElementById('messages'); if(msgs){msgs.style.cssText='min-height:45px;max-height:105px;overflow-y:auto;padding:5px;margin:0;';}
                      const form=document.getElementById('chatForm'); if(form){form.style.cssText='display:flex;gap:5px;margin:5px 0 0;';}
                      const input=document.getElementById('chatText'); if(input){input.placeholder='اكتبي سؤالك هنا…';input.style.minHeight='38px';}
                      const consent=document.getElementById('chatConsentWrap'); if(consent) consent.style.display='none';
                      const panel=document.getElementById(target); if(panel){panel.style.setProperty('margin','0','important');panel.style.setProperty('padding','8px','important');panel.style.setProperty('overflow-y','auto','important');}
                      document.body.style.cssText='margin:0;padding:0;background:#f3f7f5;overflow-y:auto;overflow-x:hidden;';
                      document.documentElement.style.cssText='height:100%;overflow:auto;';
                    })();"""
                    val loadedView = view ?: return
                    loadedView.evaluateJavascript(script) {
                        overlayPageReady = true
                        loadedView.evaluateJavascript("(function(){var x=document.querySelector('#messages .bubble.assistant:last-child');return x?(x.innerText||x.textContent||''):''})()") { rawReply ->
                            lastSpokenReply = try { org.json.JSONTokener(rawReply ?: "").nextValue() as? String ?: "" } catch (_: Exception) { "" }
                        }
                        while (pendingOverlayScripts.isNotEmpty()) {
                            val next = pendingOverlayScripts.removeFirst()
                            loadedView.evaluateJavascript(next, null)
                        }
                    }
                }
            }
        }
        assistantWebView = web
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val anchor = params
        val lp = WindowManager.LayoutParams(panelWidth, panelHeight, type, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (anchor?.x ?: 10).coerceAtMost((screenWidth - panelWidth).coerceAtLeast(0))
            y = ((anchor?.y ?: (screenHeight/3)) + (70*density).toInt()).coerceAtMost((screenHeight-panelHeight).coerceAtLeast(0))
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        try {
            windowManager.addView(root, lp)
            assistantPanel = root
            activeOverlayCommand = command
            val target = when(command) {
                "settings" -> "settings"
                "behavior" -> "behavior"
                "plan" -> "tasks"
                "family" -> "family"
                "prayer" -> "prayer"
                "habits" -> "habits"
                "eye" -> "settings"
                "voice" -> "assistant"
                else -> "assistant"
            }
            web.loadUrl("file:///android_asset/index.html")
            web.postVisualStateCallback(0L, object : WebView.VisualStateCallback() {
                override fun onComplete(requestId: Long) {
                    runOverlayJs("window.__alislahOverlayTarget='$target';if(typeof tab==='function'){tab('$target')}else{document.querySelectorAll('.view').forEach(x=>x.classList.toggle('active',x.id==='$target'))}")
                    if (target == "assistant" && command != "question") { handler.removeCallbacks(pollReply); handler.postDelayed(pollReply, 700L) }
                    if (command == "question") { autoListenAfterSpeech = true; speak("ما أكثر شيء يشغل وقتك الآن؟") }
                    selectOverlaySection(command)
                    if (command == "ask") handler.postDelayed({ startAssistantListening() }, 550L)
                }
            })
        } catch (_: Exception) {
            assistantPanel = null
            assistantWebView = null
            activeOverlayCommand = null
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("openAssistant", true)
            }
            startActivity(launch)
        }
    }

    private fun overlayTargetFor(command: String): String = when (command) {
        "settings", "eye" -> "settings"
        "behavior" -> "behavior"
        "plan" -> "tasks"
        "family" -> "family"
        "prayer" -> "prayer"
        "habits" -> "habits"
        "voice", "question", "ask" -> "assistant"
        else -> "assistant"
    }

    private fun selectOverlaySection(command: String) {
        val js = when(command) {
            "settings" -> "if(typeof tab==='function')tab('settings');else document.querySelector('[data-tab=\"settings\"]')?.click();"
            "behavior" -> "if(typeof tab==='function')tab('behavior');else document.querySelector('[data-tab=\"behavior\"]')?.click();"
            "plan" -> "if(typeof tab==='function')tab('tasks');else document.querySelector('[data-tab=\"tasks\"]')?.click();"
            "family" -> "if(typeof tab==='function')tab('family');else document.querySelector('[data-tab=\"family\"]')?.click();"
            "prayer" -> "if(typeof tab==='function')tab('prayer');else document.querySelector('[data-tab=\"prayer\"]')?.click();"
            "habits" -> "if(typeof tab==='function')tab('habits');else document.querySelector('[data-tab=\"habits\"]')?.click();"
            "eye" -> "if(typeof tab==='function')tab('settings');else document.querySelector('[data-tab=\"settings\"]')?.click();setTimeout(()=>document.getElementById('eyeBreakEnabled')?.scrollIntoView({block:'center'}),180);"
            "voice" -> "if(typeof tab==='function')tab('assistant');else document.querySelector('[data-tab=\"assistant\"]')?.click();setTimeout(()=>document.getElementById('alislahVoiceGender')?.scrollIntoView({block:'center'}),180);"
            "question" -> "if(typeof tab==='function')tab('assistant');if(window.__alislahShowFollowupQuestion)window.__alislahShowFollowupQuestion('ما أكثر شيء يشغل وقتك الآن؟');var q=document.getElementById('chatText');if(q)q.focus();"
            else -> "if(typeof tab==='function')tab('assistant');else document.querySelector('[data-tab=\"assistant\"]')?.click();document.getElementById('chatText')?.focus();"
        }
        runOverlayJs(js)
    }

    private fun hideAssistantOverlay() {
        autoListenAfterSpeech = false
        assistantListening = false
        stopAssistantRecognizer()
        handler.removeCallbacks(pollReply)
        overlayPageReady = false
        pendingOverlayScripts.clear()
        assistantWebView?.stopLoading()
        assistantWebView?.destroy()
        assistantWebView = null
        assistantPanel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        assistantPanel = null
        activeOverlayCommand = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel("alislah_bubble", "فقاعة ALISLAH", NotificationManager.IMPORTANCE_LOW).apply { description = "إبقاء الفقاعة العائمة متاحة فوق التطبيقات" })
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "alislah_bubble").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("فقاعة ALISLAH مفعّلة").setContentText("ضغط مطوّل لإضافة مهمة صوتيًا، ضغطة للفقاعات الجانبية، وضغطتان لفتح التطبيق").setContentIntent(open).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("فقاعة ALISLAH مفعّلة").setContentText("ضغط مطوّل لإضافة مهمة صوتيًا، ضغطة للفقاعات الجانبية، وضغطتان لفتح التطبيق").setContentIntent(open).setOngoing(true).build()
        }
    }

    private var pendingDisplayReflow: Runnable? = null

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Android may deliver the configuration callback before WindowManager has
        // published the new physical display metrics/rotation. Reflow only after
        // those values have settled, otherwise the old geometry gets cached again.
        pendingDisplayReflow?.let { handler.removeCallbacks(it) }
        val snapshot = Configuration(newConfig)
        val task = Runnable {
            pendingDisplayReflow = null
            applyDisplayConfiguration(snapshot)
        }
        pendingDisplayReflow = task
        handler.postDelayed(task, 350L)
    }

    private fun applyDisplayConfiguration(newConfig: Configuration) {
        val main = bubble ?: return
        val lp = params ?: return
        val wasMenuVisible = quickMenu != null
        val openCommand = activeOverlayCommand
        hideQuickMenu()
        // The orbit is display-relative, not a physical direction that should
        // survive a 90/180/270 degree turn. Start from its canonical layout.
        orbitRotation = 0.0

        val d = resources.displayMetrics.density
        val (newW, newH) = realScreenSize()
        val oldW = lastBubbleScreenWidth.takeIf { it > 0 } ?: newW
        val oldH = lastBubbleScreenHeight.takeIf { it > 0 } ?: newH
        val oldCenterX = (lp.x + lp.width / 2f).coerceIn(0f, oldW.toFloat())
        val oldCenterY = (lp.y + lp.height / 2f).coerceIn(0f, oldH.toFloat())
        val xRatio = if (oldW > 0) oldCenterX / oldW else 0.5f
        val yRatio = if (oldH > 0) oldCenterY / oldH else 0.5f
        val oldOrientation = lastConfigOrientation.takeIf { it != Configuration.ORIENTATION_UNDEFINED }
            ?: if (oldW > oldH) Configuration.ORIENTATION_LANDSCAPE else Configuration.ORIENTATION_PORTRAIT
        rememberBubbleAnchor(oldOrientation, lp, oldW, oldH)
        val newOrientation = if (newW > newH) Configuration.ORIENTATION_LANDSCAPE else Configuration.ORIENTATION_PORTRAIT

        // Rotate within the same orientation, but restore a separate saved anchor when
        // switching between portrait and landscape.
        val newRotation = try { windowManager.defaultDisplay.rotation } catch (_: Exception) { lastDisplayRotation }
        val rotationDelta = (newRotation - lastDisplayRotation + 4) % 4
        val mappedRatios = when (rotationDelta) {
            1 -> Pair(1f - yRatio, xRatio)       // 90 degrees clockwise
            2 -> Pair(1f - xRatio, 1f - yRatio)  // 180 degrees
            3 -> Pair(yRatio, 1f - xRatio)       // 270 degrees clockwise
            else -> Pair(xRatio, yRatio)
        }
        val savedRatios = if (newOrientation == Configuration.ORIENTATION_LANDSCAPE) {
            if (oldOrientation != newOrientation && landscapeAnchorXRatio != null && landscapeAnchorYRatio != null)
                Pair(landscapeAnchorXRatio!!, landscapeAnchorYRatio!!) else mappedRatios
        } else {
            if (oldOrientation != newOrientation && portraitAnchorXRatio != null && portraitAnchorYRatio != null)
                Pair(portraitAnchorXRatio!!, portraitAnchorYRatio!!) else mappedRatios
        }
        val mappedX = savedRatios.first * newW
        val mappedY = savedRatios.second * newH
        lastDisplayRotation = newRotation
        lastConfigOrientation = newOrientation
        val nearest = edgeDistances(mappedX, mappedY, newW, newH).minByOrNull { it.second }?.first ?: "left"
        val mainView = main as? MainBubbleView
        if (mainView != null) {
            dockMainBubble(mainView, lp, nearest, newW, newH, mappedX.toInt(), mappedY.toInt())
        }
        lastBubbleScreenWidth = newW
        lastBubbleScreenHeight = newH
        rememberBubbleAnchor(newOrientation, lp, newW, newH)
        try { windowManager.updateViewLayout(main, lp) } catch (_: Exception) { }
        main.invalidate()
        syncReminderOverlay(lp)
        syncAdhanMuteBubble()
        syncAssistantStopBubble()
        if (wasMenuVisible) showQuickMenu(lp)
        if (openCommand != null) {
            val panel = assistantPanel
            val panelLp = panel?.layoutParams as? WindowManager.LayoutParams
            if (panel != null && panelLp != null) {
                panelLp.width = (newW - 82 * d).toInt().coerceAtLeast((245 * d).toInt())
                panelLp.height = (newH * 0.72f).toInt().coerceAtMost((newH - 28 * d).toInt()).coerceAtLeast((300 * d).toInt())
                panelLp.x = (lp.x + lp.width / 2 - panelLp.width / 2).coerceIn(0, (newW - panelLp.width).coerceAtLeast(0))
                panelLp.y = (lp.y + lp.height / 2 + (18 * d).toInt()).coerceIn(0, (newH - panelLp.height).coerceAtLeast(0))
                try { windowManager.updateViewLayout(panel, panelLp) } catch (_: Exception) { }
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(reshowBubble)
        handler.removeCallbacks(pollReply)
        mainLongPressRunnable?.let { handler.removeCallbacks(it) }
        pendingDisplayReflow?.let { handler.removeCallbacks(it) }
        pendingDisplayReflow = null
        pendingMainTap?.let { handler.removeCallbacks(it) }
        pendingMainTap = null
        hideCloseButton()
        hideQuickMenu()
        hideReminderViews()
        hideAdhanMuteBubble()
        hideAssistantStopBubble()
        stopAssistantListening()
        hideAssistantOverlay()
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_ANSWERED = "dz.alislah.app.ACTION_ASSISTANT_ANSWERED"
        const val ACTION_SHOW_FOR_EVENT = "dz.alislah.app.ACTION_SHOW_BUBBLE_FOR_EVENT"
        const val ACTION_HIDE_PANEL = "dz.alislah.app.ACTION_HIDE_PANEL"
        const val ACTION_SPEAK_TEST = "dz.alislah.app.ACTION_SPEAK_TEST"
        const val ACTION_SPEAK_TEXT = "dz.alislah.app.ACTION_SPEAK_TEXT"
        const val ACTION_START_ASSISTANT_LISTENING = "dz.alislah.app.ACTION_START_ASSISTANT_LISTENING"
        const val ACTION_STOP_ASSISTANT_LISTENING = "dz.alislah.app.ACTION_STOP_ASSISTANT_LISTENING"
        const val ACTION_ASSISTANT_MIC_PERMISSION_RESULT = "dz.alislah.app.ACTION_ASSISTANT_MIC_PERMISSION_RESULT"
        const val EXTRA_ASSISTANT_MIC_GRANTED = "assistant_mic_granted"
        const val ACTION_STOP_SPEECH = "dz.alislah.app.ACTION_STOP_SPEECH"
        const val ACTION_ADHAN_STARTED = "dz.alislah.app.ACTION_ADHAN_STARTED"
        const val ACTION_ADHAN_STOPPED = "dz.alislah.app.ACTION_ADHAN_STOPPED"
        const val ACTION_SHOW_REMINDER = "dz.alislah.app.ACTION_SHOW_PRAYER_REMINDER"
        const val EXTRA_REMINDER_TITLE = "reminder_title"
        const val EXTRA_REMINDER_TEXT = "reminder_text"
        const val EXTRA_SPEAK_TEXT = "speak_text"
    }
}
