# إشعارات المكونات الخارجية — ALISLAH Mixer-TTS

- محرك Mixer-TTS وVocos وواجهة ONNX مأخوذة من مشروع `nipponjo/tts-arabic-flutter` ومستودع النماذج `nipponjo/tts-arabic-onnx`. النماذج المطلوبة لهذا الدمج: `mixer128.onnx` و`vocos22.onnx` و`shakkelha.onnx`.
- ملف `ar_phonemizer.dart` مقتبس ومحوّل من Arabic-Phonetiser للمطور Nawar Halabi، ويذكر مصدره الأصلي ترخيص Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0). لذلك يجب عدم استخدام هذا المكوّن أو توزيع التطبيق لأغراض تجارية قبل الحصول على إذن مناسب من صاحب الحقوق.
- كود Shakkelha المرفق يحمل ملف ترخيص MIT ضمن مجلد مصدره.
- محرك ONNX Runtime وjust_audio يستخدمان تبعياتهما وتراخيصهما الأصلية كما يحددها pub.dev.
- تُضمّن النماذج داخل APK حزمة الصوت الاختيارية فقط، ولا تدخل في APK تطبيق ALISLAH الأساسي. يعمل النطق محليًا بعد تثبيت الحزمة الاختيارية.

المراجع: https://github.com/nipponjo/tts-arabic-flutter ، https://huggingface.co/nipponjo/tts-arabic-onnx ، https://creativecommons.org/licenses/by-nc/4.0/
