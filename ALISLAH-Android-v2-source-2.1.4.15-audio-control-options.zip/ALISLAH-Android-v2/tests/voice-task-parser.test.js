'use strict';
const assert = require('node:assert/strict');
const parser = require('../app/src/main/assets/js/voice-task-parser.js');
const now = new Date(2026, 10, 9, 15, 34, 0);
global.ALI_PRAYER_TASK_TIME = (key, date, moveIfPassed) => ({ date: moveIfPassed ? '2026-11-10' : date, time: ({Fajr:'05:10',Dhuhr:'12:15',Asr:'15:20',Maghrib:'17:45',Isha:'19:05'})[key] });

let result = parser.parse('ذكّرني غدًا الساعة الثامنة بشراء الحليب', now);
assert.equal(result.taskText, 'ذكّرني بشراء الحليب');
assert.equal(result.date, '2026-11-10');
assert.equal(result.time, '08:00');
assert.equal(result.hasTime, true);

result = parser.parse('نظف المنزل اليوم على الساعة 10 مساء', now);
assert.equal(result.taskText, 'نظف المنزل');
assert.equal(result.date, '2026-11-09');
assert.equal(result.time, '22:00');

result = parser.parse('اتصل بالطبيب', now);
assert.equal(result.taskText, 'اتصل بالطبيب');
assert.equal(result.time, '');
assert.equal(result.hasTime, false);

result = parser.parse('اشتر الخبز بعد ساعة', now);
assert.equal(result.taskText, 'اشتر الخبز');
assert.equal(result.date, '2026-11-09');
assert.equal(result.time, '16:34');
assert.equal(result.hasTime, true);

result = parser.parse('شراء الخبز يوم السبت الساعة 7 صباحا', now);
assert.equal(result.taskText, 'شراء الخبز');
assert.equal(result.date, '2026-11-14');
assert.equal(result.time, '07:00');

result = parser.parse('ذكّرني بعد صلاة المغرب بشراء الدواء', now);
assert.equal(result.taskText, 'ذكّرني بشراء الدواء');
assert.equal(result.date, '2026-11-10');
assert.equal(result.time, '17:45');
assert.equal(result.hasTime, true);

result = parser.parse('اجتماع الساعة 8 مساء', now);
assert.equal(result.time, '20:00');
assert.equal(result.hasTime, true);

console.log('Voice task parser tests passed.');
