from pathlib import Path

root = Path(__file__).resolve().parents[1]
activity = (root / 'app/src/main/java/dz/alislah/app/MainActivity.kt').read_text(encoding='utf-8')
bubble = (root / 'app/src/main/java/dz/alislah/app/FloatingBubbleService.kt').read_text(encoding='utf-8')
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
index = (root / 'app/src/main/assets/index.html').read_text(encoding='utf-8')
main_js = (root / 'app/src/main/assets/js/main.js').read_text(encoding='utf-8')
parser = (root / 'app/src/main/assets/js/voice-task-parser.js').read_text(encoding='utf-8')
gradle = (root / 'app/build.gradle').read_text(encoding='utf-8')

checks = {
    'runtime microphone permission': 'android.permission.RECORD_AUDIO' in manifest,
    'live partial speech results': 'RecognizerIntent.EXTRA_PARTIAL_RESULTS, true' in activity and 'onPartialResults' in activity,
    'Arabic-Algerian recognizer locale': 'RecognizerIntent.EXTRA_LANGUAGE, "ar-DZ"' in activity,
    'hold-to-record bubble timer': 'handler.postDelayed(longPress, 650L)' in bubble,
    'release stops bubble recording': 'stopVoiceTaskFromBubble()' in bubble and 'EXTRA_STOP_VOICE_TASK' in activity,
    'landscape navbar edge uses exposed half-circle': 'if (landscape && navigation.edge == edge)' in bubble and 'lp.y = boundary - circle/2' in bubble and 'lp.x = boundary - circle/2' in bubble,
    'microphone remains optional device hardware': 'android.hardware.microphone' in manifest and 'android:required=\"false\"' in manifest,
    'landscape side-navigation detection': 'config_navBarCanMove' in bubble and 'Surface.ROTATION_270' in bubble and 'navigation_bar_width' in bubble,
    'voice task entry in app': 'id="voiceTaskStart"' in index and 'AndroidUsage.startVoiceTask()' in main_js,
    'missing-time prompt': 'id="voiceTaskSheet"' in index and 'حددي وقت المهمة' in index,
    'prayer-relative scheduling hook': 'ALI_PRAYER_TASK_TIME' in parser and 'ALI_PRAYER_TASK_TIME=function' in (root / 'app/src/main/assets/js/prayer.js').read_text(encoding='utf-8'),
    'editable transcript continues receiving new words': 'voiceTaskLastRecognized' in activity and 'voiceTaskUserEdited' in activity,
    're-record button restarts recognition': 'voiceTaskRequiresHold = false' in activity,
    'shared task-list integration': 'addVoiceTask:addVoiceTaskFromTranscript' in main_js and 'scheduleTaskReminder(task)' in main_js,
    'voice parser loaded before main app': index.index('js/voice-task-parser.js') < index.index('js/main.js'),
    'version increment': "versionCode 45" in gradle and "versionName '2.1.4.15'" in gradle,
    'side assistant bubble starts Android recognizer': 'if (command == "ask") handler.postDelayed({ startAssistantListening() }' in bubble and 'ACTION_START_ASSISTANT_LISTENING' in bubble,
    'Arabic overlay speech recognizer with partial results': 'RecognizerIntent.EXTRA_LANGUAGE, "ar-DZ"' in bubble and 'override fun onPartialResults(partialResults: Bundle?)' in bubble,
    'speech recognizer code 5 has an explanatory Arabic message': 'SpeechRecognizer.ERROR_CLIENT' in bubble and 'الرمز 5' in bubble,
    'overlay speech callbacks reach the web assistant': '__alislahOverlaySpeechPartial' in bubble and '__alislahOverlaySpeechResult' in bubble and '__alislahOverlaySpeechStatus' in main_js,
    'overlay microphone asks Android permission': 'requestOverlayAssistantMic' in bubble and 'ASSISTANT_OVERLAY_MIC_PERMISSION_REQUEST' in activity,
    'side assistant bubble stays available after answering': 'isBubbleOverlay(): Boolean = true' in bubble and 'AndroidUsage.isBubbleOverlay()' in main_js,
    'voice assistant reads and completes actual task records': 'function handleVoiceTaskStatusCommand(transcript)' in main_js and 'completeTask(matches[0],true)' in main_js and 'data.tasks.filter(t=>(t.date||today())===today())' in main_js,
    'voice can add and check habits with explicit action': 'async function addVoiceHabitFromTranscript(transcript)' in main_js and "await ui.confirm('إضافة عادة جديدة؟'" in main_js and 'data.checks[today()][matches[0].id]=true' in main_js,
    'startup spoken welcome uses the legacy Android TTS': 'startupGreetingSent' in activity and 'speakWithLegacyTts(greeting' in activity,
    'live local usage insights shown on behavior screen': 'id="liveInsights"' in index and 'function renderLiveInsights()' in main_js and 'getProductivityMetrics()' in main_js,
    'voice advice uses live local data without cloud upload': 'renderLiveInsights();' in main_js and 'قدمت لك نصيحة اعتمادًا على بياناتك المحلية الحالية.' in main_js,
    'voice analysis composes a reviewable one-time data summary after consent': "input.value=text+'\\n\\n'+makeBehaviorPrompt()" in main_js and "input.dataset.includesPersonalAnalysis='true'" in main_js,
    'voice task requires explicit confirmation from overlay': 'function addVoiceTaskFromTranscript(raw,explicitlyConfirmed=false)' in main_js and 'data.pendingVoiceTask=draft' in main_js and 'function saveVoiceTaskDraft()' in main_js and 'saveVoiceTaskDraft();return' in main_js,
    'AI plan task conversion is automatic after an explicit plan request': "await autoCreateTasksFromPlan(m,answer)" in main_js and "سيحوّل التطبيق عناصر الخطة إلى مهام تلقائيًا" in main_js and "await ui.confirm('هل تريد تحويل الخطة إلى مهام؟'" not in main_js,
    'assistant stop bubble is independent from adhan mute': 'assistantStopBubble' in bubble and 'إيقاف صوت المساعد' in bubble and 'stopAssistantSpeech()' in bubble and 'إيقاف الأذان' in bubble,
    'adhan state survives floating service recreation': 'putBoolean("adhanPlaying", active)' in (root / 'app/src/main/java/dz/alislah/app/PrayerVoiceService.kt').read_text(encoding='utf-8') and 'getBoolean("adhanPlaying", false)' in bubble,
    'assistant speaking completion starts microphone again': 'autoListenAfterSpeech = true; speak(value)' in bubble and 'startAssistantListening()' in bubble and 'autoListenAfterSpeech && assistantPanel != null' in bubble,
    'assistant recognition stops after three seconds of silence': 'EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L' in bubble and 'EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L' in bubble,
    'assistant stops waiting when no speech starts within three seconds': 'assistantNoSpeechTimeout' in bubble and 'انتهى الاستماع بعد 3 ثوانٍ دون كلام' in bubble,
    'assistant follow-up opens visible floating conversation': 'showAssistantOverlay("followup")' in bubble and 'window.__alislahShowFollowupQuestion' in main_js,
    'follow-up reply is read and then microphone reopens': 'target == "assistant"' in bubble and 'autoListenAfterSpeech = true; speak(value)' in bubble,
    'task creation accepts natural Arabic completion phrasing': 'function isTaskCreationIntent(value)' in main_js and 'أنجز|انجز' in main_js and 'isTaskCreationIntent(text)' in main_js,
    'task confirmation can be accepted by voice and saved': 'data.pendingVoiceTask' in main_js and 'saveVoiceTaskDraft();return' in main_js and 'data.tasks.push(task);data.pendingVoiceTask=null' in main_js,
    'old Android WebView form submission fallback': 'function submitFormCompat(form)' in main_js and "form.dispatchEvent(new Event('submit'" in main_js,
    'overlay and main app share task data through native storage': "nat('saveAppDataJson',snapshot)" in main_js and "nat('getAppDataJson')" in main_js and 'window.__alislahSync&&window.__alislahSync()' in main_js,
    'answer callback preserves active adhan and prayer reminder overlays': 'if (adhanPlaying || reminderCardVisible || assistantSpeaking)' in bubble,
    'navigation edge uses fallback inset when Android metrics omit it': '(24 * resources.displayMetrics.density).toInt()' in bubble and 'syncAssistantStopBubble()' in bubble,
    'no Mixer-TTS model or binary payload added': not any((root / 'app/src/main').rglob('*.onnx')) and not any((root / 'app/src/main').rglob('*.tflite')),
    'two audio-control choices are visible': 'value="current">الوضع الحالي' in main_js and 'value="unified">الوضع الموحّد' in main_js,
    'audio-control choice persists in native preferences': 'getAudioControlMode()' in activity and 'putString("audioControlMode", selected)' in activity,
    'unified mode uses media volume keys in foreground activity': 'AudioManager.STREAM_MUSIC' in activity and 'setVolumeControlStream(stream)' in activity,
    'unified adhan uses media channel while current keeps alarm channel': 'if (unified) AudioAttributes.USAGE_MEDIA else AudioAttributes.USAGE_ALARM' in (root / 'app/src/main/java/dz/alislah/app/PrayerVoiceService.kt').read_text(encoding='utf-8'),
    'assistant TTS follows selected audio channel': 'applyAssistantAudioAttributes()' in bubble and 'AudioAttributes.USAGE_MEDIA' in bubble,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit('Voice-task integration checks failed: ' + ', '.join(failed))
