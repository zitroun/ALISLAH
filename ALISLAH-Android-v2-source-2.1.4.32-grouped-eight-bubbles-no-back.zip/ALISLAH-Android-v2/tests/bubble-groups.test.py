from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
source = root / "app/src/main/java/dz/alislah/app/FloatingBubbleService.kt"
s = source.read_text(encoding="utf-8")
start = s.index("val groups = listOf(", s.index("private fun showQuickMenu"))
end = s.index("val nextAt = PrayerScheduler.nextAdhan(this)?.second", start)
block = s[start:end]
assert len(re.findall(r'BubbleGroup\("', block)) == 8, "orbit must expose exactly eight main groups"
expected = {"ask", "question", "voice", "readtasks", "plan", "miniDashboard", "quickComplete", "quickPostpone", "behavior", "family", "prayer", "habits", "settings", "eye", "closeWindows"}
actual = set(re.findall(r'BubbleAction\([^\n]*?,\s*"([A-Za-z_][A-Za-z0-9_]*)",\s*Color\.rgb', block))
missing = expected - actual
extra = actual - expected
assert not missing, f"shortcuts missing from groups: {sorted(missing)}"
assert not extra, f"unexpected shortcut commands: {sorted(extra)}"
assert 'selectedGroup = if (selectedGroup?.id == tappedGroup?.id) null else tappedGroup' in s
assert 'group?.children.orEmpty()' in s and 'parentActions + childActions' in s
assert 'buttons.forEach { menu.removeView(it.view) }' in s, 'orbit cleanup must remove the wrapped Android View, not the OrbitButton data holder'
assert '__back' not in s and 'رجوع إلى الأقسام' not in s
print("Bubble groups contract passed: 8 parent groups, all 15 existing shortcuts retained, direct group switching and toggle-close wired without a back bubble.")
