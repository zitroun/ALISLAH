(()=>{'use strict';const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)],KEY='alislah_v2',ENDPOINT='https://alislah-ai.zitroun2222.workers.dev/';const today=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));const uid=()=>globalThis.crypto?.randomUUID?.()||String(Date.now())+Math.random().toString(16).slice(2);const NATIVE=!!window.AndroidUsage,nat=(fn,...a)=>{try{return window.AndroidUsage&&typeof AndroidUsage[fn]==='function'?AndroidUsage[fn](...a):undefined}catch(_){return undefined}};const ymd=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');const O=v=>v&&typeof v==='object'&&!Array.isArray(v);
function ALI_norm(d){d.family=O(d.family)?d.family:{};const f=d.family;f.members=Array.isArray(f.members)?f.members:[];f.routines=O(f.routines)?f.routines:{};f.routineLog=O(f.routineLog)?f.routineLog:{};f.events=Array.isArray(f.events)?f.events:[];f.controls=O(f.controls)?f.controls:{};f.controls.enabled=!!f.controls.enabled;f.controls.dailyLimitMinutes=Math.max(0,Math.min(1440,Number(f.controls.dailyLimitMinutes)||0));f.controls.blockedApps=Array.isArray(f.controls.blockedApps)?f.controls.blockedApps:[];f.controls.blockedSites=Array.isArray(f.controls.blockedSites)?f.controls.blockedSites:[];
d.worship=O(d.worship)?d.worship:{};const w=d.worship;w.khatma=O(w.khatma)?w.khatma:{};const k=w.khatma;k.pages=Math.max(0,Number(k.pages)||0);k.total=Number(k.total)||604;k.goalDays=Number(k.goalDays)||30;k.start=typeof k.start==='string'?k.start:'';k.log=O(k.log)?k.log:{};w.qada=O(w.qada)?w.qada:{};w.qada.owed=Math.max(0,Number(w.qada.owed)||0);w.dhikrDone=O(w.dhikrDone)?w.dhikrDone:{};
d.focus=O(d.focus)?d.focus:{};d.focus.sessions=Array.isArray(d.focus.sessions)?d.focus.sessions:[];d.focus.work=Number(d.focus.work)||25;d.focus.rest=Number(d.focus.rest)||5;
d.settings=O(d.settings)?d.settings:{};return d}
const blank=()=>({tasks:[],habits:[],checks:{},prayerLog:[],prayerResponses:[],chat:[],undoStack:[],lastAutoRescheduleDate:'',pendingVoiceTask:null,behavior:{},usageProfile:{snapshots:[]},family:{members:[],routines:{},routineLog:{},events:[],controls:{enabled:false,dailyLimitMinutes:0,blockedApps:[],blockedSites:[]}},dashboard:{cards:{prayer:true,timeline:true,habits:true,notifications:true,achievements:true,activity:false},top3:[],visualFocus:false,oneHanded:false,largeTargets:false,highContrast:false},activityLog:[],worship:{khatma:{pages:0,total:604,goalDays:30,start:'',log:{}},qada:{owed:0},dhikrDone:{}},focus:{sessions:[],work:25,rest:5},settings:{worker:ENDPOINT,name:'',autoShareUsage:false,questionCloudEnabled:false,theme:'auto',fontScale:'normal',appLock:false,encryptBackup:false,backupReminder:false,digest:{morning:{on:false,time:'07:30'},evening:{on:false,time:'21:00'}},welcomed:false,interactionMode:'both',voiceRead:false,assistantVoiceEngine:'old',audioControlMode:'current'},idea:0});
const readStoredObject=value=>{try{const x=JSON.parse(value||'{}');return x&&typeof x==='object'?x:{}}catch(_){return {}}};
const localSaved=readStoredObject(localStorage.getItem(KEY));
const nativeSaved=readStoredObject(nat('getAppDataJson'));
const FIRST_RUN=!localStorage.getItem(KEY)&&!nativeSaved._rev&&!nativeSaved.tasks?.length;
let data={...blank(),...(Number(nativeSaved._rev||0)>Number(localSaved._rev||0)?nativeSaved:localSaved)};try{if(NATIVE&&(!nativeSaved._rev||Number(localSaved._rev||0)>Number(nativeSaved._rev||0))){nat('saveAppDataJson',JSON.stringify(data));}else if(Number(nativeSaved._rev||0)>Number(localSaved._rev||0)){localStorage.setItem(KEY,JSON.stringify(data));}}catch(_){}ALI_norm(data);data.tasks=Array.isArray(data.tasks)?data.tasks:[];data.habits=Array.isArray(data.habits)?data.habits:[];data.prayerLog=Array.isArray(data.prayerLog)?data.prayerLog:[];data.prayerResponses=Array.isArray(data.prayerResponses)?data.prayerResponses:[];data.undoStack=Array.isArray(data.undoStack)?data.undoStack.slice(-20):[];data.checks=data.checks&&typeof data.checks==='object'?data.checks:{};data.behavior=data.behavior&&typeof data.behavior==='object'?data.behavior:{};data.usageProfile=data.usageProfile&&typeof data.usageProfile==='object'?data.usageProfile:{snapshots:[]};data.usageProfile.snapshots=Array.isArray(data.usageProfile.snapshots)?data.usageProfile.snapshots.slice(-14):[];data.chat=Array.isArray(data.chat)?data.chat.slice(-30):[];data.settings={...blank().settings,...data.settings};data.dashboard={...blank().dashboard,...(data.dashboard||{}),cards:{...blank().dashboard.cards,...((data.dashboard||{}).cards||{})}};data.activityLog=Array.isArray(data.activityLog)?data.activityLog.slice(-100):[];data.family.controls={...blank().family.controls,...(data.family.controls||{})};let timer;function toast(t){$('#toast').textContent=t;$('#toast').classList.remove('hidden');clearTimeout(timer);timer=setTimeout(()=>$('#toast').classList.add('hidden'),2600)}function save(){try{let cur=null;try{cur=JSON.parse(localStorage.getItem(KEY)||'null')}catch{}
if(cur&&typeof cur==='object'){const M=['tasks','habits','checks','chat','undoStack','lastAutoRescheduleDate','pendingVoiceTask','behavior','usageProfile','family','dashboard','activityLog','worship','focus','idea','settings','_rev'],MS=['worker','name','autoShareUsage','questionCloudEnabled','theme','fontScale','appLock','encryptBackup','backupReminder','digest','welcomed','interactionMode','voiceRead','voiceGender','assistantVoiceEngine','audioControlMode'],bad=k=>k==='__proto__'||k==='constructor'||k==='prototype';
Object.keys(cur).forEach(k=>{if(!M.includes(k)&&!bad(k))data[k]=cur[k]});
if(cur.settings&&typeof cur.settings==='object'){data.settings=data.settings||{};Object.keys(cur.settings).forEach(k=>{if(!MS.includes(k)&&!bad(k))data.settings[k]=cur.settings[k]})}}
data._rev=Math.max(Number(data._rev)||0,Number(cur&&cur._rev)||0)+1;
const snapshot=JSON.stringify(data);localStorage.setItem(KEY,snapshot);nat('saveAppDataJson',snapshot)}catch{toast('تعذر حفظ البيانات في المتصفح')}stats();try{renderLiveInsights()}catch(_){}try{window.__alislahDashboardRefresh&&window.__alislahDashboardRefresh()}catch(_){}try{window.__alislahAfterSave&&window.__alislahAfterSave()}catch(_){}}
window.__toast=toast;
let connectivityPromise=null;
async function checkInternetConnection(){
  const badge=$('#connectivityStatus');if(!badge)return false;
  if(navigator.onLine===false){badge.dataset.state='offline';badge.textContent='غير متصل بالإنترنت';badge.title='الأوامر المحلية والمهام والعادات تبقى متاحة دون اتصال';return false;}
  if(connectivityPromise)return connectivityPromise;
  badge.dataset.state='checking';badge.textContent='جارٍ التحقق…';
  connectivityPromise=(async()=>{
    const controller=typeof AbortController==='function'?new AbortController():null;
    const timeout=setTimeout(()=>{try{controller&&controller.abort()}catch(_){}},5000);
    try{
      const response=await fetch(ENDPOINT,{method:'GET',mode:'cors',cache:'no-store',...(controller?{signal:controller.signal}:{})});
      // A 405 response is expected from this POST-only endpoint and still proves reachability.
      const reachable=!!response;
      badge.dataset.state=reachable?'online':'offline';
      badge.textContent=reachable?'متصل بالإنترنت':'غير متصل بالإنترنت';
      badge.title=reachable?'تم التحقق من الوصول إلى خدمة ALISLAH. قد تختلف حالة الذكاء الاصطناعي حسب الخدمة.':'الأوامر المحلية متاحة؛ المساعد السحابي يحتاج اتصالًا.';
      return reachable;
    }catch(_){
      badge.dataset.state='offline';badge.textContent='غير متصل بالإنترنت';badge.title='الأوامر المحلية متاحة؛ المساعد السحابي يحتاج اتصالًا.';return false;
    }finally{clearTimeout(timeout);connectivityPromise=null;}
  })();
  return connectivityPromise;
}
window.addEventListener('online',()=>checkInternetConnection());
window.addEventListener('offline',()=>{const b=$('#connectivityStatus');if(b){b.dataset.state='offline';b.textContent='غير متصل بالإنترنت';b.title='الأوامر المحلية متاحة دون إنترنت.'}});

window.__alislahSync=function(){try{if(document.getElementById('settings').classList.contains('active'))renderNative()}catch(_){}try{const local=readStoredObject(localStorage.getItem(KEY)),native=readStoredObject(nat('getAppDataJson'));const cur=Number(native._rev||0)>Number(local._rev||0)?native:local;if(!cur||typeof cur!=='object'||(Number(cur._rev)||0)<=(Number(data._rev)||0))return;const nd={...blank(),...cur,settings:{...blank().settings,...(cur.settings&&typeof cur.settings==='object'?cur.settings:{})}};['tasks','habits','chat'].forEach(k=>{if(!Array.isArray(nd[k]))nd[k]=[]});['checks','behavior'].forEach(k=>{if(!nd[k]||typeof nd[k]!=='object')nd[k]={}});if(!nd.usageProfile||typeof nd.usageProfile!=='object')nd.usageProfile={snapshots:[]};if(!Array.isArray(nd.usageProfile.snapshots))nd.usageProfile.snapshots=[];if(!Array.isArray(nd.undoStack))nd.undoStack=[];ALI_norm(nd);data=nd;localStorage.setItem(KEY,JSON.stringify(nd));renderTasks();renderHabits();stats();drawChat();renderBehavior();renderUsage();try{window.__alislahResync&&window.__alislahResync()}catch(_){}}catch(_){}};const PRIMARY=['tasks','habits','prayer','family'];
function applyTabState(n){if(!document.getElementById(n))n='tasks';const prim=PRIMARY.includes(n)?n:'more';$$('.tab').forEach(b=>{const on=b.dataset.tab===prim&&!b.classList.contains('legacy');b.classList.toggle('active',on);if(on)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current')});$$('.view').forEach(v=>v.classList.toggle('active',v.id===n));document.body.dataset.view=n;if(n==='settings')renderNative();try{window.scrollTo({top:0})}catch(_){}document.dispatchEvent(new CustomEvent('alislah:tab',{detail:n}));return n}
function tab(n){n=applyTabState(n);try{localStorage.setItem('alislah_active_tab',n)}catch(_){} }
let lastSyncedTab='';function syncActiveTab(){try{window.__alislahSync&&window.__alislahSync();const n=localStorage.getItem('alislah_active_tab');if(n&&n!==lastSyncedTab&&document.getElementById(n)){lastSyncedTab=n;if(document.body.dataset.view!==n)applyTabState(n)}else if(!n&&document.body.dataset.view)lastSyncedTab=document.body.dataset.view}catch(_){}}
setInterval(syncActiveTab,650);document.addEventListener('alislah:tab',e=>{lastSyncedTab=e.detail});
$$('.tab').forEach(b=>b.onclick=()=>{tab(b.dataset.tab);if(b.dataset.tab==='behavior')renderUsage()});
// Basic horizontal swipe navigation between the four primary views.
// Form controls and horizontal gestures beginning on interactive content are intentionally ignored.
(()=>{
  const swipeTabs=['tasks','habits','prayer','family','more','dashboard','assistant','behavior','worship','adhkar','qibla','calendar','report','focustimer','settings'];let start=null;
  const interactive='input,textarea,select,button,a,summary,video,[contenteditable="true"],.no-swipe';
  document.addEventListener('touchstart',e=>{
    const t=e.touches&&e.touches[0],view=e.target&&e.target.closest?e.target.closest('.view.active'):null;
    if(!t||!view||e.target.closest(interactive)){start=null;return;}
    start={x:t.clientX,y:t.clientY,view:view.id};
  },{passive:true});
  document.addEventListener('touchend',e=>{
    if(!start)return;const t=e.changedTouches&&e.changedTouches[0],from=start;start=null;
    if(!t||document.body.dataset.view!==from.view)return;
    const dx=t.clientX-from.x,dy=t.clientY-from.y;
    if(Math.abs(dx)<82||Math.abs(dx)<Math.abs(dy)*1.35)return;
    const at=swipeTabs.indexOf(from.view);if(at<0)return;
    const next=swipeTabs[Math.max(0,Math.min(swipeTabs.length-1,at+(dx<0?1:-1)))];
    if(next!==from.view)tab(next);
  },{passive:true});
  document.addEventListener('touchcancel',()=>{start=null;},{passive:true});
})();
$('#date').textContent=new Intl.DateTimeFormat('ar-DZ',{dateStyle:'full'}).format(new Date());$('#taskDate').value=today();

function currentBehavior(){
  return {
    mood:Number($('#mood').value||3),
    energy:Number($('#energy').value||3),
    focus:Number($('#focus').value||3),
    sleepHours:Math.max(0,Math.min(24,Number($('#sleepHours').value||0))),
    phoneMinutes:$('#phoneMinutes').value===''?null:Math.max(0,Math.min(1440,Number($('#phoneMinutes').value))),
    note:$('#behaviorNote').value.trim().slice(0,700),
    updatedAt:new Date().toISOString()
  };
}
function behaviorLabel(n,low,mid,high){return n<=2?low:(n===3?mid:high)}
function renderBehavior(){
  const keys=Object.keys(data.behavior||{}).sort().slice(-7).reverse();
  const todayEntry=data.behavior[today()];
  if(todayEntry){
    $('#mood').value=String(todayEntry.mood||3);
    $('#energy').value=String(todayEntry.energy||3);
    $('#focus').value=String(todayEntry.focus||3);
    $('#sleepHours').value=todayEntry.sleepHours??7;
    $('#phoneMinutes').value=todayEntry.phoneMinutes==null?'':todayEntry.phoneMinutes;
    $('#behaviorNote').value=todayEntry.note||'';
  }
  const summary=$('#behaviorSummary');
  if(!todayEntry){summary.innerHTML='<div class="empty">لم تحفظي مؤشرات اليوم بعد.</div>';}
  else {
    const phone=todayEntry.phoneMinutes==null?'لم يُسجّل':`${todayEntry.phoneMinutes} دقيقة`;
    summary.innerHTML=[
      `<div class="item"><div class="grow"><div class="title">المزاج</div><div class="muted">${behaviorLabel(todayEntry.mood,'صعب','عادي','جيد')}</div></div></div>`,
      `<div class="item"><div class="grow"><div class="title">الطاقة والتركيز</div><div class="muted">الطاقة ${todayEntry.energy}/5 · التركيز ${todayEntry.focus}/5</div></div></div>`,
      `<div class="item"><div class="grow"><div class="title">النوم واستعمال الهاتف</div><div class="muted">${todayEntry.sleepHours} ساعة نوم · ${phone}</div></div></div>`
    ].join('');
  }
  const hist=$('#behaviorHistory');
  hist.innerHTML=keys.length?keys.map(k=>{
    const b=data.behavior[k], phone=b.phoneMinutes==null?'غير مسجل':`${b.phoneMinutes} د`;
    return `<div class="item"><div class="grow"><div class="title">${esc(k)}</div><div class="muted">المزاج ${esc(b.mood)}/5 · الطاقة ${esc(b.energy)}/5 · التركيز ${esc(b.focus)}/5 · النوم ${esc(b.sleepHours)} س · الهاتف ${esc(phone)}</div>${b.note?`<div>${esc(b.note)}</div>`:''}</div></div>`;
  }).join(''):'<div class="empty">لا توجد سجلات بعد.</div>';
  renderLiveInsights();
}

function getProductivityMetrics(){
  const day=today(),tasks=Array.isArray(data.tasks)?data.tasks:[];
  const due=tasks.filter(t=>(t.date||day)===day),done=due.filter(t=>!!(t.done||t.completed||t.status==='done'));
  const overdue=tasks.filter(t=>!t.done&&!t.completed&&t.status!=='done'&&t.date&&t.date<day);
  const checks=data.checks[day]||{},habitDone=(data.habits||[]).filter(h=>!!checks[h.id]).length;
  const days=Object.keys(data.behavior||{}).sort().slice(-7).map(k=>data.behavior[k]).filter(Boolean);
  const avg=key=>days.length?Math.round(days.reduce((a,x)=>a+(Number(x[key])||0),0)/days.length*10)/10:null;
  const usage=getNativeUsage(),topApps=usage.permission?(usage.apps||[]).slice(0,3).map(a=>({name:String(a.name||a.packageName||'تطبيق').slice(0,60),minutes:Math.max(0,Math.round(Number(a.minutes)||0))})):[];
  return {date:day,tasksToday:{total:due.length,done:done.length,pending:due.length-done.length},overdueTasks:overdue.length,habits:{total:(data.habits||[]).length,done:habitDone},behaviorDays:days.length,averageFocus:avg('focus'),averageEnergy:avg('energy'),averageSleepHours:avg('sleepHours'),usagePermission:!!usage.permission,topApps};
}
function renderLiveInsights(){
  const target=$('#liveInsights');if(!target)return;
  const m=getProductivityMetrics(),items=[];
  if(m.tasksToday.total)items.push(`أنجزت ${m.tasksToday.done} من ${m.tasksToday.total} مهام اليوم، والمتبقي ${m.tasksToday.pending}.`);
  else items.push('لا توجد مهام مسجلة لهذا اليوم حتى الآن.');
  if(m.overdueTasks)items.push(`هناك ${m.overdueTasks} مهام متأخرة بحسب تواريخها المسجلة.`);
  if(m.habits.total)items.push(`أنجزت ${m.habits.done} من ${m.habits.total} عادات اليوم.`);
  if(m.behaviorDays)items.push(`متوسط التركيز المسجل خلال ${m.behaviorDays} أيام: ${m.averageFocus}/5، ومتوسط الطاقة: ${m.averageEnergy}/5.`);
  if(m.usagePermission&&m.topApps.length)items.push(`أعلى وقت ظاهر اليوم: ${m.topApps[0].name} — ${m.topApps[0].minutes} دقيقة تقريبًا.`);
  const advice=[];
  if(m.overdueTasks)advice.push('اختر مهمة متأخرة واحدة فقط، وحدد لها 15 دقيقة للبدء بدل محاولة إنجازها كلها دفعة واحدة.');
  else if(m.tasksToday.pending>0)advice.push('ابدأ بالمهمة الأهم المتبقية، وأبعد المشتتات لمدة 20 دقيقة ثم خذ استراحة قصيرة.');
  else if(m.tasksToday.done>0)advice.push('أحسنت؛ راجع ما أنجزته ولا تضف مهامًا جديدة إلا إذا بقي لديك وقت وطاقة.');
  if(m.habits.total&&m.habits.done<m.habits.total)advice.push('اختر عادة واحدة متبقية ونفذ أصغر خطوة منها الآن.');
  if(m.behaviorDays>=3&&m.averageFocus!==null&&m.averageFocus<=2.5)advice.push('تشير سجلاتك الذاتية الأخيرة إلى تركيز منخفض نسبيًا؛ جرّب جلسة قصيرة من 10–15 دقيقة مع راحة، ثم قيّم النتيجة.');
  if(m.usagePermission&&m.topApps[0]&&m.topApps[0].minutes>=120)advice.push(`سجل الهاتف نحو ساعتين أو أكثر في ${m.topApps[0].name} اليوم؛ راجع هل كان ذلك مقصودًا، دون افتراض سبب الاستخدام.`);
  if(!advice.length)advice.push('سجّل مهامك وعاداتك بانتظام حتى تصبح النصائح أدق وتعتمد على بيانات أكثر.');
  target.innerHTML='<div class="item"><div class="grow"><div class="title">ما تقوله بياناتك الآن</div><div class="muted">'+items.map(esc).join('<br>')+'</div></div></div><div class="item"><div class="grow"><div class="title">اقتراح عملي</div><div class="muted">'+advice.map(esc).join('<br>')+'</div></div></div><div class="muted" style="padding:6px 2px">تحليل محلي تقريبي؛ لا يُرسل إلى الإنترنت تلقائيًا ولا يمثل تشخيصًا.</div>';
}
function getAutoContext(){
  if(!data.settings.autoShareUsage) return '';
  const u=getNativeUsage();
  const usage={permission:!!u.permission,apps:(u.apps||[]).slice(0,12).map(a=>({app:String(a.name||'').slice(0,80),minutes:Math.max(0,Math.min(1440,Number(a.minutes)||0))})),foreground:u.foreground&&u.foreground.name?String(u.foreground.name).slice(0,80):'غير متاح',days:(data.usageProfile.snapshots||[]).slice(-7).map(x=>({date:x.date,foreground:x.foreground,apps:(x.apps||[]).slice(0,8)}))};
  const metrics=getProductivityMetrics();
  const habitNames=(data.habits||[]).map(h=>({habit:String(h.text||'').slice(0,80),done:!!((data.checks[today()]||{})[h.id])}));
  const behavior=(data.behavior||{});
  const recentBehavior=Object.keys(behavior).sort().slice(-7).map(k=>({date:k,mood:behavior[k].mood,energy:behavior[k].energy,focus:behavior[k].focus,sleepHours:behavior[k].sleepHours}));
  const taskPreview=(data.tasks||[]).filter(t=>!t.done).sort((a,b)=>String(a.date||'').localeCompare(String(b.date||''))).slice(0,12).map(t=>({text:String(t.text||'').slice(0,120),date:t.date||null,time:t.time||null,priority:t.priority||'عادية'}));
  return 'ملخص سلوكي اختياري وافق المستخدم على مشاركته تلقائيًا مع هذا الطلب: '+JSON.stringify({usage,metrics,habitNames,recentBehavior,taskPreview})+'. استخدمه لبناء نصيحة عملية محددة، ولا تستنتج معلومات حساسة أو تشخّص المستخدم. اذكر أن إحصاءات الهاتف تقريبية ولا تدّع مراقبة مستمرة.';
}
function getNativeUsage(){
  try{
    if(!window.AndroidUsage || typeof window.AndroidUsage.getUsageStatsJson!=='function') return {available:false,permission:false,apps:[],foreground:null};
    const raw=window.AndroidUsage.getUsageStatsJson();
    const parsed=JSON.parse(raw||'{}');
    return {available:true,permission:!!parsed.permission,apps:Array.isArray(parsed.apps)?parsed.apps:[],foreground:parsed.foreground||null,collectedAt:Number(parsed.collectedAt)||Date.now()};
  }catch(e){return {available:false,permission:false,apps:[],foreground:null,error:String(e)}}
}
function renderUsage(recordSnapshot=false){
  const target=$('#usageSummary'); if(!target)return;
  const u=getNativeUsage();
  if(!u.available){
    target.innerHTML='<div class="empty">إحصاءات التطبيقات متاحة داخل نسخة أندرويد الأصلية، وليست في صفحة الويب وحدها.</div>';
    renderLiveInsights();return;
  }
  if(!u.permission){
    target.innerHTML='<div class="empty">لم تُمنح صلاحية إحصاءات الاستخدام بعد. اضغطي زر منح الصلاحية، ثم ارجعي للتطبيق.</div>';
    renderLiveInsights();return;
  }
  const fg=u.foreground;
  const fgHtml=fg&&fg.name&&fg.name!=='غير متاح'?`<div class="item"><div class="grow"><div class="title">التطبيق النشط الأخير (تقديري)</div><div>${esc(fg.name)}</div><div class="muted">آخر انتقال مسجّل؛ قد لا يطابق التطبيق المفتوح في هذه اللحظة تمامًا.</div></div></div>`:'';
  if(recordSnapshot){
    const snap={date:today(),at:new Date(u.collectedAt||Date.now()).toISOString(),foreground:fg&&fg.name?fg.name:'غير متاح',apps:u.apps.slice(0,12).map(a=>({app:a.name||a.packageName,minutes:Math.max(0,Math.round(Number(a.minutes)||0))}))};
    const snapshots=data.usageProfile.snapshots.filter(x=>x.date!==snap.date);snapshots.push(snap);data.usageProfile.snapshots=snapshots.slice(-14);save();
  }
  if(!u.apps.length){
    target.innerHTML=fgHtml+'<div class="empty">لا توجد إحصاءات يومية كافية بعد. استخدمي الهاتف ثم اضغطي تحديث.</div>';
    renderLiveInsights();return;
  }
  target.innerHTML=fgHtml+u.apps.slice(0,12).map(a=>{
    const mins=Math.max(0,Math.round(Number(a.minutes)||0));
    const label=esc(a.name||a.packageName||'تطبيق');
    return `<div class="item"><div class="grow"><div class="title">${label}</div><div class="muted">${mins>=60?Math.floor(mins/60)+' س ':''}${mins%60} د اليوم</div></div></div>`;
  }).join('');
  renderLiveInsights();
}
$('#refreshUsage').onclick=()=>{renderUsage(true);toast('تم تحديث الإحصاءات وحفظ ملخص محلي لهذا اليوم')};
$('#grantUsage').onclick=()=>{
  try{
    if(window.AndroidUsage&&typeof window.AndroidUsage.requestUsagePermission==='function')window.AndroidUsage.requestUsagePermission();
    else toast('افتحي التطبيق الأصلي على أندرويد لمنح الصلاحية');
  }catch(e){toast('تعذر فتح إعدادات الصلاحية')}
};
$('#behaviorForm').onsubmit=e=>{
  e.preventDefault();
  data.behavior[today()]=currentBehavior();
  save();renderBehavior();toast('تم حفظ مؤشرات اليوم على هذا الجهاز');
};
function makeBehaviorPrompt(){
  const days=Object.keys(data.behavior||{}).sort().slice(-7).map(d=>({date:d,...data.behavior[d]}));
  const tasksToday=data.tasks.filter(t=>t.date===today());
  const habitsToday=data.habits.map(h=>({habit:h.text,done:!!(data.checks[today()]||{})[h.id]}));
  const nativeUsage=getNativeUsage();
  const appUsage=nativeUsage.available&&nativeUsage.permission?nativeUsage.apps.slice(0,12).map(a=>({app:a.name||a.packageName,minutes:Math.max(0,Math.round(Number(a.minutes)||0))})):[];
  const foreground=nativeUsage.available&&nativeUsage.permission&&nativeUsage.foreground?{app:nativeUsage.foreground.name||'غير متاح',approximate:true,lastSeenAt:nativeUsage.foreground.lastSeenAt||null}:null;
  const usageSnapshots=(data.usageProfile?.snapshots||[]).slice(-7);
  return `حلّل البيانات التالية التي اختار المستخدم تسجيلها في تطبيق ALISLAH، وقدّم إرشادًا عمليًا متوازنًا وخطة يومية قابلة للتنفيذ. لا تشخّص حالة صحية ولا تستنتج أكثر مما تدعمه البيانات. اذكر حدود البيانات واسأل سؤالًا توضيحيًا عند الحاجة. تعامل مع اسم التطبيق النشط على أنه تقديري وليس مراقبة دقيقة مستمرة، ولا تستنتج محتوى ما يفعله المستخدم داخل التطبيق.
سجلات المؤشرات اليومية لآخر 7 أيام: ${JSON.stringify(days)}
مهام اليوم: ${JSON.stringify(tasksToday.map(t=>({text:t.text,priority:t.priority,done:t.done})))}
العادات وحالة إنجازها اليوم: ${JSON.stringify(habitsToday)}
إحصاءات التطبيقات اليوم (محلية وتُضمّن فقط عند الموافقة على الإرسال): ${JSON.stringify(appUsage)}
التطبيق النشط الأخير وفق سجل أندرويد (تقديري): ${JSON.stringify(foreground)}
ملخصات استخدام محفوظة محليًا لآخر 7 أيام: ${JSON.stringify(usageSnapshots)}
المطلوب: 1) لخّص الأنماط الظاهرة بحذر واذكر ما البيانات الناقصة. 2) حدّد نقطة قوة ونقطة تحسين مدعومتين بالبيانات. 3) أنشئ خطة عملية لمدة 7 أيام، وكل يوم بعنوان مستقل «اليوم 1:» إلى «اليوم 7:». تحت كل يوم اكتب 2 إلى 4 مهام قابلة للقياس، كل مهمة في سطر مستقل يبدأ برقم ثم نقطة مثل «1. **اسم المهمة** — وصف عملي ومدة محددة». لا تضع العنوان العام أو النصائح كمهمة. 4) اجعل كل مهمة مستقلة قابلة للتأشير والإنجاز، مع اقتراح وقت مناسب. 5) لا تعتبر مدة الهاتف اليدوية قياسًا تلقائيًا ولا تخترع بيانات غير موجودة.`;
}
$('#analyzeBehavior').onclick=()=>{
  const usageNow=getNativeUsage();
  if(!Object.keys(data.behavior||{}).length && !(usageNow.permission&&usageNow.apps.length) && !(data.usageProfile?.snapshots||[]).length){toast('سجّلي مؤشرات يوم أو فعّلي إحصاءات التطبيقات واضغطي تحديث أولًا');return;}
  if(!$('#analysisConsent').checked){toast('فعّلي الموافقة أولًا للسماح بإرسال ملخص البيانات للتحليل');return;}
  tab('assistant');
  $('#chatText').value=makeBehaviorPrompt();
  $('#chatText').dataset.includesPersonalAnalysis='true';
  $('#chatText').focus();
  toast('راجعي النص؛ لن يُرسل إلا بعد ضغطك على إرسال');
};
$('#deleteBehavior').onclick=async()=>{
  if(await ui.confirm('حذف سجلات التحليل؟','حذف',true,'لا يمكن التراجع عن ذلك.')){
    data.behavior={};save();renderBehavior();toast('تم حذف سجلات التحليل');
  }
};

function scheduleTaskReminder(t){try{if(!t||!t.time||!t.date||t.done||!window.AndroidUsage||typeof AndroidUsage.scheduleTaskReminder!=='function')return;const when=new Date(t.date+'T'+t.time+':00').getTime();if(Number.isFinite(when)&&when>Date.now())AndroidUsage.scheduleTaskReminder(String(t.id),String(t.text).slice(0,160),when)}catch(_){}}

function cloneData(value){try{return JSON.parse(JSON.stringify(value))}catch(_){return null}}
function refreshUndoButton(){const b=$('#undoLast');if(b)b.disabled=!Array.isArray(data.undoStack)||!data.undoStack.length}
function recordUndo(label,keys){
  const allowed=Array.isArray(keys)&&keys.length?keys:['tasks','habits','checks'];
  const snapshot={};
  allowed.forEach(key=>{if(['tasks','habits','checks','family','behavior','worship','focus','idea'].includes(key))snapshot[key]=cloneData(data[key])});
  if(!Object.keys(snapshot).length)return false;
  data.undoStack=Array.isArray(data.undoStack)?data.undoStack:[];
  const actionLabel=String(label||'إجراء سابق').slice(0,100);
  data.undoStack.push({label:actionLabel,at:Date.now(),snapshot});
  data.undoStack=data.undoStack.slice(-20);
  data.activityLog=Array.isArray(data.activityLog)?data.activityLog:[];data.activityLog.unshift({id:uid(),label:actionLabel,detail:'إجراء محفوظ للتراجع',at:Date.now()});data.activityLog=data.activityLog.slice(0,100);
  save();refreshUndoButton();return true;
}
function undoLastAction(){
  if(!Array.isArray(data.undoStack)||!data.undoStack.length){toast('لا يوجد إجراء حديث للتراجع عنه');return false;}
  const entry=data.undoStack.pop(),snapshot=entry&&entry.snapshot;
  if(!snapshot||typeof snapshot!=='object'){save();refreshUndoButton();toast('تعذر استعادة الإجراء السابق');return false;}
  const currentTasks=Array.isArray(data.tasks)?data.tasks:[];
  currentTasks.forEach(t=>cancelTaskReminder(t.id));
  Object.keys(snapshot).forEach(key=>{if(['tasks','habits','checks','family','behavior','worship','focus','idea'].includes(key))data[key]=cloneData(snapshot[key])});
  data.tasks=Array.isArray(data.tasks)?data.tasks:[];data.habits=Array.isArray(data.habits)?data.habits:[];data.checks=data.checks&&typeof data.checks==='object'?data.checks:{};
  data.tasks.forEach(scheduleTaskReminder);
  data.activityLog=Array.isArray(data.activityLog)?data.activityLog:[];data.activityLog.unshift({id:uid(),label:'تراجع عن: '+String(entry.label||'الإجراء السابق').slice(0,70),detail:'استُعيدت الحالة السابقة',at:Date.now()});data.activityLog=data.activityLog.slice(0,100);
  save();renderTasks();renderHabits();stats();
  try{window.__alislahResync&&window.__alislahResync()}catch(_){}
  refreshUndoButton();toast('تم التراجع عن: '+String(entry.label||'الإجراء السابق'));return true;
}
async function ensureTaskTimeAvailable(task,excludeId){
  const planner=window.ALISLAHTaskPlanner;
  if(!planner||!task||!task.time||!task.date)return true;
  const overlaps=planner.conflicts(task,data.tasks,excludeId);
  if(!overlaps.length)return true;
  const next=planner.findNextSlot(data.tasks,task.date,task.time,task.durationMin||30,Date.now(),excludeId);
  const names=overlaps.slice(0,3).map(x=>String(x.text||'مهمة أخرى')).join('، ');
  const message='هذا الموعد يتعارض مع: '+names+'.'+(next?'\nالوقت البديل المتاح: '+next+'.':'\nلا توجد فترة خالية في هذا اليوم ضمن ساعات الجدولة.');
  if(!next){toast(message);return false;}
  const accepted=await ui.confirm('تعارض في مواعيد المهام','استخدم '+next,false,message);
  if(!accepted)return false;
  task.time=next;return true;
}
function createPlannedTasks(items,source){
  const planner=window.ALISLAHTaskPlanner;if(!planner||!Array.isArray(items)||!items.length)return 0;
  const now=new Date();let targetDate=today();
  let preferred=now.getHours()<8?'09:00':now.getHours()>=21? '09:00':String(Math.ceil((now.getHours()*60+now.getMinutes()+5)/15)*15).padStart(4,'0');
  if(preferred.length===4)preferred=preferred.slice(0,2)+':'+preferred.slice(2);
  if(now.getHours()>=21)targetDate=planner.addDays(targetDate,1);
  const slots=['09:00','11:00','14:00','16:00','18:00'];
  if(now.getHours()<8)preferred=slots[0];
  let created=0,skipped=0;
  recordUndo('إضافة مهام من الخطة');
  for(let i=0;i<items.length;i++){
    let found=null;
    for(let dayOffset=0;dayOffset<30&&!found;dayOffset++){
      const date=dayOffset?planner.addDays(targetDate,dayOffset):targetDate;
      const base=dayOffset?'09:00':preferred;
      const time=planner.findNextSlot(data.tasks,date,base,30,Date.now());
      if(time)found={date,time};
    }
    if(!found){skipped++;continue;}
    const text=String(items[i]||'').trim().slice(0,180);if(!text){skipped++;continue;}
    const task={id:uid(),text,date:found.date,time:found.time,priority:/عاجل|ضروري|مهم جدًا|أولوية قصوى/i.test(text)?'مهمة جدًا':i<2?'مهمة جدًا':'عادية',cat:categoryForTask(text),done:false,source:source||'assistant-plan',durationMin:30};
    data.tasks.push(task);scheduleTaskReminder(task);created++;
    const mins=planner.toMinutes(found.time)+90;
    if(mins<=21*60)preferred=planner.toTime(mins);
    else {targetDate=planner.addDays(found.date,1);preferred='09:00';}
  }
  save();renderTasks();
  if(created)toast('أُضيفت '+created+' مهام مجدولة دون تعارض.');
  if(skipped)toast('تعذر جدولة '+skipped+' عناصر؛ راجعيها يدويًا.');
  return created;
}
function categoryForTask(text){
  if(/عمل|وظيف|مشروع|مكتب|اجتماع|عميل|مهنة/i.test(text))return 'عمل';
  if(/بيت|تنظيف|ترتيب|مطبخ|غسيل|تسوق|مشتريات/i.test(text))return 'بيت';
  if(/أسرة|عائلة|طفل|أطفال|زوج|زوجة|زيارة|أهل/i.test(text))return 'أسرة';
  if(/صحة|طبيب|دواء|رياضة|مشي|نوم|راحة|ماء/i.test(text))return 'صحة';
  if(/دراسة|قراءة|تعلم|درس|مراجعة|حفظ|كتابة/i.test(text))return 'دراسة';
  if(/صلاة|قرآن|ذكر|عبادة|دعاء|ورد/i.test(text))return 'عبادة';
  return 'أخرى';
}
function runDailyAutoReschedule(){
  const planner=window.ALISLAHTaskPlanner;if(!planner||data.lastAutoRescheduleDate===today())return;
  const candidate=cloneData(data.tasks)||[];
  const changes=planner.rescheduleOverdue(candidate,today(),Date.now());
  data.lastAutoRescheduleDate=today();
  if(changes.length){
    recordUndo('إعادة جدولة المهام المتأخرة');
    data.tasks=candidate;
    changes.forEach(change=>{cancelTaskReminder(change.id);const task=data.tasks.find(t=>t.id===change.id);if(task)scheduleTaskReminder(task)});
    save();renderTasks();
    const shown=changes.slice(0,3).map(x=>x.text+' إلى '+x.to.date+' '+x.to.time).join('؛ ');
    toast('أُعيدت جدولة '+changes.length+' مهام متأخرة. يمكنك التراجع. '+shown);
  } else save();
}

function extractPlanTasks(reply){
  const lines=String(reply||'').replace(/\r/g,'').split('\n').map(x=>x.trim()).filter(Boolean);
  const result=[]; let current=null; let inPlan=false;
  const cleanText=x=>String(x||'').replace(/^\s*#+\s*/,'').replace(/\*{1,2}/g,'').replace(/`/g,'').replace(/\s+/g,' ').trim();
  const isTitle=x=>/^(?:خطة\s*(?:يومية|شخصية|أسبوعية|مختصرة)?|ملخص الخطة|الخطة المقترحة)(?:\s*\([^)]*\))?\s*[:：-]?$/i.test(cleanText(x));
  const isDay=x=>/^(?:اليوم\s*(?:\d+|الأول|الأولى|الثاني|الثانية|الثالث|الثالثة|الرابع|الرابعة|الخامس|الخامسة|السادس|السادسة|السابع|السابعة))\s*[:：-]?/i.test(cleanText(x));
  const isBullet=x=>/^(?:[-*•▪◦]\s+|\d{1,3}\s*[.)、:：-]\s+)/.test(x);
  const strip=x=>cleanText(x.replace(/^(?:[-*•▪◦]\s+|\d{1,3}\s*[.)、:：-]\s+)/,''));
  const flush=()=>{if(current){let t=cleanText(current).replace(/^[—–:؛,\s]+|[—–:؛,\s]+$/g,'');if(t.length>=5&&t.length<=360&&!result.some(x=>x.toLocaleLowerCase('ar')===t.toLocaleLowerCase('ar')))result.push(t);current=null;}};
  for(let line of lines){
    line=line.replace(/^\s*#+\s*/,'').trim(); const plain=cleanText(line);
    if(!plain||/^[-*_]{3,}$/.test(line))continue;
    if(isTitle(line)){inPlan=true;flush();continue;}
    if(isDay(line)){inPlan=true;flush();continue;}
    if(/^(?:ملاحظة|نصائح عامة|الخلاصة|مؤشر التقدم|نقطة القوة|نقطة التحسين|تحليل البيانات|الأنماط الظاهرة)\b/i.test(plain)){flush();continue;}
    if(isBullet(line)){
      const numbered=/^\d{1,3}\s*[.)、:：-]\s+/.test(line);
      const content=strip(line);
      if(!content)continue;
      if(numbered){flush();current=content;inPlan=true;}
      else if(current){current+=' — '+content;}
      else {current=content;inPlan=true;}
      continue;
    }
    // Keep wrapped description lines with the current task, but do not turn explanatory prose into tasks.
    if(current && !/^(?:إذا|ملاحظة|تذكري|تذكّر|الهدف|لماذا|مؤشر النجاح)\b/i.test(plain))current+=' '+plain;
    else if(inPlan && /^(?:المهمة|نشاط|تمرين)\s*\d+/i.test(plain)){flush();current=plain;}
  }
  flush();
  return result;
}
async function autoCreateTasksFromPlan(prompt,reply){
  if(!/خطة|خطّة|خطط|جدول يوم|نظّم لي يوم|نظم لي يوم|مهام اليوم|خطة يومية|خطة شخصية|خطة أسبوعية/i.test(String(prompt||'')))return 0;
  const clean=extractPlanTasks(reply);
  if(!clean.length)return 0;
  const norm=x=>String(x||'').toLocaleLowerCase('ar').replace(/[\s\u0640.,،؛:!?؟()\[\]{}'"ـ-]/g,'');
  const existing=new Set(data.tasks.filter(t=>!t.done).map(t=>norm(t.text)));
  const unique=clean.filter(t=>{const key=norm(t);if(!key||existing.has(key))return false;existing.add(key);return true;});
  if(!unique.length){toast('لم أضف مهامًا مكررة؛ لا توجد خطوات جديدة في الخطة.');return 0;}
  const created=createPlannedTasks(unique,'assistant-plan');
  return created;
}

function cancelTaskReminder(id){try{if(window.AndroidUsage&&typeof AndroidUsage.cancelTaskReminder==='function')AndroidUsage.cancelTaskReminder(String(id))}catch(_){}}
const CATS=['عمل','بيت','أسرة','صحة','دراسة','عبادة','أخرى'],REPEATS={daily:'يوميًا',weekly:'أسبوعيًا',monthly:'شهريًا'};
let taskFilter='soon',taskCat='';
function nextDate(ds,rep){const p=ds.split('-').map(Number);if(rep==='daily')return ymd(new Date(p[0],p[1]-1,p[2]+1));if(rep==='weekly')return ymd(new Date(p[0],p[1]-1,p[2]+7));if(rep==='monthly'){const first=new Date(p[0],p[1],1),last=new Date(first.getFullYear(),first.getMonth()+1,0).getDate();return ymd(new Date(first.getFullYear(),first.getMonth(),Math.min(p[2],last)))}return ds}
function completeTask(t,done){t.done=done;if(done){t.doneAt=today();logActivity('إنجاز مهمة',t.text);cancelTaskReminder(t.id);if(t.repeat&&REPEATS[t.repeat]&&!t.spawned){const base=(t.date||today())<today()?today():(t.date||today()),nd=nextDate(base,t.repeat);if(!data.tasks.some(x=>!x.done&&x.text===t.text&&x.repeat===t.repeat&&x.date===nd)){const n={id:uid(),text:t.text,date:nd,time:t.time||'',priority:t.priority||'عادية',cat:t.cat||'',repeat:t.repeat,done:false};data.tasks.push(n);scheduleTaskReminder(n)}t.spawned=true}}else{delete t.doneAt;scheduleTaskReminder(t)}}
function renderTasks(){const now=today();const maxDate=ymd(new Date(Date.now()+7*86400000));
let ts=data.tasks.slice();
if(taskCat)ts=ts.filter(t=>(t.cat||'')===taskCat);
if(taskFilter==='soon')ts=ts.filter(t=>String(t.date||now)<=maxDate&&(!t.done||t.date===now));else if(taskFilter==='done')ts=ts.filter(t=>t.done);
ts.sort(taskFilter==='done'?(a,b)=>String(b.doneAt||b.date||'').localeCompare(String(a.doneAt||a.date||'')):(a,b)=>Number(a.done)-Number(b.done)||String(a.date||now).localeCompare(String(b.date||now))||String(a.time||'99:99').localeCompare(String(b.time||'99:99')));
$('#count').textContent=ts.length+(ts.length===1?' مهمة':' مهام');
$$('#taskFilter button').forEach(b=>b.classList.toggle('on',b.dataset.f===taskFilter));
const empty={soon:'لا توجد مهام قريبة. أضيفي مهمة أو أنشئي خطة من المساعد',all:'لا توجد مهام بعد. ابدئي بإضافة أول مهمة',done:'لم تُنجزي مهامًا بعد، خطوة صغيرة تكفي'}[taskFilter];
$('#tasksList').innerHTML=ts.length?ts.map(t=>{const d=t.date||now,over=!t.done&&d<now,when=d===now?'اليوم':d===ymd(new Date(Date.now()+86400000))?'غدًا':d;const pr=t.priority||'عادية',pc=pr==='مهمة جدًا'?'gold':pr==='يمكن تأجيلها'?'gray':'',conflict=!!(window.ALISLAHTaskPlanner&&window.ALISLAHTaskPlanner.conflicts(t,data.tasks,t.id).length);return `<div class="item ${t.done?'done':''} ${over?'overdue':''}"><input class="check tc" type="checkbox" data-id="${esc(t.id)}" ${t.done?'checked':''} aria-label="إنجاز: ${esc(t.text)}"><div class="grow"><div class="title">${esc(t.text)}</div><div class="meta"><span class="chip ${pc}">${esc(pr)}</span><span class="chip gray">📅 ${esc(when)}</span>${t.time?`<span class="chip gray">⏰ ${esc(t.time)}</span>`:''}${t.cat?`<span class="chip">🏷️ ${esc(t.cat)}</span>`:''}${REPEATS[t.repeat]?`<span class="chip gray">🔁 ${esc(REPEATS[t.repeat])}</span>`:''}${over?'<span class="chip red">متأخرة</span>':''}${conflict?'<span class="chip red">تعارض موعد</span>':''}</div></div><button class="mini edittask" type="button" data-id="${esc(t.id)}" aria-label="تعديل المهمة">✏️</button><button class="mini del deltask" type="button" data-id="${esc(t.id)}" aria-label="حذف المهمة">🗑️</button></div>`}).join(''):`<div class="empty"><span class="ei">🌱</span>${empty}</div>`;
$('#clearDone').classList.toggle('hidden',!data.tasks.some(t=>t.done));refreshUndoButton();
$$('.tc').forEach(c=>c.onchange=()=>{let t=data.tasks.find(x=>x.id===c.dataset.id);if(t){recordUndo(c.checked?'إنجاز مهمة':'إعادة فتح مهمة');completeTask(t,c.checked)}save();renderTasks();if(typeof renderHabits==='function')stats()});
$$('.deltask').forEach(b=>b.onclick=async()=>{const t=data.tasks.find(x=>x.id===b.dataset.id);if(!t)return;if(!(await ui.confirm('حذف المهمة؟','حذف',true,t.text)))return;recordUndo('حذف مهمة');cancelTaskReminder(t.id);data.tasks=data.tasks.filter(x=>x.id!==t.id);save();renderTasks()});
$$('.edittask').forEach(b=>b.onclick=()=>{const t=data.tasks.find(x=>x.id===b.dataset.id);if(t)openTaskSheet(t)});
const todayTasks=data.tasks.filter(t=>(t.date||now)===now);let done=todayTasks.filter(t=>t.done).length;const pct=todayTasks.length?done/todayTasks.length*100:0;$('#progress').style.width=pct+'%';$('#progress').parentNode.setAttribute('aria-valuenow',Math.round(pct));$('#progressText').textContent=todayTasks.length?`أنجزتِ ${done} من ${todayTasks.length} مهام اليوم.`:'أضيفي مهامًا بموعد واضح لتتابعي تقدمك اليوم.'}
function openTaskSheet(t){const sh=$('#taskSheet');$('#etText').value=t.text;$('#etDate').value=t.date||today();$('#etTime').value=t.time||'';$('#etPriority').value=t.priority||'عادية';$('#etCat').value=t.cat||'';$('#etRepeat').value=t.repeat||'';sh.dataset.id=t.id;sh.classList.add('open');setTimeout(()=>$('#etText').focus(),60)}
$('#etCancel').onclick=()=>$('#taskSheet').classList.remove('open');
$('#taskSheet').addEventListener('click',e=>{if(e.target.id==='taskSheet')e.target.classList.remove('open')});
$('#etSave').onclick=async()=>{const sh=$('#taskSheet'),t=data.tasks.find(x=>x.id===sh.dataset.id);if(!t)return sh.classList.remove('open');const nt=$('#etText').value.trim().slice(0,180);if(!nt){toast('اكتبي نص المهمة');return}const proposed={...t,text:nt,date:$('#etDate').value||today(),time:$('#etTime').value||'',priority:$('#etPriority').value,cat:$('#etCat').value,repeat:$('#etRepeat').value,spawned:false};if(!(await ensureTaskTimeAvailable(proposed,t.id)))return;recordUndo('تعديل مهمة');cancelTaskReminder(t.id);Object.assign(t,proposed);scheduleTaskReminder(t);save();renderTasks();sh.classList.remove('open');toast('تم حفظ التعديل')};
$$('#taskFilter button').forEach(b=>b.onclick=()=>{taskFilter=b.dataset.f;renderTasks()});
$('#taskCatFilter').onchange=e=>{taskCat=e.target.value;renderTasks()};
$('#clearDone').onclick=async()=>{const n=data.tasks.filter(t=>t.done).length;if(!n)return;if(!(await ui.confirm('حذف المهام المنجزة؟','حذف',true,'سيتم حذف '+n+' مهام منجزة نهائيًا.')))return;recordUndo('حذف المهام المنجزة');data.tasks=data.tasks.filter(t=>!t.done);save();renderTasks();toast('تم الحذف')};
$('#undoLast').onclick=undoLastAction;
window.__alislahShowQuickTaskAction=function(mode){
  const planner=window.ALISLAHTaskPlanner,complete=mode==='complete';
  const pending=data.tasks.filter(t=>t&&!t.done&&!t.completed).slice().sort((a,b)=>String(a.date||today()).localeCompare(String(b.date||today()))||String(a.time||'99:99').localeCompare(String(b.time||'99:99'))).slice(0,15);
  if(!pending.length){toast('لا توجد مهام غير منجزة في القائمة.');return false;}
  const old=document.getElementById('alislahQuickTaskDialog');if(old)old.remove();
  const backdrop=document.createElement('div');backdrop.id='alislahQuickTaskDialog';backdrop.setAttribute('role','dialog');backdrop.setAttribute('aria-modal','true');
  backdrop.style.cssText='position:fixed;inset:0;z-index:2147483000;background:rgba(10,25,22,.62);display:flex;align-items:center;justify-content:center;padding:14px;box-sizing:border-box;';
  const panel=document.createElement('div');panel.style.cssText='width:min(100%,430px);max-height:82vh;overflow:auto;background:#fff;color:#18332d;border-radius:18px;padding:16px;box-shadow:0 16px 48px rgba(0,0,0,.28);direction:rtl;font-family:inherit;';
  const heading=document.createElement('h3');heading.textContent=complete?'اختاري المهمة التي أنجزتِها':'اختاري المهمة التي تريدين تأجيلها';heading.style.cssText='margin:0 0 8px;font-size:18px;';panel.appendChild(heading);
  const desc=document.createElement('p');desc.textContent=complete?'سيتم وضع علامة إنجاز وتحديث قائمة المهام.':'سيبحث التطبيق عن أول وقت خالٍ بعد ساعة، ويمكنك التراجع.';desc.style.cssText='margin:0 0 12px;color:#52645f;font-size:13px;';panel.appendChild(desc);
  pending.forEach(task=>{
    const row=document.createElement('button');row.type='button';row.style.cssText='display:block;width:100%;text-align:right;padding:12px;margin:7px 0;border:1px solid #dce7e2;border-radius:12px;background:#f7faf8;color:#163c32;font-size:14px;';
    const title=document.createElement('span');title.textContent=String(task.text||'مهمة').slice(0,150);title.style.cssText='display:block;font-weight:700;';row.appendChild(title);
    const meta=document.createElement('small');meta.textContent=[task.date||'دون تاريخ',task.time||'دون وقت'].join(' · ');meta.style.cssText='display:block;margin-top:4px;color:#63736d;';row.appendChild(meta);
    row.addEventListener('click',function(){
      const current=data.tasks.find(x=>String(x.id)===String(task.id));if(!current||current.done){backdrop.remove();toast('تغيرت حالة المهمة؛ حدّثي القائمة وحاولي مجددًا.');return;}
      if(complete){recordUndo('إنجاز مهمة من الفقاعة');completeTask(current,true);save();renderTasks();backdrop.remove();toast('تم إنجاز المهمة من الفقاعة.');return;}
      if(!planner){toast('أداة الجدولة غير متاحة حاليًا.');return;}
      const next=planner.findPostponeSlot(data.tasks,current,today(),Date.now(),60);if(!next){toast('لم أجد وقتًا خاليًا للتأجيل خلال الأيام الثلاثين القادمة.');return;}
      recordUndo('تأجيل مهمة من الفقاعة');cancelTaskReminder(current.id);current.date=next.date;current.time=next.time;scheduleTaskReminder(current);save();renderTasks();backdrop.remove();toast('تم تأجيل المهمة إلى '+next.date+' الساعة '+next.time+'.');
    });
    panel.appendChild(row);
  });
  const cancel=document.createElement('button');cancel.type='button';cancel.textContent='إلغاء';cancel.style.cssText='width:100%;padding:11px;margin-top:8px;border:0;border-radius:12px;background:#e9efec;color:#29443b;font-weight:700;';cancel.onclick=()=>backdrop.remove();panel.appendChild(cancel);
  backdrop.addEventListener('click',e=>{if(e.target===backdrop)backdrop.remove()});backdrop.appendChild(panel);document.body.appendChild(backdrop);cancel.focus();return true;
};

$('#taskForm').onsubmit=async e=>{e.preventDefault();let text=$('#taskText').value.trim();if(!text)return;const task={id:uid(),text,date:$('#taskDate').value||today(),time:$('#taskTime').value||'',priority:$('#priority').value,cat:$('#taskCat').value||'',repeat:$('#taskRepeat').value||'',done:false,durationMin:30};if(!(await ensureTaskTimeAvailable(task)))return;recordUndo('إضافة مهمة');data.tasks.push(task);logActivity('إضافة مهمة',task.text);scheduleTaskReminder(task);$('#taskText').value='';$('#taskDate').value=today();$('#taskTime').value='';$('#priority').value='عادية';$('#taskCat').value='';$('#taskRepeat').value='';save();renderTasks();toast(task.time?'أضيفت المهمة مع تذكير مجدول':'تمت إضافة المهمة؛ أضيفي وقتًا إذا أردتِ تذكيرًا');if(task.time)ensureNotif()};
function isTaskCreationIntent(value){const t=String(value||'').trim();return /(?:أضف|اضف|إضافة|اضافة|أنشئ|انشئ|سجّل|سجل|ذكّرني|ذكرني|لا تنس|لا تنسى|مهمة جديدة|أريد|اريد|إنجاز|انجاز|أنجز|انجز|تنفيذ|أقوم|اقوم).{0,110}(?:مهمة|مهام|تذكير|موعد|ذكرني|لا تنس)|(?:مهمة|مهمتي)\s+(?:جديدة|هي|لـ|ل|أن|ان)|(?:أريد|اريد)\s+(?:أن\s+)?(?:أنجز|انجز|إنجاز|انجاز|أنفذ|انفذ|أقوم|اقوم)\s+(?:ب?\s*)?مهمة|^(?:ذكّرني|ذكرني|لا تنس|لا تنسى)\s+.+$/i.test(t)}
function addVoiceTaskFromTranscript(raw,explicitlyConfirmed=false){
  const parser=window.ALISLAHVoiceTaskParser;
  const parsed=parser&&typeof parser.parse==='function'?parser.parse(raw):{taskText:String(raw||'').trim(),date:today(),time:'',hasTime:false};
  let text=String(parsed.taskText||raw||'').trim();
  text=text.replace(/^(?:(?:من فضلك|لو سمحت)\s*)?(?:(?:أريد|اريد)\s*(?:(?:أن|ان)\s*)?)?(?:(?:إنجاز|انجاز|أنجز|انجز|تنفيذ|إضافة|اضافة|إنشاء|انشاء|تسجيل|سجل|أقوم ب|اقوم ب|ذكّرني|ذكرني|لا تنس(?:ى)?)\s*)?(?:مهمة(?: جديدة)?\s*)?/i,'').replace(/^[\s،:؛-]+|[\s،:؛-]+$/g,'').trim().slice(0,180);
  if(!text){toast('لم أجد وصفًا واضحًا للمهمة؛ عدّل الطلب ثم أعد المحاولة');return 'empty'}
  const date=parsed.date||today(),time=parsed.time||'';
  const draft={text,date,time,hasTime:!!parsed.hasTime,createdAt:Date.now()};
  data.pendingVoiceTask=draft;save();
  bubble('user',String(raw||'').trim(),true,false);
  $('#voiceTaskText').value=text;$('#voiceTaskDate').value=date;$('#voiceTaskTime').value=time;
  $('#voiceTaskTitle').textContent=parsed.hasTime?'تأكيد المهمة الصوتية':'حددي وقت المهمة';
  const note=$('#voiceTaskSheet').querySelector('p');
  if(parsed.hasTime){
    const timestamp=new Date(date+'T'+time+':00').getTime();
    note.textContent=Number.isFinite(timestamp)&&timestamp>Date.now()?'راجعي اسم المهمة والتاريخ والوقت ثم أكدي الإضافة. لن تُحفظ قبل تأكيدك.':'الموعد الذي التقطه التطبيق قد مضى. عدّلي التاريخ أو الوقت إلى موعد قادم ثم أكدي الإضافة.';
  } else note.textContent='لم يُذكر وقت محدد. اختاري وقت تنفيذ المهمة ثم راجعي البيانات وأكدي الإضافة.';
  $('#voiceTaskSheet').classList.add('open');
  bubble('assistant',`فهمت أنك تريد تنفيذ «${text}». راجع المهمة وموعدها في نافذة التأكيد، ثم اضغط «إضافة المهمة» أو قل نعم بعد سماع السؤال.`);
  setTimeout(()=>$('#voiceTaskTime').focus(),100);
  return 'needs-confirmation';
}
async function saveVoiceTaskDraft(){
  const pending=data.pendingVoiceTask||{};
  const text=String($('#voiceTaskText').value||pending.text||'').trim().slice(0,180);
  const date=$('#voiceTaskDate').value||pending.date||today();
  const time=$('#voiceTaskTime').value||pending.time||'';
  if(!text){toast('اكتب نص المهمة');$('#voiceTaskText').focus();return false}
  if(!time){toast('حدّد وقت تنفيذ المهمة أولًا');$('#voiceTaskTime').focus();return false}
  const timestamp=new Date(date+'T'+time+':00').getTime();
  if(!Number.isFinite(timestamp)||timestamp<=Date.now()){toast('اختر وقتًا قادمًا للمهمة');$('#voiceTaskTime').focus();return false}
  const norm=x=>String(x||'').toLocaleLowerCase('ar').replace(/[\s\u0640.,،؛:!?؟()\[\]{}'"ـ-]/g,'');
  const key=norm(text);
  if(data.tasks.some(t=>!t.done&&norm(t.text)===key&&String(t.date||'')===date&&String(t.time||'')===time)){
    data.pendingVoiceTask=null;save();$('#voiceTaskSheet').classList.remove('open');bubble('assistant','هذه المهمة موجودة بالفعل في قائمتك بالموعد نفسه؛ لم أكررها.');return false;
  }
  const task={id:uid(),text,date,time,priority:'عادية',cat:'',repeat:'',done:false,source:'voice',durationMin:30};
  if(!(await ensureTaskTimeAvailable(task)))return false;
  recordUndo('إضافة مهمة بالصوت');data.tasks.push(task);data.pendingVoiceTask=null;logActivity('إضافة مهمة بالصوت',task.text);scheduleTaskReminder(task);save();renderTasks();tab('tasks');$('#voiceTaskSheet').classList.remove('open');toast('تم حفظ المهمة في قائمة المهام مع تذكيرها');ensureNotif();
  bubble('assistant',`تمت إضافة «${text}» إلى قائمة المهام يوم ${date} الساعة ${time}.`);
  window.__alislahOverlaySpeechStatus&&window.__alislahOverlaySpeechStatus('تم حفظ المهمة فعليًا في قائمة المهام.');
  return true;
}
const voiceTaskStart=$('#voiceTaskStart');
if(voiceTaskStart)voiceTaskStart.onclick=()=>{if(window.AndroidUsage&&typeof AndroidUsage.startVoiceTask==='function'){try{AndroidUsage.startVoiceTask()}catch(_){toast('تعذر تشغيل إضافة المهام بالصوت')}}else toast('إضافة المهام بالصوت متاحة في تطبيق Android')};
$('#voiceTaskSave').onclick=saveVoiceTaskDraft;
$('#voiceTaskCancel').onclick=()=>{data.pendingVoiceTask=null;save();$('#voiceTaskSheet').classList.remove('open');};
$('#voiceTaskSheet').addEventListener('click',e=>{if(e.target.id==='voiceTaskSheet'){data.pendingVoiceTask=null;save();$('#voiceTaskSheet').classList.remove('open')}});

const ayyam=n=>n===1?'يوم':n===2?'يومان':(n>=3&&n<=10)?n+' أيام':n+' يومًا';
function streakOf(id){let n=0;const d=new Date();if(!(data.checks[today()]||{})[id])d.setDate(d.getDate()-1);while(n<3650){const k=ymd(d);if((data.checks[k]||{})[id]){n++;d.setDate(d.getDate()-1)}else break}return n}
function weekDots(id){const out=[];for(let i=6;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);const k=ymd(d);out.push('<i class="'+(((data.checks[k]||{})[id])?'on':'')+(i===0?' today':'')+'" title="'+k+'"></i>')}return out.join('')}
function renderHabits(){let c=data.checks[today()]||{};
$('#habitsList').innerHTML=data.habits.length?data.habits.map(h=>{const dn=!!c[h.id],st=streakOf(h.id);return `<div class="habit ${dn?'done':''}"><div class="row"><h4>${esc(h.text)}</h4><div style="display:flex"><button class="mini edithabit" type="button" data-id="${esc(h.id)}" aria-label="تعديل العادة">✏️</button><button class="mini del delhabit" type="button" data-id="${esc(h.id)}" aria-label="حذف العادة">🗑️</button></div></div><div class="streak">${st?'🔥 سلسلة: '+ayyam(st):'ابدئي سلسلتك اليوم'}</div><div class="dots" aria-label="آخر 7 أيام">${weekDots(h.id)}</div><button class="btn ${dn?'soft':'primary'} block togglehabit" type="button" data-id="${esc(h.id)}">${dn?'✓ تمّ اليوم — إلغاء':'أنجزتها اليوم'}</button></div>`}).join(''):'<div class="empty" style="grid-column:1/-1"><span class="ei">🔁</span>أضيفي عادة تريدين المحافظة عليها.</div>';
$$('.togglehabit').forEach(b=>b.onclick=()=>{recordUndo('تغيير إنجاز عادة');data.checks[today()]=data.checks[today()]||{};data.checks[today()][b.dataset.id]=!data.checks[today()][b.dataset.id];logActivity(data.checks[today()][b.dataset.id]?'إنجاز عادة':'إلغاء إنجاز عادة',data.habits.find(x=>x.id===b.dataset.id)?.text||b.dataset.id);save();renderHabits()});
$$('.delhabit').forEach(b=>b.onclick=async()=>{const h=data.habits.find(x=>x.id===b.dataset.id);if(!h)return;if(!(await ui.confirm('حذف العادة؟','حذف',true,h.text)))return;recordUndo('حذف عادة');data.habits=data.habits.filter(x=>x.id!==h.id);logActivity('حذف عادة',h.text);save();renderHabits()});
$$('.edithabit').forEach(b=>b.onclick=async()=>{const h=data.habits.find(x=>x.id===b.dataset.id);if(!h)return;const v=await ui.prompt('تعديل العادة',h.text);if(v===null)return;const nt=String(v).trim().slice(0,100);if(!nt){toast('اكتبي اسم العادة');return}recordUndo('تعديل عادة');h.text=nt;logActivity('تعديل عادة',nt);save();renderHabits()})}$('#habitForm').onsubmit=e=>{
 e.preventDefault();
 let text=$('#habitText').value.trim();
 if(!text)return;
 if(data.habits.some(h=>String(h.text||'').trim().toLocaleLowerCase()===text.toLocaleLowerCase())){toast('هذه العادة موجودة بالفعل');return}
 if(data.habits.length>=40){toast('وصلتِ إلى الحد الأقصى للعادات');return}
 recordUndo('إضافة عادة');data.habits.push({id:uid(),text});logActivity('إضافة عادة',text);$('#habitText').value='';save();renderHabits()
};function stats(){let ts=data.tasks.filter(t=>t.date===today()),done=ts.filter(t=>t.done).length,c=data.checks[today()]||{},hd=data.habits.filter(h=>c[h.id]).length;$('#doneN').textContent=done;$('#leftN').textContent=ts.length-done;$('#habitN').textContent=hd;$('#habitPct').textContent=(data.habits.length?Math.round(hd/data.habits.length*100):0)+'%';
const total=ts.length+data.habits.length,got=done+hd,pct=total?Math.round(got/total*100):0;const hp=$('#heroPct');if(hp){hp.textContent=pct+'%';$('#heroRing').style.setProperty('--p',pct);$('#heroSub').textContent=total?(pct>=100?'أحسنتِ! أنجزتِ كل شيء اليوم 🎉':pct>=60?'أنتِ في منتصف الطريق، واصلي 💪':pct>0?'بداية موفقة، واصلي 🌿':'ابدئي بخطوة صغيرة الآن 🌱'):'أضيفي مهمة أو عادة لتبدأي يومك'}}
const ideas=[['سؤال اليوم','ما أجمل شيء حدث لكل فرد اليوم؟'],['صيد الألوان','ابحثوا عن ثلاثة أشياء من اللون نفسه.'],['مساعدة صغيرة','رتّبوا ركنًا صغيرًا معًا لخمس دقائق.'],['قصة مشتركة','كل شخص يضيف جملة إلى قصة خيالية.'],['امتنان','اذكروا شيئًا جميلًا تقدّرونه اليوم.']];function idea(){let x=ideas[data.idea%ideas.length];$('#idea').innerHTML=`<div class="grow"><div class="title">${esc(x[0])}</div><div class="muted">${esc(x[1])}</div></div>`}$('#nextIdea').onclick=()=>{data.idea++;save();idea()};
function escHtml(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;')}
function formatAssistantText(text){
  let raw=String(text||'').replace(/\\\*\*/g,'**').replace(/\\\*/g,'*').replace(/\\#/g,'#').replace(/\\\|/g,'|');
  const lines=raw.split(/\r?\n/),out=[];let list=null,code=false,codeLines=[];
  const closeList=()=>{if(list){out.push(list==='ol'?'</ol>':'</ul>');list=null}};
  const inline=t=>escHtml(t).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/\*(.+?)\*/g,'<em>$1</em>');
  for(let line of lines){let t=line.trim();
    if(/^```/.test(t)){closeList();if(!code){code=true;codeLines=[]}else{out.push('<code>'+escHtml(codeLines.join('\n'))+'</code>');code=false}continue}
    if(code){codeLines.push(line);continue}
    if(!t){closeList();continue}
    if(/^\|?\s*[-:| ]+\|\s*$/.test(t))continue;
    if(t.includes('|') && /^\|/.test(t)){closeList();let cells=t.split('|').map(x=>x.trim()).filter(Boolean);if(cells.length)out.push('<p>'+cells.map(inline).join(' — ')+'</p>');continue}
    let m=t.match(/^(#{1,3})\s+(.+)$/);if(m){closeList();out.push('<h3>'+inline(m[2])+'</h3>');continue}
    m=t.match(/^>\s?(.*)$/);if(m){closeList();out.push('<p><em>'+inline(m[1])+'</em></p>');continue}
    m=t.match(/^[-*•]\s+(.+)$/);if(m){if(list!=='ul'){closeList();out.push('<ul>');list='ul'}out.push('<li>'+inline(m[1])+'</li>');continue}
    m=t.match(/^\d+[.)]\s+(.+)$/);if(m){if(list!=='ol'){closeList();out.push('<ol>');list='ol'}out.push('<li>'+inline(m[1])+'</li>');continue}
    closeList();out.push('<p>'+inline(t)+'</p>');
  }
  closeList();if(code)out.push('<code>'+escHtml(codeLines.join('\n'))+'</code>');return '<div class="md">'+out.join('')+'</div>';
}
function bubble(role,text,store=true,sensitive=false){let el=document.createElement('div');el.className='bubble '+role;if(role==='assistant')el.innerHTML=formatAssistantText(text);else el.textContent=text;$('#messages').append(el);$('#messages').scrollTop=$('#messages').scrollHeight;if(store){data.chat.push({role:role==='user'?'user':'assistant',content:text.slice(0,4000),sensitive:!!sensitive});data.chat=data.chat.slice(-30);save()}return el}window.__alislahShowFollowupQuestion=function(q){const question=String(q||'').trim();if(question)bubble('assistant',question,true,false);const input=$('#chatText');if(input)input.focus();};function submitFormCompat(form){if(!form)return;if(typeof form.requestSubmit==='function'){try{form.requestSubmit();return}catch(_){}}form.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));}function drawChat(){if(data.chat.length){$('#messages').innerHTML='';data.chat.forEach(x=>bubble(x.role==='user'?'user':'assistant',x.content,false))}}function localReply(m){if(/جدول|تنظيم|مهام|يوم/i.test(m))return 'لننظم اليوم ببساطة:\n1. اختاري أهم ثلاث مهام.\n2. ابدئي بمهمة صغيرة لمدة 20 دقيقة.\n3. ضعي وقتًا للراحة والأسرة.\n4. اجعلي المهام الإضافية اختيارية.';if(/طفل|بنت|ابنت|أسرة|عائلة/i.test(m))return 'جرّبي نشاطًا قصيرًا يناسب العمر، مثل قصة مشتركة أو البحث عن أشياء بلون واحد. اجعلي الوقت ممتعًا دون ضغط.';if(/عادة|التزام/i.test(m))return 'ابدئي بعادة صغيرة جدًا واربطِيها بروتين قائم، وسجّلي إنجازك. إذا فاتك يوم، عودي في اليوم التالي دون لوم.';return 'هذا رد محلي مبسّط، وليس ردًا من الذكاء الاصطناعي المتصل. تحققي من اتصال الإنترنت ورابط الخدمة في الإعدادات، ثم أعيدي المحاولة.'}
async function online(m){nat('setBubbleState','thinking');let raw=data.settings.worker.trim();let u;try{u=new URL(raw);if(u.protocol!=='https:')throw 0}catch{throw Error('رابط الخدمة غير صالح؛ افتحي الإعدادات وتحققي منه.')}let controller=new AbortController(),to=setTimeout(()=>controller.abort(),25000);try{let history=data.chat.filter(x=>!x.sensitive).slice(-8).map(x=>({role:x.role==='user'?'user':'assistant',content:x.content}));let r=await fetch(u.href,{method:'POST',mode:'cors',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:'تحدث بالعربية بأسلوب ودود وطبيعي كرفيق منظم، وتابع سياق الرسائل السابقة دون تكرار التحية أو الردود الجاهزة. اسأل سؤالًا واحدًا مناسبًا إذا نقصتك معلومة، واشرح ما ستفعله قبل الأوامر الحساسة. لا تدّع أنك إنسان أو أنك تراقب المستخدم. إذا طلب المستخدم خطة، فاكتب المهام العملية في أسطر منفصلة وواضحة تحت عناوين الأيام، مع وقت مقترح لكل مهمة إن أمكن؛ سيحوّل التطبيق عناصر الخطة إلى مهام تلقائيًا وفق إعداد المستخدم. استخدم البيانات المرفقة فقط عند وجود موافقة، وميّز الحقائق عن التوقعات. '+getAutoContext()+' طلب المستخدم: '+m,history}),signal:controller.signal,cache:'no-store'});let j={};try{j=await r.json()}catch{}if(!r.ok)throw Error(j.error||`استجابة الخدمة ${r.status}`);if(typeof j.reply!=='string'||!j.reply.trim())throw Error('الخدمة لم ترجع إجابة صالحة');return j.reply.trim()}finally{clearTimeout(to)}}const consentMain=$('#analysisConsent'),consentChat=$('#chatAnalysisConsent');if(consentMain&&consentChat){consentMain.addEventListener('change',()=>{consentChat.checked=consentMain.checked});consentChat.addEventListener('change',()=>{consentMain.checked=consentChat.checked})}
$('#chatForm').onsubmit=async e=>{e.preventDefault();let m=$('#chatText').value.trim();if(!m)return;if(isTaskCreationIntent(m)){ $('#chatText').value='';addVoiceTaskFromTranscript(m,false);return;}if(/(?:أضف|اضف|إضافة|اضافة|سجل|سجّل|أريد إضافة|اريد اضافة)\s+(?:لي\s+)?(?:عادة|روتين)/i.test(m)){$('#chatText').value='';await addVoiceHabitFromTranscript(m);return;}if(handleVoiceTaskStatusCommand(m)){$('#chatText').value='';return;}const sensitive=$('#chatText').dataset.includesPersonalAnalysis==='true';if(sensitive&&!($('#analysisConsent')?.checked||$('#chatAnalysisConsent')?.checked)){toast('فعّلي موافقة إرسال الملخص الظاهرة فوق زر الإرسال؛ لن يُرسل شيء دونها.');$('#chatConsentWrap').style.display='flex';return;}$('#chatText').dataset.includesPersonalAnalysis='false';$('#chatText').value='';bubble('user',m,true,sensitive);$('#send').disabled=true;$('#send').textContent='انتظري…';let w=bubble('system','أحاول الاتصال بالذكاء الاصطناعي عبر الإنترنت…',false);try{let answer=await online(m);w.remove();bubble('assistant',answer,true,sensitive);$('#aiStatus').textContent='تم الرد عبر الإنترنت';await autoCreateTasksFromPlan(m,answer)}catch(err){w.remove();$('#aiStatus').textContent='تعذر الاتصال — مساعدة محلية';bubble('assistant','لم يصلني رد من خدمة الذكاء الاصطناعي. السبب: '+(err.name==='AbortError'?'انتهت مهلة الاتصال.':err.message)+'\n\nمساعدة محلية مؤقتة:\n'+localReply(m),true,sensitive)}finally{$('#send').disabled=false;$('#send').textContent='إرسال';try{if(window.AndroidUsage&&typeof AndroidUsage.assistantAnswered==='function'&&!(typeof AndroidUsage.isBubbleOverlay==='function'&&AndroidUsage.isBubbleOverlay()))AndroidUsage.assistantAnswered();const last=$('#messages .bubble.assistant:last-child');const answerText=last?(last.textContent||''):'';const eventWords=/(هل\s|؟|\?|نصيح|أنصح|تذكير|ذكّ?ر|إرشاد|خطوة عملية|اقترح|جرّب|جرّبي|ابدأ|ابدئي|خطة|ينبغي|حاول|حاولي)/i;if(eventWords.test(answerText)&&window.AndroidUsage&&typeof AndroidUsage.showBubbleForEvent==='function')AndroidUsage.showBubbleForEvent()}catch(_){}}};
window.__alislahOverlaySpeechStatus=function(message){const el=$('#aiStatus');if(el)el.textContent=String(message||'');const input=$('#chatText');if(input&&String(message||'').includes('أستمع'))input.placeholder='تحدث الآن… أظهر النص هنا أثناء الكلام';};
window.__alislahOverlaySpeechPartial=function(transcript){const input=$('#chatText');if(input)input.value=String(transcript||'').slice(0,1200);};
function handleVoiceTaskStatusCommand(transcript){
  const text=String(transcript||'').trim();
  if(/^(?:تراجع|تراجع عن اخر امر|تراجع عن آخر أمر|الغاء اخر امر|إلغاء آخر أمر|ألغ آخر أمر)[.!؟،\s]*$/i.test(text)){const ok=undoLastAction();bubble('user',text,true,false);bubble('assistant',ok?'تم التراجع عن آخر إجراء محفوظ.':'لا يوجد إجراء سابق للتراجع عنه.');window.__alislahOverlaySpeechStatus('تمت معالجة طلب التراجع محليًا.');return true;}
  if(/(?:ماذا|ما)\s*(?:تنصحني|نصيحتك)|ما الذي ينبغي أن أفعله الآن|كيف أستغل وقتي الآن/i.test(text)){
    renderLiveInsights();
    const insight=$('#liveInsights');
    const reply=insight?(insight.innerText||insight.textContent||'').trim():'لا تتوفر بيانات كافية بعد. سجّل مهامك وعاداتك حتى أقدم لك نصيحة أدق.';
    bubble('user',text,true,false);bubble('assistant',reply||'لا تتوفر بيانات كافية بعد. سجّل مهامك وعاداتك حتى أقدم لك نصيحة أدق.');
    window.__alislahOverlaySpeechStatus('قدمت لك نصيحة اعتمادًا على بياناتك المحلية الحالية.');return true;
  }
  const listIntent=/(?:اعرض|أرني|وريني|قائمة|ما هي|ما عندي|ماذا لدي|وش عندي|واش عندي).{0,35}(?:المهام|مهامي|مهام اليوم|اليوم)|(?:ما مهامي|ماذا أنجزت|ما الذي بقي علي)/i.test(text);
  if(listIntent){
    const dayTasks=data.tasks.filter(t=>(t.date||today())===today()),pending=dayTasks.filter(t=>!t.done&&!t.completed),done=dayTasks.filter(t=>t.done||t.completed);
    const next=pending.slice().sort((a,b)=>String(a.time||'99:99').localeCompare(String(b.time||'99:99'))).slice(0,5);
    const lines=next.map((t,i)=>`${i+1}. ${t.text}${t.time?' — '+t.time:''}`).join('\n');
    const reply=dayTasks.length?`اليوم لديك ${dayTasks.length} مهام: أنجزت ${done.length}، والمتبقي ${pending.length}.`+(lines?'\nالمهام المتبقية:\n'+lines:'\nأكملت مهام اليوم، أحسنت!'):'لا توجد مهام مسجلة لهذا اليوم. هل تريد إضافة مهمة جديدة؟';
    bubble('user',text,true,false);bubble('assistant',reply,true,false);window.__alislahOverlaySpeechStatus('عرضت لك ملخص مهام اليوم.');return true;
  }
  if(/(?:اعرض|أرني|وريني|ما هي|ما عاداتي|قائمة).{0,25}(?:عاداتي|العادات|عادات اليوم)/i.test(text)){
    const checks=data.checks[today()]||{},items=(data.habits||[]).map(h=>`${checks[h.id]?'✓':'○'} ${h.text}`);
    bubble('user',text,true,false);bubble('assistant',items.length?`عاداتك اليوم:\n${items.join('\n')}`:'لم تسجل عادات بعد. هل تريد إضافة عادة؟');window.__alislahOverlaySpeechStatus('عرضت لك عاداتك.');return true;
  }
  const habitDone=text.match(/(?:أنجزت|انجزت|أكملت|اكملت|مارست|التزمت ب)\s*(?:العادة|عادة)?\s*(.*)$/i);
  if(habitDone&&/عادة|عادات|مارست|التزمت/i.test(text)){
    const requested=String(habitDone[1]||'').trim().replace(/[؟?.،,]+$/g,'');
    const norm=x=>String(x||'').toLocaleLowerCase('ar').replace(/[\s\u0640.,،؛:!?؟()\[\]{}'"ـ-]/g,'');
    const key=norm(requested),matches=(data.habits||[]).filter(h=>key&&(norm(h.text).includes(key)||key.includes(norm(h.text))));
    if(matches.length===1){recordUndo('إنجاز عادة بالصوت');data.checks[today()]=data.checks[today()]||{};data.checks[today()][matches[0].id]=true;save();renderHabits();bubble('user',text,true,false);bubble('assistant',`أحسنت! سجلت إنجاز عادة «${matches[0].text}» لهذا اليوم.`);return true;}
    if(matches.length>1){bubble('user',text,true,false);bubble('assistant','لديك أكثر من عادة مشابهة. اذكر اسم العادة كاملًا.');return true;}
  }
  const postpone=text.match(/(?:اجل|أجل|أخّر|اخر|أخر|أجّل|اجّل)\s+(?:المهمة\s+)?(.+)$/i);
  if(postpone){
    const requested=String(postpone[1]||'').trim();
    const norm=x=>String(x||'').toLocaleLowerCase('ar').replace(/[\s\u0640.,،؛:!?؟()\[\]{}'"ـ-]/g,'');
    const key=norm(requested),matches=data.tasks.filter(t=>!t.done&&key&&(norm(t.text).includes(key)||key.includes(norm(t.text))));
    if(matches.length===1){
      const t=matches[0],next=window.ALISLAHTaskPlanner&&window.ALISLAHTaskPlanner.findPostponeSlot(data.tasks,t,today(),Date.now(),60);
      if(!next){bubble('user',text,true,false);bubble('assistant','لم أجد وقتًا خاليًا للتأجيل خلال الأيام الثلاثين القادمة. يمكنك تعديل الموعد يدويًا.');return true;}
      recordUndo('تأجيل مهمة');cancelTaskReminder(t.id);t.date=next.date;t.time=next.time;scheduleTaskReminder(t);save();renderTasks();
      bubble('user',text,true,false);bubble('assistant',`أُجّلت «${t.text}» إلى ${t.date} الساعة ${t.time}. يمكنك التراجع عن هذا التغيير.`);return true;
    }
    if(matches.length>1){bubble('user',text,true,false);bubble('assistant','وجدت أكثر من مهمة مشابهة. اذكر اسمها كاملًا.');return true;}
  }
  const doneMatch=text.match(/(?:أنجزت|انجزت|أكملت|اكملت|خلصت|تم إنجاز|تم انجاز)\s*(?:المهمة|مهمة)?\s*(.*)$/i);
  if(doneMatch){
    const requested=String(doneMatch[1]||'').trim().replace(/[؟?.،,]+$/g,'');
    if(!requested){bubble('user',text,true,false);bubble('assistant','ما اسم المهمة التي أنجزتها؟ أريد التأكد من تسجيل المهمة الصحيحة.');return true;}
    const norm=x=>String(x||'').toLocaleLowerCase('ar').replace(/[\s\u0640.,،؛:!?؟()\[\]{}'"ـ-]/g,'');
    const key=norm(requested),matches=data.tasks.filter(t=>!t.done&&!t.completed&&key&&(norm(t.text).includes(key)||key.includes(norm(t.text))));
    if(matches.length===1){recordUndo('إنجاز مهمة بالصوت');completeTask(matches[0],true);save();renderTasks();bubble('user',text,true,false);bubble('assistant',`أحسنت! سجلت «${matches[0].text}» كمهمة منجزة.`);window.__alislahOverlaySpeechStatus('تم تحديث المهمة بنجاح.');return true;}
    if(matches.length>1){bubble('user',text,true,false);bubble('assistant','وجدت أكثر من مهمة مشابهة. قل اسم المهمة كاملًا حتى لا أضع علامة على المهمة الخطأ.');return true;}
    if(key){bubble('user',text,true,false);bubble('assistant','لم أجد مهمة بهذا الاسم ضمن قائمتك غير المنجزة. أعد ذكر اسمها كما يظهر في القائمة.');return true;}
  }
  return false;
}
async function addVoiceHabitFromTranscript(transcript){
  const match=String(transcript||'').match(/(?:أضف|اضف|إضافة|اضافة|سجل|سجّل|أريد إضافة|اريد اضافة)\s+(?:لي\s+)?(?:عادة|روتين)\s*(.*)$/i);
  const name=String(match?.[1]||'').trim().replace(/[؟?.،,]+$/g,'').slice(0,100);
  bubble('user',String(transcript||''),true,false);
  if(!name){bubble('assistant','ما اسم العادة التي تريد إضافتها؟');return;}
  if((data.habits||[]).some(h=>String(h.text||'').trim().toLocaleLowerCase('ar')===name.toLocaleLowerCase('ar'))){bubble('assistant','هذه العادة موجودة بالفعل في قائمتك.');return;}
  if(data.habits.length>=40){bubble('assistant','وصلت إلى الحد الأقصى للعادات المسجلة. احذف عادة قديمة قبل إضافة أخرى.');return;}
  if(!(await ui.confirm('إضافة عادة جديدة؟','إضافة',false,`هل تريد إضافة عادة «${name}» إلى قائمتك؟`))){bubble('assistant','لم أضف العادة. يمكنك تعديل طلبك أو المحاولة لاحقًا.');return;}
  recordUndo('إضافة عادة بالصوت');data.habits.push({id:uid(),text:name});logActivity('إضافة عادة بالصوت',name);save();renderHabits();bubble('assistant',`تمت إضافة عادة «${name}». يمكنك تسجيل إنجازها كل يوم من صفحة العادات.`);window.__alislahOverlaySpeechStatus('تمت إضافة العادة بعد موافقتك.');
}
window.__alislahOverlaySpeechResult=function(transcript){
  const text=String(transcript||'').trim().slice(0,1200);if(!text)return;
  const input=$('#chatText'),form=$('#chatForm');if(!input||!form)return;input.value=text;input.focus();
  if(data.pendingVoiceTask){
    if(/^(?:نعم|أجل|اجل|أكيد|اكيد|أوافق|اوافق|أضفها|اضفها|أكد|اكد|تمام|موافق|موافقة)[.!؟،\s]*$/i.test(text)){saveVoiceTaskDraft();return;}
    if(/^(?:لا|كلا|إلغاء|الغاء|لا تضف|لا تضيفها)[.!؟،\s]*$/i.test(text)){data.pendingVoiceTask=null;save();$('#voiceTaskSheet').classList.remove('open');bubble('assistant','حسنًا، لم أضف المهمة.');return;}
    const parser=window.ALISLAHVoiceTaskParser,when=parser&&parser.parse?parser.parse(text):null;
    if(when&&when.hasTime){data.pendingVoiceTask.date=when.date;data.pendingVoiceTask.time=when.time;data.pendingVoiceTask.hasTime=true;$('#voiceTaskDate').value=when.date;$('#voiceTaskTime').value=when.time;save();bubble('assistant',`حسنًا، حددت الموعد ${when.date} الساعة ${when.time}. هل تؤكد إضافة المهمة؟`);window.__alislahOverlaySpeechStatus('حددت الموعد. قل نعم للتأكيد أو عدّل الحقول.');return;}
    bubble('assistant','لم أفهم الوقت بعد. قل مثلًا: غدًا الساعة الثامنة، أو عدّل التاريخ والوقت في نافذة المهمة.');window.__alislahOverlaySpeechStatus('أحتاج وقتًا واضحًا للمهمة.');return;
  }
  if(/(?:أضف|اضف|إضافة|اضافة|سجل|سجّل|أريد إضافة|اريد اضافة)\s+(?:لي\s+)?(?:عادة|روتين)/i.test(text)){addVoiceHabitFromTranscript(text);return;}
  if(isTaskCreationIntent(text)){addVoiceTaskFromTranscript(text,false);window.__alislahOverlaySpeechStatus('راجِع المهمة والموعد ثم أكد الإضافة.');return;}
  if(handleVoiceTaskStatusCommand(text))return;
  if(/حلل (?:بيانات|استخدامي|وقتي|سلوكي|مهامي|عاداتي)|تحليل (?:بيانات|استخدام|المهام|العادات)|أنشئ لي خطة بناءً على|خطة حسب بياناتي/i.test(text)){input.value=text+'\n\n'+makeBehaviorPrompt();input.dataset.includesPersonalAnalysis='true';const consent=$('#chatConsentWrap');if(consent)consent.style.display='flex';const note=$('#chatAnalysisConsent');if(note)note.checked=!!$('#analysisConsent')?.checked;window.__alislahOverlaySpeechStatus('أعددت ملخصًا من بياناتك المحلية. راجعه ووافق على المشاركة، ثم اضغط إرسال بنفسك.');return;}
  input.dataset.includesPersonalAnalysis='false';window.__alislahOverlaySpeechStatus('وصل كلامك. أجهز لك الرد…');submitFormCompat(form);
};
$$('.quick').forEach(b=>b.onclick=()=>{$('#chatText').value=b.dataset.prompt;$('#chatText').focus()});$('#clearChat').onclick=async()=>{if(await ui.confirm('مسح المحادثة؟','مسح',true)){data.chat=[];save();$('#messages').innerHTML='';bubble('assistant','أهلًا بكِ، كيف أساعدك اليوم؟',false)}};
$('#worker').value=data.settings.worker;$('#questionCloudEnabled').checked=data.settings.questionCloudEnabled===true;$('#name').value=data.settings.name;$('#themeMode').value=data.settings.theme||'auto';$('#questionCloudEnabled').addEventListener('change',e=>{data.settings.questionCloudEnabled=e.target.checked;save();toast(e.target.checked?'تم تفعيل إرسال إجابات الأسئلة بعد اختيارها.':'تم إيقاف إرسال إجابات الأسئلة؛ ستبقى محلية.')});const autoShare=$('#autoShareUsage');if(autoShare){autoShare.checked=!!data.settings.autoShareUsage;autoShare.addEventListener('change',()=>{data.settings.autoShareUsage=autoShare.checked;save();toast(autoShare.checked?'فُعّلت المشاركة التلقائية بعد موافقتك':'أُوقفت المشاركة التلقائية')})}$('#saveSettings').onclick=()=>{let w=$('#worker').value.trim();try{if(w&&new URL(w).protocol!=='https:')throw 0}catch{toast('أدخلي رابط HTTPS صحيحًا');return}data.settings.worker=w;data.settings.name=$('#name').value.trim();data.settings.theme=$('#themeMode').value;save();applyTheme();applyGreeting();toast('تم حفظ الإعدادات')};$('#test').onclick=async()=>{let o=$('#testResult');o.textContent=' جارٍ الاختبار…';try{let r=await fetch($('#worker').value.trim(),{method:'GET',mode:'cors'});let t=await r.text();o.textContent=r.status===405&&/Use POST/i.test(t)?' الرابط يستجيب؛ جرّبي إرسال رسالة من المساعد.':` الاستجابة: ${r.status}`}catch{o.textContent=' تعذر اختبار الاتصال؛ جرّبي إرسال رسالة.'}};

/* ===== dialogs ===== */
const ui=(()=>{const dlg=$('#dlg'),t=$('#dlgTitle'),m=$('#dlgMsg'),inp=$('#dlgInput'),ok=$('#dlgOk'),cancel=$('#dlgCancel');let resolver=null,lastFocus=null;
function close(v){dlg.classList.remove('open');const r=resolver;resolver=null;try{lastFocus&&lastFocus.focus&&lastFocus.focus()}catch(_){}if(r)r(v)}
function open(o){return new Promise(res=>{if(resolver)close(null);resolver=res;lastFocus=document.activeElement;t.textContent=o.title||'';m.textContent=o.message||'';m.style.display=o.message?'':'none';inp.classList.toggle('hidden',!o.input);inp.type=o.password?'password':'text';inp.maxLength=o.password?64:180;if(o.input){inp.value=o.value||''}ok.textContent=o.ok||'موافق';ok.className='btn '+(o.danger?'danger':'primary');dlg.classList.add('open');setTimeout(()=>(o.input?inp:ok).focus(),60)})}
ok.onclick=()=>close(inp.classList.contains('hidden')?true:inp.value);
cancel.onclick=()=>close(inp.classList.contains('hidden')?false:null);
dlg.addEventListener('click',e=>{if(e.target===dlg)cancel.onclick()});
inp.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();ok.onclick()}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&dlg.classList.contains('open'))cancel.onclick()});
return{confirm:(title,okLabel,danger,message)=>open({title,message,ok:okLabel,danger}),prompt:(title,value,okLabel,opts)=>open({title,input:true,value,ok:okLabel||'حفظ',...(opts||{})}),isOpen:()=>dlg.classList.contains('open'),close:()=>cancel.onclick()}})();
window.__alislahBack=function(){if(ui.isOpen()){ui.close();return true}const sh=document.querySelector('.sheet-backdrop.open:not(#welcome)');if(sh){sh.classList.remove('open');return true}const w=$('#welcome');if(w&&w.classList.contains('open'))return true;const ck=$('#alislahCheckin');if(ck&&ck.classList.contains('open')){ck.classList.remove('open');const f=$('#alislahFloat');if(f)f.setAttribute('aria-expanded','false');return true}const eb=$('#eyeBreakOverlay');if(eb&&eb.classList.contains('open'))return true;const v=document.body.dataset.view||'tasks';if(v==='more'){tab('tasks');return true}if(!PRIMARY.includes(v)){tab(window.__alislahFrom==='more'||document.getElementById('more')?'more':'tasks');return true}if(v!=='tasks'){tab('tasks');return true}return false};

/* ===== theme / greeting ===== */
function applyTheme(){const th=data.settings.theme;if(th==='light'||th==='dark')document.documentElement.setAttribute('data-theme',th);else document.documentElement.removeAttribute('data-theme')}
function applyGreeting(){const n=String(data.settings.name||'').trim();$('#greeting').textContent=n?`مرحبًا بعودتك ${n}، ماذا تريد أن تفعل الآن؟ 🌿`:'مرحبًا بك في ALISLAH، ماذا تريد أن تفعل الآن؟ 🌿'}

/* ===== native (Android) status, permissions, welcome ===== */
function nativeStatus(){try{return NATIVE&&window.AndroidUsage.getNativeStatus?JSON.parse(AndroidUsage.getNativeStatus()||'{}'):null}catch(_){return null}}
function renderNative(){const box=$('#nativePanel'),rows=$('#nativeRows');if(!box||!rows)return;const st=nativeStatus();if(!st||!st.native){box.classList.add('hidden');return}box.classList.remove('hidden');
const ov=!!(st.overlayEnabled&&st.overlayPermission);
const row=(ic,title,desc,ok,btn,id)=>`<div class="perm"><span class="pi" aria-hidden="true">${ic}</span><div class="grow"><div class="ph"><strong>${title}</strong><span class="state ${ok?'ok':'off'}">${ok?'مفعّل':'غير مفعّل'}</span></div><small>${desc}</small></div>${btn?`<button class="btn soft" type="button" data-n="${id}">${btn}</button>`:''}</div>`;
rows.innerHTML=row('🔔','الإشعارات','تذكير المهام وتنبيهات الصلاة وأسئلة المتابعة',st.notifications,st.notifications?'إدارة':'السماح','notif')
+row('🔋','العمل في الخلفية','استثني التطبيق من توفير البطارية ليصل الأذان في وقته',st.battery,st.battery?'':'ضبط','battery')
+row('🫧','الفقاعة العائمة','زر ALISLAH فوق التطبيقات للوصول السريع للمساعد',ov,ov?'إيقاف':'تفعيل','overlay')
+row('🎙️','الميكروفون','للإملاء الصوتي في المساعد',st.microphone,st.microphone?'':'السماح','mic')
+row('📊','إحصاءات الاستخدام','تحليل وقت الشاشة على جهازك',st.usage,st.usage?'':'منح','usage')
+`<div class="perm"><span class="pi" aria-hidden="true">🌙</span><div class="grow"><div class="ph"><strong>وضع عدم الإزعاج</strong><span class="state ${st.dndModeApplied?'ok':'off'}">${st.dndModeApplied?'مفعّل':'غير مفعّل'}</span></div><small>${st.notificationPolicyAccess?'يسمح بتفعيل وضع الأولوية ثم استعادة الوضع السابق عند الإيقاف.':'يلزم منح ALISLAH صلاحية الوصول إلى وضع عدم الإزعاج.'}</small></div>${st.notificationPolicyAccess?`<input id="nativeDndSwitch" class="switch" type="checkbox" ${st.dndModeApplied?'checked':''} aria-label="وضع عدم الإزعاج">`:`<button class="btn soft" type="button" data-n="dnd">منح الصلاحية</button>`}</div>`
+`<div class="perm"><span class="pi" aria-hidden="true">💬</span><div class="grow"><strong>أسئلة المتابعة</strong><small>سؤال خفيف كل بضع ساعات، ولا يصلك بين 10 مساءً و8 صباحًا</small></div><input id="nativeQuestions" class="switch" type="checkbox" ${st.questions?'checked':''} aria-label="أسئلة المتابعة"></div>`;
rows.querySelectorAll('[data-n]').forEach(b=>b.onclick=()=>{const k=b.dataset.n;if(k==='notif')nat('requestNotificationPermission');else if(k==='battery')nat('openBatterySettings');else if(k==='overlay'){if(ov)nat('disableOverlay');else nat('enableOverlay')}else if(k==='mic')nat('requestRuntimePermissions');else if(k==='usage')nat('requestUsagePermission');else if(k==='dnd')nat('requestDndAccess');setTimeout(renderNative,700);setTimeout(renderNative,2500)});
const dnd=$('#nativeDndSwitch');if(dnd)dnd.onchange=()=>{let result=null;try{result=JSON.parse(nat('setDndMode',dnd.checked)||'{}')}catch(_){}if(!result||!result.ok){dnd.checked=false;if(result&&result.needsAccess){toast('امنحي الصلاحية من إعدادات Android أولًا');nat('requestDndAccess')}else toast(result&&result.message||'تعذر تغيير وضع عدم الإزعاج')}else toast(dnd.checked?'تم تفعيل وضع عدم الإزعاج':'تمت استعادة وضع الإشعارات السابق');setTimeout(renderNative,500)};
const q=$('#nativeQuestions');if(q)q.onchange=()=>{nat('enableBackgroundQuestions',q.checked);toast(q.checked?'فُعّلت أسئلة المتابعة':'أُوقفت أسئلة المتابعة')};
if(st.version){const a=$('#appVersion'),b=$('#appVersion2');if(a)a.textContent=st.version;if(b)b.textContent=st.version}}
window.__alislahNativeRefresh=renderNative;
let notifAsked=false;
function ensureNotif(){if(!NATIVE||notifAsked)return;const st=nativeStatus();if(st&&st.notifications===false){notifAsked=true;toast('اسمحي بالإشعارات ليصلك التذكير');setTimeout(()=>nat('requestNotificationPermission'),1100)}}
function maybeWelcome(){if(!NATIVE||!FIRST_RUN||data.settings.welcomed)return;const w=$('#welcome');if(!w)return;$('#welcomeNative').classList.remove('hidden');const nb=$('#welcomeNotif');
const refresh=()=>{const s2=nativeStatus()||{};nb.textContent=s2.notifications?'مفعّل ✓':'السماح';nb.disabled=!!s2.notifications};refresh();
nb.onclick=()=>{nat('requestNotificationPermission');setTimeout(refresh,900);setTimeout(refresh,3000)};
$('#welcomeName').value=data.settings.name||'';
$('#welcomeStart').onclick=()=>{const n=$('#welcomeName').value.trim().slice(0,40);if(n){data.settings.name=n;$('#name').value=n;applyGreeting()}data.settings.welcomed=true;save();if($('#welcomeQuestions').checked)nat('enableBackgroundQuestions',true);w.classList.remove('open');toast('أهلًا بك! ابدئي بإضافة أول مهمة 🌿')};
w.classList.add('open')}

/* ===== backup / restore ===== */
const STORE_CHECKINS='alislah_checkins_v1';
function readJSON(k,def){try{const v=JSON.parse(localStorage.getItem(k)||'null');return v&&typeof v==='object'?v:def}catch{return def}}
async function exportBackup(){const payload={...data,checkins:readJSON(STORE_CHECKINS,{}),_format:'alislah-backup',exportedAt:new Date().toISOString()};let json=JSON.stringify(payload,null,2),name='alislah-backup-'+today()+'.json';
if(data.settings.encryptBackup){if(!(NATIVE&&window.AndroidUsage&&typeof AndroidUsage.encryptBackup==='function')){toast('التشفير متاح في نسخة أندرويد فقط');return}const pass=await ui.prompt('كلمة سر النسخة','','تشفير',{password:true,message:'احفظيها جيدًا؛ لا يمكن فتح النسخة بدونها.'});if(pass===null)return;if(String(pass).length<6){toast('كلمة السر يجب ألا تقل عن 6 أحرف');return}const env=AndroidUsage.encryptBackup(json,String(pass));if(!env){toast('تعذر تشفير النسخة');return}json=env;name=name.replace('.json','.enc.json')}
if(NATIVE&&window.AndroidUsage&&typeof AndroidUsage.saveBackup==='function'){nat('saveBackup',name,json);return}
try{const b=new Blob([json],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1500)}catch{toast('تعذر إنشاء النسخة الاحتياطية')}}
function cleanImport(x){const isObj=v=>v&&typeof v==='object'&&!Array.isArray(v),str=(v,n)=>String(v==null?'':v).slice(0,n),num=(v,a,b,d)=>{v=Number(v);return Number.isFinite(v)?Math.min(b,Math.max(a,v)):d};const dateRe=/^\d{4}-\d{2}-\d{2}$/,timeRe=/^\d{2}:\d{2}$/;
const tasks=(Array.isArray(x.tasks)?x.tasks:[]).filter(isObj).slice(0,3000).map(t=>({id:str(t.id||uid(),80),text:str(t.text,180).trim(),date:dateRe.test(t.date||'')?t.date:today(),time:timeRe.test(t.time||'')?t.time:'',priority:['عادية','مهمة جدًا','يمكن تأجيلها'].includes(t.priority)?t.priority:'عادية',done:!!t.done,...(CATS.includes(t.cat)?{cat:t.cat}:{}),...(REPEATS[t.repeat]?{repeat:t.repeat}:{}),...(dateRe.test(t.doneAt||'')?{doneAt:t.doneAt}:{}),...(t.source==='assistant-plan'?{source:'assistant-plan'}:{})})).filter(t=>t.text);
const habits=(Array.isArray(x.habits)?x.habits:[]).filter(isObj).slice(0,500).map(h=>({id:str(h.id||uid(),80),text:str(h.text,100).trim()})).filter(h=>h.text);
const checks={};if(isObj(x.checks))Object.keys(x.checks).slice(-800).forEach(k=>{if(!dateRe.test(k)||!isObj(x.checks[k]))return;const o={};Object.keys(x.checks[k]).slice(0,300).forEach(h=>{if(h.length<=80&&x.checks[k][h]===true)o[h]=true});checks[k]=o});
const chat=(Array.isArray(x.chat)?x.chat:[]).filter(m=>isObj(m)&&typeof m.content==='string').slice(-30).map(m=>({role:m.role==='user'?'user':'assistant',content:m.content.slice(0,4000),sensitive:m.sensitive===true}));
const behavior={};if(isObj(x.behavior))Object.keys(x.behavior).slice(-400).forEach(k=>{const b=x.behavior[k];if(!dateRe.test(k)||!isObj(b))return;behavior[k]={mood:num(b.mood,1,5,3),energy:num(b.energy,1,5,3),focus:num(b.focus,1,5,3),sleepHours:num(b.sleepHours,0,24,0),phoneMinutes:b.phoneMinutes==null||b.phoneMinutes===''?null:num(b.phoneMinutes,0,1440,0),note:str(b.note,700),updatedAt:str(b.updatedAt,40)}});
const snaps=(isObj(x.usageProfile)&&Array.isArray(x.usageProfile.snapshots)?x.usageProfile.snapshots:[]).filter(isObj).slice(-14).map(p=>({date:dateRe.test(p.date||'')?p.date:today(),apps:(Array.isArray(p.apps)?p.apps:[]).filter(isObj).slice(0,12).map(a=>({name:str(a.name,80),minutes:num(a.minutes,0,1440,0)})),...(typeof p.foreground==='string'?{foreground:p.foreground.slice(0,80)}:{}),capturedAt:num(p.capturedAt,0,4102444800000,0)}));
const sx=isObj(x.settings)?x.settings:{};const settings={name:str(sx.name,40),...(['text','voice','both'].includes(sx.interactionMode)?{interactionMode:sx.interactionMode}:{}),voiceRead:sx.voiceRead===true,...(['male','female'].includes(sx.voiceGender)?{voiceGender:sx.voiceGender}:{}),...(['old','neural'].includes(sx.assistantVoiceEngine)?{assistantVoiceEngine:sx.assistantVoiceEngine}:{}),...(['current','unified'].includes(sx.audioControlMode)?{audioControlMode:sx.audioControlMode}:{}),...(['auto','light','dark'].includes(sx.theme)?{theme:sx.theme}:{}),...(['small','normal','large','xlarge'].includes(sx.fontScale)?{fontScale:sx.fontScale}:{})};
const px=isObj(sx.prayer)?sx.prayer:{};const adj={};['Fajr','Dhuhr','Asr','Maghrib','Isha'].forEach(k=>{adj[k]=num(isObj(px.adj)?px.adj[k]:0,-30,30,0)});const prayer={wilaya:/^\d{1,2}$/.test(String(px.wilaya))?String(px.wilaya):'14',lat:num(px.lat,-90,90,35.37),lon:num(px.lon,-180,180,1.32),method:['algeria','mwl','makkah','egypt','isna','france','karachi','tunisia','morocco'].includes(px.method)?px.method:'algeria',adj,before:num(px.before,0,120,10),after:num(px.after,0,180,20),followup:px.followup!==false};
const prayerLog=(Array.isArray(x.prayerLog)?x.prayerLog:[]).filter(isObj).slice(-1500).map(p=>({name:str(p.name,20),date:str(p.date,40),day:dateRe.test(p.day||'')?p.day:'',done:true}));
const prayerResponses=(Array.isArray(x.prayerResponses)?x.prayerResponses:[]).filter(isObj).slice(-1500).map(p=>({name:str(p.name,20),date:str(p.date,40),day:dateRe.test(p.day||'')?p.day:'',done:p.done===true,response:p.done===true?'done':'not-yet',at:num(p.at,0,4102444800000,0)})).filter(p=>p.name);
const checkins={};if(isObj(x.checkins))Object.keys(x.checkins).slice(-500).forEach(k=>{const c=x.checkins[k];if(k.length>80||!isObj(c)||typeof c.question!=='string'||typeof c.answer!=='string')return;checkins[k]={qid:num(c.qid,0,200,0),question:c.question.slice(0,200),answer:c.answer.slice(0,200),at:str(c.at,40)}});
const fx=isObj(x.family)?x.family:{};const members=(Array.isArray(fx.members)?fx.members:[]).filter(isObj).slice(0,12).map(m=>({id:str(m.id||uid(),40),name:str(m.name,30).trim(),emoji:str(m.emoji||'🙂',8),role:['parent','child'].includes(m.role)?m.role:'child',goal:num(m.goal,0,1000,20),reward:str(m.reward,60),base:num(m.base,0,100000,0)})).filter(m=>m.name);const mids=new Set(members.map(m=>m.id));
const routines={};if(isObj(fx.routines))Object.keys(fx.routines).filter(k=>mids.has(k)).forEach(k=>{const r=fx.routines[k];if(!isObj(r))return;routines[k]={morning:(Array.isArray(r.morning)?r.morning:[]).filter(isObj).slice(0,20).map(i=>({id:str(i.id||uid(),40),text:str(i.text,60).trim()})).filter(i=>i.text),evening:(Array.isArray(r.evening)?r.evening:[]).filter(isObj).slice(0,20).map(i=>({id:str(i.id||uid(),40),text:str(i.text,60).trim()})).filter(i=>i.text)}});
const routineLog={};if(isObj(fx.routineLog))Object.keys(fx.routineLog).slice(-200).forEach(k=>{if(!dateRe.test(k)||!isObj(fx.routineLog[k]))return;const o={};Object.keys(fx.routineLog[k]).slice(0,300).forEach(i=>{if(i.length<=90&&fx.routineLog[k][i]===true)o[i]=true});routineLog[k]=o});
const events=(Array.isArray(fx.events)?fx.events:[]).filter(isObj).slice(0,500).map(ev=>({id:str(ev.id||uid(),40),title:str(ev.title,80).trim(),date:dateRe.test(ev.date||'')?ev.date:today(),time:timeRe.test(ev.time||'')?ev.time:'',who:mids.has(ev.who)?ev.who:'',remind:['','15','60','1440'].includes(String(ev.remind))?String(ev.remind):'',done:!!ev.done})).filter(ev=>ev.title);
const family={members,routines,routineLog,events};
const wx=isObj(x.worship)?x.worship:{},kx=isObj(wx.khatma)?wx.khatma:{};const klog={};if(isObj(kx.log))Object.keys(kx.log).slice(-400).forEach(k=>{if(dateRe.test(k))klog[k]=num(kx.log[k],0,604,0)});
const dh={};if(isObj(wx.dhikrDone))Object.keys(wx.dhikrDone).slice(-120).forEach(k=>{if(!dateRe.test(k)||!isObj(wx.dhikrDone[k]))return;const o={};['morning','evening','afterPrayer','sleep'].forEach(s=>{if(wx.dhikrDone[k][s]===true)o[s]=true});dh[k]=o});
const worship={khatma:{pages:num(kx.pages,0,604,0),total:604,goalDays:num(kx.goalDays,1,3650,30),start:dateRe.test(kx.start||'')?kx.start:'',log:klog},qada:{owed:num(isObj(wx.qada)?wx.qada.owed:0,0,5000,0)},dhikrDone:dh};
const fox=isObj(x.focus)?x.focus:{};const focus={work:num(fox.work,5,120,25),rest:num(fox.rest,1,60,5),sessions:(Array.isArray(fox.sessions)?fox.sessions:[]).filter(isObj).slice(-600).map(p=>({date:dateRe.test(p.date||'')?p.date:today(),minutes:num(p.minutes,1,240,25)}))};
return{tasks,habits,checks,chat,behavior,snaps,settings,prayer,prayerLog,prayerResponses,checkins,family,worship,focus,idea:num(x.idea,0,100000,0)}}
async function importText(text){let x;try{if(String(text).length>5*1024*1024)throw 0;x=JSON.parse(text);if(x&&x._enc==='alislah-enc-v1'){if(!(NATIVE&&window.AndroidUsage&&typeof AndroidUsage.decryptBackup==='function')){toast('فتح النسخ المشفّرة متاح في نسخة أندرويد فقط');return}const pass=await ui.prompt('كلمة سر النسخة','','فتح',{password:true});if(pass===null)return;const plain=AndroidUsage.decryptBackup(String(text),String(pass));if(!plain){toast('كلمة السر غير صحيحة أو الملف تالف');return}x=JSON.parse(plain)}if(!x||typeof x!=='object'||Array.isArray(x)||!Array.isArray(x.tasks)||!Array.isArray(x.habits))throw 0}catch{toast('الملف غير صالح أو ليس نسخة من ALISLAH');return}
const c=cleanImport(x);if(!(await ui.confirm('استعادة النسخة؟','استعادة',true,'ستحل المهام والعادات والسجلات في هذه النسخة (${t} مهمة، ${h} عادة) محل بياناتك الحالية. لا تُستورد عناوين الخدمات ولا إعدادات المشاركة لأسباب أمنية.'.replace('${t}',c.tasks.length).replace('${h}',c.habits.length))))return;
try{data.tasks.forEach(t=>cancelTaskReminder(t.id))}catch(_){}
const cur=readJSON(KEY,{});const curS=isObj0(cur.settings)?cur.settings:{};
const fin={...cur,tasks:c.tasks,habits:c.habits,checks:c.checks,chat:c.chat,behavior:c.behavior,usageProfile:{snapshots:c.snaps},idea:c.idea,prayerLog:c.prayerLog,prayerResponses:c.prayerResponses,settings:{...curS,...c.settings,prayer:{...(curS.prayer||{}),...c.prayer,adhanEnabled:!!(curS.prayer&&curS.prayer.adhanEnabled)}},family:c.family,worship:c.worship,focus:c.focus,_rev:(Number(cur._rev)||0)+1};
try{localStorage.setItem(KEY,JSON.stringify(fin));localStorage.setItem(STORE_CHECKINS,JSON.stringify(c.checkins))}catch{toast('تعذر حفظ البيانات المستعادة');return}
location.reload()}
function isObj0(v){return v&&typeof v==='object'&&!Array.isArray(v)}
window.__alislahImport=importText;
const bindClick=(sel,fn)=>{const e=$(sel);if(e)e.onclick=fn};bindClick('#export',exportBackup);bindClick('#export2',exportBackup);
const pickFile=()=>$('#file').click();bindClick('#import',pickFile);bindClick('#import2',pickFile);
$('#file').onchange=async e=>{const f=e.target.files&&e.target.files[0];e.target.value='';if(!f)return;if(f.size>5*1024*1024){toast('الملف كبير جدًا');return}try{await importText(await f.text())}catch{toast('تعذر قراءة الملف')}};
$('#reset').onclick=async()=>{if(!(await ui.confirm('مسح كل البيانات؟','مسح الكل',true,'سيتم حذف المهام والعادات والمحادثات والإجابات والإعدادات من هذا الجهاز نهائيًا. احفظي نسخة احتياطية أولًا إن رغبتِ.')))return;
try{data.tasks.forEach(t=>cancelTaskReminder(t.id))}catch(_){}nat('syncPrayerPlan','[]',false);nat('enableBackgroundQuestions',false);
try{Object.keys(localStorage).filter(k=>/^alislah/i.test(k)).forEach(k=>localStorage.removeItem(k))}catch(_){}location.reload()};

function logActivity(label,detail){
  data.activityLog=Array.isArray(data.activityLog)?data.activityLog:[];
  data.activityLog.unshift({id:uid(),label:String(label||'نشاط').slice(0,80),detail:String(detail||'').slice(0,160),at:Date.now()});
  data.activityLog=data.activityLog.slice(0,100);save();
  try{document.dispatchEvent(new CustomEvent('alislah:activity'))}catch(_){}
}
window.ALI={get data(){return data},save,toast,ui,tab,today,ymd,uid,esc,nat,NATIVE,stats,renderTasks,renderHabits,scheduleTaskReminder,cancelTaskReminder,completeTask,applyTheme,nativeStatus,renderNative,CATS,REPEATS,exportBackup,pickFile,addVoiceTask:addVoiceTaskFromTranscript,recordUndo,undoLastAction,logActivity,openTask:function(id){const t=data.tasks.find(x=>x.id===id);if(!t)return false;tab('tasks');setTimeout(()=>openTaskSheet(t),80);return true}};
renderTasks();data.tasks.forEach(scheduleTaskReminder);renderHabits();stats();idea();drawChat();renderBehavior();renderUsage();applyTheme();applyGreeting();renderNative();maybeWelcome();document.dispatchEvent(new CustomEvent('alislah:ready'));checkInternetConnection();setInterval(checkInternetConnection,60000);runDailyAutoReschedule();setInterval(runDailyAutoReschedule,60000);
// Collect a lightweight local usage snapshot when Android grants Usage Access; never upload automatically.
try{if(window.AndroidUsage&&typeof AndroidUsage.getUsageStatsJson==='function'){const u=JSON.parse(AndroidUsage.getUsageStatsJson()||'{}');if(u.permission&&Array.isArray(u.apps)){const day=today();if(!data.usageProfile.snapshots.some(x=>x.date===day)){data.usageProfile.snapshots.push({date:day,apps:u.apps.slice(0,12).map(a=>({name:a.name||a.packageName,minutes:Math.max(0,Number(a.minutes)||0)})),capturedAt:Date.now()});data.usageProfile.snapshots=data.usageProfile.snapshots.slice(-14);save();}}} }catch(_){}if(data.settings.name)$('#greeting').textContent=`مرحبًا بعودتك ${data.settings.name}، ماذا تريد أن تفعل الآن؟ 🌿`;

// ميزات صوتية اختيارية: لا يبدأ الميكروفون إلا عند الضغط على الزر.
(function addVoiceAndPlan(){
  const form=$('#chatForm'), text=$('#chatText');
  if(!form||!text)return;
  const row=document.createElement('div');
  row.className='field';row.style.marginTop='8px';
  row.innerHTML='<label style="display:flex;align-items:center;gap:6px;font-size:.9rem">طريقة المساعد: <select id="alislahMode" style="max-width:160px"><option value="text">كتابة فقط</option><option value="voice">صوت</option><option value="both">كتابة وصوت</option></select></label><button type="button" class="btn soft" id="alislahVoice">🎙️ تحدثي</button><button type="button" class="btn" id="alislahStop">إيقاف الصوت</button><button type="button" class="btn soft" id="alislahVoiceTest">اختبار الصوت</button><label style="display:flex;align-items:center;gap:6px;font-size:.9rem"><input id="alislahRead" type="checkbox" style="width:18px"> قراءة الردود بصوت</label><label style="display:flex;align-items:center;gap:6px;font-size:.9rem">جنس الصوت القديم: <select id="alislahVoiceGender" style="max-width:120px"><option value="female">أنثى</option><option value="male">ذكر</option></select></label><label style="display:flex;align-items:center;gap:6px;font-size:.9rem">محرك صوت المساعد: <select id="alislahVoiceEngine" style="max-width:190px"><option value="old">المساعد القديم (محلي)</option><option value="neural">المساعد العربي العصبي الجديد (محلي)</option></select></label><label style="display:flex;align-items:center;gap:6px;font-size:.9rem">التحكم بأزرار صوت الهاتف: <select id="alislahAudioControlMode" style="max-width:190px"><option value="current">الوضع الحالي</option><option value="unified">الوضع الموحّد</option></select></label><small id="alislahAudioControlHint" class="muted" aria-live="polite"></small><small id="alislahVoiceStatus" class="muted" aria-live="polite">حالة الصوت: لم يُختبر بعد</small>';
  form.parentNode.insertBefore(row,form);
  const voice=$('#alislahVoice'),stop=$('#alislahStop'),voiceTest=$('#alislahVoiceTest'),read=$('#alislahRead'),mode=$('#alislahMode'),gender=$('#alislahVoiceGender'),engineSelect=$('#alislahVoiceEngine'),voiceStatus=$('#alislahVoiceStatus'),audioMode=$('#alislahAudioControlMode'),audioHint=$('#alislahAudioControlHint');audioMode.value=nat('getAudioControlMode')==='unified'?'unified':'current';data.settings.audioControlMode=audioMode.value;const updateAudioHint=()=>{audioHint.textContent=audioMode.value==='unified'?'المساعد والأذان والتذكيرات تستخدم مستوى صوت الوسائط وأزرار الصوت نفسها.':'تبقى قنوات الصوت كما كانت قبل هذا التحديث.'};updateAudioHint();audioMode.addEventListener('change',()=>{data.settings.audioControlMode=audioMode.value;save();nat('setAudioControlMode',audioMode.value);updateAudioHint();toast(audioMode.value==='unified'?'تم تفعيل التحكم الصوتي الموحّد':'تمت استعادة التحكم الصوتي الحالي')});mode.value=data.settings.interactionMode||'both';gender.value=data.settings.voiceGender||'female';engineSelect.value=data.settings.assistantVoiceEngine||'old';gender.addEventListener('change',()=>{data.settings.voiceGender=gender.value;save();try{if(window.AndroidUsage&&AndroidUsage.setAssistantVoice)AndroidUsage.setAssistantVoice(gender.value)}catch(_){}});engineSelect.addEventListener('change',()=>{data.settings.assistantVoiceEngine=engineSelect.value;save();try{nat('setAssistantVoiceEngine',engineSelect.value)}catch(_){}const ready=!!(window.AndroidUsage&&typeof AndroidUsage.isMixerTtsInstalled==='function'&&AndroidUsage.isMixerTtsInstalled());voiceStatus.textContent=engineSelect.value==='neural'?(ready?'المحرك العصبي الاختياري مثبت — يعمل محليًا دون إنترنت':'حزمة الصوت العصبي غير مثبتة؛ سيُستخدم الصوت القديم. ثبّت ALISLAH-Voice-Pack عند الحاجة.'):'المحرك المختار: القديم — يعمل محليًا';});try{nat('setAssistantVoiceEngine',engineSelect.value);if(window.AndroidUsage&&AndroidUsage.setAssistantVoice)AndroidUsage.setAssistantVoice(gender.value);if(window.AndroidUsage&&AndroidUsage.setAssistantVoiceMode)AndroidUsage.setAssistantVoiceMode(mode.value);const ready=!!(window.AndroidUsage&&typeof AndroidUsage.isMixerTtsInstalled==='function'&&AndroidUsage.isMixerTtsInstalled());if(engineSelect.value==='neural'&&!ready)voiceStatus.textContent='حزمة الصوت العصبي الاختيارية غير مثبتة؛ سيُستخدم الصوت القديم حتى تثبيتها.';}catch(_){};read.checked=!!data.settings.voiceRead||mode.value==='voice';mode.addEventListener('change',()=>{data.settings.interactionMode=mode.value;if(mode.value==='voice')read.checked=true;if(mode.value==='text')read.checked=false;data.settings.voiceRead=read.checked;save();try{if(window.AndroidUsage&&AndroidUsage.setAssistantVoiceMode)AndroidUsage.setAssistantVoiceMode(mode.value)}catch(_){}voice.style.display=mode.value==='text'?'none':'inline-flex';text.placeholder=mode.value==='voice'?'اضغطي تحدثي ثم تكلمي...':'اكتبي سؤالك...';});read.addEventListener('change',()=>{data.settings.voiceRead=read.checked;save()});voice.style.display=mode.value==='text'?'none':'inline-flex';
  const Recognition=window.SpeechRecognition||window.webkitSpeechRecognition;let rec=null;
  function say(t){
    if(window.AndroidUsage&&typeof AndroidUsage.speakAssistantText==='function'){try{AndroidUsage.speakAssistantText(String(t||'').slice(0,700))}catch{}return;}
    if(!('speechSynthesis' in window)){toast('المتصفح لا يدعم قراءة الردود بالصوت');return;}
    speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang='ar';u.rate=.95;const voices=speechSynthesis.getVoices();const female=/female|woman|salma|amira|hoda|laila|sara|ar.*fem|أنثى|امرأة/i;const male=/male|man|ahmed|hamza|omar|ar.*male|ذكر|رجل/i;const wanted=gender.value==='male'?male:female;const chosen=voices.find(v=>/^ar/i.test(v.lang)&&wanted.test(v.name))||voices.find(v=>/^ar/i.test(v.lang));if(chosen)u.voice=chosen;speechSynthesis.speak(u);
  }
  voice.onclick=()=>{
    if(window.AndroidUsage&&typeof AndroidUsage.startListening==='function'){
      try{
        if(typeof AndroidUsage.isSpeechAvailable==='function'&&!AndroidUsage.isSpeechAvailable()){toast('خدمة التعرف على الكلام غير متوفرة على هذا الهاتف');return;}
        voice.disabled=true;voice.textContent='🎙️ أستمع…';
        window.__alislahSpeech=(kind,val)=>{
          if(kind==='result'&&val){text.value=(text.value.trim()?text.value.trim()+' ':'')+val;text.focus();if(mode.value==='voice'){submitFormCompat(form);}}
          else if(kind==='error'){toast(val==='not-allowed'||val==='9'?'اسمحي للتطبيق باستخدام الميكروفون ثم أعيدي المحاولة':'لم أسمع بوضوح؛ أعيدي المحاولة')}
          else if(kind==='end'){voice.disabled=false;voice.textContent='🎙️ تحدثي'}
        };
        AndroidUsage.startListening();
      }catch{voice.disabled=false;voice.textContent='🎙️ تحدثي';toast('تعذّر تشغيل الميكروفون')}
      return;
    }
    if(!Recognition){toast('الإملاء الصوتي غير مدعوم في هذا المتصفح؛ جرّبي Chrome');return;}
    try{
      rec=new Recognition();rec.lang='ar-DZ';rec.interimResults=false;
      voice.disabled=true;voice.textContent='🎙️ أستمع…';
      rec.onresult=e=>{const t=e.results?.[0]?.[0]?.transcript;if(t){text.value=(text.value.trim()?text.value.trim()+' ':'')+t;text.focus();if(mode.value==='voice'){submitFormCompat(form);}}};
      rec.onerror=e=>{if(e.error==='not-allowed')toast('اسمحي للمتصفح باستخدام الميكروفون');};
      rec.onend=()=>{voice.disabled=false;voice.textContent='🎙️ تحدثي';};
      rec.start();
    }catch{voice.disabled=false;voice.textContent='🎙️ تحدثي';toast('تعذّر تشغيل الميكروفون');}
  };
  voiceTest.onclick=()=>{try{if(window.AndroidUsage&&typeof AndroidUsage.testAssistantVoice==='function'){AndroidUsage.testAssistantVoice();toast('جارٍ اختبار صوت المساعد')}else{say('مرحبًا بك في الإصلاح. هذا اختبار لصوت المساعد العربي.')}}catch{toast('تعذّر بدء اختبار الصوت')}};
  stop.onclick=()=>{try{rec?.stop()}catch{}try{nat('stopListening');nat('stopAssistantSpeech')}catch{}if('speechSynthesis'in window)speechSynthesis.cancel();if(window.AlishlahNeuralVoice)window.AlishlahNeuralVoice.stop();};
  window.addEventListener('alislah:neural-voice',e=>{if(voiceStatus)voiceStatus.textContent=e.detail&&e.detail.ok?'حالة الصوت: المحرك العصبي جاهز ويعمل':'حالة الصوت: '+String(e.detail&&e.detail.detail||'تعذر تشغيل المحرك العصبي')+' — تحقق من ملفات المحرك أو اختر المساعد القديم';});
  const messages=$('#messages');
  if(messages)new MutationObserver(records=>{
    if(!(read.checked||mode.value==='voice'))return;
    for(const r of records)for(const n of r.addedNodes){
      if(n.nodeType===1&&n.classList.contains('bubble')&&n.classList.contains('assistant'))say(n.textContent||'');
    }
  }).observe(messages,{childList:true});
  const panel=document.createElement('div');panel.className='panel';panel.style.marginTop='12px';
  panel.innerHTML='<h3>✨ خطة ذكية</h3><p class="muted">تستخدم الخطة المهام والعادات ومؤشرات السلوك التي حفظتِها. راجعي الطلب قبل إرساله.</p><button type="button" class="btn primary" id="alislahPlan">إنشاء خطة شخصية</button>';
  const tasks=$('#tasks');if(tasks)tasks.appendChild(panel);
  const savePlan=document.createElement('button');savePlan.type='button';savePlan.className='btn soft';savePlan.textContent='تحويل آخر خطة إلى مهام مجدولة';savePlan.style.marginInlineStart='6px';panel.appendChild(savePlan);
  savePlan.onclick=async()=>{const last=$('#messages .bubble.assistant:last-child');const raw=(last?.innerText||last?.textContent||'').trim();if(!raw||raw.length<12){toast('اطلبي الخطة من المساعد أولًا ثم حوّلي الرد إلى مهام');return}const clean=extractPlanTasks(raw);if(!clean.length){toast('لم أجد مهامًا واضحة في آخر رد؛ اطلبي من المساعد كتابة كل مهمة في سطر مستقل');return}const norm=x=>String(x||'').toLocaleLowerCase('ar').replace(/[\s\u0640.,،؛:!?؟()\[\]{}'"ـ-]/g,'');const existing=new Set(data.tasks.filter(t=>!t.done).map(t=>norm(t.text)));const unique=clean.filter(t=>{const k=norm(t);if(!k||existing.has(k))return false;existing.add(k);return true;});if(!unique.length){toast('هذه المهام موجودة بالفعل؛ لم أكررها.');return}if(!(await ui.confirm('تحويل الخطة إلى مهام؟','تحويل',false,'سأحوّل '+unique.length+' مهام إلى مهام قابلة للتأشير مع مواعيد أولية. يمكنك تعديلها بعد ذلك.')))return;createPlannedTasks(unique,'assistant-plan');tab('tasks');toast('تمت إضافة المهام بأوقات خالية من التعارض؛ راجعي الجدول')};
  $('#alislahPlan').onclick=()=>{
    if(Object.keys(data.behavior||{}).length && !$('#analysisConsent').checked){tab('behavior');toast('فعّلي الموافقة قبل إعداد خطة تعتمد على بياناتك');return;}
    tab('assistant');
    text.value=makeBehaviorPrompt();
    text.dataset.includesPersonalAnalysis=Object.keys(data.behavior||{}).length?'true':'false';
    if(!Object.keys(data.behavior||{}).length)text.value='أنشئ لي خطة شخصية عملية لمدة 7 أيام اعتمادًا على البيانات المتاحة فقط. اكتب كل يوم بعنوان اليوم 1 إلى اليوم 7، وتحته 2 إلى 4 مهام مستقلة قابلة للتنفيذ، كل مهمة في سطر مستقل يبدأ برقم ونقطة. اجمع عنوان المهمة مع وصفها العملي في السطر نفسه، وحدد مدة أو وقتًا مقترحًا. لا تكتب نصائح عامة كأنها مهام ولا تخترع بيانات.';
    text.focus();
  };
})();

})();
