from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/dz/alislah/app/FloatingBubbleService.kt').read_text(encoding='utf-8')
gpu=(root/'app/src/main/java/dz/alislah/app/Plasma3DRenderer.kt').read_text(encoding='utf-8')
assert 'Plasma3DView(context)' in s
assert 'PlasmaActionTextView' in s and 'PlasmaOrbit3DView(this)' in s
assert 'float sdTorus(vec3 p)' in gpu
assert 'runOverlayJs("document.getElementById(\'contentRead\')?.click();")' in s
assert 'handler.postDelayed({ hideAssistantOverlay() }, 350L)' in s
print('PASS: OpenGL main orb, independent side orbs, 3D energy orbit, and floating-bubble zad read path')
