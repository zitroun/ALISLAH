from pathlib import Path
root=Path(__file__).resolve().parents[1]
renderer=(root/'app/src/main/java/dz/alislah/app/Plasma3DRenderer.kt').read_text(encoding='utf-8')
service=(root/'app/src/main/java/dz/alislah/app/FloatingBubbleService.kt').read_text(encoding='utf-8')
gradle=(root/'app/build.gradle').read_text(encoding='utf-8')
checks={
 'OpenGL ES 2 context':'setEGLContextClientVersion(2)' in renderer,
 'battery-aware frame pacing':'RENDERMODE_WHEN_DIRTY' in renderer and 'framePump' in renderer,
 'GPU vertex and fragment shaders':'GL_VERTEX_SHADER' in renderer and 'GL_FRAGMENT_SHADER' in renderer,
 '3D sphere ray intersection':'float h=b*b-c' in renderer and 'vec3 n=normalize(p)' in renderer,
 'volumetric animated plasma fields':'float field(vec3 p,float t)' in renderer and 'uTime' in renderer,
 'real lighting and specular reflections':'float diffuse=max(dot(n,light),0.0)' in renderer and 'float spec=' in renderer,
 'assistant state speed mapping': all(x in renderer for x in ['"idle"','"listening"','"thinking"','"speaking"']),
 'service uses GPU sphere':'private val sphere = Plasma3DView(context)' in service,
 'orbit uses ray-marched 3D torus':'PlasmaOrbit3DView(this)' in service and 'float sdTorus(vec3 p)' in renderer,
 'side actions use independent GPU spheres':'private val plasma = Plasma3DView(context, compact = true)' in service and 'plasma.setTint(tint)' in service,
 'existing min Android 8.1':'minSdk 26' in gradle,
 'version code 64':'versionCode 64' in gradle,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' '+name)
assert all(checks.values())
