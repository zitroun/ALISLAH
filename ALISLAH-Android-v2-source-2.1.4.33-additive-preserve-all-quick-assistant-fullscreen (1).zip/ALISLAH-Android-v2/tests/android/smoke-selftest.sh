#!/usr/bin/env bash
# Checks the smoke script's logic with a fake adb: a healthy launch, a crash, a process that is not running,
# and an almost blank screen.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/bin"
cat > "$TMP/bin/adb" <<'FAKE'
#!/usr/bin/env bash
case "$*" in
  wait-for-device) exit 0 ;;
  "shell getprop sys.boot_completed") echo 1 ;;
  "shell input keyevent 82") exit 0 ;;
  install*) echo "Success" ;;
  logcat\ -c) exit 0 ;;
  "shell pm grant"*) exit 0 ;;
  "shell am start"*) echo "Status: ok" ;;
  "shell pidof"*) if [ "${FAKE_PID:-1}" = "1" ]; then echo 4321; else exit 1; fi ;;
  "shell dumpsys activity activities") echo "mResumedActivity: ActivityRecord{x u0 dz.alislah.app.allinone/dz.alislah.app.MainActivity t12}" ;;
  logcat\ -d*) cat "${FAKE_LOG:-/dev/null}" ;;
  "exec-out screencap -p") head -c "${FAKE_PNG_BYTES:-60000}" /dev/zero ;;
  *) echo "unexpected adb call: $*" >&2; exit 2 ;;
esac
FAKE
chmod +x "$TMP/bin/adb"
printf 'apk' > "$TMP/app.apk"
printf '01-01 I/ActivityThread: start ok\n' > "$TMP/log-ok.txt"
printf '01-01 E/AndroidRuntime: FATAL EXCEPTION: main\n01-01 E/AndroidRuntime: Process: dz.alislah.app.allinone\n' > "$TMP/log-crash.txt"
fail=0
run() {  # name, expected exit code, expected text, then VAR=value settings for the fake adb
  local name="$1" want_code="$2" want_text="$3"; shift 3
  local out code
  out=$(env "$@" SMOKE_WAIT=0 SMOKE_OUT="$TMP/out-$name" PATH="$TMP/bin:$PATH" bash "$HERE/smoke.sh" "$TMP/app.apk" 2>&1)
  code=$?
  if [ "$code" = "$want_code" ] && printf '%s' "$out" | grep -q "$want_text"; then
    echo "ok   $name"
  else
    echo "FAIL $name (exit $code):"; printf '%s\n' "$out" | head -5; fail=1
  fi
}
run healthy 0 "PASS" FAKE_PID=1 FAKE_LOG="$TMP/log-ok.txt" FAKE_PNG_BYTES=60000
run crash 1 "FAIL: crash or ANR" FAKE_PID=1 FAKE_LOG="$TMP/log-crash.txt" FAKE_PNG_BYTES=60000
run not-running 1 "FAIL: the app process" FAKE_PID=0 FAKE_LOG="$TMP/log-ok.txt" FAKE_PNG_BYTES=60000
run blank-screen 1 "almost blank" FAKE_PID=1 FAKE_LOG="$TMP/log-ok.txt" FAKE_PNG_BYTES=2000
if [ "$fail" = 0 ]; then echo "smoke self-test: all cases pass"; else echo "smoke self-test: failures"; exit 1; fi
