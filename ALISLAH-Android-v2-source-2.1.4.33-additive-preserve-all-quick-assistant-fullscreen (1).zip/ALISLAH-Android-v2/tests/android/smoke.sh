#!/usr/bin/env bash
# Smoke test on an Android emulator (2.1.4.33). Installs the debug APK, launches MainActivity, and fails if the app
# is not running, is not in the foreground, crashed or froze (ANR), or drew an almost blank screen.
# The blank-screen check is a size heuristic: a drawn app screen is much larger than a plain colour.
# It keeps a screenshot and the log as evidence.
set -euo pipefail
APK="${1:?usage: smoke.sh <path-to-apk>}"
PKG="dz.alislah.app.allinone"
ACT="dz.alislah.app.MainActivity"
OUT="${SMOKE_OUT:-smoke-out}"
MIN_PNG="${SMOKE_MIN_PNG:-30000}"
mkdir -p "$OUT"

adb wait-for-device
until [ "$(adb shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" = "1" ]; do sleep 2; done
adb shell input keyevent 82 >/dev/null 2>&1 || true
adb install -r -t "$APK" | tee "$OUT/install.txt"
grep -q "Success" "$OUT/install.txt" || { echo "FAIL: install did not succeed"; exit 1; }
adb logcat -c || true
adb shell pm grant "$PKG" android.permission.POST_NOTIFICATIONS >/dev/null 2>&1 || true
adb shell am start -W -n "$PKG/$ACT" | tee "$OUT/start.txt"
sleep "${SMOKE_WAIT:-20}"

if ! adb shell pidof "$PKG" >/dev/null 2>&1; then
  echo "FAIL: the app process is not running"
  exit 1
fi
if ! adb shell dumpsys activity activities | grep -q "$PKG/$ACT"; then
  echo "FAIL: MainActivity is not in the foreground"
  exit 1
fi
adb logcat -d -v brief > "$OUT/logcat.txt" || true
if grep -E "FATAL EXCEPTION|ANR in $PKG" "$OUT/logcat.txt" >/dev/null; then
  echo "FAIL: crash or ANR found in logcat:"
  grep -E -A4 "FATAL EXCEPTION|ANR in $PKG" "$OUT/logcat.txt" | head -60
  exit 1
fi
adb exec-out screencap -p > "$OUT/home.png" || echo "WARN: screenshot failed"
shot_bytes=$(wc -c < "$OUT/home.png" 2>/dev/null || echo 0)
if [ "$shot_bytes" -lt "$MIN_PNG" ]; then
  echo "FAIL: the screenshot is almost blank ($shot_bytes bytes, below $MIN_PNG): the WebView may not have drawn the app"
  exit 1
fi
js_errors=$(grep -c -E "Uncaught|SyntaxError|ReferenceError" "$OUT/logcat.txt" || true)
echo "WARN: JavaScript errors in the WebView log: ${js_errors} (see $OUT/logcat.txt)"
echo "PASS: the app launched, stayed alive, drew the screen ($shot_bytes bytes) and showed no crash. Evidence in $OUT/"
