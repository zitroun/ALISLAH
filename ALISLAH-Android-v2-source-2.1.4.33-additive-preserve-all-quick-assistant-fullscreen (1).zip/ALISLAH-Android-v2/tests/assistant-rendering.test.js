// Assistant replies and restored chat history are untrusted text. They must reach the page escaped.
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const src = fs.readFileSync(path.join(__dirname, '..', 'app/src/main/assets/js/main.js'), 'utf8');

function extract(name) {
  const start = src.indexOf('function ' + name + '(');
  assert.ok(start >= 0, 'function not found: ' + name);
  let depth = 0;
  for (let i = src.indexOf('{', start); i < src.length; i++) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) return src.slice(start, i + 1); }
  }
  throw new Error('unbalanced braces in ' + name);
}
const ctx = vm.createContext({});
vm.runInContext(extract('escHtml') + '\n' + extract('formatAssistantText'), ctx);
const render = (s) => vm.runInContext('formatAssistantText(' + JSON.stringify(s) + ')', ctx);

assert.strictEqual(vm.runInContext('escHtml(\'<a>&"\\\'\')', ctx), '&lt;a&gt;&amp;&quot;&#39;');
const cases = [
  ['<img src=x onerror=alert(1)>', (o) => !o.includes('<img') && o.includes('&lt;img')],
  ['<script>alert(1)</script>', (o) => !o.includes('<script')],
  ['- <a href="javascript:x">link</a>', (o) => !o.includes('<a href')],
  ['# <u>title</u>', (o) => !o.includes('<u>')],
  ['| <i>cell</i> | next |', (o) => !o.includes('<i>')],
  ['> <b>quoted</b>', (o) => !o.includes('<b>')],
  ['```\n<svg onload=x>\n```', (o) => !o.includes('<svg') && o.includes('&lt;svg')],
  ['**مهم** و <b>x</b>', (o) => o.includes('<strong>مهم</strong>') && o.includes('&lt;b&gt;')],
];
for (const [input, ok] of cases) {
  const out = render(input);
  assert.ok(ok(out), 'unsafe or wrong rendering for ' + JSON.stringify(input) + ' -> ' + out);
}
console.log('assistant rendering: ' + cases.length + ' cases escape live markup');
