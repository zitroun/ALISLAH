const assert = require('assert');
const { makeStore } = require('../app/src/main/assets/js/store.js');
function fakeStorage() {
  const s = {};
  let full = false;
  Object.defineProperties(s, {
    getItem: { value: (k) => (Object.prototype.hasOwnProperty.call(s, k) ? s[k] : null), enumerable: false },
    setItem: { value: (k, v) => { if (full) throw new Error('QuotaExceededError'); s[k] = String(v); }, enumerable: false },
    removeItem: { value: (k) => { delete s[k]; }, enumerable: false },
    setFull: { value: (on) => { full = on; }, enumerable: false },
  });
  return s;
}
const st = makeStore(fakeStorage());
assert.strictEqual(st.getRaw('missing'), null, 'a missing key reads as null');
assert.deepStrictEqual(st.getJSON('missing', { a: 1 }), { a: 1 }, 'a missing key gives the default');
st.setJSON('obj', { tasks: [{ id: 't1', text: 'سقي' }] });
assert.deepStrictEqual(st.getJSON('obj', null), { tasks: [{ id: 't1', text: 'سقي' }] }, 'JSON round trip');
st.setRaw('raw', 'plain text');
assert.strictEqual(st.getRaw('raw'), 'plain text');
st.setRaw('num', '5');
assert.deepStrictEqual(st.getJSON('num', 'd'), 'd', 'non-object JSON gives the default');
st.setRaw('empty', '');
assert.deepStrictEqual(st.getJSON('empty', 'd'), 'd', 'an empty value gives the default');
assert.strictEqual(st.getRaw('alislah_quarantine:empty'), null, 'an empty value is not quarantined');
st.setRaw('broken', '{"tasks": [');
assert.deepStrictEqual(st.getJSON('broken', { tasks: [] }), { tasks: [] }, 'corrupted JSON gives the default');
assert.strictEqual(st.getRaw('alislah_quarantine:broken'), '{"tasks": [', 'corrupted JSON is kept for recovery');
assert.ok(st.keys().includes('obj') && st.keys().includes('alislah_quarantine:broken'), 'keys lists stored keys');
st.removeRaw('raw');
assert.strictEqual(st.getRaw('raw'), null, 'removeRaw deletes');
const s2 = fakeStorage(); const st2 = makeStore(s2);
s2.setFull(true);
assert.throws(() => st2.setRaw('x', '1'), /QuotaExceededError/, 'write errors are re-thrown as before');
assert.throws(() => st2.setJSON('x', { a: 1 }), /QuotaExceededError/, 'JSON write errors are re-thrown as before');
const brokenRead = makeStore({ getItem() { throw new Error('SecurityError'); }, setItem() {}, removeItem() {}, });
assert.deepStrictEqual(brokenRead.getJSON('k', 'fallback'), 'fallback', 'an unreadable store gives the default');

// The revision rule must match the old inline expressions for every kind of value they could meet.
const samples = [undefined, null, 0, 1, 2, 5, '3', '', 'x', NaN];
for (const a of samples) {
  for (const b of samples) {
    const local = a === undefined ? {} : { _rev: a };
    const native = b === undefined ? {} : { _rev: b };
    const old = Number(native._rev || 0) > Number(local._rev || 0);
    assert.strictEqual(st.nativeIsNewer(local, native), old, `nativeIsNewer differs for ${a} / ${b}`);
    const oldLocal = Number(local._rev || 0) > Number(native._rev || 0);
    assert.strictEqual(st.localIsNewer(local, native), oldLocal, `localIsNewer differs for ${a} / ${b}`);
  }
}
assert.strictEqual(st.nativeIsNewer({ _rev: 5 }, { _rev: 5 }), false, 'a tie keeps the local copy');
assert.strictEqual(st.nativeIsNewer({ _rev: 1 }, { _rev: 'x' }), false, 'a non-numeric revision never wins');
assert.strictEqual(st.localIsNewer({ _rev: 6 }, { _rev: 5 }), true);
console.log('store gateway: all checks pass');
