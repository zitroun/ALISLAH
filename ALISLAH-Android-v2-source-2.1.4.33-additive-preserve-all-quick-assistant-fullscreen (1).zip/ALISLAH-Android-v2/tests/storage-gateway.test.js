// Nothing except the gateway may touch the browser storage directly, so every write is visible in one place.
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const dir = path.join(__dirname, '..', 'app/src/main/assets');
const jsDir = path.join(dir, 'js');
const modules = fs.readdirSync(jsDir).filter((f) => f.endsWith('.js') && f !== 'store.js');
const offenders = modules.filter((f) => /\blocalStorage\b/.test(fs.readFileSync(path.join(jsDir, f), 'utf8')));
assert.deepStrictEqual(offenders, [], 'direct localStorage use outside store.js: ' + offenders.join(', '));
const html = fs.readFileSync(path.join(dir, 'index.html'), 'utf8');
const inlineUses = (html.match(/\blocalStorage\b/g) || []).length;
assert.ok(inlineUses <= 1, 'index.html may keep its single inline use (its CSP hash depends on it); found ' + inlineUses);
const scripts = [...html.matchAll(/<script\s+src="([^"]+)"/g)].map((m) => m[1]);
assert.strictEqual(scripts[0], 'js/store.js', 'store.js must load before every other script');
console.log(`storage gateway: ${modules.length} modules use ALI_STORE only; store.js loads first`);
