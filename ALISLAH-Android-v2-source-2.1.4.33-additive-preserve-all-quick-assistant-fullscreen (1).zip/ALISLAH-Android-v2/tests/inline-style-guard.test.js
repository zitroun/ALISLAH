// Ratchet for inline style attributes (2.1.4.33): the page and the scripts may not gain new ones.
// Moving a style to a class lowers the number; when it does, lower the limit here too.
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const dir = path.join(__dirname, '..', 'app/src/main/assets');
const html = fs.readFileSync(path.join(dir, 'index.html'), 'utf8');
const pageStyles = (html.match(/\sstyle="/g) || []).length;
const jsDir = path.join(dir, 'js');
const scriptStyles = fs.readdirSync(jsDir).filter((f) => f.endsWith('.js'))
  .reduce((n, f) => n + (fs.readFileSync(path.join(jsDir, f), 'utf8').match(/\sstyle="/g) || []).length, 0);
assert.ok(pageStyles <= 16, 'index.html gained inline style attributes: ' + pageStyles + ' (limit 16)');
assert.ok(scriptStyles <= 70, 'scripts gained inline style attributes: ' + scriptStyles + ' (limit 70)');
console.log('inline styles: page ' + pageStyles + ' (limit 16), scripts ' + scriptStyles + ' (limit 70)');
