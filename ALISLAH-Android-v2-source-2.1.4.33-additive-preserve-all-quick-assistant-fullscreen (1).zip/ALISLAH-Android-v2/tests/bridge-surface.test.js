// Guards the bridge between the web page and the native code.
// Fails when a method is exposed to the page without review, when the page calls a method that is not exposed,
// when a method is exposed but never used by the page, or when a second interface name appears.
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (e.name.endsWith('.kt')) out.push(p);
  }
  return out;
}

const exposed = new Map();      // method name -> files that expose it
const interfaces = new Set();   // names given to addJavascriptInterface
for (const file of walk(path.join(ROOT, 'app/src/main/java'))) {
  const text = fs.readFileSync(file, 'utf8');
  const lines = text.split('\n');
  lines.forEach((line, i) => {
    if (!line.includes('@JavascriptInterface')) return;
    let name = null;
    for (let j = i; j < Math.min(i + 5, lines.length) && !name; j++) {
      const m = /\bfun\s+(?:<[^>]+>\s*)?([A-Za-z_]\w*)\s*\(/.exec(lines[j]);
      if (m) name = m[1];
    }
    assert.ok(name, `no method found for the annotation in ${path.basename(file)}:${i + 1}`);
    if (!exposed.has(name)) exposed.set(name, []);
    exposed.get(name).push(path.basename(file));
  });
  let at = text.indexOf('addJavascriptInterface(');
  while (at >= 0) {
    const m = /,\s*"([A-Za-z_]\w*)"\s*\)/.exec(text.slice(at, at + 4000));
    assert.ok(m, `interface name not found after addJavascriptInterface in ${path.basename(file)}`);
    interfaces.add(m[1]);
    at = text.indexOf('addJavascriptInterface(', at + 1);
  }
}

const allowed = JSON.parse(fs.readFileSync(path.join(__dirname, 'bridge-surface.allow.json'), 'utf8'));
const current = [...exposed.keys()].sort();
const wanted = [...allowed.methods].sort();
const added = current.filter((n) => !wanted.includes(n));
const removed = wanted.filter((n) => !current.includes(n));
assert.deepStrictEqual(added, [], 'new methods are exposed to the page; review them, then add them to tests/bridge-surface.allow.json: ' + added.join(', '));
assert.deepStrictEqual(removed, [], 'methods were removed; update tests/bridge-surface.allow.json: ' + removed.join(', '));
assert.deepStrictEqual([...interfaces].sort(), [...allowed.interfaces].sort(), 'unexpected interface names: ' + [...interfaces].join(', '));

const assetsDir = path.join(ROOT, 'app/src/main/assets');
const jsFiles = fs.readdirSync(path.join(assetsDir, 'js')).filter((f) => f.endsWith('.js')).map((f) => path.join(assetsDir, 'js', f));
const js = [...jsFiles, path.join(assetsDir, 'index.html')].map((f) => fs.readFileSync(f, 'utf8')).join('\n');
const called = new Set([
  ...[...js.matchAll(/\bnat\(\s*['"](\w+)['"]/g)].map((m) => m[1]),
  ...[...js.matchAll(/(?:AndroidUsage|ALISLAHStore)\??\.(\w+)\s*\(/g)].map((m) => m[1]),
]);
const missing = [...called].filter((n) => !exposed.has(n));
assert.deepStrictEqual(missing, [], 'the page calls methods that are not exposed: ' + missing.join(', '));
const unused = current.filter((n) => !new RegExp('\\b' + n + '\\b').test(js));
assert.deepStrictEqual(unused, [], 'exposed but never used by the page (drop the annotation): ' + unused.join(', '));
console.log(`bridge surface: ${current.length} methods, all reviewed, all used by the page; interfaces ${[...interfaces].sort().join(', ')}`);
