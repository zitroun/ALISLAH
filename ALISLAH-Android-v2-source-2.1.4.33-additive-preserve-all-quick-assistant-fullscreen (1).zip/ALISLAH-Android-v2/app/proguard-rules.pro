# Prepared for enabling R8 (2.1.4.32). Not used while minifyEnabled is false.
# The page calls native code through addJavascriptInterface. R8 would rename or remove those methods
# unless they are kept, so every method annotated with @JavascriptInterface is kept.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
