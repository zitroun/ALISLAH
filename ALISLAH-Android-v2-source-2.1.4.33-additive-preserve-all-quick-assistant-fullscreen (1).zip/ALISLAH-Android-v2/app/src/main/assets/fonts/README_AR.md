# الخطوط العربية داخل التطبيق

الهدف أن يظهر النص بالشكل نفسه على كل الهواتف، بدل الاعتماد على خط النظام الذي يختلف بين الشركات.

## الملفات المطلوبة
1. `alislah-ui-arabic.woff2` للواجهة، مثل Noto Kufi Arabic أو IBM Plex Sans Arabic.
2. `alislah-quran-arabic.woff2` للنص القرآني والعناوين، مثل Amiri أو Noto Naskh Arabic.
3. `OFL.txt`، وهو نص الترخيص المرافق للخط. كل هذه الخطوط بترخيص SIL Open Font License 1.1، ويشترط الترخيص توزيع نصه مع الخط.

## التحويل (على حاسوبكِ، بعد تنزيل ملف TTF من Google Fonts)
```
pip install fonttools brotli
pyftsubset NotoKufiArabic-Regular.ttf --unicodes="U+0020-007E,U+00A0-00FF,U+0600-06FF,U+0750-077F,U+08A0-08FF,U+2000-206F,U+FB50-FDFF,U+FE70-FEFF" --layout-features='*' --flavor=woff2 --output-file=alislah-ui-arabic.woff2
```
كرّري الأمر للخط القرآني باسم الملف `alislah-quran-arabic.woff2`. التحويل إلى ملف مقتطع بهذه النطاقات يحافظ على حروف العربية وتشكيلها ويصغّر الحجم.

## التفعيل
بعد وضع الملفين هنا، اتبعي الخطوات الثلاث المكتوبة في أعلى `fonts.css`. قبل ذلك لا يُربط الملف، لكي لا تظهر أخطاء تحميل في سجل التطبيق.
