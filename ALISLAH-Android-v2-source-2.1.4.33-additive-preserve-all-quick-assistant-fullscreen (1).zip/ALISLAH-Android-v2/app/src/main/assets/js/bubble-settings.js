/* Bubble options of 2.1.4.33: system bubbles, full-screen hiding through the accessibility watcher, live prayer countdown. */
(function () {
  'use strict';
  var KEY = 'alislah_bubble_extras';
  function $(id) { return document.getElementById(id); }
  function native(name, arg) {
    try {
      if (window.AndroidUsage && typeof AndroidUsage[name] === 'function') {
        return arg === undefined ? AndroidUsage[name]() : AndroidUsage[name](arg);
      }
    } catch (e) { return undefined; }
    return undefined;
  }
  function read() { try { return JSON.parse(ALI_STORE.getRaw(KEY) || '{}') || {}; } catch (e) { return {}; } }
  function write(extras) {
    try { ALI_STORE.setRaw(KEY, JSON.stringify(extras)); } catch (e) { /* storage full: the setting still applies now */ }
    native('setBubbleExtras', JSON.stringify(extras));
  }
  function refreshStatus() {
    var mode = $('bubbleModeStatus'), acc = $('a11yStatus');
    if (!window.AndroidUsage) {
      if (mode) mode.textContent = 'متاح في نسخة أندرويد';
      if (acc) acc.textContent = '';
      return;
    }
    var ms = native('bubbleModeStatus');
    if (mode) mode.textContent = ms === 'ready' ? 'الفقاعات الرسمية جاهزة للاستعمال'
      : ms === 'blocked' ? 'فعّلي الفقاعات لـ ALISLAH من إعدادات Android أولاً'
      : 'تحتاج الفقاعات الرسمية إلى Android 11 فما بعد';
    var on = native('accessibilityEnabled');
    if (acc) acc.textContent = on ? 'إذن إمكانية الوصول: ممنوح ✓' : 'إذن إمكانية الوصول: غير ممنوح بعد';
  }
  function init() {
    var extras = read();
    if ($('bubbleMode')) $('bubbleMode').value = extras.mode === 'system' ? 'system' : 'custom';
    if ($('bubbleFullscreen')) $('bubbleFullscreen').checked = extras.hideFullscreen === true;
    if ($('bubbleLive')) $('bubbleLive').checked = extras.liveCountdown === true;
    if (window.AndroidUsage) write(extras);
    refreshStatus();
    if ($('bubbleMode')) $('bubbleMode').onchange = function (e) {
      var extras = read(); extras.mode = e.target.value === 'system' ? 'system' : 'custom';
      write(extras); native('setBubbleMode', extras.mode); setTimeout(refreshStatus, 400);
    };
    if ($('openBubbleSettings')) $('openBubbleSettings').onclick = function () { native('openBubbleSettings'); };
    if ($('bubbleFullscreen')) $('bubbleFullscreen').onchange = function (e) {
      var extras = read(); extras.hideFullscreen = e.target.checked === true; write(extras);
      if (extras.hideFullscreen && window.AndroidUsage && !native('accessibilityEnabled')) native('openAccessibilitySettings');
      setTimeout(refreshStatus, 400);
    };
    if ($('bubbleScale')) { $('bubbleScale').value = String(Math.round((extras.scale || 1) * 100)); $('bubbleScale').oninput = function (e) { var x = read(); x.scale = Number(e.target.value) / 100; write(x); }; }
    if ($('bubbleAlpha')) { $('bubbleAlpha').value = String(Math.round((extras.alpha || 1) * 100)); $('bubbleAlpha').oninput = function (e) { var x = read(); x.alpha = Number(e.target.value) / 100; write(x); }; }
    if ($('bubbleFree')) { $('bubbleFree').checked = extras.free === true; $('bubbleFree').onchange = function (e) { var x = read(); x.free = e.target.checked === true; write(x); }; }
    if ($('bubbleDriving')) { $('bubbleDriving').checked = extras.driving !== false; $('bubbleDriving').onchange = function (e) { var x = read(); x.driving = e.target.checked === true; write(x); }; }
    if ($('bubbleLive')) $('bubbleLive').onchange = function (e) {
      var extras = read(); extras.liveCountdown = e.target.checked === true; write(extras);
    };
    if ($('requestA11y')) $('requestA11y').onclick = function () {
      native('openAccessibilitySettings'); setTimeout(refreshStatus, 1500);
    };
  }
  /* The focus timer tells the bubble when it runs, so the ring changes colour. */
  document.addEventListener('click', function (e) {
    var t = e.target && e.target.closest ? e.target.closest('#fStart,#fReset,#fSkip') : null;
    if (!t) return;
    setTimeout(function () {
      var st = document.getElementById('fStart');
      var running = t.id === 'fStart' && !!st && !/▶|ابدئ/.test(st.textContent);
      native('setFocusActive', running);
    }, 60);
  });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
