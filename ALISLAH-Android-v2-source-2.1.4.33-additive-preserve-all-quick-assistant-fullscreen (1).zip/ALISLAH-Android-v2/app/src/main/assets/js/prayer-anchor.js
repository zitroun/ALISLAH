/* Tasks tied to a prayer (2.1.4.33): the time is the prayer time plus or minus some minutes. */
(function (root) {
  'use strict';
  /** Shifts an HH:MM time by minutes, wrapping past midnight. Returns '' for an invalid time. */
  function shiftHHMM(hhmm, minutes) {
    var m = /^(\d{1,2}):(\d{2})$/.exec(String(hhmm || '').trim());
    if (!m) return '';
    var t = Number(m[1]) * 60 + Number(m[2]) + (Math.round(Number(minutes)) || 0);
    t = ((t % 1440) + 1440) % 1440;
    var h = Math.floor(t / 60), mi = t % 60;
    return (h < 10 ? '0' : '') + h + ':' + (mi < 10 ? '0' : '') + mi;
  }
  var api = { shiftHHMM: shiftHHMM };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.ALI_ANCHOR = api;
})(typeof window !== 'undefined' ? window : globalThis);
