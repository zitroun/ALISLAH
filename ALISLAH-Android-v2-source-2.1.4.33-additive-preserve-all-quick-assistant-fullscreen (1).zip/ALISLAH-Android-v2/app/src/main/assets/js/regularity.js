/* Monthly regularity map (2.1.4.33). Each day shows how many of the five prayers were logged. */
(function (root) {
  'use strict';
  var PRAYERS = 5;
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function dayKey(y, m, d) { return y + '-' + pad(m + 1) + '-' + pad(d); }
  function monthLength(y, m) { return new Date(y, m + 1, 0).getDate(); }
  /** Counts distinct logged prayers per day for one month. Entries marked not done are ignored. */
  function dayScores(entries, y, m) {
    var prefix = y + '-' + pad(m + 1) + '-', names = {}, out = {};
    (entries || []).forEach(function (x) {
      if (!x || x.done === false) return;
      var key = x.day || String(x.date || '').slice(0, 10);
      if (typeof key !== 'string' || key.indexOf(prefix) !== 0) return;
      (names[key] = names[key] || {})[x.name || ''] = true;
    });
    Object.keys(names).forEach(function (k) { out[k] = Math.min(PRAYERS, Object.keys(names[k]).length); });
    return out;
  }
  function level(count) {
    if (count <= 0) return 0;
    if (count <= 2) return 1;
    if (count <= 4) return 2;
    return 3;
  }
  var api = { dayScores: dayScores, level: level, dayKey: dayKey, monthLength: monthLength, PRAYERS: PRAYERS };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.ALI_REGULARITY = api;
  if (typeof document === 'undefined') return;

  function readLog() {
    try { return (JSON.parse(ALI_STORE.getRaw('alislah_v2') || '{}') || {}).prayerLog || []; }
    catch (e) { return []; }
  }
  function render() {
    var box = document.getElementById('regularityMap');
    if (!box) return;
    var now = new Date(), y = now.getFullYear(), m = now.getMonth();
    var scores = dayScores(readLog(), y, m);
    box.textContent = '';
    var title = document.createElement('h3'); title.textContent = 'انتظامي في الصلاة هذا الشهر';
    var note = document.createElement('p'); note.className = 'muted';
    note.textContent = 'كل مربع يمثل يوماً، وتزداد قتامته بعدد الصلوات المسجلة فيه.';
    var grid = document.createElement('div'); grid.className = 'rg-grid';
    ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'].forEach(function (n) {
      var h = document.createElement('div'); h.className = 'rg-head'; h.textContent = n; grid.appendChild(h);
    });
    var offset = new Date(y, m, 1).getDay();
    for (var i = 0; i < offset; i++) grid.appendChild(document.createElement('div'));
    var len = monthLength(y, m);
    for (var d = 1; d <= len; d++) {
      var n = scores[dayKey(y, m, d)] || 0;
      var cell = document.createElement('div');
      cell.className = 'rg-cell l' + level(n);
      cell.textContent = String(d);
      cell.setAttribute('aria-label', d + ': ' + n + ' من ' + PRAYERS + ' صلوات');
      grid.appendChild(cell);
    }
    box.appendChild(title); box.appendChild(note); box.appendChild(grid);
    box.style.display = '';
  }
  function start() { render(); setInterval(render, 60000); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})(typeof window !== 'undefined' ? window : globalThis);
