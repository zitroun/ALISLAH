/* Time-aware suggestion on the dashboard (2.1.4.33). The rule is pure; the view reads the saved data and the prayer times. */
(function (root) {
  'use strict';
  /** state: { hour (0-23), minutesToPrayer (number or null), prayerName (Arabic), pendingTasks (number) } */
  function suggestNow(state) {
    if (!state) return null;
    var h = state.hour, m = state.minutesToPrayer, p = state.prayerName || '', n = state.pendingTasks || 0;
    if (typeof m === 'number' && m >= 0 && m <= 20) {
      return 'بقي على ' + p + ' ' + Math.max(1, Math.round(m)) + ' دقيقة: أنهي ما بين يديك الآن أو أجّلي المهمة التالية.';
    }
    if (n > 0 && h >= 21) return 'قبل النوم: راجعي ' + n + ' مهام متبقية للغد.';
    if (n > 0 && h >= 5 && h < 9) return 'صباح الخير: ' + n + ' مهام تنتظرك اليوم، ابدئي بأصغرها.';
    return null;
  }
  var api = { suggestNow: suggestNow };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.ALI_SUGGESTIONS = api;
  if (typeof document === 'undefined') return;

  var NAMES = { Fajr: 'الفجر', Dhuhr: 'الظهر', Asr: 'العصر', Maghrib: 'المغرب', Isha: 'العشاء' };
  function dateKey(d) {
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function nextPrayer(now) {
    if (typeof window.ALI_PRAYER_TASK_TIME !== 'function') return null;
    var key = dateKey(now), nowMin = now.getHours() * 60 + now.getMinutes(), best = null;
    Object.keys(NAMES).forEach(function (k) {
      var r = window.ALI_PRAYER_TASK_TIME(k, key, false);
      var parts = r && r.time ? /^(\d{1,2}):(\d{2})$/.exec(r.time) : null;
      if (!parts) return;
      var t = Number(parts[1]) * 60 + Number(parts[2]), d = t - nowMin;
      if (d >= 0 && (best === null || d < best.d)) best = { d: d, name: NAMES[k] };
    });
    return best;
  }
  function pendingTasks(now) {
    try {
      var data = JSON.parse(ALI_STORE.getRaw('alislah_v2') || '{}') || {};
      var today = dateKey(now);
      return (data.tasks || []).filter(function (t) { return t && !t.done && (!t.date || t.date <= today); }).length;
    } catch (e) { return 0; }
  }
  function render() {
    var tip = document.getElementById('smartTip');
    if (!tip) return;
    var now = new Date(), next = nextPrayer(now);
    var text = suggestNow({ hour: now.getHours(), minutesToPrayer: next ? next.d : null,
      prayerName: next ? next.name : '', pendingTasks: pendingTasks(now) });
    tip.textContent = text || '';
    tip.style.display = text ? '' : 'none';
  }
  function start() { render(); setInterval(render, 60000); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})(typeof window !== 'undefined' ? window : globalThis);
