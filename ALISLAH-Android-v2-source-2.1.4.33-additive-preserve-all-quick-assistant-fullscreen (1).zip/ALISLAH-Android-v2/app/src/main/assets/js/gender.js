/* Address gender (masculine base text, feminine on request).
   All UI text is written in the masculine form; when the user chooses the feminine form every
   addressed word (see PAIRS) is converted in the DOM, including text added later. Religious texts,
   chat bubbles and the user's own content are never touched. */
(function(root){
  'use strict';
  var PAIRS=[["ابدأ", "ابدئي"], ["أضف", "أضيفي"], ["اكتب", "اكتبي"], ["جرّب", "جرّبي"], ["تحدث", "تحدثي"], ["سجّل", "سجّلي"], ["اسمح", "اسمحي"], ["فعّل", "فعّلي"], ["راجع", "راجعي"], ["افتح", "افتحي"], ["اضغط", "اضغطي"], ["أعد", "أعيدي"], ["اختر", "اختاري"], ["ضع", "ضعي"], ["اجعل", "اجعلي"], ["حاول", "حاولي"], ["اطلب", "اطلبي"], ["خذ", "خذي"], ["علّم", "علّمي"], ["احتفظ", "احتفظي"], ["اسأل", "اسألي"], ["انظر", "انظري"], ["استمع", "استمعي"], ["حرّك", "حرّكي"], ["تأكد", "تأكدي"], ["دوّر", "دوّري"], ["أجب", "أجيبي"], ["احفظ", "احفظي"], ["ارجع", "ارجعي"], ["استخدم", "استخدمي"], ["أنشئ", "أنشئي"], ["عُد", "عودي"], ["تحقق", "تحققي"], ["انتظر", "انتظري"], ["أدخل", "أدخلي"], ["استثنِ", "استثني"], ["تكلم", "تكلمي"], ["حوّل", "حوّلي"], ["حدّد", "حدّدي"], ["تذكر", "تذكري"], ["واصل", "واصلي"], ["اتصل", "اتصلي"], ["انتبه", "انتبهي"], ["استعد", "استعدي"], ["اقرأ", "اقرئي"], ["انفث", "انفثي"], ["اضبط", "اضبطي"], ["أنهِ", "أنهي"], ["اشرب", "اشربي"], ["قم", "قومي"], ["تمش", "تمشّي"], ["تنفس", "تنفسي"], ["ارتح", "ارتاحي"], ["اعتمد", "اعتمدي"], ["ابحث", "ابحثي"], ["تابع", "تابعي"], ["اترك", "اتركي"], ["احصل", "احصلي"], ["ابتعد", "ابتعدي"], ["اطلع", "اطلعي"], ["حمّل", "حمّلي"], ["اذكر", "اذكري"], ["انتقل", "انتقلي"], ["اعرف", "اعرفي"], ["استعن", "استعيني"], ["اغتنم", "اغتنمي"], ["اجلس", "اجلسي"], ["ادعُ", "ادعي"], ["ارفع", "ارفعي"], ["أكمل", "أكملي"], ["احرص", "احرصي"], ["اهتم", "اهتمي"], ["انطلق", "انطلقي"], ["اسمع", "اسمعي"], ["أرسل", "أرسلي"], ["ساعد", "ساعدي"], ["شارك", "شاركي"], ["وابدأ", "وابدئي"], ["وأضف", "وأضيفي"], ["واكتب", "واكتبي"], ["وسجّل", "وسجّلي"], ["واضغط", "واضغطي"], ["وتابع", "وتابعي"], ["واترك", "واتركي"], ["واحصل", "واحصلي"], ["وابتعد", "وابتعدي"], ["وأرخِ", "وأرخي"], ["وتحقق", "وتحققي"], ["وراجع", "وراجعي"], ["فاضبط", "فاضبطي"], ["فاستثنِ", "فاستثني"], ["فاختر", "فاختاري"], ["فاكتب", "فاكتبي"], ["فجرّب", "فجرّبي"], ["فافتح", "فافتحي"], ["وخذ", "وخذي"], ["وضع", "وضعي"], ["واجعل", "واجعلي"], ["وحاول", "وحاولي"], ["فتأكد", "فتأكدي"], ["وانتظر", "وانتظري"], ["تحرَّ", "تحرَّي"], ["أخفِ", "أخفي"], ["وامسح", "وامسحي"], ["أنجزتَ", "أنجزتِ"], ["فتحتَ", "فتحتِ"], ["نمتَ", "نمتِ"], ["سجّلتَ", "سجّلتِ"], ["أتممتَ", "أتممتِ"], ["قرأتَ", "قرأتِ"], ["صمتَ", "صمتِ"], ["أردتَ", "أردتِ"], ["وصلتَ", "وصلتِ"], ["أحسنتَ", "أحسنتِ"], ["رغبتَ", "رغبتِ"], ["صليتَ", "صليتِ"], ["صلّيتَ", "صلّيتِ"], ["استطعتَ", "استطعتِ"], ["قمتَ", "قمتِ"], ["اخترتَ", "اخترتِ"], ["أضفتَ", "أضفتِ"], ["نسيتَ", "نسيتِ"], ["بدأتَ", "بدأتِ"], ["حفظتَ", "حفظتِ"], ["تعبتَ", "تعبتِ"], ["تريد", "تريدين"], ["ترغب", "ترغبين"], ["تطلب", "تطلبين"], ["تختار", "تختاري"], ["تضع", "تضعي"], ["تسأل", "تسألين"], ["تفعّل", "تفعّلين"], ["تحب", "تحبين"], ["تواجه", "تواجهين"], ["تحفظ", "تحفظي"], ["تشعر", "تشعرين"], ["تعرف", "تعرفين"], ["تبدأ", "تبدئين"], ["لتبدأ", "لتبدأي"], ["لتتابع", "لتتابعي"], ["لتنشئ", "لتنشئي"], ["لتكتب", "لتكتبي"], ["لتختار", "لتختاري"], ["ليصلك", "ليصلكِ"], ["تُنجز", "تُنجزي"], ["تستطيع", "تستطيعين"], ["تحتاج", "تحتاجين"], ["تفضّل", "تفضّلين"], ["تقرأ", "تقرئين"], ["أنتَ", "أنتِ"], ["منك", "منكِ"], ["عليك", "عليكِ"], ["بك", "بكِ"], ["إليك", "إليكِ"], ["لك", "لكِ"], ["معك", "معكِ"], ["أخاطبك", "أخاطبكِ"], ["صديقي", "صديقتي"], ["عزيزي", "عزيزتي"]];
  var M2F=Object.create(null),F2M=Object.create(null);
  PAIRS.forEach(function(p){M2F[p[0]]=p[1];F2M[p[1]]=p[0]});
  var TOKEN=/[\u0621-\u0652]+/g;
  var SKIP_TAGS={SCRIPT:1,STYLE:1,TEXTAREA:1,INPUT:1,SELECT:1,OPTION:1,CODE:1,NOSCRIPT:1};
  var SKIP_SEL='[data-ug],#messages,.bubble,.dhikr-text,.content-text,#alislahContentText,#alislahContentSource,#tasksList .title,.habit h4,.mem-chip,#memPanel .title,#memPanel h3,#evList .title,#fam-events .title,#taskSheet input,#kidsList .title';
  var ATTRS=['placeholder','title','aria-label'];
  var female=false,tracked=[],obs=null;
  function toFemale(text){return typeof text==='string'?text.replace(TOKEN,function(t){return M2F[t]||t}):text}
  function toMale(text){return typeof text==='string'?text.replace(TOKEN,function(t){return F2M[t]||t}):text}
  function skip(el){
    if(!el)return true;
    for(var n=el;n&&n.nodeType===1;n=n.parentElement){if(SKIP_TAGS[n.tagName])return true}
    return !!(el.closest&&el.closest(SKIP_SEL));
  }
  function skipAttr(el){return !!(el.closest&&el.closest(SKIP_SEL))||el.tagName==='SCRIPT'||el.tagName==='STYLE'}
  function convertText(node){
    var v=node.nodeValue;if(!v||!/[\u0621-\u064A]/.test(v))return;
    var o=node.__g;if(o&&o.out===v)return;
    if(skip(node.parentElement))return;
    var out=toFemale(v);
    if(out!==v){node.__g={src:v,out:out};node.nodeValue=out;tracked.push(node)}else if(o){node.__g=null}
  }
  function convertAttr(el,name){
    var v=el.getAttribute(name);if(!v||!/[\u0621-\u064A]/.test(v))return;
    var st=el.__ga=el.__ga||{},o=st[name];if(o&&o.out===v)return;
    if(skipAttr(el))return;
    var out=toFemale(v);
    if(out!==v){st[name]={src:v,out:out};el.setAttribute(name,out);tracked.push(el)}else if(o){delete st[name]}
  }
  function walk(root0){
    if(!root0)return;
    if(root0.nodeType===3){convertText(root0);return}
    if(root0.nodeType!==1||(root0.closest&&root0.closest(SKIP_SEL)))return;
    var w=document.createTreeWalker(root0,NodeFilter.SHOW_TEXT|NodeFilter.SHOW_ELEMENT,null),n=w.currentNode,list=[];
    while(n){list.push(n);n=w.nextNode()}
    list.forEach(function(x){
      if(x.nodeType===3)convertText(x);
      else if(x.nodeType===1){ATTRS.forEach(function(a){if(x.hasAttribute(a))convertAttr(x,a)})}
    });
  }
  function restore(){
    tracked.forEach(function(n){
      if(n.nodeType===3){if(n.__g&&n.nodeValue===n.__g.out)n.nodeValue=n.__g.src;n.__g=null}
      else if(n.__ga){Object.keys(n.__ga).forEach(function(a){var o=n.__ga[a];if(n.getAttribute(a)===o.out)n.setAttribute(a,o.src)});n.__ga=null}
    });
    tracked=[];
  }
  function startObserver(){
    if(obs||!root.MutationObserver)return;
    obs=new MutationObserver(function(muts){
      if(!female)return;
      muts.forEach(function(m){
        if(m.type==='childList'){m.addedNodes.forEach(function(n){walk(n)})}
        else if(m.type==='characterData'){convertText(m.target)}
        else if(m.type==='attributes'){convertAttr(m.target,m.attributeName)}
      });
      if(tracked.length>4000)tracked=tracked.filter(function(n){return n.isConnected});
    });
    obs.observe(document.documentElement,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:ATTRS});
  }
  function set(g){
    var f=g==='female';if(f===female)return;
    female=f;
    document.documentElement.setAttribute('data-addr',f?'female':'male');
    if(f){startObserver();if(document.body)walk(document.body)}else restore();
  }
  function initial(){
    try{
      var raw=root.ALI_DB?root.ALI_DB.read():JSON.parse(root.ALI_STORE.getRaw('alislah_v2')||'{}');
      return (raw&&raw.settings&&raw.settings.addressGender)==='female'?'female':'male';
    }catch(e){return 'male'}
  }
  var api={
    PAIRS:PAIRS,toFemale:toFemale,toMale:toMale,
    isFemale:function(){return female},
    set:set,
    /** text for contexts outside the DOM (notifications, share text, prompts) */
    t:function(masculine){return female?toFemale(masculine):masculine},
    refresh:function(){if(female&&document.body)walk(document.body)},
    hint:function(){return female?'خاطب المستخدمة بصيغة المؤنث.':'خاطب المستخدم بصيغة المذكر.'}
  };
  root.ALI_G=api;
  if(initial()==='female'){
    set('female');
    if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){walk(document.body)});
  }
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
