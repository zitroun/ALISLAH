/* Guidance in empty lists (2.1.4.33). The app shows its own empty message; this adds the next step to it,
   and adds a short hint only where a list has no message at all. */
(function (root) {
  'use strict';
  var TIPS = {
    tasksList: 'اكتبي المهمة في الحقل أعلاه، أو قولي «ذكّرني…» بالميكروفون.',
    habitsList: 'ابدئي بعادة واحدة صغيرة تتكرر كل يوم.',
    kidsList: 'أضيفي الطفل من زر الإضافة في هذا القسم.'
  };
  function sync(list, tip) {
    if (!list) return;
    var own = list.querySelector(':scope > .empty');
    var hint = list.querySelector(':scope > .empty-hint');
    var items = Array.prototype.filter.call(list.children, function (el) {
      return !el.classList.contains('empty') && !el.classList.contains('empty-hint');
    });
    if (items.length > 0) { if (hint) hint.remove(); return; }
    if (own) {
      var tipEl = own.querySelector(':scope > .empty-tip');
      if (!tipEl) { tipEl = document.createElement('small'); tipEl.className = 'empty-tip muted'; own.appendChild(tipEl); }
      tipEl.textContent = ' ' + tip;
      if (hint) hint.remove();
      return;
    }
    if (!hint) { hint = document.createElement('p'); hint.className = 'empty-hint muted'; list.insertBefore(hint, list.firstChild); }
    hint.textContent = tip;
  }
  function syncAll() { Object.keys(TIPS).forEach(function (id) { sync(document.getElementById(id), TIPS[id]); }); }
  function watch() {
    Object.keys(TIPS).forEach(function (id) {
      var list = document.getElementById(id);
      if (list) new MutationObserver(syncAll).observe(list, { childList: true });
    });
    syncAll();
  }
  var api = { TIPS: TIPS, sync: sync };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.ALI_EMPTY = api;
  if (typeof document === 'undefined') return;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', watch); else watch();
})(typeof window !== 'undefined' ? window : globalThis);
