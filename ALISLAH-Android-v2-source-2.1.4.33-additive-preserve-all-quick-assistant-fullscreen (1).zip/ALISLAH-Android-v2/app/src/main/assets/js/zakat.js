/* Zakat and fitra estimator (2.1.4.33). The maths is pure so it can be tested; the view is built in the browser. */
(function (root) {
  'use strict';
  var GOLD_NISAB_G = 85, SILVER_NISAB_G = 595, RATE = 0.025;
  function num(x) { var v = Number(x); return isFinite(v) && v > 0 ? v : 0; }
  function round2(x) { return Math.round(x * 100) / 100; }
  function zakat(input) {
    input = input || {};
    var goldValue = num(input.goldGrams) * num(input.goldPrice);
    var silverValue = num(input.silverGrams) * num(input.silverPrice);
    var wealth = num(input.cash) + goldValue + silverValue;
    var net = Math.max(0, wealth - num(input.debts));
    var basis = input.nisabBasis === 'silver' ? 'silver' : 'gold';
    var nisab = basis === 'silver' ? SILVER_NISAB_G * num(input.silverPrice) : GOLD_NISAB_G * num(input.goldPrice);
    var eligible = nisab > 0 && net >= nisab;
    return { wealth: round2(wealth), net: round2(net), nisab: round2(nisab), basis: basis,
             eligible: eligible, due: eligible ? round2(net * RATE) : 0 };
  }
  function fitra(input) {
    input = input || {};
    var people = Math.floor(num(input.people));
    var kg = num(input.kgEach) || 2.5;
    var amount = people * kg * num(input.pricePerKg);
    return { people: people, kgTotal: round2(people * kg), amount: round2(amount) };
  }
  var api = { zakat: zakat, fitra: fitra, GOLD_NISAB_G: GOLD_NISAB_G, SILVER_NISAB_G: SILVER_NISAB_G, RATE: RATE };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.ALI_ZAKAT = api;

  if (typeof document === 'undefined') return;
  var LABELS = {
    cash: ['المال المدّخر (نقداً وفي الحسابات)', 'number'], goldGrams: ['الذهب بالغرام', 'number'],
    goldPrice: ['سعر غرام الذهب', 'number'], silverGrams: ['الفضة بالغرام', 'number'],
    silverPrice: ['سعر غرام الفضة', 'number'], debts: ['الديون الحالّة (تُخصم)', 'number']
  };
  function field(id, label, type, value) {
    var wrap = document.createElement('label'); wrap.className = 'fld';
    var span = document.createElement('span'); span.textContent = label;
    var input = document.createElement('input'); input.id = id; input.type = type; input.min = '0'; input.step = 'any';
    if (value !== undefined) input.value = value;
    wrap.appendChild(span); wrap.appendChild(input); return wrap;
  }
  function build() {
    var section = document.getElementById('zakat');
    if (!section || section.dataset.ready) return;
    section.dataset.ready = '1';
    var title = document.createElement('h2'); title.textContent = 'الزكاة والفطرة';
    var note = document.createElement('p'); note.className = 'muted';
    note.textContent = 'تقدير تقريبي للتوضيح فقط. في الحالات الخاصة راجعي عالماً موثوقاً. لا تُرسل هذه القيم إلى أي خادم.';
    var zPanel = document.createElement('div'); zPanel.className = 'panel';
    var zh = document.createElement('h3'); zh.textContent = 'زكاة المال';
    zPanel.appendChild(zh);
    Object.keys(LABELS).forEach(function (k) { zPanel.appendChild(field('z_' + k, LABELS[k][0], LABELS[k][1])); });
    var basisWrap = document.createElement('label'); basisWrap.className = 'fld';
    var basisSpan = document.createElement('span'); basisSpan.textContent = 'أساس النصاب';
    var basis = document.createElement('select'); basis.id = 'z_basis';
    [['gold', 'الذهب (85 غرام)'], ['silver', 'الفضة (595 غراماً)']].forEach(function (o) {
      var opt = document.createElement('option'); opt.value = o[0]; opt.textContent = o[1]; basis.appendChild(opt);
    });
    basisWrap.appendChild(basisSpan); basisWrap.appendChild(basis); zPanel.appendChild(basisWrap);
    var zOut = document.createElement('p'); zOut.id = 'zakatResult'; zOut.setAttribute('aria-live', 'polite');
    zPanel.appendChild(zOut);
    var fPanel = document.createElement('div'); fPanel.className = 'panel';
    var fh = document.createElement('h3'); fh.textContent = 'زكاة الفطر';
    fPanel.appendChild(fh);
    fPanel.appendChild(field('f_people', 'عدد الأشخاص', 'number'));
    fPanel.appendChild(field('f_kg', 'الكمية لكل شخص بالكيلوغرام', 'number', '2.5'));
    fPanel.appendChild(field('f_price', 'سعر الكيلوغرام من الطعام المعتمد', 'number'));
    var fOut = document.createElement('p'); fOut.id = 'fitraResult'; fOut.setAttribute('aria-live', 'polite');
    fPanel.appendChild(fOut);
    section.appendChild(title); section.appendChild(note); section.appendChild(zPanel); section.appendChild(fPanel);
    section.addEventListener('input', recalc);
    section.addEventListener('change', recalc);
    recalc();
  }
  function val(id) { var el = document.getElementById(id); return el ? el.value : ''; }
  function recalc() {
    var z = zakat({ cash: val('z_cash'), goldGrams: val('z_goldGrams'), goldPrice: val('z_goldPrice'),
      silverGrams: val('z_silverGrams'), silverPrice: val('z_silverPrice'), debts: val('z_debts'), nisabBasis: val('z_basis') });
    var zOut = document.getElementById('zakatResult');
    if (zOut) zOut.textContent = z.eligible
      ? 'الزكاة المستحقة: ' + z.due + ' (2.5% من ' + z.net + ')'
      : (z.nisab > 0 ? 'لم يبلغ المال النصاب (' + z.nisab + ') بعد، فلا زكاة واجبة الآن.' : 'أدخلي الأسعار لحساب النصاب.');
    var f = fitra({ people: val('f_people'), kgEach: val('f_kg'), pricePerKg: val('f_price') });
    var fOut = document.getElementById('fitraResult');
    if (fOut) fOut.textContent = f.people > 0 ? 'الفطرة: ' + f.amount + ' (' + f.kgTotal + ' كغ لـ' + f.people + ' أشخاص)' : 'أدخلي عدد الأشخاص لحساب الفطرة.';
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build); else build();
})(typeof window !== 'undefined' ? window : globalThis);
