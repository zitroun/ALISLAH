/* Ramadan card (2.1.4.33): imsak and iftar from the prayer times the app already computes. */
(function (root) {
  'use strict';
  function parseHHMM(s) {
    var m = /^(\d{1,2}):(\d{2})$/.exec(String(s || '').trim());
    if (!m) return null;
    var h = Number(m[1]), mi = Number(m[2]);
    return h > 23 || mi > 59 ? null : h * 60 + mi;
  }
  function fmt(min) {
    min = ((min % 1440) + 1440) % 1440;
    var h = Math.floor(min / 60), m = min % 60;
    return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m;
  }
  /** Imsak is ten minutes before Fajr, the common practice. Returns null outside Ramadan (Hijri month 9). */
  function ramadanWindow(hijriMonth, fajr, maghrib) {
    if (hijriMonth !== 9) return null;
    var f = parseHHMM(fajr), g = parseHHMM(maghrib);
    if (f === null || g === null) return null;
    return { imsak: fmt(f - 10), fajr: fmt(f), iftar: fmt(g) };
  }
  function minutesUntil(nowMinutes, hhmm) {
    var t = parseHHMM(hhmm);
    if (t === null) return null;
    var d = t - nowMinutes;
    return d >= 0 ? d : d + 1440;
  }
  var api = { parseHHMM: parseHHMM, fmt: fmt, ramadanWindow: ramadanWindow, minutesUntil: minutesUntil };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.ALI_RAMADAN = api;
  if (typeof document === 'undefined') return;

  function hijriMonthOf(date) {
    try { return Number(new Intl.DateTimeFormat('en-u-ca-islamic', { month: 'numeric' }).format(date)); }
    catch (e) { return 0; }
  }
  function dateKey(d) {
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function render() {
    var card = document.getElementById('ramadanCard');
    if (!card || typeof window.ALI_PRAYER_TASK_TIME !== 'function') return;
    var now = new Date(), key = dateKey(now);
    var fajr = window.ALI_PRAYER_TASK_TIME('Fajr', key, false), maghrib = window.ALI_PRAYER_TASK_TIME('Maghrib', key, false);
    var win = ramadanWindow(hijriMonthOf(now), fajr && fajr.time, maghrib && maghrib.time);
    if (!win) { card.style.display = 'none'; return; }
    var left = minutesUntil(now.getHours() * 60 + now.getMinutes(), win.iftar);
    card.textContent = '';
    var title = document.createElement('b'); title.textContent = 'رمضان كريم';
    var line = document.createElement('p'); line.className = 'muted';
    line.textContent = 'الإمساك ' + win.imsak + ' · الفجر ' + win.fajr + ' · الإفطار ' + win.iftar;
    var count = document.createElement('p');
    count.textContent = left === null ? '' : (left === 0 ? 'حان وقت الإفطار' : 'بعد ' + left + ' دقيقة للإفطار');
    card.appendChild(title); card.appendChild(line); card.appendChild(count);
    card.style.display = '';
  }
  function start() { render(); setInterval(render, 60000); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})(typeof window !== 'undefined' ? window : globalThis);
