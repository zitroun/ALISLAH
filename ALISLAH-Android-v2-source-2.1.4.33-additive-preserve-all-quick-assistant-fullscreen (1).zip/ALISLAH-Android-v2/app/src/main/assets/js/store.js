/* Storage gateway (2.1.4.33). Every read and write of the browser's storage goes through this file.
   Keys and value formats are unchanged, so existing data keeps working. Errors are re-thrown exactly as before,
   so callers that already handle them keep working. Corrupted JSON is copied to a quarantine key before the default is used. */
(function (root) {
  'use strict';
  var QUARANTINE_PREFIX = 'alislah_quarantine:';
  /* Revision of a saved copy: a missing or non-numeric _rev counts as 0, exactly as the old expressions did. */
  function revOf(o) { return Number((o && o._rev) || 0); }
  function nativeIsNewer(local, native) { return revOf(native) > revOf(local); }
  function localIsNewer(local, native) { return revOf(local) > revOf(native); }
  function makeStore(storage) {
    return {
      getRaw: function (key) { return storage.getItem(key); },
      setRaw: function (key, value) { storage.setItem(key, value); },
      removeRaw: function (key) { storage.removeItem(key); },
      keys: function () { return Object.keys(storage); },
      getJSON: function (key, fallback) {
        var raw = null;
        try { raw = storage.getItem(key); } catch (e) { return fallback; }
        if (!raw) return fallback;
        try {
          var v = JSON.parse(raw);
          return v && typeof v === 'object' ? v : fallback;
        } catch (e) {
          try { storage.setItem(QUARANTINE_PREFIX + key, raw); } catch (_) { /* full storage: the default is still used */ }
          return fallback;
        }
      },
      setJSON: function (key, value) { storage.setItem(key, JSON.stringify(value)); },
      nativeIsNewer: nativeIsNewer,
      localIsNewer: localIsNewer
    };
  }
  var api = { makeStore: makeStore };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  var storage = null;
  try { storage = typeof localStorage !== 'undefined' ? localStorage : null; } catch (e) { storage = null; }
  root.ALI_STORE = makeStore(storage);
})(typeof window !== 'undefined' ? window : globalThis);
