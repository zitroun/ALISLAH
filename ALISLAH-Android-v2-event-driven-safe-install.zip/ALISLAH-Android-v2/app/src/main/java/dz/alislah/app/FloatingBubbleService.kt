package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.view.WindowManager
import android.widget.TextView

class FloatingBubbleService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f
    private var dragged = false
    private var downAt = 0L
    private var closeButton: TextView? = null
    private var closeParams: WindowManager.LayoutParams? = null
    private var assistantPanel: View? = null
    private var assistantWebView: WebView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val reshowBubble = Runnable { showBubble() }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(4107, buildNotification())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) showBubble() else stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ANSWERED -> {
                handler.removeCallbacks(reshowBubble)
                hideBubble()
            }
            ACTION_SHOW_FOR_EVENT -> {
                handler.removeCallbacks(reshowBubble)
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) showBubble()
            }
            else -> if (bubble == null && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))) showBubble()
        }
        return START_STICKY
    }

    private fun hideBubble() {
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        params = null
        hideCloseButton()
    }

    private fun showCloseButton(anchor: WindowManager.LayoutParams) {
        if (closeButton != null) return
        val size = (38 * resources.displayMetrics.density).toInt()
        val xButton = TextView(this).apply {
            text = "×"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(180, 35, 24))
                setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
            }
            contentDescription = "إغلاق الفقاعة العائمة"
            setOnClickListener {
                getSharedPreferences("alislah_native", MODE_PRIVATE).edit().putBoolean("overlayEnabled", false).apply()
                handler.removeCallbacks(reshowBubble)
                stopSelf()
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val cp = WindowManager.LayoutParams(size, size, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (anchor.x + 42 * resources.displayMetrics.density).toInt()
            y = (anchor.y - 12 * resources.displayMetrics.density).toInt().coerceAtLeast(0)
        }
        try { windowManager.addView(xButton, cp); closeButton = xButton; closeParams = cp } catch (_: Exception) {}
    }

    private fun hideCloseButton() {
        closeButton?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        closeButton = null
        closeParams = null
    }

    private fun showBubble() {
        if (bubble != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = (58 * resources.displayMetrics.density).toInt()
        val view = TextView(this).apply {
            text = "A"
            textSize = 23f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(23, 107, 91))
            elevation = 12f
            contentDescription = "فقاعة ALISLAH العائمة؛ اضغطي لفتح المساعد"
            // Rounded drawable without external assets.
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(23, 107, 91))
                setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(size, size, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (12 * resources.displayMetrics.density).toInt()
            y = (220 * resources.displayMetrics.density).toInt()
        }
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragged = false; downAt = System.currentTimeMillis(); startX = lp.x; startY = lp.y; touchX = event.rawX; touchY = event.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt(); val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 6 || kotlin.math.abs(dy) > 6) dragged = true
                    lp.x = startX + dx; lp.y = startY + dy
                    try { windowManager.updateViewLayout(v, lp) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val heldLong = System.currentTimeMillis() - downAt >= 650L
                    if (!dragged && heldLong) {
                        showCloseButton(lp)
                    } else if (!dragged) {
                        showAssistantOverlay()
                    }
                    true
                }
                else -> false
            }
        }
        try { windowManager.addView(view, lp); bubble = view; params = lp } catch (_: Exception) { stopSelf() }
    }

    private fun showAssistantOverlay() {
        if (assistantPanel != null) {
            assistantPanel?.visibility = View.VISIBLE
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("openAssistant", true)
            }
            startActivity(launch)
            return
        }
        val density = resources.displayMetrics.density
        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val panelWidth = (screenWidth - 24 * density).toInt().coerceAtLeast((280 * density).toInt())
        val panelHeight = (screenHeight * 0.72f).toInt().coerceAtLeast((360 * density).toInt())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            elevation = 18 * density
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = 18 * density
                setStroke((1 * density).toInt(), Color.rgb(220, 231, 226))
            }
            clipToOutline = true
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((12*density).toInt(), (5*density).toInt(), (8*density).toInt(), (5*density).toInt())
            setBackgroundColor(Color.rgb(23, 107, 91))
        }
        val title = TextView(this).apply {
            text = "ALISLAH · المساعد الذكي"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, (44*density).toInt(), 1f)
        }
        val close = TextView(this).apply {
            text = "×"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = "إغلاق نافذة المساعد"
            layoutParams = LinearLayout.LayoutParams((44*density).toInt(), (44*density).toInt())
            setOnClickListener { hideAssistantOverlay() }
        }
        bar.addView(title); bar.addView(close); root.addView(bar)
        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    val script = """(function(){
                      document.querySelector('header.top')?.style.setProperty('display','none','important');
                      document.querySelector('.hero')?.style.setProperty('display','none','important');
                      document.querySelector('.stats')?.style.setProperty('display','none','important');
                      document.querySelector('.tabs')?.style.setProperty('display','none','important');
                      document.querySelectorAll('.view').forEach(x=>{x.classList.toggle('active',x.id==='assistant');x.style.display=x.id==='assistant'?'block':'none'});
                      document.querySelectorAll('#alislahFloat,#alislahCheckin,.footer,#nativeOverlayControls').forEach(x=>x.style.display='none');
                      const app=document.querySelector('.app'); if(app){app.style.padding='8px';app.style.maxWidth='none';app.style.margin='0';}
                      const chat=document.querySelector('#assistant .chat'); if(chat){chat.style.minHeight='0';chat.style.height='auto';chat.style.padding='10px';}
                      const msgs=document.getElementById('messages'); if(msgs){msgs.style.minHeight='180px';msgs.style.maxHeight='38vh';msgs.style.overflowY='auto';}
                      const panel=document.querySelector('#assistant'); if(panel){panel.style.display='block';panel.style.margin='0';}
                      document.body.style.background='#f3f7f5';
                    })();"""
                    view?.evaluateJavascript(script, null)
                }
            }
        }
        assistantWebView = web
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(panelWidth, panelHeight, type, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        try {
            windowManager.addView(root, lp)
            assistantPanel = root
            web.loadUrl("file:///android_asset/index.html")
        } catch (_: Exception) {
            assistantPanel = null
            assistantWebView = null
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("openAssistant", true)
            }
            startActivity(launch)
        }
    }

    private fun hideAssistantOverlay() {
        assistantWebView?.stopLoading()
        assistantWebView?.destroy()
        assistantWebView = null
        assistantPanel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        assistantPanel = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel("alislah_bubble", "فقاعة ALISLAH", NotificationManager.IMPORTANCE_LOW).apply { description = "إبقاء الفقاعة العائمة متاحة فوق التطبيقات" })
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "alislah_bubble").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("فقاعة ALISLAH مفعّلة").setContentText("اضغطي على الفقاعة لفتح المساعد الذكي").setContentIntent(open).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("فقاعة ALISLAH مفعّلة").setContentText("اضغطي على الفقاعة لفتح المساعد الذكي").setContentIntent(open).setOngoing(true).build()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(reshowBubble)
        hideCloseButton()
        hideAssistantOverlay()
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_ANSWERED = "dz.alislah.app.ACTION_ASSISTANT_ANSWERED"
        const val ACTION_SHOW_FOR_EVENT = "dz.alislah.app.ACTION_SHOW_BUBBLE_FOR_EVENT"
    }
}
