package dz.alislah.app

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import org.json.JSONObject

/** Bubble preferences kept on the device: size, opacity, movement, modes and usage counts. */
object BubbleSettings {
    private const val PREFS = "alislah_native"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun behavior(context: Context): JSONObject = try {
        JSONObject(prefs(context).getString("bubbleExtras", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    fun scale(context: Context): Float = behavior(context).optDouble("scale", 1.0).toFloat().coerceIn(0.8f, 1.4f)

    fun alpha(context: Context): Float = behavior(context).optDouble("alpha", 1.0).toFloat().coerceIn(0.5f, 1f)

    fun freeMove(context: Context): Boolean = behavior(context).optBoolean("free", false)

    fun liveCountdown(context: Context): Boolean = false // Countdown stays inside the bubbles; no status-bar notification.

    fun mainBubbleColor(context: Context): Int {
        val raw = behavior(context).optString("mainBubbleColor", "#176B5B")
        return try { android.graphics.Color.parseColor(raw) } catch (_: Exception) { android.graphics.Color.rgb(23, 107, 91) }
    }

    fun hideInGames(context: Context): Boolean = behavior(context).optBoolean("hideInGames", false)

    fun drivingEnabled(context: Context): Boolean = behavior(context).optBoolean("driving", true)

    fun focusActive(context: Context): Boolean = prefs(context).getBoolean("focusActive", false)

    /** How often each shortcut was used, so the fan can put the favourites first. */
    fun usage(context: Context): Map<String, Int> {
        val out = HashMap<String, Int>()
        try {
            val o = JSONObject(prefs(context).getString("orbitUsage", "{}") ?: "{}")
            val keys = o.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                out[k] = o.optInt(k, 0)
            }
        } catch (e: Exception) {
            // no usage yet
        }
        return out
    }

    fun recordUsage(context: Context, id: String) {
        try {
            val o = JSONObject(prefs(context).getString("orbitUsage", "{}") ?: "{}")
            o.put(id, o.optInt(id, 0) + 1)
            prefs(context).edit().putString("orbitUsage", o.toString()).apply()
        } catch (e: Exception) {
            // usage counting is best effort
        }
    }

    /** Headphones or a car stereo on Bluetooth or cable count as driving. */
    fun isCarAudioConnected(context: Context): Boolean {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
    }

    fun drivingMode(context: Context): Boolean = drivingEnabled(context) && isCarAudioConnected(context)

    fun hideFullscreen(context: Context): Boolean = behavior(context).optBoolean("hideFullscreen", false)

    fun systemMode(context: Context): Boolean =
        BubbleBehavior.normalizeMode(prefs(context).getString("bubbleMode", "custom")) == "system"

}
