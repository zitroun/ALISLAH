package dz.alislah.app

/** Gesture mapping, orbit contents and time rules for the bubble. Pure logic, covered by unit tests. */
object BubbleBehavior {
    const val ACTION_ORBIT = "orbit"
    const val ACTION_NONE = "none"
    val ACTIONS = listOf(
        "orbit", "ask", "plan", "prayer", "qibla", "focus", "adhkar", "addtask", "open", "snooze", "readtasks", "none"
    )
    val GESTURES = listOf("tap", "double", "long", "swipeup", "swipedown")
    private val DEFAULTS = mapOf(
        "tap" to "orbit",
        "double" to "ask",
        "long" to "plan",
        "swipeup" to "open",
        "swipedown" to "snooze"
    )
    private const val MINUTE_MS = 60_000L
    private const val HOUR_MS = 60L * MINUTE_MS

    fun sanitize(action: String?): String = if (action != null && action in ACTIONS) action else ACTION_NONE

    /** The action for a gesture: the user's choice when it is valid, otherwise the default. */
    fun actionFor(gesture: String, mapping: Map<String, String>): String =
        sanitize(mapping[gesture] ?: DEFAULTS[gesture] ?: ACTION_NONE)

    /**
     * Shortcuts on the fan, in display order.
     * Driving mode shows three voice-friendly shortcuts. Otherwise the most used come first and "more" is last.
     * The prayer comes first when it is close.
     */
    fun orbitOrder(prayerSoon: Boolean, usage: Map<String, Int> = emptyMap(), driving: Boolean = false): List<String> {
        if (driving) return listOf("ask", "readtasks", "plan")
        val base = listOf("ask", "plan", "prayer", "qibla", "focus")
        val ranked = base.sortedByDescending { usage[it] ?: 0 }
        val list = ranked + "more"
        return if (prayerSoon) listOf("prayer") + list.filter { it != "prayer" } else list
    }

    fun label(id: String): String = when (id) {
        "ask" -> "المساعد"
        "plan" -> "المهام"
        "prayer" -> "الصلاة"
        "qibla" -> "القبلة"
        "focus" -> "التركيز"
        "more" -> "المزيد"
        "readtasks" -> "اقرئي مهامي"
        else -> id
    }

    /** Disc colour of a shortcut, as ARGB. */
    fun color(id: String): Int = when (id) {
        "prayer" -> 0xFF10825F.toInt()
        "ask" -> 0xFF176B5B.toInt()
        "plan", "readtasks" -> 0xFF2B70BE.toInt()
        "qibla" -> 0xFF8C5C28.toInt()
        "focus" -> 0xFF754CAF.toInt()
        else -> 0xFF3B5A54.toInt()
    }

    fun iconRes(id: String): Int = when (id) {
        "ask" -> R.drawable.ic_bubble_ask
        "plan", "readtasks" -> R.drawable.ic_bubble_plan
        "prayer" -> R.drawable.ic_bubble_prayer
        "qibla" -> R.drawable.ic_bubble_qibla
        "focus" -> R.drawable.ic_bubble_focus
        else -> R.drawable.ic_bubble_more
    }

    /** Remaining fraction of the one-hour prayer ring. It visibly shrinks as the prayer approaches. */
    fun ringFraction(nowMs: Long, nextPrayerMs: Long?): Float {
        if (nextPrayerMs == null) return 0f
        val remaining = nextPrayerMs - nowMs
        if (remaining <= 0L || remaining > HOUR_MS) return 0f
        return (remaining.toFloat() / HOUR_MS).coerceIn(0f, 1f)
    }

    /** Arabic-friendly digital countdown, kept deterministic for unit tests. */
    fun countdownText(nowMs: Long, targetMs: Long?): String {
        if (targetMs == null) return "--:--:--"
        val seconds = ((targetMs - nowMs).coerceAtLeast(0L) / 1000L)
        val hours = seconds / 3600L
        val minutes = (seconds % 3600L) / 60L
        val secs = seconds % 60L
        return String.format(java.util.Locale.US, "%02d:%02d:%02d", hours, minutes, secs)
    }

    /** True during the 15 minutes before a prayer. The bubble then promotes the prayer. */
    fun prayerSoon(nowMs: Long, nextPrayerMs: Long?): Boolean =
        nextPrayerMs != null && nextPrayerMs - nowMs in 1L..(15L * MINUTE_MS)

    fun badgeText(pending: Int): String = when {
        pending <= 0 -> ""
        pending > 9 -> "9+"
        else -> pending.toString()
    }

    /** The bubble steps aside while a phone call is in progress. */
    fun hiddenByCall(inCall: Boolean): Boolean = inCall

    /** The bubble type the user picked: the custom bubble or Android's system bubbles. */
    fun normalizeMode(raw: String?): String = if (raw == "system") "system" else "custom"

}
