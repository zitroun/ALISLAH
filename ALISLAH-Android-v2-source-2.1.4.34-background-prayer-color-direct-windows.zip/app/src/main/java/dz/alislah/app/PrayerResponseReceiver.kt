package dz.alislah.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

/** Stores the user's explicit answer to a post-prayer notification for the app to consume. */
class PrayerResponseReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != ACTION_RESPONSE) return
        val name = (intent.getStringExtra(EXTRA_NAME) ?: "").trim().take(20)
        if (name.isBlank()) return
        val done = intent.getBooleanExtra(EXTRA_DONE, false)
        val prefs = context.getSharedPreferences("alislah_native", Context.MODE_PRIVATE)
        val stamp = System.currentTimeMillis()
        val date = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }.format(java.util.Date(stamp))
        val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(stamp))
        try {
            val data = JSONObject(prefs.getString("alislah_app_data", "{}") ?: "{}")
            val responses = data.optJSONArray("prayerResponses") ?: JSONArray()
            responses.put(JSONObject().put("name", name).put("done", done).put("date", date).put("day", day))
            while (responses.length() > 500) responses.remove(0)
            data.put("prayerResponses", responses)
            val log = data.optJSONArray("prayerLog") ?: JSONArray()
            if (done) {
                val already = (0 until log.length()).any { i ->
                    val item = log.optJSONObject(i)
                    item != null && item.optString("name") == name && (item.optString("day") == day || item.optString("date").startsWith(day))
                }
                if (!already) log.put(JSONObject().put("name", name).put("date", date).put("day", day).put("done", true))
            }
            while (log.length() > 1500) log.remove(0)
            data.put("prayerLog", log)
            prefs.edit().putString("alislah_app_data", data.toString()).apply()
            FloatingBubbleService.notifyDataUpdated(context)
        } catch (e: Exception) { AppLog.ignored(e) }
        // Notification actions are recorded in the background; never launch MainActivity.

    }

    companion object {
        const val ACTION_RESPONSE = "dz.alislah.app.ACTION_PRAYER_RESPONSE"
        const val EXTRA_NAME = "prayer_name"
        const val EXTRA_DONE = "prayer_done"
    }
}
