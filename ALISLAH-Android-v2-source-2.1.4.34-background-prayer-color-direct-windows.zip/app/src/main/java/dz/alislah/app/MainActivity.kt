package dz.alislah.app

import android.media.AudioManager

import android.app.Activity
import android.app.KeyguardManager
import android.content.ComponentName
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Color
import android.graphics.drawable.Icon
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.app.PendingIntent
import android.Manifest
import android.content.pm.PackageManager
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.PermissionRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.app.NotificationManager
import android.content.res.Configuration
import android.graphics.drawable.ColorDrawable
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.View
import android.text.Editable
import android.text.TextWatcher
import org.json.JSONArray
import org.json.JSONObject
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.app.usage.UsageEvents
import java.util.Calendar

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("alislah_native", Context.MODE_PRIVATE) }
    private var pendingWebPermission: PermissionRequest? = null
    private val AUDIO_PERMISSION_REQUEST = 7801
    private val NOTIFICATION_PERMISSION_REQUEST = 7802
    private val ASSISTANT_OVERLAY_MIC_PERMISSION_REQUEST = 7806
    private var pendingOverlayAssistantMicPermission = false
    private var startupGreetingSent = false
    private var recognizer: SpeechRecognizer? = null
    private var voiceTaskRecognizer: SpeechRecognizer? = null
    private var voiceTaskDialog: AlertDialog? = null
    private var voiceTaskInput: EditText? = null
    private var voiceTaskStatus: TextView? = null
    private var voiceTaskStopButton: Button? = null
    private var voiceTaskMode = false
    private var voiceTaskHoldActive = false
    private var voiceTaskRequiresHold = false
    private var voiceTaskStopRequested = false
    private var voiceTaskUserEdited = false
    private var voiceTaskLastRecognized = ""
    private var voiceTaskProgrammaticUpdate = false
    private var pendingVoiceTaskPermission = false
    private var pendingVoiceTaskText: String? = null
    private var lastUsageRefresh = 0L
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingBackup: String? = null
    private var pendingCalendar: String? = null
    private val FILE_CHOOSER_REQUEST = 7803
    private val BACKUP_SAVE_REQUEST = 7804
    private val CALENDAR_SAVE_REQUEST = 7807
    private val LOCK_REQUEST = 7805
    private lateinit var cover: LinearLayout
    private var locked = false
    private var authInProgress = false
    private var skipAutoPrompt = false
    private var lastPausedAt = 0L
    private var pageLoaded = false
    private var pendingShared: String? = null

    private fun speakWithLegacyTts(text: String) {
        val clean = text.trim().take(700)
        if (clean.isBlank()) return
        try {
            val intent = Intent(this, FloatingBubbleService::class.java).apply {
                action = FloatingBubbleService.ACTION_SPEAK_TEXT
                putExtra(FloatingBubbleService.EXTRA_SPEAK_TEXT, clean)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        } catch (e: Exception) { AppLog.ignored(e); 
        }
    }



    private fun applyAudioControlMode() {
        val stream = if (prefs.getString("audioControlMode", "current") == "unified") AudioManager.STREAM_MUSIC else AudioManager.USE_DEFAULT_STREAM_TYPE
        setVolumeControlStream(stream)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyAudioControlMode()

        // Match the system bars and the page background to the light/dark theme (no white flash).
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val bg = if (night) 0xFF0E1A17.toInt() else 0xFFF3F7F5.toInt()
        window.setBackgroundDrawable(ColorDrawable(bg))
        window.statusBarColor = if (night) 0xFF0A1412.toInt() else 0xFF0F4F43.toInt()
        window.navigationBarColor = bg
        if (!night && Build.VERSION.SDK_INT >= 26) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        webView = WebView(this)
        webView.setBackgroundColor(bg)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        // The page is loaded from file:///android_asset, which stays readable with these disabled.
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.allowFileAccessFromFileURLs = false
        webView.settings.allowUniversalAccessFromFileURLs = false
        webView.webChromeClient = object : WebChromeClient() {
            // Without this the <input type="file"> used by "restore backup" never opens in a WebView.
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    val chooser = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    startActivityForResult(chooser, FILE_CHOOSER_REQUEST)
                    true
                } catch (e: Exception) { AppLog.ignored(e);
                    fileCallback = null
                    callback?.onReceiveValue(null)
                    false
                }
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val wantsAudio = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    if (wantsAudio && Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        pendingWebPermission = request
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_REQUEST)
                    } else {
                        val allowed = request.resources.filter { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }
                        if (allowed.isNotEmpty() && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) request.grant(allowed.toTypedArray()) else request.deny()
                    }
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return url == null || !url.startsWith("file:///android_asset/")
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                BackgroundScheduler.cancelLegacyPrayer(this@MainActivity)
                pageLoaded = true
                if (!startupGreetingSent) {
                    startupGreetingSent = true
                    webView.postDelayed({
                        if (!isFinishing && prefs.getString("voiceMode", "both") != "text") {
                            webView.evaluateJavascript("(function(){var d={};try{d=JSON.parse(localStorage.getItem('alislah_v2')||'{}')}catch(e){};var n=String((d.settings&&d.settings.name)||'').trim();return n?'مرحبًا بعودتك '+n+'. ماذا تريد أن تفعل الآن؟':'مرحبًا بك في ALISLAH. ماذا تريد أن تفعل الآن؟';})()") { raw ->
                                val greeting = try { org.json.JSONTokener(raw ?: "").nextValue() as? String } catch (e: Exception) { AppLog.ignored(e); null }
                                speakWithLegacyTts(greeting ?: "مرحبًا بك في ALISLAH. ماذا تريد أن تفعل الآن؟")
                            }
                        }
                    }, 1300L)
                }
                openAssistantIfRequested()
                deliverShared()
                pendingVoiceTaskText?.let { pending ->
                    pendingVoiceTaskText = null
                    submitVoiceTaskToWeb(pending)
                }
            }
            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                runOnUiThread { recreate() }
                return true
            }
        }
        webView.addJavascriptInterface(NativeBridge(), "AndroidUsage")
        val root = FrameLayout(this)
        root.addView(webView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        cover = buildLockCover(bg)
        root.addView(cover, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        locked = lockEnabled()
        cover.visibility = if (locked) View.VISIBLE else View.GONE
        applySecureFlag(lockEnabled())
        webView.loadUrl("file:///android_asset/index.html")
        handleIncomingIntent(intent)
        publishShortcuts()
    }

    override fun onDestroy() {
        try { recognizer?.destroy() } catch (e: Exception) { AppLog.ignored(e); }
        recognizer = null
        try { voiceTaskRecognizer?.destroy() } catch (e: Exception) { AppLog.ignored(e); }
        voiceTaskRecognizer = null
        voiceTaskDialog = null
        super.onDestroy()
    }

    override fun onPause() {
        if (!authInProgress) lastPausedAt = System.currentTimeMillis()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        applyAudioControlMode()
        if (::webView.isInitialized) {
            try { webView.evaluateJavascript("window.__alislahNativeRefresh&&window.__alislahNativeRefresh()", null) } catch (e: Exception) { AppLog.ignored(e); }
        }
        if (lockEnabled()) {
            val now = System.currentTimeMillis()
            if (!locked && lastPausedAt > 0L && now - lastPausedAt > 30_000L) locked = true
            if (locked) {
                cover.visibility = View.VISIBLE
                if (!skipAutoPrompt) promptUnlock()
                skipAutoPrompt = false
            }
        } else {
            locked = false
            cover.visibility = View.GONE
        }
        if (prefs.getBoolean("overlayEnabled", false) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
            startBubbleService()
            hideBubblePanel() // never keep two editors of the same data alive
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
            if (prefs.getBoolean("eyeBreakServiceEnabled", false)) {
                val eye = Intent(this, EyeBreakService::class.java)
                    .putExtra("minutes", prefs.getInt("eyeBreakMinutes", 20))
                    .putExtra("seconds", prefs.getInt("eyeBreakSeconds", 20))
                try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(eye) else startService(eye) } catch (e: Exception) { AppLog.ignored(e); }
            }
            if (prefs.getBoolean("eyeFilterEnabled", false)) {
                try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(Intent(this, EyeFilterService::class.java)) else startService(Intent(this, EyeFilterService::class.java)) } catch (e: Exception) { AppLog.ignored(e); }
            }
        }
        if (::webView.isInitialized) webView.postDelayed({
            if (!isFinishing) {
                webView.evaluateJavascript("window.__alislahSync && window.__alislahSync();", null)
                val nowMs = System.currentTimeMillis()
                if (nowMs - lastUsageRefresh > 60_000L) {
                    lastUsageRefresh = nowMs
                    webView.evaluateJavascript("document.getElementById('refreshUsage')?.click();", null)
                }
            }
        }, 400)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) setIntent(intent)
        handleIncomingIntent(intent)
        webView.postDelayed({ openAssistantIfRequested() }, 350)
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!::webView.isInitialized) { super.onBackPressed(); return }
        webView.evaluateJavascript("(window.__alislahBack && window.__alislahBack()) ? '1' : '0'") { result ->
            if (result == "\"1\"" || result == "1") return@evaluateJavascript
            super.onBackPressed()
        }
    }

    private fun openAssistantIfRequested() {
        val currentIntent = intent ?: return
        if (!::webView.isInitialized) return
        if (currentIntent.getBooleanExtra("openAssistant", false)) {
            webView.evaluateJavascript("document.querySelector('[data-tab=assistant]')?.click();", null)
            val prefillText = currentIntent.getStringExtra("prefillText")
            if (!prefillText.isNullOrBlank()) {
                webView.postDelayed({
                    webView.evaluateJavascript("(function(){var x=document.getElementById('chatText');if(x){x.value=" + JSONObject.quote(prefillText.take(1000)) + ";x.focus();}})();", null)
                }, 500)
            }
            currentIntent.removeExtra("prefillText")
            if (currentIntent.getBooleanExtra("backgroundQuestion", false)) {
                webView.postDelayed({
                    webView.evaluateJavascript("(function(){var x=document.getElementById('chatText');if(x){x.value='متابعة سريعة: كيف كان تركيزي وطاقتي خلال الساعات الماضية؟ وما أهم شيء أريد تحسينه الآن؟';x.focus();} })();", null)
                }, 700)
                currentIntent.removeExtra("backgroundQuestion")
            }
            currentIntent.removeExtra("openAssistant")
        }
        val tab = currentIntent.getStringExtra("openTab")
        if (tab != null) {
            val allowed = setOf("tasks", "habits", "prayer", "family", "more", "assistant", "settings", "adhkar", "calendar", "qibla", "worship", "report", "focustimer")
            if (tab in allowed) webView.evaluateJavascript("window.ALI && ALI.tab(" + JSONObject.quote(tab) + ");", null)
            currentIntent.removeExtra("openTab")
        }
        if (currentIntent.getBooleanExtra("focusAddTask", false)) {
            webView.evaluateJavascript("setTimeout(function(){var x=document.getElementById('taskText');if(x)x.focus()},500);", null)
            currentIntent.removeExtra("focusAddTask")
        }
        handleOverlayBridgeAction(currentIntent)
    }

    private fun handleOverlayBridgeAction(source: Intent) {
        when (source.getStringExtra("overlayBridgeAction")) {
            "startListening" -> webView.postDelayed({ if (!isFinishing) startNativeListening() }, 300)
            "stopListening" -> stopNativeListening()
            "requestRuntimePermissions" -> requestRuntimePermissions()
            "requestOverlayAssistantMic" -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    val i = Intent(this, FloatingBubbleService::class.java).apply { action = FloatingBubbleService.ACTION_ASSISTANT_MIC_PERMISSION_RESULT; putExtra(FloatingBubbleService.EXTRA_ASSISTANT_MIC_GRANTED, true) }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
                } else {
                    pendingOverlayAssistantMicPermission = true
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), ASSISTANT_OVERLAY_MIC_PERMISSION_REQUEST)
                }
            }
            "requestNotifications" -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST)
                } else {
                    try { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)) } catch (e: Exception) { AppLog.ignored(e); openAppSettingsScreen() }
                }
            }
            "saveBackup" -> {
                val shared = getSharedPreferences("alislah_native", MODE_PRIVATE)
                val json = shared.getString("overlay_backup_pending", null)
                val filename = shared.getString("overlay_backup_name", "alislah-backup.json") ?: "alislah-backup.json"
                if (!json.isNullOrBlank()) {
                    shared.edit().remove("overlay_backup_pending").remove("overlay_backup_name").apply()
                    requestBackupSave(filename, json)
                }
            }
        }
        source.removeExtra("overlayBridgeAction")
    }

    private fun hideBubblePanel() {
        val i = Intent(this, FloatingBubbleService::class.java).apply { action = FloatingBubbleService.ACTION_HIDE_PANEL }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    private fun stopNativeListening() {
        try { recognizer?.stopListening() } catch (e: Exception) { AppLog.ignored(e); }
        sendSpeech("end", "")
    }

    private fun sendSpeech(kind: String, value: String) {
        if (!::webView.isInitialized) return
        webView.evaluateJavascript("window.__alislahSpeech && window.__alislahSpeech(" + JSONObject.quote(kind) + "," + JSONObject.quote(value) + ");", null)
    }

    private fun startNativeListening() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_REQUEST)
            sendSpeech("error", "not-allowed"); sendSpeech("end", "")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { sendSpeech("error", "unavailable"); sendSpeech("end", ""); return }
        try { recognizer?.destroy() } catch (e: Exception) { AppLog.ignored(e); }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) { sendSpeech("error", error.toString()); sendSpeech("end", "") }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (!executeOfflineVoiceCommand(text)) sendSpeech("result", text)
                sendSpeech("end", "")
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-DZ")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-DZ")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try { r.startListening(i) } catch (e: Exception) { AppLog.ignored(e); sendSpeech("error", "failed"); sendSpeech("end", "") }
    }

    private fun startVoiceTaskSession(requireHold: Boolean) {
        if (locked) {
            jsToast("افتحي التطبيق أولًا لاستخدام إضافة المهام بالصوت")
            return
        }
        if (voiceTaskDialog?.isShowing == true) {
            if (requireHold) {
                voiceTaskRequiresHold = true
                voiceTaskHoldActive = true
                if (voiceTaskStopRequested) startVoiceTaskRecognition()
            }
            return
        }
        voiceTaskMode = true
        voiceTaskRequiresHold = requireHold
        voiceTaskHoldActive = true
        voiceTaskStopRequested = false
        voiceTaskUserEdited = false
        voiceTaskLastRecognized = ""
        val density = resources.displayMetrics.density
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20*density).toInt(), (8*density).toInt(), (20*density).toInt(), (4*density).toInt())
        }
        val status = TextView(this).apply {
            text = if (requireHold) "🎙️ استمع الآن… ارفعي إصبعك عن الفقاعة لإيقاف التسجيل." else "🎙️ استمع الآن… اضغطي إيقاف التسجيل عند الانتهاء."
            textDirection = View.TEXT_DIRECTION_RTL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            textSize = 14f
            setTextColor(Color.rgb(23,107,91))
            setPadding(0, 0, 0, (10*density).toInt())
        }
        val input = EditText(this).apply {
            hint = "سيظهر الكلام هنا ويمكنك تعديله أثناء التسجيل"
            textSize = 17f
            minLines = 3
            maxLines = 6
            gravity = Gravity.TOP or Gravity.START
            textDirection = View.TEXT_DIRECTION_RTL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding((12*density).toInt(), (10*density).toInt(), (12*density).toInt(), (10*density).toInt())
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        val stop = Button(this).apply {
            text = "إيقاف التسجيل"
            setOnClickListener { stopVoiceTaskRecording() }
        }
        content.addView(status)
        content.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (132*density).toInt()))
        content.addView(stop, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (48*density).toInt()))
        voiceTaskInput = input
        voiceTaskStatus = status
        voiceTaskStopButton = stop
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) { }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (!voiceTaskProgrammaticUpdate) voiceTaskUserEdited = true
            }
            override fun afterTextChanged(s: Editable?) { }
        })
        val dialog = AlertDialog.Builder(this)
            .setTitle("إضافة مهمة بالصوت")
            .setView(content)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("إضافة المهمة", null)
            .create()
        voiceTaskDialog = dialog
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                cancelVoiceTaskSession()
                dialog.dismiss()
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val transcript = voiceTaskInput?.text?.toString()?.trim().orEmpty()
                if (transcript.isBlank()) {
                    setVoiceTaskStatus("لم يظهر نص بعد. تحدثي بوضوح أو ألغِي العملية.")
                    return@setOnClickListener
                }
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = false
                stopVoiceTaskRecognizer()
                setVoiceTaskStatus("جارٍ تجهيز المهمة…")
                submitVoiceTaskToWeb(transcript)
            }
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                pendingVoiceTaskPermission = true
                setVoiceTaskStatus("اسمحي باستخدام الميكروفون لبدء تسجيل المهمة.")
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_REQUEST)
            } else startVoiceTaskRecognition()
        }
        dialog.setOnCancelListener { cancelVoiceTaskSession() }
        dialog.setOnDismissListener {
            if (voiceTaskDialog === dialog) voiceTaskDialog = null
            voiceTaskInput = null
            voiceTaskStatus = null
            voiceTaskStopButton = null
            voiceTaskMode = false
            voiceTaskHoldActive = false
            pendingVoiceTaskPermission = false
            stopVoiceTaskRecognizer()
        }
        dialog.show()
    }

    private fun setVoiceTaskStatus(message: String) {
        runOnUiThread { voiceTaskStatus?.text = message }
    }

    private fun updateVoiceTaskTranscript(value: String, final: Boolean = false) {
        val clean = value.trim().take(180)
        if (clean.isBlank()) return
        runOnUiThread {
            val field = voiceTaskInput ?: return@runOnUiThread
            val current = field.text?.toString().orEmpty().trimEnd()
            val previous = voiceTaskLastRecognized
            val nextText = if (!voiceTaskUserEdited) {
                clean
            } else if (previous.isNotBlank() && clean.startsWith(previous)) {
                val suffix = clean.substring(previous.length).trim()
                if (suffix.isBlank() || current.endsWith(suffix)) current else listOf(current, suffix).filter { it.isNotBlank() }.joinToString(" ").take(180)
            } else current
            voiceTaskLastRecognized = clean
            if (nextText.isNotBlank() && nextText != field.text.toString()) {
                voiceTaskProgrammaticUpdate = true
                field.setText(nextText)
                field.setSelection(field.text.length)
                voiceTaskProgrammaticUpdate = false
            }
            setVoiceTaskStatus(if (final) "اكتمل التحويل. راجعي النص وعدّليه ثم أضيفي المهمة." else "🎙️ يتم تحويل كلامك إلى كتابة… يمكنك تعديل النص الآن.")
        }
    }

    private fun startVoiceTaskRecognition() {
        if (!voiceTaskMode || (voiceTaskRequiresHold && !voiceTaskHoldActive)) return
        voiceTaskStopRequested = false
        voiceTaskUserEdited = false
        voiceTaskLastRecognized = ""
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            pendingVoiceTaskPermission = true
            setVoiceTaskStatus("اسمحي باستخدام الميكروفون لبدء التسجيل.")
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_REQUEST)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setVoiceTaskStatus("خدمة تحويل الكلام إلى نص غير متوفرة على هذا الهاتف.")
            return
        }
        stopVoiceTaskRecognizer()
        try {
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            voiceTaskRecognizer = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { setVoiceTaskStatus("🎙️ استمع الآن…") }
                override fun onBeginningOfSpeech() { setVoiceTaskStatus("🎙️ أستمع إلى المهمة…") }
                override fun onRmsChanged(rmsdB: Float) { }
                override fun onBufferReceived(buffer: ByteArray?) { }
                override fun onEndOfSpeech() { setVoiceTaskStatus("جارٍ إنهاء تحويل الكلام…") }
                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    updateVoiceTaskTranscript(partial)
                }
                override fun onEvent(eventType: Int, params: Bundle?) { }
                override fun onError(error: Int) {
                    if (!voiceTaskMode) return
                    val message = when (error) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "إذن الميكروفون غير متاح. راجعي إعدادات التطبيق."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "تعذر الاتصال بخدمة تحويل الكلام. تحققي من اتصال الإنترنت أو حزمة التعرف الصوتي المثبتة."
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "لم ألتقط كلامًا واضحًا. أعيدي التسجيل مع التحدث بوضوح."
                        else -> "توقف تحويل الكلام (رمز $error). يمكنك تعديل النص أو إعادة التسجيل."
                    }
                    setVoiceTaskStatus(message)
                    voiceTaskStopRequested = true
                    voiceTaskStopButton?.text = "إعادة التسجيل"
                    voiceTaskStopButton?.setOnClickListener {
                        voiceTaskRequiresHold = false
                        startVoiceTaskRecognition()
                    }
                }
                override fun onResults(results: Bundle?) {
                    val finalText = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (finalText.isNotBlank()) updateVoiceTaskTranscript(finalText, true)
                    else setVoiceTaskStatus("لم يتم التعرف على الكلام. عدّلي النص أو أعيدي التسجيل.")
                    voiceTaskStopRequested = true
                    voiceTaskStopButton?.text = "إعادة التسجيل"
                    voiceTaskStopButton?.setOnClickListener {
                        voiceTaskRequiresHold = false
                        startVoiceTaskRecognition()
                    }
                }
            })
            val request = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-DZ")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-DZ")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 60000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 60000L)
            }
            r.startListening(request)
            voiceTaskStopButton?.text = "إيقاف التسجيل"
            voiceTaskStopButton?.setOnClickListener { stopVoiceTaskRecording() }
        } catch (e: Exception) { AppLog.ignored(e);
            setVoiceTaskStatus("تعذر تشغيل الميكروفون. تحققي من إذن التسجيل وخدمة التعرف الصوتي.")
        }
    }

    /** Execute explicit device actions locally before forwarding speech to the online assistant. */
    private fun executeOfflineVoiceCommand(raw: String): Boolean {
        val command = OfflineCommandRouter.parse(raw) ?: return false
        when (command.type) {
            OfflineCommandRouter.Type.OPEN_TAB -> {
                if (!pageLoaded || !::webView.isInitialized) return false
                val extra = if (command.value == "more") ";setTimeout(function(){document.getElementById('alislahContentPanel')?.scrollIntoView({block:'center'});},250);" else ""
                webView.evaluateJavascript("window.ALI&&ALI.tab(" + JSONObject.quote(command.value) + ");" + extra, null)
            }
            OfflineCommandRouter.Type.READ_ZAD -> {
                if (!pageLoaded || !::webView.isInitialized) return false
                webView.evaluateJavascript("window.ALI&&ALI.tab('more');setTimeout(function(){document.getElementById('alislahContentPanel')?.scrollIntoView({block:'center'});},300);", null)
            }
            OfflineCommandRouter.Type.STOP_ADHAN -> PrayerVoiceService.stopPlayback(this)
            OfflineCommandRouter.Type.STOP_ASSISTANT -> {
                val i = Intent(this, FloatingBubbleService::class.java).apply { action = FloatingBubbleService.ACTION_STOP_SPEECH }
                try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } catch (e: Exception) { AppLog.ignored(e); return false }
            }
            OfflineCommandRouter.Type.MOVE_BUBBLE_LEFT -> {
                val i = Intent(this, FloatingBubbleService::class.java).apply { action = FloatingBubbleService.ACTION_MOVE_BUBBLE_LEFT }
                try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } catch (e: Exception) { AppLog.ignored(e); return false }
            }
        }
        return true
    }

    private fun stopVoiceTaskRecording() {
        if (!voiceTaskMode) return
        voiceTaskHoldActive = false
        voiceTaskStopRequested = true
        pendingVoiceTaskPermission = false
        try { voiceTaskRecognizer?.stopListening() } catch (e: Exception) { AppLog.ignored(e); }
        setVoiceTaskStatus("تم إيقاف التسجيل. جارٍ تثبيت النص النهائي…")
        voiceTaskStopButton?.text = "إعادة التسجيل"
        voiceTaskStopButton?.setOnClickListener { startVoiceTaskRecognition() }
    }

    private fun stopVoiceTaskRecognizer() {
        try { voiceTaskRecognizer?.cancel() } catch (e: Exception) { AppLog.ignored(e); }
        try { voiceTaskRecognizer?.destroy() } catch (e: Exception) { AppLog.ignored(e); }
        voiceTaskRecognizer = null
    }

    private fun cancelVoiceTaskSession() {
        pendingVoiceTaskText = null
        pendingVoiceTaskPermission = false
        voiceTaskHoldActive = false
        stopVoiceTaskRecognizer()
    }

    private fun submitVoiceTaskToWeb(transcript: String) {
        if (!pageLoaded || !::webView.isInitialized) {
            pendingVoiceTaskText = transcript.take(180)
            voiceTaskDialog?.dismiss()
            return
        }
        val js = "window.ALI && typeof ALI.addVoiceTask === 'function' ? ALI.addVoiceTask(" + JSONObject.quote(transcript.take(180)) + ", true) : 'not-ready';"
        webView.evaluateJavascript(js) { result ->
            val outcome = result?.trim()?.removeSurrounding("\"")
            when (outcome) {
                "added", "needs-time" -> voiceTaskDialog?.dismiss()
                "empty" -> {
                    setVoiceTaskStatus("لم أجد نصًا للمهمة. عدّلي الكتابة ثم حاولي مجددًا.")
                    voiceTaskDialog?.getButton(AlertDialog.BUTTON_POSITIVE)?.isEnabled = true
                }
                else -> {
                    setVoiceTaskStatus("تعذر فتح قائمة المهام. أعيدي المحاولة بعد اكتمال تحميل التطبيق.")
                    voiceTaskDialog?.getButton(AlertDialog.BUTTON_POSITIVE)?.isEnabled = true
                }
            }
        }
    }

    private fun lockEnabled(): Boolean = prefs.getBoolean("appLockEnabled", false)

    private fun applySecureFlag(on: Boolean) {
        if (on) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun buildLockCover(bg: Int): LinearLayout {
        val d = resources.displayMetrics.density
        val dark = Color.red(bg) < 100
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(bg); isClickable = true }
        val icon = TextView(this).apply { text = "🔒"; textSize = 54f; gravity = Gravity.CENTER }
        val msg = TextView(this).apply { text = "ALISLAH مقفل"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(if (dark) Color.WHITE else Color.rgb(18,48,42)); setPadding(0,(12*d).toInt(),0,0) }
        val btn = Button(this).apply { text = "فتح"; setOnClickListener { promptUnlock() } }
        val lp = LinearLayout.LayoutParams((200*d).toInt(),(52*d).toInt()).apply { topMargin=(20*d).toInt() }
        c.addView(icon); c.addView(msg); c.addView(btn,lp)
        return c
    }

    private fun promptUnlock() {
        if (authInProgress) return
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isDeviceSecure) {
            prefs.edit().putBoolean("appLockEnabled", false).apply(); locked=false; cover.visibility=View.GONE; applySecureFlag(false); return
        }
        val i = km.createConfirmDeviceCredentialIntent("ALISLAH", "أكّدي هويتك لفتح التطبيق")
        if (i == null) { locked=false; cover.visibility=View.GONE; return }
        authInProgress=true
        try { startActivityForResult(i, LOCK_REQUEST) } catch (e: Exception) { AppLog.ignored(e); authInProgress=false }
    }

    private fun handleIncomingIntent(i: Intent?) {
        if (i == null) return
        if (i.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            val t=i.getStringExtra(Intent.EXTRA_TEXT); if (!t.isNullOrBlank()) pendingShared=t.take(500); i.action=null
        }
        if (i.getBooleanExtra(EXTRA_START_VOICE_TASK, false)) {
            i.removeExtra(EXTRA_START_VOICE_TASK)
            startVoiceTaskSession(requireHold = true)
        }
        if (i.getBooleanExtra(EXTRA_STOP_VOICE_TASK, false)) {
            i.removeExtra(EXTRA_STOP_VOICE_TASK)
            stopVoiceTaskRecording()
        }
        deliverShared()
    }

    private fun deliverShared() {
        val t=pendingShared ?: return
        if (!pageLoaded || locked || !::webView.isInitialized) return
        pendingShared=null
        webView.evaluateJavascript("window.__alislahShared && window.__alislahShared("+JSONObject.quote(t)+");",null)
    }

    private fun publishShortcuts() {
        try {
            val sm=getSystemService(ShortcutManager::class.java) ?: return
            fun make(id:String,label:String,tab:String,focus:Boolean):ShortcutInfo {
                val i=Intent(this,MainActivity::class.java).apply { action=Intent.ACTION_VIEW; putExtra("openTab",tab); if(focus) putExtra("focusAddTask",true) }
                return ShortcutInfo.Builder(this,id).setShortLabel(label).setIcon(Icon.createWithResource(this,R.mipmap.ic_launcher)).setIntent(i).build()
            }
            sm.setDynamicShortcuts(listOf(make("add_task","مهمة جديدة","tasks",true),make("prayer","الصلاة","prayer",false),make("assistant","المساعد","assistant",false)))
        } catch (e: Exception) { AppLog.ignored(e); }
    }

    private fun jsToast(message: String) {
        if (!::webView.isInitialized) return
        webView.evaluateJavascript("window.__toast && window.__toast(" + JSONObject.quote(message) + ");", null)
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            LOCK_REQUEST -> {
                authInProgress = false
                if (resultCode == RESULT_OK) {
                    locked = false
                    cover.visibility = View.GONE
                    lastPausedAt = System.currentTimeMillis()
                    deliverShared()
                } else {
                    locked = true
                    cover.visibility = View.VISIBLE
                    skipAutoPrompt = true
                }
            }
            FILE_CHOOSER_REQUEST -> {
                fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
                fileCallback = null
            }
            BACKUP_SAVE_REQUEST -> {
                val json = pendingBackup
                pendingBackup = null
                val uri = data?.data
                if (resultCode == RESULT_OK && uri != null && json != null) {
                    val ok = try {
                        contentResolver.openOutputStream(uri, "wt")?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                        true
                    } catch (e: Exception) { AppLog.ignored(e); false }
                    jsToast(if (ok) "تم حفظ النسخة الاحتياطية" else "تعذر حفظ الملف")
                }
            }
            CALENDAR_SAVE_REQUEST -> {
                val calendar = pendingCalendar
                pendingCalendar = null
                val uri = data?.data
                if (resultCode == RESULT_OK && uri != null && calendar != null) {
                    val ok = try {
                        contentResolver.openOutputStream(uri, "wt")?.use { it.write(calendar.toByteArray(Charsets.UTF_8)) }
                        true
                    } catch (e: Exception) { AppLog.ignored(e); false }
                    jsToast(if (ok) "تم حفظ ملف التقويم" else "تعذر حفظ ملف التقويم")
                }
            }
        }
    }

    private fun requestBackupSave(filename: String, json: String) {
        pendingBackup = json.take(5_000_000)
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, filename.take(80))
        }
        try { startActivityForResult(i, BACKUP_SAVE_REQUEST) } catch (e: Exception) { AppLog.ignored(e);
            pendingBackup = null
            jsToast("تعذر فتح نافذة الحفظ")
        }
    }

    private fun requestCalendarSave(filename: String, content: String) {
        pendingCalendar = content.take(5_000_000)
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/calendar"
            putExtra(Intent.EXTRA_TITLE, filename.take(80))
        }
        try { startActivityForResult(i, CALENDAR_SAVE_REQUEST) } catch (e: Exception) { AppLog.ignored(e);
            pendingCalendar = null
            jsToast("تعذر فتح نافذة حفظ التقويم")
        }
    }

    private fun openAppSettingsScreen() {
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (e: Exception) { AppLog.ignored(e); }
    }

    private fun startBubbleService() {
        val i = Intent(this, FloatingBubbleService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    private fun enableOverlay() {
        prefs.edit().putBoolean("overlayEnabled", true).apply()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else startBubbleService()
    }

    private fun disableOverlay() {
        prefs.edit().putBoolean("overlayEnabled", false).apply()
        stopService(Intent(this, FloatingBubbleService::class.java))
    }

    private fun requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_REQUEST)
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == ASSISTANT_OVERLAY_MIC_PERMISSION_REQUEST) {
            pendingOverlayAssistantMicPermission = false
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            val i = Intent(this, FloatingBubbleService::class.java).apply {
                action = FloatingBubbleService.ACTION_ASSISTANT_MIC_PERMISSION_RESULT
                putExtra(FloatingBubbleService.EXTRA_ASSISTANT_MIC_GRANTED, granted)
            }
            try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } catch (e: Exception) { AppLog.ignored(e); }
            return
        }
        if (requestCode == AUDIO_PERMISSION_REQUEST) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            val request = pendingWebPermission
            pendingWebPermission = null
            if (request != null) {
                if (granted) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else request.deny()
            }
            if (pendingVoiceTaskPermission) {
                pendingVoiceTaskPermission = false
                if (granted && (!voiceTaskRequiresHold || voiceTaskHoldActive)) startVoiceTaskRecognition()
                else if (granted) setVoiceTaskStatus("تم السماح بالميكروفون. اضغطي مطولًا على الفقاعة مرة أخرى لبدء التسجيل.")
                else setVoiceTaskStatus("لم يُمنح إذن الميكروفون؛ لا يمكن تسجيل المهمة الصوتية.")
            }
        }
    }

    private fun hasUsagePermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun todayStartMillis(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun readUsageJson(): String {
        val result = JSONObject().put("permission", hasUsagePermission())
        val apps = JSONArray()
        if (hasUsagePermission()) {
            val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val stats: List<UsageStats> = manager.queryAndAggregateUsageStats(todayStartMillis(), System.currentTimeMillis())?.values?.toList() ?: emptyList()
            val grouped = stats.filter { it.totalTimeInForeground > 0 && it.packageName != packageName }
                .groupBy { it.packageName }
                .map { (pkg, rows) -> pkg to rows.sumOf { it.totalTimeInForeground } }
                .sortedByDescending { it.second }.take(20)
            for ((pkg, millis) in grouped) {
                val appName = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { AppLog.ignored(e); pkg }
                apps.put(JSONObject().put("packageName", pkg).put("name", appName).put("minutes", (millis / 60000.0).toInt()))
            }
        }
        var foreground = JSONObject().put("name", "غير متاح").put("packageName", "").put("approximate", true)
        if (hasUsagePermission()) {
            try {
                val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                val now = System.currentTimeMillis()
                val events = manager.queryEvents(now - 2 * 60 * 60 * 1000L, now)
                val event = UsageEvents.Event()
                var latestTime = 0L
                var latestPackage = ""
                while (events.hasNextEvent()) {
                    events.getNextEvent(event)
                    val isForeground = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
                    } else {
                        @Suppress("DEPRECATION") event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
                    }
                    if (isForeground && event.timeStamp >= latestTime) {
                        latestTime = event.timeStamp
                        latestPackage = event.packageName ?: ""
                    }
                }
                if (latestPackage.isNotBlank()) {
                    val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(latestPackage, 0)).toString() } catch (e: Exception) { AppLog.ignored(e); latestPackage }
                    foreground = JSONObject().put("name", label).put("packageName", latestPackage)
                        .put("lastSeenAt", latestTime).put("approximate", true)
                }
            } catch (e: Exception) { AppLog.ignored(e); }
        }
        return result.put("apps", apps).put("foreground", foreground).put("collectedAt", System.currentTimeMillis()).toString()
    }

    private val EXTRA_START_VOICE_TASK = "dz.alislah.app.extra.START_VOICE_TASK"
    private val EXTRA_STOP_VOICE_TASK = "dz.alislah.app.extra.STOP_VOICE_TASK"

    private fun hasNotificationPolicyAccess(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return false
        return try { getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted } catch (e: Exception) { AppLog.ignored(e); false }
    }

    private fun setDoNotDisturbMode(enabled: Boolean): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return JSONObject().put("ok", false).put("unsupported", true).put("message", "وضع عدم الإزعاج غير مدعوم على هذا الإصدار").toString()
        }
        val manager = getSystemService(NotificationManager::class.java)
        if (!manager.isNotificationPolicyAccessGranted) {
            return JSONObject().put("ok", false).put("needsAccess", true).put("message", "امنحي ALISLAH صلاحية الوصول إلى وضع عدم الإزعاج من إعدادات Android").toString()
        }
        return try {
            if (enabled) {
                if (!prefs.getBoolean("dndModeApplied", false)) {
                    prefs.edit().putInt("dndPreviousFilter", manager.currentInterruptionFilter).apply()
                }
                manager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                prefs.edit().putBoolean("dndModeApplied", true).apply()
            } else if (prefs.getBoolean("dndModeApplied", false)) {
                val previous = prefs.getInt("dndPreviousFilter", NotificationManager.INTERRUPTION_FILTER_ALL)
                manager.setInterruptionFilter(previous)
                prefs.edit().putBoolean("dndModeApplied", false).apply()
            }
            JSONObject().put("ok", true).put("enabled", enabled).put("currentFilter", manager.currentInterruptionFilter).toString()
        } catch (e: SecurityException) {
            JSONObject().put("ok", false).put("needsAccess", true).put("message", "لم يسمح Android بتغيير وضع عدم الإزعاج").toString()
        } catch (e: Exception) { AppLog.ignored(e);
            JSONObject().put("ok", false).put("message", "تعذر تغيير وضع عدم الإزعاج").toString()
        }
    }

    private fun bubbleBehaviorJson(): String {
        return JSONObject()
            .put("singleTap", prefs.getString("bubbleSingleTapAction", "menu"))
            .put("doubleTap", prefs.getString("bubbleDoubleTapAction", "app"))
            .put("longPress", prefs.getString("bubbleLongPressAction", "voice"))
            .put("orbitRadiusDp", prefs.getInt("bubbleOrbitRadiusDp", 116).coerceIn(100, 150))
            .put("sideRotation", prefs.getBoolean("bubbleSideRotationEnabled", true))
            .put("hideGames", prefs.getBoolean("bubbleHideGamesEnabled", false))
            .toString()
    }

    private fun saveBubbleBehavior(singleTap: String, doubleTap: String, longPress: String, radius: Int, rotate: Boolean) {
        val single = if (singleTap in listOf("menu", "app", "none")) singleTap else "menu"
        val double = if (doubleTap in listOf("menu", "app", "ask", "none")) doubleTap else "app"
        val long = if (longPress in listOf("voice", "menu", "none")) longPress else "voice"
        prefs.edit()
            .putString("bubbleSingleTapAction", single)
            .putString("bubbleDoubleTapAction", double)
            .putString("bubbleLongPressAction", long)
            .putInt("bubbleOrbitRadiusDp", radius.coerceIn(100, 150))
            .putBoolean("bubbleSideRotationEnabled", rotate)
            .apply()
        if (prefs.getBoolean("overlayEnabled", false) && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))) {
            try {
                val i = Intent(this, FloatingBubbleService::class.java).apply { action = FloatingBubbleService.ACTION_REFRESH_BUBBLE_CONFIG }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
            } catch (e: Exception) { AppLog.ignored(e); }
        }
    }

    inner class NativeBridge {
        @JavascriptInterface fun getAppDataJson(): String = prefs.getString("alislah_app_data", "{}") ?: "{}"
        @JavascriptInterface fun consumePrayerResponsesJson(): String {
            val responsePrefs = getSharedPreferences("alislah_prayer_response", MODE_PRIVATE)
            val raw = responsePrefs.getString("pending", "[]") ?: "[]"
            responsePrefs.edit().putString("pending", "[]").apply()
            return if (raw.length <= 20_000) raw else "[]"
        }
        @JavascriptInterface fun saveAppDataJson(json: String) { if (json.length <= 2_000_000) { prefs.edit().putString("alislah_app_data", json).apply(); FloatingBubbleService.refreshLiveIndicator() } }
        @JavascriptInterface fun setBubbleState(state: String) { FloatingBubbleService.setLiveBubbleState(state) }
        fun getEyeBreakContentCache(): String = prefs.getString("eyeBreakContentCache", "{}") ?: "{}"
        fun saveEyeBreakContentCache(json: String) { if (json.length <= 1_000_000) prefs.edit().putString("eyeBreakContentCache", json).apply() }
        @JavascriptInterface fun getUsageStatsJson(): String = readUsageJson()
        @JavascriptInterface fun getAudioControlMode(): String = prefs.getString("audioControlMode", "current") ?: "current"
        @JavascriptInterface fun setAudioControlMode(mode: String) {
            val selected = if (mode == "unified") "unified" else "current"
            prefs.edit().putString("audioControlMode", selected).apply()
            runOnUiThread { applyAudioControlMode() }
        }
        @JavascriptInterface fun setAssistantVoice(gender: String) { prefs.edit().putString("assistantVoiceGender", if (gender == "male") "male" else "female").apply() }
        @JavascriptInterface fun speakDisplayedAyah(text: String) { runOnUiThread {
            val clean = text.trim().take(700)
            if (clean.isBlank()) return@runOnUiThread
            run {
                try { val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply { action = FloatingBubbleService.ACTION_SPEAK_TEXT; putExtra(FloatingBubbleService.EXTRA_SPEAK_TEXT, clean) }; if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } catch (e: Exception) { AppLog.ignored(e); }
            }
        } }
        @JavascriptInterface fun speakAssistantText(text: String) { runOnUiThread {
            val clean = text.trim().take(700)
            if (clean.isBlank()) return@runOnUiThread
            run { val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply { action = FloatingBubbleService.ACTION_SPEAK_TEXT; putExtra(FloatingBubbleService.EXTRA_SPEAK_TEXT, clean) }; if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) }
        } }
        @JavascriptInterface fun stopAssistantSpeech() { runOnUiThread { try { val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply { action = FloatingBubbleService.ACTION_STOP_SPEECH }; if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } catch (e: Exception) { AppLog.ignored(e); } } }
        @JavascriptInterface fun setAssistantVoiceMode(mode: String) { prefs.edit().putString("voiceMode", if (mode == "text" || mode == "voice" || mode == "both") mode else "both").apply() }
        @JavascriptInterface fun testAssistantVoice() { runOnUiThread { run { val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply { action = FloatingBubbleService.ACTION_SPEAK_TEST }; if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } } }
        @JavascriptInterface fun playAdhanTest() { runOnUiThread { PrayerScheduler.playAdhan(this@MainActivity, "اختبار") } }
        @JavascriptInterface fun stopAdhan() {
            runOnUiThread {
                PrayerVoiceService.stopPlayback(this@MainActivity)
            }
        }
        @JavascriptInterface fun enableEyeFilter() {
            runOnUiThread {
                prefs.edit().putBoolean("eyeFilterEnabled", true).apply()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else { val i = Intent(this@MainActivity, EyeFilterService::class.java); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) }
            }
        }
        @JavascriptInterface fun disableEyeFilter() {
            runOnUiThread { prefs.edit().putBoolean("eyeFilterEnabled", false).apply(); stopService(Intent(this@MainActivity, EyeFilterService::class.java)) }
        }
        @JavascriptInterface fun configureEyeBreak(enabled: Boolean, minutes: Int, seconds: Int) {
            runOnUiThread {
                prefs.edit().putBoolean("eyeBreakServiceEnabled", enabled)
                    .putInt("eyeBreakMinutes", minutes.coerceIn(1,180)).putInt("eyeBreakSeconds", seconds.coerceIn(5,120)).apply()
                if (!enabled) { stopService(Intent(this@MainActivity, EyeBreakService::class.java)); return@runOnUiThread }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    val i = Intent(this@MainActivity, EyeBreakService::class.java).putExtra("minutes", minutes).putExtra("seconds", seconds)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
                }
            }
        }
        @JavascriptInterface fun savePrayerConfig(json: String) { PrayerScheduler.saveConfig(this@MainActivity, json) }
        @JavascriptInterface fun setBubbleMode(mode: String) {
            val chosen = BubbleBehavior.normalizeMode(mode)
            prefs.edit().putString("bubbleMode", chosen).apply()
            runOnUiThread {
                if (chosen == "system") {
                    SystemBubble.post(this@MainActivity)
                    stopService(Intent(this@MainActivity, FloatingBubbleService::class.java))
                } else {
                    SystemBubble.cancel(this@MainActivity)
                    if (prefs.getBoolean("overlayEnabled", false)) {
                        try {
                            startForegroundService(Intent(this@MainActivity, FloatingBubbleService::class.java))
                        } catch (e: Exception) {
                            AppLog.ignored(e)
                        }
                    }
                }
            }
        }
        @JavascriptInterface fun bubbleModeStatus(): String = when {
            android.os.Build.VERSION.SDK_INT < 30 -> "unsupported"
            !SystemBubble.allowed(this@MainActivity) -> "blocked"
            else -> "ready"
        }
        @JavascriptInterface fun openBubbleSettings() {
            runOnUiThread { SystemBubble.openSettings(this@MainActivity) }
        }
        @JavascriptInterface fun accessibilityEnabled(): Boolean = AccessibilityChecks.isEnabled(this@MainActivity)
        @JavascriptInterface fun openAccessibilitySettings() {
            runOnUiThread {
                try {
                    startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    AppLog.ignored(e)
                }
            }
        }
        @JavascriptInterface fun setBubbleExtras(json: String) {
            prefs.edit().putString("bubbleExtras", json.take(400)).apply()
            runOnUiThread {
                PrayerScheduler.refill(this@MainActivity)
                try { startService(Intent(this@MainActivity, FloatingBubbleService::class.java).setAction(FloatingBubbleService.ACTION_REFRESH_BUBBLE_CONFIG)) } catch (e: Exception) { AppLog.ignored(e) }
            }
        }
        @JavascriptInterface fun setFocusActive(on: Boolean) {
            prefs.edit().putBoolean("focusActive", on).apply()
        }
        @JavascriptInterface fun syncPrayerPlan(itemsJson: String, enabled: Boolean) {
            PrayerScheduler.sync(this@MainActivity, itemsJson.take(700000), enabled)
        }
        @JavascriptInterface fun enableBackgroundQuestions(enabled: Boolean) {
            prefs.edit().putBoolean("backgroundQuestionsEnabled", enabled).putBoolean("backgroundQuestionsConfigured", true).apply()
            if (enabled) BackgroundScheduler.scheduleQuestion(this@MainActivity, System.currentTimeMillis() + 4 * 60 * 60 * 1000L)
            else BackgroundScheduler.cancelQuestion(this@MainActivity)
        }
        @JavascriptInterface fun getNativeStatus(): String {
            val power = getSystemService(Context.POWER_SERVICE) as PowerManager
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notif = nm.areNotificationsEnabled() &&
                (Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
            val mic = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            return JSONObject()
                .put("native", true)
                .put("version", try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { AppLog.ignored(e); "" })
                .put("notifications", notif)
                .put("microphone", mic)
                .put("overlayEnabled", prefs.getBoolean("overlayEnabled", false))
                .put("overlayPermission", Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this@MainActivity))
                .put("usage", hasUsagePermission())
                .put("childProtectionAccessibility", isChildProtectionAccessibilityEnabled())
                .put("battery", power.isIgnoringBatteryOptimizations(packageName))
                .put("questions", prefs.getBoolean("backgroundQuestionsEnabled", false))
                .put("notificationPolicyAccess", hasNotificationPolicyAccess())
                .put("dndModeApplied", prefs.getBoolean("dndModeApplied", false))
                .put("drivingMode", prefs.getBoolean("drivingMode", false))
                .toString()
        }
        @JavascriptInterface fun getBubbleBehaviorJson(): String = bubbleBehaviorJson()
        @JavascriptInterface fun setBubbleBehavior(singleTap: String, doubleTap: String, longPress: String, radius: Int, rotate: Boolean) {
            saveBubbleBehavior(singleTap, doubleTap, longPress, radius, rotate)
        }
        @JavascriptInterface fun setAssistantEndpoint(url: String) {
            val clean = url.trim()
            if (clean.isEmpty() || AssistantRules.isAllowedEndpoint(clean)) prefs.edit().putString("assistantEndpoint", clean.take(300)).apply()
        }
        @JavascriptInterface fun setHideBubbleInFullscreen(enabled: Boolean) {
            prefs.edit().putBoolean("bubbleHideGamesEnabled", enabled).apply()
            if (prefs.getBoolean("overlayEnabled", false)) {
                try {
                    val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply { action = FloatingBubbleService.ACTION_REFRESH_BUBBLE_CONFIG }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
                } catch (e: Exception) { AppLog.ignored(e); }
            }
        }
        @JavascriptInterface fun requestDndAccess() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !hasNotificationPolicyAccess()) {
                    try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } catch (e: Exception) { AppLog.ignored(e); openAppSettingsScreen() }
                }
            }
        }
        @JavascriptInterface fun setDndMode(enabled: Boolean): String = setDoNotDisturbMode(enabled)
        @JavascriptInterface fun setDrivingMode(enabled: Boolean) { prefs.edit().putBoolean("drivingMode", enabled).apply() }
        @JavascriptInterface fun requestNotificationPermission() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST)
                } else {
                    try { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)) } catch (e: Exception) { AppLog.ignored(e); openAppSettingsScreen() }
                }
            }
        }
        @JavascriptInterface fun openBatterySettings() {
            runOnUiThread { try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e: Exception) { AppLog.ignored(e); openAppSettingsScreen() } }
        }
        fun openAppSettings() { runOnUiThread { openAppSettingsScreen() } }
        @JavascriptInterface fun saveBackup(filename: String, json: String) {
            runOnUiThread { requestBackupSave(filename, json) }
        }
        @JavascriptInterface fun saveCalendar(filename: String, content: String) {
            runOnUiThread { requestCalendarSave(filename, content) }
        }
        @JavascriptInterface fun setAppLock(on: Boolean): String {
            if (on) { val km=getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager; if(!km.isDeviceSecure) return "no-secure" }
            prefs.edit().putBoolean("appLockEnabled",on).apply()
            runOnUiThread { applySecureFlag(on); if(!on){locked=false;cover.visibility=View.GONE} }
            return "ok"
        }
        @JavascriptInterface fun setDigest(json: String) { prefs.edit().putString("digestConfig",json.take(500)).apply(); BackgroundScheduler.scheduleDigest(this@MainActivity) }
        @JavascriptInterface fun setBackupReminder(on: Boolean) { prefs.edit().putBoolean("backupReminder",on).apply(); BackgroundScheduler.scheduleBackupReminder(this@MainActivity) }
        @JavascriptInterface fun setEyeFilterLevel(level: Int) { prefs.edit().putInt("eyeFilterLevel",level.coerceIn(5,60)).apply(); if(prefs.getBoolean("eyeFilterEnabled",false)) runOnUiThread { try { startForegroundService(Intent(this@MainActivity,EyeFilterService::class.java)) } catch (_:Exception){} } }
        @JavascriptInterface fun updateSnapshot(json: String) { Snapshot.save(this@MainActivity,json); AlislahWidgetProvider.refreshAll(this@MainActivity) }
        @JavascriptInterface fun encryptBackup(json: String, pass: String): String = try { BackupCrypto.encrypt(json,pass) } catch (_:Exception) { "" }
        @JavascriptInterface fun decryptBackup(envelope: String, pass: String): String = try { BackupCrypto.decrypt(envelope,pass) ?: "" } catch (_:Exception) { "" }
        @JavascriptInterface fun shareText(text: String) { runOnUiThread { try { val send=Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT,text.take(4000)) }; startActivity(Intent.createChooser(send,"مشاركة")) } catch (_:Exception){} } }
        @JavascriptInterface fun copyText(text: String) { runOnUiThread { try { val cm=getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager; cm.setPrimaryClip(ClipData.newPlainText("ALISLAH",text.take(4000))) } catch (_:Exception){} } }
        @JavascriptInterface fun isSpeechAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(this@MainActivity)
        @JavascriptInterface fun startVoiceTask() { runOnUiThread { startVoiceTaskSession(requireHold = false) } }
        @JavascriptInterface fun startListening() { runOnUiThread { this@MainActivity.startNativeListening() } }
        @JavascriptInterface fun stopListening() { runOnUiThread { stopNativeListening() } }
        @JavascriptInterface fun requestUsagePermission() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply { data = Uri.parse("package:$packageName") }) }
        }
        fun isChildProtectionAccessibilityEnabled(): Boolean {
            val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
            return enabled.split(':').any { raw ->
                val component = ComponentName.unflattenFromString(raw)
                component != null && component.packageName == packageName &&
                    component.className.endsWith("ChildProtectionService")
            }
        }
        @JavascriptInterface fun getLaunchableAppsJson(): String {
            val rows = JSONArray()
            try {
                val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                @Suppress("DEPRECATION")
                val matches = packageManager.queryIntentActivities(launcher, 0)
                matches.map { it.activityInfo.packageName }.distinct().sorted().forEach { pkg ->
                    if (pkg == packageName) return@forEach
                    try {
                        val app = packageManager.getApplicationInfo(pkg, 0)
                        val label = packageManager.getApplicationLabel(app).toString().take(80)
                        rows.put(JSONObject().put("packageName", pkg).put("label", label))
                    } catch (e: Exception) { AppLog.ignored(e); }
                }
            } catch (e: Exception) { AppLog.ignored(e); }
            return rows.toString()
        }
        @JavascriptInterface fun requestRuntimePermissions() { runOnUiThread { this@MainActivity.requestRuntimePermissions() } }
        @JavascriptInterface fun enableOverlay() { runOnUiThread { this@MainActivity.enableOverlay() } }
        @JavascriptInterface fun disableOverlay() { runOnUiThread { this@MainActivity.disableOverlay() } }
        @JavascriptInterface fun scheduleTaskReminder(id: String, title: String, atMillis: Long) {
            if (id.isBlank()) return
            ReminderStore.schedule(this@MainActivity, id.take(120), title.take(180), atMillis)
        }
        @JavascriptInterface fun cancelTaskReminder(id: String) {
            if (id.isBlank()) return
            ReminderStore.cancel(this@MainActivity, id.take(120))
        }
        @JavascriptInterface fun assistantAnswered() {
            runOnUiThread {
                val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply {
                    action = FloatingBubbleService.ACTION_ANSWERED
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
            }
        }
        @JavascriptInterface fun showBubbleForEvent() {
            runOnUiThread {
                val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply {
                    action = FloatingBubbleService.ACTION_SHOW_FOR_EVENT
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
            }
        }
    }
}
