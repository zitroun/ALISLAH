package dz.alislah.app

import android.content.Context

/** Prayer countdown is rendered only inside the floating bubbles, never as a notification. */
object LiveCountdown {
    const val CHANNEL = "alislah_live"
    fun update(context: Context, prayerName: String, atMs: Long) = cancel(context)
    fun cancel(context: Context) {
        context.getSystemService(android.app.NotificationManager::class.java)?.cancel(9460)
    }
    fun refresh(context: Context) = cancel(context)
}
