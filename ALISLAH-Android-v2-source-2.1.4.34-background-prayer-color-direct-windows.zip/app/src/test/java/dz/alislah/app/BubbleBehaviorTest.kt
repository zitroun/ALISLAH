package dz.alislah.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BubbleBehaviorTest {

    @Test
    fun defaultsApplyUntilTheUserChoosesOtherwise() {
        assertEquals("orbit", BubbleBehavior.actionFor("tap", emptyMap()))
        assertEquals("ask", BubbleBehavior.actionFor("double", emptyMap()))
        assertEquals("prayer", BubbleBehavior.actionFor("long", mapOf("long" to "prayer")))
    }

    @Test
    fun unknownActionsFallBackToNone() {
        assertEquals("none", BubbleBehavior.actionFor("tap", mapOf("tap" to "shutdown")))
        assertEquals("none", BubbleBehavior.sanitize(null))
    }

    @Test
    fun swipesHaveSafeDefaults() {
        assertEquals("open", BubbleBehavior.actionFor("swipeup", emptyMap()))
        assertEquals("snooze", BubbleBehavior.actionFor("swipedown", emptyMap()))
    }

    @Test
    fun prayerLeadsTheFanWhenItIsClose() {
        assertEquals("prayer", BubbleBehavior.orbitOrder(true).first())
        assertEquals("ask", BubbleBehavior.orbitOrder(false).first())
        assertEquals(6, BubbleBehavior.orbitOrder(true).size)
        assertEquals(6, BubbleBehavior.orbitOrder(true).distinct().size)
    }

    @Test
    fun mostUsedShortcutComesFirstAndMoreStaysLast() {
        val order = BubbleBehavior.orbitOrder(false, mapOf("qibla" to 9))
        assertEquals("qibla", order.first())
        assertEquals("more", order.last())
    }

    @Test
    fun drivingModeKeepsVoiceShortcuts() {
        assertEquals(listOf("ask", "readtasks", "plan"), BubbleBehavior.orbitOrder(true, emptyMap(), true))
    }

    @Test
    fun prayerRingOnlyAppearsInTheLastHour() {
        val now = 1_000_000L
        assertEquals(0f, BubbleBehavior.ringFraction(now, null), 0.0001f)
        assertEquals(0f, BubbleBehavior.ringFraction(now, now + 2 * 3_600_000L), 0.0001f)
        assertEquals(0.5f, BubbleBehavior.ringFraction(now, now + 30 * 60_000L), 0.01f)
        assertEquals(0.75f, BubbleBehavior.ringFraction(now, now + 45 * 60_000L), 0.01f)
        assertEquals("01:01:01", BubbleBehavior.countdownText(now, now + 3_661_000L))
        assertEquals("00:00:00", BubbleBehavior.countdownText(now, now - 1000L))
        assertEquals(0.75f, BubbleBehavior.ringFraction(now, now + 45 * 60_000L), 0.01f)
        assertEquals("01:01:01", BubbleBehavior.countdownText(now, now + 3_661_000L))
        assertEquals("00:00:00", BubbleBehavior.countdownText(now, now - 1000L))
        assertEquals(0f, BubbleBehavior.ringFraction(now, now - 1), 0.0001f)
    }

    @Test
    fun prayerSoonIsTheFifteenMinutesBeforeTheAdhan() {
        val now = 1_000_000L
        assertTrue(BubbleBehavior.prayerSoon(now, now + 10 * 60_000L))
        assertFalse(BubbleBehavior.prayerSoon(now, now + 40 * 60_000L))
        assertFalse(BubbleBehavior.prayerSoon(now, null))
    }

    @Test
    fun badgeShowsTheCountUpToNinePlus() {
        assertEquals("", BubbleBehavior.badgeText(0))
        assertEquals("3", BubbleBehavior.badgeText(3))
        assertEquals("9+", BubbleBehavior.badgeText(12))
    }

    @Test
    fun callsHideTheBubble() {
        assertTrue(BubbleBehavior.hiddenByCall(true))
        assertFalse(BubbleBehavior.hiddenByCall(false))
    }

    @Test
    fun bubbleModeDefaultsToTheCustomBubble() {
        assertEquals("custom", BubbleBehavior.normalizeMode(null))
        assertEquals("custom", BubbleBehavior.normalizeMode("anything"))
        assertEquals("system", BubbleBehavior.normalizeMode("system"))
    }

}
