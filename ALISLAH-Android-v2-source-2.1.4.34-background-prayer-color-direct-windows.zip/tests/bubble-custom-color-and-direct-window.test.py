from pathlib import Path
r=Path(__file__).resolve().parents[1]
svc=(r/'app/src/main/java/dz/alislah/app/FloatingBubbleService.kt').read_text()
settings=(r/'app/src/main/java/dz/alislah/app/BubbleSettings.kt').read_text()
html=(r/'app/src/main/assets/index.html').read_text()
js=(r/'app/src/main/assets/js/bubble-settings.js').read_text()
assert 'else -> showAssistantOverlay(a.command)' in svc
assert 'mainBubbleColor(this)' in svc and 'setBubbleColor' in svc
assert 'mainBubbleColor' in settings and 'bubbleMainColor' in html and 'bubbleMainColor' in js
print('custom color and direct full-window contract: OK')
