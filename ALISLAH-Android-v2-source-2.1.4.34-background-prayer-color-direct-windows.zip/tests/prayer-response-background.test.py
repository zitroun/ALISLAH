from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'app/src/main/java/dz/alislah/app/PrayerResponseReceiver.kt').read_text()
assert 'context.startActivity' not in s
assert 'prayerResponses' in s and 'prayerLog' in s
assert 'put("done", done)' in s
print('prayer response background contract: OK')
