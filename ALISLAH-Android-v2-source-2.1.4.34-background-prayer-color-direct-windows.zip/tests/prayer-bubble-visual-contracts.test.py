from pathlib import Path

root = Path(__file__).resolve().parents[1]
service = (root / "app/src/main/java/dz/alislah/app/FloatingBubbleService.kt").read_text(encoding="utf-8")
logic = (root / "app/src/main/java/dz/alislah/app/BubbleBehavior.kt").read_text(encoding="utf-8")
assert "PrayerOrbitBubbleView" in service
assert 'text = "🕌\\n$time"' in service
assert "canvas.drawArc(rect, -90f, 360f * ringFraction" in service
assert "prayerCountdownTicker" in service and "handler.postDelayed(this, 1000L)" in service
assert "updatePrayerCountdownVisuals()" in service
assert "activeParentIndex" in service and "parentAngle - span / 2.0" in service
assert "tappedGroup?.children.isNullOrEmpty()" in service
assert "return (remaining.toFloat() / HOUR_MS).coerceIn(0f, 1f)" in logic
assert "fun countdownText" in logic
print("Prayer bubble visual contract passed: centred countdown, shrinking ring, synced main ring, and parent-anchored child arc.")
