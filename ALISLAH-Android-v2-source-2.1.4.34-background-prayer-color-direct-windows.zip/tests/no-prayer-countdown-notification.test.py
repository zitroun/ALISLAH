from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'app/src/main/java/dz/alislah/app/LiveCountdown.kt').read_text()
assert 'Notification.Builder' not in s and 'notify(' not in s
assert 'cancel(context)' in s
print('no prayer countdown notification contract: OK')
