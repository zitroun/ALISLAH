from pathlib import Path
root = Path(__file__).resolve().parents[1]
js = (root / 'app/src/main/assets/js/test-center.js').read_text(encoding='utf-8')
html = (root / 'app/src/main/assets/index.html').read_text(encoding='utf-8')
bubble = (root / 'app/src/main/java/dz/alislah/app/FloatingBubbleService.kt').read_text(encoding='utf-8')
assert js.split('const newFeatures')[0].count("{id:'") == 14, 'Expected exactly 14 feature categories'
for item in ['tcCopy', 'tcCopyErrors', 'tcNewFeatures', 'tcHistory', 'tcCategories']:
    assert item in html, f'Missing test center UI element: {item}'
for state in ['فشلت', 'تعذر الاختبار', 'نجحت حسب ملاحظتك', 'بانتظار تجربتك']:
    assert state in js, f'Missing test status: {state}'
assert 'navigator.clipboard.writeText' in js
assert 'alislah_test_center_v1' in js
assert 'testcenter' in bubble and 'اختبار الميزات' in bubble
assert 'BubbleAction("🧪", "اختبار الميزات", "testcenter"' in bubble
assert 'window.ALI?.tab?.(\'testcenter\')' in bubble
assert 'newFeatures' in js and 'تشغيل وتجربة' in js
assert 'tcRunAll' not in js and 'function probe' not in js
assert 'runFeatureTest' in js and "nativeTest('bubble')" in js
main_activity = (root / 'app/src/main/java/dz/alislah/app/MainActivity.kt').read_text(encoding='utf-8')
assert 'runFeatureTest' in main_activity
assert 'requestBootRestoreTest' in main_activity
assert 'if(!state[id]?.attemptAt)' in js, 'User decisions must be blocked until the feature has actually been launched'
assert 'data-user=\"${c.id}|pass\"' in js and 'ready?' in js
assert 'lastBootRestoreVerifiedAt' in main_activity
assert 'bubble_shown' in bubble and 'bubble_not_visible' in bubble
receiver = (root / 'app/src/main/java/dz/alislah/app/BackgroundEventsReceiver.kt').read_text(encoding='utf-8')
assert 'Intent.ACTION_BOOT_COMPLETED' in receiver and 'startForegroundService(service)' in receiver
assert "versionCode 65" in (root / 'app/build.gradle').read_text(encoding='utf-8')
assert "versionName '2.1.4.26'" in (root / 'app/build.gradle').read_text(encoding='utf-8')
print('Test center contracts: PASS (14 categories, actual feature launch, user decisions, persistent history and reports)')
