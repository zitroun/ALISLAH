from pathlib import Path
root=Path(__file__).resolve().parents[1]
service=(root/'app/src/main/java/dz/alislah/app/FloatingBubbleService.kt').read_text(encoding='utf-8')
gpu=(root/'app/src/main/java/dz/alislah/app/Plasma3DRenderer.kt').read_text(encoding='utf-8')
assert 'class MainBubbleView' in service and 'private val sphere = Plasma3DView(context)' in service
assert 'class PlasmaActionTextView' in service and 'private val plasma = Plasma3DView(context, compact = true)' in service
assert 'PlasmaOrbit3DView(this)' in service and 'float sdTorus(vec3 p)' in gpu
assert 'setBubbleMode' in service and 'setPrayerRing' in service and 'setBadge' in service
assert 'onAttachedToWindow' in service and 'onDetachedFromWindow' in service
assert 'setEGLContextClientVersion(2)' in gpu
assert 'GL_FRAGMENT_SHADER' in gpu and 'float h = b*b - c' in gpu
assert 'for (int i=0; i<32; i++)' in gpu and 'float field(vec3 p, float t)' in gpu
assert 'float ndl = max(dot(n, lightDir), 0.0)' in gpu and 'float spec = pow' in gpu
assert 'layoutInDisplayCutoutMode' in service
assert 'anchorCenterX(anchor)' in service and 'anchorCenterY(anchor)' in service
assert 'FLAG_LAYOUT_NO_LIMITS' in service
print('OpenGL 3D main sphere, action spheres and torus orbit contracts: PASS')
