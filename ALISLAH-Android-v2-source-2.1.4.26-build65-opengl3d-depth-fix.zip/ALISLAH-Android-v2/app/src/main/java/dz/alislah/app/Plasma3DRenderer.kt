package dz.alislah.app

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.view.SurfaceHolder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** Real GPU-rendered volumetric sphere. The fragment shader ray-intersects a 3D sphere and
 * evaluates animated volumetric plasma fields, lighting, Fresnel rim and specular glass. */
internal class Plasma3DView(context: Context, private val compact: Boolean = false) : GLSurfaceView(context) {
    private val plasmaRenderer = PlasmaRenderer()
    @Volatile private var tintR=0.08f; @Volatile private var tintG=0.95f; @Volatile private var tintB=0.68f
    @Volatile private var currentMode = "idle"
    private val frameHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val framePump = object : Runnable { override fun run() { requestRender(); frameHandler.postDelayed(this, when(currentMode){"idle"->if(compact)240L else 120L;"listening"->if(compact)130L else 58L;"thinking","waiting"->if(compact)110L else 38L;"speaking"->if(compact)90L else 28L;else->if(compact)180L else 90L}) } }
    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        holder.setFormat(android.graphics.PixelFormat.RGBA_8888)
        setZOrderMediaOverlay(true)
        setRenderer(plasmaRenderer)
        renderMode = RENDERMODE_WHEN_DIRTY
        setPreserveEGLContextOnPause(true)
    }
    fun setAssistantMode(mode: String) { currentMode=mode; plasmaRenderer.mode=mode; frameHandler.removeCallbacks(framePump); frameHandler.post(framePump) }
    fun setTint(color:Int) { tintR=((color shr 16) and 255)/255f; tintG=((color shr 8) and 255)/255f; tintB=(color and 255)/255f; plasmaRenderer.tint=floatArrayOf(tintR,tintG,tintB); requestRender() }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); frameHandler.removeCallbacks(framePump); frameHandler.post(framePump) }
    override fun onDetachedFromWindow() { frameHandler.removeCallbacks(framePump); super.onDetachedFromWindow() }

    private class PlasmaRenderer : Renderer {
        @Volatile var mode: String = "idle"
        @Volatile var tint: FloatArray = floatArrayOf(.08f,.95f,.68f)
        private var program = 0
        private var position = 0
        private var resolution = 0
        private var time = 0
        private var speed = 0
        private var tintLoc = 0
        private lateinit var vertices: FloatBuffer
        private val vertexShader = """
            attribute vec2 aPosition;
            varying vec2 vUv;
            void main(){ vUv=aPosition*0.5+0.5; gl_Position=vec4(aPosition,0.0,1.0); }
        """.trimIndent()
        private val fragmentShader = """
            precision highp float;
            varying vec2 vUv;
            uniform vec2 uResolution;
            uniform float uTime;
            uniform float uSpeed;
            uniform vec3 uTint;

            float field(vec3 p, float t) {
                float a = sin(p.x*4.1 + t*0.72 + sin(p.y*3.2-t*.4));
                float b = cos(p.y*4.6 - t*.55 + sin(p.z*3.5+t*.3));
                float c = sin(p.z*4.0 + t*.61 + cos(p.x*3.1-t*.35));
                return (a+b+c) * .3333333;
            }

            void main() {
                vec2 q = (vUv - .5) * 2.0;
                q.x *= uResolution.x / max(uResolution.y, 1.0);
                float screenR = length(q);
                if (screenR > 1.02) discard;

                // Perspective camera and exact ray/sphere intersection.
                vec3 ro = vec3(0.0, 0.0, 2.72);
                vec3 rd = normalize(vec3(q, -1.78));
                float b = dot(ro, rd);
                float c = dot(ro, ro) - 1.0;
                float h = b*b - c;
                if (h <= 0.0) discard;
                float rootH = sqrt(h);
                float tNear = -b - rootH;
                float tFar  = -b + rootH;
                vec3 p = ro + rd*tNear;
                vec3 n = normalize(p);
                vec3 viewDir = normalize(-rd);

                // Large soft key light, emerald bounce and a restrained rim light.
                vec3 lightDir = normalize(vec3(-.48, .62, .92));
                float ndl = max(dot(n, lightDir), 0.0);
                float hemi = .5 + .5*n.y;
                float fresnel = pow(1.0-max(dot(n,viewDir),0.0), 3.2);
                float phase = uTime*uSpeed;

                // Smooth, broad plasma currents (avoid noisy speckled surface patterns).
                float f1 = field(p*1.05, phase);
                float f2 = field(p*1.72+vec3(1.3,-.7,.4), phase*.68);
                float currents = .5 + .5*(f1*.66 + f2*.34);
                float plasma = smoothstep(.20,.82,currents);
                float filament = pow(max(0.0, smoothstep(.62,.91,currents + .12*sin(p.x*2.8-p.y*2.1+phase*.4))), 2.0);

                // Volumetric light accumulation along the camera ray inside the sphere.
                vec3 volumeColor = vec3(0.0);
                float volumeAlpha = 0.0;
                for (int i=0; i<32; i++) {
                    float st = mix(tNear,tFar,(float(i)+.5)/32.0);
                    vec3 sp = ro + rd*st;
                    float vf = field(sp*1.75,phase*.78);
                    float pocket = smoothstep(.12,.78,.5+.5*vf);
                    float strand = smoothstep(.73,.96,.5+.5*field(sp*3.0+vec3(.2,.8,-.5),phase));
                    vec3 vc = mix(vec3(.008,.075,.060),vec3(.035,.62,.39),pocket);
                    vc = mix(vc,vec3(.32,1.0,.78),strand*.42);
                    float va = .012 + pocket*.018 + strand*.012;
                    volumeColor += (1.0-volumeAlpha)*vc*va;
                    volumeAlpha += (1.0-volumeAlpha)*va;
                }

                vec3 deep = vec3(.003,.025,.026);
                vec3 emerald = vec3(.012,.34,.205);
                vec3 jade = vec3(.035,.72,.48);
                vec3 col = mix(deep,emerald,plasma);
                col = mix(col,jade,filament*.42);

                // Soft internal glow, physically-shaped diffuse shading and contact shadow.
                float innerGlow = exp(-dot(p.xy-vec2(-.22,.24),p.xy-vec2(-.22,.24))*3.2);
                col += vec3(.08,.48,.30)*innerGlow*.30;
                float terminator = smoothstep(-.30,.38,dot(n,lightDir));
                float lighting = .20 + .60*ndl + .16*hemi + .08*terminator;
                col *= lighting;

                // Two controlled specular lobes create a glossy, curved glass/plasma surface.
                vec3 halfDir = normalize(lightDir+viewDir);
                float spec = pow(max(dot(n,halfDir),0.0),64.0);
                float broadSpec = pow(max(dot(n,normalize(lightDir+vec3(-.35,.28,.4))),0.0),12.0);
                col += vec3(.72,1.0,.91)*spec*.95;
                col += vec3(.18,.82,.58)*broadSpec*.18;
                col += volumeColor*1.75;
                col += vec3(.08,.78,.52)*fresnel*.48;
                col *= mix(vec3(1.0),max(uTint,vec3(.08)),.24);

                // Correct, monotonic edge masks: no reversed smoothstep edges.
                float edge = 1.0-smoothstep(.955,1.015,screenR);
                float limbShade = 1.0-smoothstep(.70,1.0,screenR)*.48;
                col *= limbShade;
                gl_FragColor = vec4(col,edge);
            }
        """.trimIndent()
        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            GLES20.glClearColor(0f,0f,0f,0f)
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA,GLES20.GL_ONE_MINUS_SRC_ALPHA)
            val vs=compile(GLES20.GL_VERTEX_SHADER,vertexShader)
            val fs=compile(GLES20.GL_FRAGMENT_SHADER,fragmentShader)
            program=GLES20.glCreateProgram().also { GLES20.glAttachShader(it,vs); GLES20.glAttachShader(it,fs); GLES20.glLinkProgram(it) }
            val status=IntArray(1); GLES20.glGetProgramiv(program,GLES20.GL_LINK_STATUS,status,0)
            if(status[0]==0) throw IllegalStateException("Plasma3D shader link failed: "+GLES20.glGetProgramInfoLog(program))
            position=GLES20.glGetAttribLocation(program,"aPosition")
            resolution=GLES20.glGetUniformLocation(program,"uResolution")
            time=GLES20.glGetUniformLocation(program,"uTime")
            speed=GLES20.glGetUniformLocation(program,"uSpeed")
            tintLoc=GLES20.glGetUniformLocation(program,"uTint")
            val data=floatArrayOf(-1f,-1f,1f,-1f,-1f,1f,1f,1f)
            vertices=ByteBuffer.allocateDirect(data.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(data); position(0) }
        }
        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) { surfaceWidth=width.coerceAtLeast(1); surfaceHeight=height.coerceAtLeast(1); GLES20.glViewport(0,0,width,height) }
        override fun onDrawFrame(gl: GL10?) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
            if(program==0) return
            val rate=when(mode){"idle"->.42f;"listening"->1.15f;"thinking","waiting"->1.75f;"speaking"->2.5f;else->.8f}
            GLES20.glUseProgram(program)
            GLES20.glUniform2f(resolution, surfaceWidth.toFloat().coerceAtLeast(1f), surfaceHeight.toFloat().coerceAtLeast(1f))
            GLES20.glUniform1f(time,System.nanoTime()/1_000_000_000f)
            GLES20.glUniform1f(speed,rate)
            val tintValue=tint
            GLES20.glUniform3f(tintLoc,tintValue[0],tintValue[1],tintValue[2])
            vertices.position(0); GLES20.glEnableVertexAttribArray(position)
            GLES20.glVertexAttribPointer(position,2,GLES20.GL_FLOAT,false,0,vertices)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4)
            GLES20.glDisableVertexAttribArray(position)
        }
        private var surfaceWidth=1; private var surfaceHeight=1
        private fun compile(type:Int,source:String):Int {
            val shader=GLES20.glCreateShader(type); GLES20.glShaderSource(shader,source); GLES20.glCompileShader(shader)
            val status=IntArray(1); GLES20.glGetShaderiv(shader,GLES20.GL_COMPILE_STATUS,status,0)
            if(status[0]==0) throw IllegalStateException("Plasma3D shader compile failed: "+GLES20.glGetShaderInfoLog(shader))
            return shader
        }
    }
}

/** GPU ray-marched torus used as the floating menu's actual 3D energy orbit. */
internal class PlasmaOrbit3DView(context: Context) : GLSurfaceView(context) {
    private val orbitRenderer = OrbitRenderer()
    private val frameHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val pump = object : Runnable { override fun run(){ requestRender(); frameHandler.postDelayed(this,64L) } }
    init { setEGLContextClientVersion(2); setEGLConfigChooser(8,8,8,8,16,0); holder.setFormat(android.graphics.PixelFormat.RGBA_8888); setZOrderMediaOverlay(true); setRenderer(orbitRenderer); renderMode=RENDERMODE_WHEN_DIRTY }
    override fun onAttachedToWindow(){super.onAttachedToWindow();frameHandler.removeCallbacks(pump);frameHandler.post(pump)}
    override fun onDetachedFromWindow(){frameHandler.removeCallbacks(pump);super.onDetachedFromWindow()}
    private class OrbitRenderer:Renderer {
        private var program=0;private var pos=0;private var res=0;private var tm=0;private lateinit var buf:FloatBuffer;private var w=1f;private var h=1f
        private val vs="attribute vec2 a; varying vec2 uv; void main(){uv=a*.5+.5;gl_Position=vec4(a,0.,1.);}"
        private val fs="""
            precision highp float; varying vec2 uv; uniform vec2 resolution; uniform float time;
            float sdTorus(vec3 p){return length(vec2(length(p.xy)-.72,p.z))-.075;}
            vec3 normalAt(vec3 p){vec2 e=vec2(.001,0.);return normalize(vec3(sdTorus(p+e.xyy)-sdTorus(p-e.xyy),sdTorus(p+e.yxy)-sdTorus(p-e.yxy),sdTorus(p+e.yyx)-sdTorus(p-e.yyx)));}
            void main(){vec2 q=(uv-.5)*2.;q.x*=resolution.x/resolution.y;vec3 ro=vec3(0.,0.,2.7);vec3 rd=normalize(vec3(q,-1.7));float t=0.;float d=0.;bool hit=false;
              for(int i=0;i<56;i++){vec3 p=ro+rd*t;d=sdTorus(p);if(d<.002){hit=true;break;}t+=max(d*.72,.004);if(t>5.)break;}if(!hit)discard;
              vec3 p=ro+rd*t;vec3 n=normalAt(p);vec3 l=normalize(vec3(-.5,.8,1.));float diff=max(dot(n,l),0.);float spec=pow(max(dot(reflect(-l,n),-rd),0.),28.);
              float a=atan(p.y,p.x);float wave=sin(a*5.-time*1.7+sin(a*3.+time)*.7);float energy=smoothstep(-.5,.8,wave);
              vec3 c=mix(vec3(.01,.19,.16),vec3(.08,.95,.66),energy);c+=vec3(1.,.58,.18)*pow(max(wave,0.),8.)*.8;c*=.32+diff*.8;c+=vec3(.65,1.,.9)*spec;
              float fres=pow(1.-max(dot(n,-rd),0.),2.);c+=vec3(.08,.8,.58)*fres*.8;gl_FragColor=vec4(c,.96);
            }
        """.trimIndent()
        override fun onSurfaceCreated(gl:GL10?,config:EGLConfig?){GLES20.glClearColor(0f,0f,0f,0f);GLES20.glEnable(GLES20.GL_BLEND);GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA,GLES20.GL_ONE_MINUS_SRC_ALPHA);val v=shader(GLES20.GL_VERTEX_SHADER,vs);val f=shader(GLES20.GL_FRAGMENT_SHADER,fs);program=GLES20.glCreateProgram().also{GLES20.glAttachShader(it,v);GLES20.glAttachShader(it,f);GLES20.glLinkProgram(it)};val ok=IntArray(1);GLES20.glGetProgramiv(program,GLES20.GL_LINK_STATUS,ok,0);if(ok[0]==0)throw IllegalStateException("Orbit shader link: "+GLES20.glGetProgramInfoLog(program));pos=GLES20.glGetAttribLocation(program,"a");res=GLES20.glGetUniformLocation(program,"resolution");tm=GLES20.glGetUniformLocation(program,"time");val a=floatArrayOf(-1f,-1f,1f,-1f,-1f,1f,1f,1f);buf=ByteBuffer.allocateDirect(a.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply{put(a);position(0)}}
        override fun onSurfaceChanged(gl:GL10?,width:Int,height:Int){w=width.coerceAtLeast(1).toFloat();h=height.coerceAtLeast(1).toFloat();GLES20.glViewport(0,0,width,height)}
        override fun onDrawFrame(gl:GL10?){GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT);GLES20.glUseProgram(program);GLES20.glUniform2f(res,w,h);GLES20.glUniform1f(tm,System.nanoTime()/1_000_000_000f);buf.position(0);GLES20.glEnableVertexAttribArray(pos);GLES20.glVertexAttribPointer(pos,2,GLES20.GL_FLOAT,false,0,buf);GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4);GLES20.glDisableVertexAttribArray(pos)}
        private fun shader(type:Int,src:String):Int{val s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s);val ok=IntArray(1);GLES20.glGetShaderiv(s,GLES20.GL_COMPILE_STATUS,ok,0);if(ok[0]==0)throw IllegalStateException("Orbit shader compile: "+GLES20.glGetShaderInfoLog(s));return s}
    }
}
