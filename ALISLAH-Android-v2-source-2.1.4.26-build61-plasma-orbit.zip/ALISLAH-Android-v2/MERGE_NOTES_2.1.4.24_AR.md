# ملاحظات دمج ALISLAH 2.1.4.24

1. استُخدم مصدر 2.1.4.23 مع المساعد السريع وإخفاء الألعاب/الفيديو كأساس.
2. نُقلت مكونات Cloud 3.7 المستقلة فقط: ChatBubbleActivity وSystemBubble وBubbleTileService وLiveCountdown وFullscreenWatcherService.
3. أضيفت واجهة إعدادات NativeBridge وHTML/JS من دون استبدال MainActivity أو FloatingBubbleService.
4. دمج إخفاء ملء الشاشة يظل اختياريًا؛ عند غياب إذن Accessibility تستمر آلية Usage Access للألعاب/الفيديو كما كانت.
5. بقيت الفقاعة المخصصة هي الافتراضية، ولا يتم إيقافها عند فشل السماح بفقاعات Android الرسمية.
6. بلاطة الإعدادات السريعة تغيّر overlayEnabled وتتعامل مع وضع الفقاعة الحالي.
7. LiveCountdown يُفعّل فقط باختيار المستخدم، ويعتمد على Snapshot.nextPrayer/PrayerScheduler.nextAdhan.
8. لم تُنسخ أي ملفات Cloud فوق خدمة الفقاعة أو MainActivity؛ لم تُحذف ميزات الأساس.
9. لم تُضمّن مفاتيح توقيع أو ملفات Mixer-TTS.
