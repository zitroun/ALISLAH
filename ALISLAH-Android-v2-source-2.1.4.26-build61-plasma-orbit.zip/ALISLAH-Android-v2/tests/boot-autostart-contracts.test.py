from pathlib import Path
root=Path(__file__).resolve().parents[1]
manifest=(root/"app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
receiver=(root/"app/src/main/java/dz/alislah/app/BackgroundEventsReceiver.kt").read_text(encoding="utf-8")
service=(root/"app/src/main/java/dz/alislah/app/FloatingBubbleService.kt").read_text(encoding="utf-8")
assert "android.permission.RECEIVE_BOOT_COMPLETED" in manifest
assert "android.intent.action.BOOT_COMPLETED" in manifest
assert "Intent.ACTION_BOOT_COMPLETED" in receiver
assert "context.startForegroundService(service)" in receiver
assert "context.startService(service)" in receiver
assert "startForeground(4107, buildNotification())" in service
assert "Settings.canDrawOverlays(this)" in service
assert "overlayEnabled" in receiver and "lastBootRestoreStatus" in receiver
assert "ACTION_RESTORE_AFTER_BOOT" in receiver and "ACTION_RESTORE_AFTER_BOOT" in service
assert "if (prefs().getBoolean(\"overlayEnabled\", false)" in service
assert "skipped_disabled" in receiver and "blocked_overlay_permission" in receiver
assert "bubble_shown" in service and "bubble_not_visible" in service
main=(root/"app/src/main/java/dz/alislah/app/MainActivity.kt").read_text(encoding="utf-8")
assert "requestBootRestoreTest" in main
assert "bootRestoreTestRequested" in receiver and "lastBootRestoreTestResult" in receiver
print("Boot auto-start contract checks: PASS (user preference, overlay permission, restore action and diagnostics)")
