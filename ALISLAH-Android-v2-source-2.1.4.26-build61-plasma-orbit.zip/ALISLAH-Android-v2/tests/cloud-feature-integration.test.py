from pathlib import Path
root=Path(__file__).resolve().parents[1]
checks={
    "versionCode 61": "versionCode 61" in (root/"app/build.gradle").read_text(),
    "Android 8.1 minSdk preserved": "minSdk 26" in (root/"app/build.gradle").read_text(),
    "system bubble activity": (root/"app/src/main/java/dz/alislah/app/ChatBubbleActivity.kt").exists(),
    "system bubble API": (root/"app/src/main/java/dz/alislah/app/SystemBubble.kt").exists(),
    "quick settings tile": (root/"app/src/main/java/dz/alislah/app/BubbleTileService.kt").exists(),
    "adaptive orbit ordering": "BubbleOrbitRules.order" in (root/"app/src/main/java/dz/alislah/app/FloatingBubbleService.kt").read_text(),
    "contextual bubble hints": "maybeShowBubbleHint" in (root/"app/src/main/java/dz/alislah/app/FloatingBubbleService.kt").read_text(),
    "prayer progress ring": "setPrayerRing" in (root/"app/src/main/java/dz/alislah/app/FloatingBubbleService.kt").read_text(),
    "live prayer countdown": "LiveCountdown.update" in (root/"app/src/main/java/dz/alislah/app/FloatingBubbleService.kt").read_text(),
    "fullscreen watcher opt-in": (root/"app/src/main/java/dz/alislah/app/FullscreenWatcherService.kt").exists(),
    "fullscreen watcher reads bounds without collecting window text": "getBoundsInScreen" in (root/"app/src/main/java/dz/alislah/app/FullscreenWatcherService.kt").read_text() and "getRootInActiveWindow" not in (root/"app/src/main/java/dz/alislah/app/FullscreenWatcherService.kt").read_text() and "android:canRetrieveWindowContent=\"true\"" in (root/"app/src/main/res/xml/fullscreen_accessibility.xml").read_text(),
    "custom bubble remains default": 'getString("bubbleMode", "custom")' in (root/"app/src/main/java/dz/alislah/app/MainActivity.kt").read_text(),
    "no keystore in source": not (root/"debug.keystore").exists(),
    "no voice model payload": not any(root.rglob("*.onnx")) and not any(root.rglob("*.tflite")),
}
for name,ok in checks.items(): print(("PASS" if ok else "FAIL")+": "+name)
if not all(checks.values()): raise SystemExit(1)
print("Cloud selective integration contract checks passed.")
