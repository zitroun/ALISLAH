from pathlib import Path
root = Path(__file__).resolve().parents[1]
source = (root / "app/src/main/java/dz/alislah/app/FloatingBubbleService.kt").read_text(encoding="utf-8")
assert "class MainBubbleView" in source
assert "RadialGradient" in source and "SweepGradient" in source
assert "plasmaGlow" in source and "glassHighlight" in source
assert "postInvalidateDelayed(420L)" in source, "idle animation should remain slow to reduce battery use"
assert "postInvalidateDelayed(85L)" in source, "voice activity should animate responsively"
assert "setGradientType(android.graphics.drawable.GradientDrawable.RADIAL_GRADIENT)" in source
assert "layoutInDisplayCutoutMode" in source
assert "anchorCenterX(anchor)" in source and "anchorCenterY(anchor)" in source
assert "FLAG_LAYOUT_NO_LIMITS" in source
print("Plasma bubble/orbit contracts: PASS")
