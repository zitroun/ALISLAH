from pathlib import Path
p=Path(__file__).parents[1]/"app/src/main/java/dz/alislah/app/OfflineCommandRouter.kt"
s=p.read_text()
checks={
 "prayer navigation":"Command(Type.OPEN_TAB, \"prayer\")",
 "task navigation":"Command(Type.OPEN_TAB, \"tasks\")",
 "adhan stop":"Command(Type.STOP_ADHAN)",
 "assistant stop":"Command(Type.STOP_ASSISTANT)",
 "left edge":"Command(Type.MOVE_BUBBLE_LEFT)",
 "offline preference":"RecognizerIntent.EXTRA_PREFER_OFFLINE",
}
for name,needle in checks.items():
    if needle not in s and name!="offline preference": raise SystemExit(f"missing {name}")
main=(Path(__file__).parents[1]/"app/src/main/java/dz/alislah/app/MainActivity.kt").read_text()
service=(Path(__file__).parents[1]/"app/src/main/java/dz/alislah/app/FloatingBubbleService.kt").read_text()
if "RecognizerIntent.EXTRA_PREFER_OFFLINE" not in main: raise SystemExit("offline recognition preference missing")
if "executeOfflineVoiceCommand(transcript)" not in service: raise SystemExit("overlay offline command routing missing")
if "ACTION_MOVE_BUBBLE_LEFT" not in service: raise SystemExit("left edge action missing")
if "showFollowupOverlay(question.take(260))" not in service: raise SystemExit("follow-up bubble card route missing")
if "OfflineCommandRouter.Type.READ_ZAD" not in service: raise SystemExit("read-zad bubble command missing")
if "OfflineCommandRouter.Type.READ_ZAD" not in main: raise SystemExit("read-zad main command missing")
if "contentRead" not in (Path(__file__).parents[1]/"app/src/main/assets/js/content.js").read_text(): raise SystemExit("zād read action missing")
print("offline command routing source checks passed")
