from pathlib import Path
root=Path(__file__).resolve().parents[1]
js=(root/"app/src/main/assets/js/test-center.js").read_text(encoding="utf-8")
main=(root/"app/src/main/java/dz/alislah/app/MainActivity.kt").read_text(encoding="utf-8")
html=(root/"app/src/main/assets/index.html").read_text(encoding="utf-8")
assert js.split("const newFeatures")[0].count("{id:'") == 14
for marker in ["nativeTest('bubble')", "nativeTest('voice')", "nativeTest('prayer')", "nativeTest('comfort')", "nativeTest('integration')", "nativeTest('backup')"]:
    assert marker in js, f"Missing direct feature action: {marker}"
for marker in ["BUBBLE_STARTED", "VOICE_TEST_STARTED", "ADHAN_TEST_STARTED", "EYE_FILTER_STARTED", "TEST_NOTIFICATION_SENT", "BACKUP_ROUNDTRIP_OK", "PRAYER_REMINDER_SHOWN", "FOLLOWUP_SHOWN"]:
    assert marker in main, f"Missing native test effect: {marker}"
assert "_alislahTestCenter:true" in js and "tcCleanup" in html
assert "voice_stop" in js and "nativeTest('bubble')" in js
assert "requestSubmit()" in js and "startVoiceTask()" in js
assert "navigator.clipboard.writeText" in js
assert "نجحت حسب ملاحظتك" in js and "تعذر الاختبار" in js
assert "runFeatureTest" in main
print("Real feature execution contracts: PASS (direct effects, safe test records, cleanup and user decision)")
