package dz.alislah.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FullscreenRulesTest {

    @Test
    fun hidesOnlyForGamesOrVideoWhenEnabled() {
        assertTrue(FullscreenRules.shouldHide(true, "com.game.x", "dz.alislah.app", true))
        assertFalse(FullscreenRules.shouldHide(true, "com.chat", "dz.alislah.app", false))
        assertFalse(FullscreenRules.shouldHide(false, "com.game.x", "dz.alislah.app", true))
    }

    @Test
    fun neverHidesForOurOwnAppOrUnknownForeground() {
        assertFalse(FullscreenRules.shouldHide(true, "dz.alislah.app", "dz.alislah.app", true))
        assertFalse(FullscreenRules.shouldHide(true, null, "dz.alislah.app", true))
        assertFalse(FullscreenRules.shouldHide(true, "", "dz.alislah.app", true))
    }

    @Test
    fun lastForegroundIsTheMostRecentResume() {
        val events = listOf(
            Triple("com.a", FullscreenRules.RESUMED, 100L),
            Triple("com.game", FullscreenRules.RESUMED, 300L),
            Triple("com.a", 2, 400L)
        )
        assertEquals("com.game", FullscreenRules.lastForeground(events))
        assertNull(FullscreenRules.lastForeground(emptyList()))
    }
}
