package dz.alislah.app

import org.junit.Assert.assertEquals
import org.junit.Test

class BubbleOrbitRulesTest {
    @Test fun prayerIsPromotedAndCloseAllStaysLast() {
        val actions=listOf("ask","plan","prayer","family","closeWindows")
        assertEquals(listOf("prayer","ask","plan","family","closeWindows"), BubbleOrbitRules.order(actions, emptyMap(), true))
    }
    @Test fun usageCountsRankShortcutsStably() {
        val actions=listOf("ask","plan","prayer","closeWindows")
        assertEquals(listOf("plan","prayer","ask","closeWindows"), BubbleOrbitRules.order(actions, mapOf("plan" to 5,"prayer" to 2), false))
    }
}
