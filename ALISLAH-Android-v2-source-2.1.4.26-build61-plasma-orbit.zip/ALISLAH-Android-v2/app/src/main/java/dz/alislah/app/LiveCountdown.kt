package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

/** Optional ongoing countdown to the next prayer. Uses Android's native chronometer. */
object LiveCountdown {
    const val CHANNEL = "alislah_live"
    private const val NOTIFICATION_ID = 9460

    fun update(context: Context, prayerName: String, atMs: Long) {
        if (atMs <= System.currentTimeMillis()) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val channel = NotificationChannel(CHANNEL, "العد التنازلي للصلاة", NotificationManager.IMPORTANCE_LOW)
            channel.setShowBadge(false)
            nm.createNotificationChannel(channel)
        }
        val open = PendingIntent.getActivity(context, 9461, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = Notification.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("الصلاة القادمة: $prayerName")
            .setContentText("العد التنازلي حتى الأذان")
            .setWhen(atMs).setShowWhen(true).setUsesChronometer(true).setChronometerCountDown(true)
            .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open).build()
        try { nm.notify(NOTIFICATION_ID, notification) } catch (_: SecurityException) { }
    }

    fun refresh(context: Context) {
        val enabled = context.getSharedPreferences("alislah_native", Context.MODE_PRIVATE)
            .getBoolean("bubbleLiveCountdownEnabled", false)
        if (!enabled) { cancel(context); return }
        val next = Snapshot.nextPrayer(context)
        if (next == null) cancel(context) else update(context, next.first, next.second)
    }

    fun cancel(context: Context) {
        context.getSystemService(NotificationManager::class.java)?.cancel(NOTIFICATION_ID)
    }
}
