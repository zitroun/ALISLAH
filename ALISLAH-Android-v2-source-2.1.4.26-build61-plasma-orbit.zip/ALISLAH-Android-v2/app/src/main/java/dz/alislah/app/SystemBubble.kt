package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.LocusId
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.os.Build
import android.provider.Settings
import android.util.Log

/** Optional Android conversation bubble. The custom ALISLAH bubble remains the default. */
object SystemBubble {
    const val CHANNEL = "alislah_bubbles"
    private const val NOTIFICATION_ID = 9470
    private const val SHORTCUT_ID = "alislah_assistant_bubble"
    private const val TAG = "ALISLAH-Bubble"

    fun supported(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R

    fun allowed(context: Context): Boolean {
        if (!supported()) return false
        val nm = context.getSystemService(NotificationManager::class.java) ?: return false
        return try {
            nm.areNotificationsEnabled() && nm.areBubblesAllowed() &&
                (nm.getNotificationChannel(CHANNEL)?.canBubble() != false)
        } catch (_: Exception) { false }
    }

    /** Returns false instead of disabling the working custom bubble if Android blocks bubbles. */
    fun post(context: Context): Boolean {
        if (!supported()) return false
        val nm = context.getSystemService(NotificationManager::class.java) ?: return false
        ensureChannel(nm)
        if (!allowed(context)) return false
        pushShortcut(context)
        val density = context.resources.displayMetrics.density
        val target = Intent(context, ChatBubbleActivity::class.java).setAction(Intent.ACTION_VIEW)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0)
        val pi = PendingIntent.getActivity(context, 9471, target, flags)
        val metadata = Notification.BubbleMetadata.Builder(pi, Icon.createWithResource(context, R.mipmap.ic_launcher))
            .setDesiredHeight((480 * density).toInt())
            .setSuppressNotification(true)
            .setAutoExpandBubble(false)
            .build()
        val notification = Notification.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("المساعد السريع")
            .setContentText("اضغط لفتح محادثة ALISLAH")
            .setShortcutId(SHORTCUT_ID)
            .setBubbleMetadata(metadata)
            .setOngoing(true)
            .build()
        return try { nm.notify(NOTIFICATION_ID, notification); true }
        catch (e: Exception) { Log.w(TAG, "system bubble post failed", e); false }
    }

    fun cancel(context: Context) {
        context.getSystemService(NotificationManager::class.java)?.cancel(NOTIFICATION_ID)
    }

    fun openSettings(context: Context) {
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            Intent(Settings.ACTION_APP_NOTIFICATION_BUBBLE_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        else Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { context.startActivity(intent) }
        catch (e: Exception) {
            try { context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (inner: Exception) { Log.w(TAG, "no notification settings screen", inner) }
        }
    }

    private fun ensureChannel(nm: NotificationManager) {
        if (nm.getNotificationChannel(CHANNEL) != null) return
        val channel = NotificationChannel(CHANNEL, "فقاعات المساعد", NotificationManager.IMPORTANCE_DEFAULT)
        channel.setAllowBubbles(true)
        nm.createNotificationChannel(channel)
    }

    private fun pushShortcut(context: Context) {
        val manager = context.getSystemService(ShortcutManager::class.java) ?: return
        val intent = Intent(context, ChatBubbleActivity::class.java).setAction(Intent.ACTION_VIEW)
        val shortcut = ShortcutInfo.Builder(context, SHORTCUT_ID)
            .setShortLabel("مساعد ALISLAH")
            .setIcon(Icon.createWithResource(context, R.mipmap.ic_launcher))
            .setIntent(intent)
            .setLongLived(true)
            .setLocusId(LocusId(SHORTCUT_ID))
            .setCategories(setOf("android.shortcut.conversation"))
            .build()
        try { manager.pushDynamicShortcut(shortcut) }
        catch (e: Exception) { Log.w(TAG, "conversation shortcut failed", e) }
    }
}
