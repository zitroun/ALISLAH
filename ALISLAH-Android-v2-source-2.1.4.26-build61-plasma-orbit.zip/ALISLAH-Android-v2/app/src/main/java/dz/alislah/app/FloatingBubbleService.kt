package dz.alislah.app

import android.app.Notification
import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.Context
import android.media.AudioAttributes
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Rect
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.Surface
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.content.res.Configuration
import android.webkit.WebChromeClient
import android.webkit.PermissionRequest
import android.Manifest
import android.content.pm.PackageManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.view.WindowManager
import android.util.DisplayMetrics
import android.widget.TextView
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class FloatingBubbleService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var bubbleAutoHiddenOrigin: Pair<Int, Int>? = null
    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f
    private var dragged = false
    private var downAt = 0L
    private var lastTapAt = 0L
    private var pendingMainTap: Runnable? = null
    private var mainLongPressRunnable: Runnable? = null
    private var mainLongPressTriggered = false
    private var longPressTriggeredAction = ""
    private var speakingTapConsumed = false
    private var lastBubbleScreenWidth = 0
    private var lastBubbleScreenHeight = 0
    private var lastDisplayRotation = Surface.ROTATION_0
    private var lastConfigOrientation = Configuration.ORIENTATION_UNDEFINED
    // Keep independent anchor positions for portrait and landscape. Returning to an
    // orientation restores its saved edge/position instead of reusing rotated pixels.
    private var portraitAnchorXRatio: Float? = null
    private var portraitAnchorYRatio: Float? = null
    private var landscapeAnchorXRatio: Float? = null
    private var landscapeAnchorYRatio: Float? = null
    private var orbitRotation = 0.0
    private var closeButton: TextView? = null
    private var closeParams: WindowManager.LayoutParams? = null
    private var quickMenu: View? = null
    private var quickMenuParams: WindowManager.LayoutParams? = null
    private var bubbleHint: BubbleHint? = null
    private data class MiniOverlayWindow(
        val id: String,
        val command: String,
        val root: LinearLayout,
        val params: WindowManager.LayoutParams,
        val body: TextView,
        var expanded: Boolean,
        var pinned: Boolean
    )
    private val miniWindows = LinkedHashMap<String, MiniOverlayWindow>()
    private var miniWindowsRestored = false
    private var tts: TextToSpeech? = null
    private var assistantRecognizer: SpeechRecognizer? = null
    private var quickAsk: QuickAsk? = null
    private var quickAskRecognizer: SpeechRecognizer? = null
    private var quickAskVoiceOk: ((String) -> Unit)? = null
    private var quickAskVoiceFail: ((String) -> Unit)? = null
    private var quickAskVoicePending = false
    private var bubbleHiddenByFullscreen = false
    private val fullscreenCheck = object : Runnable {
        override fun run() {
            try {
                val hideAnyFullscreen = prefs().getBoolean("bubbleHideFullscreenEnabled", false)
                val a11yFullscreen = hideAnyFullscreen && AccessibilityChecks.isEnabled(this@FloatingBubbleService) &&
                    FullscreenState.active && FullscreenState.pkg != packageName
                if (a11yFullscreen) {
                    setBubbleHiddenByFullscreen(true)
                } else {
                    val enabled = prefs().getBoolean("bubbleHideGamesEnabled", false)
                    val allowed = hasUsageStatsPermission()
                    if (!enabled || !allowed) setBubbleHiddenByFullscreen(false)
                    else {
                        val foreground = ForegroundTracker.currentPackage(this@FloatingBubbleService)
                        if (foreground != null) {
                            val hide = FullscreenRules.shouldHide(true, foreground, packageName,
                                ForegroundTracker.isGameOrVideo(this@FloatingBubbleService, foreground))
                            setBubbleHiddenByFullscreen(hide)
                        }
                    }
                }
                updateLivePrayerCountdown()
                updatePrayerRing()
            } catch (_: Exception) { setBubbleHiddenByFullscreen(false) }
            handler.postDelayed(this, 2500L)
        }
    }
    private var assistantListening = false
    private var lastSpokenReply = ""
    private var networkArabicVoice: android.speech.tts.Voice? = null
    private var localArabicVoice: android.speech.tts.Voice? = null
    private var pendingFallbackText = ""
    private var fallbackAttempted = false
    private var ttsReady = false
    @Volatile private var assistantSpeaking = false
    private val pollReply = object : Runnable { override fun run() { speakLatestReply(); if (assistantPanel != null) handler.postDelayed(this, 1800L) } }
    private var assistantPanel: View? = null
    private var assistantPanelPinned = false
    private var assistantWebView: WebView? = null
    private var activeOverlayCommand: String? = null
    private var overlayPageReady = false
    private val pendingOverlayScripts = ArrayDeque<String>()
    private var adhanPlaying = false
    private var adhanMuteBubble: TextView? = null
    private var adhanMuteParams: WindowManager.LayoutParams? = null
    private var assistantStopBubble: TextView? = null
    private var assistantStopParams: WindowManager.LayoutParams? = null
    @Volatile private var autoListenAfterSpeech = false
    private var currentReminderTitle = ""
    private var currentReminderText = ""
    private var reminderCardVisible = false
    private var reminderSpeechActive = false
    private var reminderCardView: LinearLayout? = null
    private var reminderCardParams: WindowManager.LayoutParams? = null
    private var reminderArrowView: TextView? = null
    private var reminderArrowParams: WindowManager.LayoutParams? = null
    private var reminderStopView: TextView? = null
    private var reminderStopParams: WindowManager.LayoutParams? = null
    private var reminderActionBar: LinearLayout? = null
    @Volatile private var bubbleState: String = "idle"
    private val handler = Handler(Looper.getMainLooper())
    private val fadeBubbleWhenIdle = Runnable {
        val view = bubble
        val lp = params
        if (view != null && lp != null && quickMenu == null && !adhanPlaying && !assistantSpeaking && !reminderCardVisible) {
            val edge = (view as? MainBubbleView)?.capsuleEdge ?: "circle"
            // Edge-docked capsules slide partly beyond the display after inactivity,
            // leaving a large, tappable portion visible. The first touch restores the
            // exact saved position before gesture handling begins.
            if (edge == "left" || edge == "right" || edge == "top" || edge == "bottom") {
                if (bubbleAutoHiddenOrigin == null) {
                    bubbleAutoHiddenOrigin = Pair(lp.x, lp.y)
                    val remain = (minOf(lp.width, lp.height) * 0.62f).toInt()
                    when (edge) {
                        "left" -> lp.x -= (lp.width - remain).coerceAtLeast(0)
                        "right" -> lp.x += (lp.width - remain).coerceAtLeast(0)
                        "top" -> lp.y -= (lp.height - remain).coerceAtLeast(0)
                        "bottom" -> lp.y += (lp.height - remain).coerceAtLeast(0)
                    }
                    try { windowManager.updateViewLayout(view, lp) } catch (_: Exception) { bubbleAutoHiddenOrigin = null }
                    view.post { syncAdhanMuteBubble(); syncAssistantStopBubble(); syncReminderOverlay(lp) }
                }
            }
            view.alpha = 0.78f
        }
    }

    private fun restoreAutoHiddenBubble() {
        val origin = bubbleAutoHiddenOrigin ?: return
        val view = bubble ?: return
        val lp = params ?: return
        lp.x = origin.first
        lp.y = origin.second
        bubbleAutoHiddenOrigin = null
        view.alpha = 1f
        try { windowManager.updateViewLayout(view, lp) } catch (_: Exception) { }
        view.post { syncAdhanMuteBubble(); syncAssistantStopBubble(); syncReminderOverlay(lp) }
    }
    private val assistantNoSpeechTimeout = Runnable {
        if (assistantListening) {
            assistantListening = false
            setBubbleState("idle")
            stopAssistantRecognizer()
            overlaySpeechStatus("انتهى الاستماع بعد 3 ثوانٍ دون كلام.")
        }
    }
    private val reshowBubble = Runnable { showBubble() }

    override fun onCreate() {
        super.onCreate()
        liveInstance = this
        adhanPlaying = prefs().getBoolean("adhanPlaying", false)
        createChannel()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                configureAssistantVoice()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { handler.post { setAssistantSpeaking(true) } }
                    override fun onDone(utteranceId: String?) {
                        handler.post {
                            setAssistantSpeaking(false)
                            if (reminderSpeechActive) { reminderSpeechActive = false; reminderStopView?.visibility = View.GONE }
                            if (autoListenAfterSpeech && assistantPanel != null) {
                                autoListenAfterSpeech = false
                                handler.postDelayed({ if (assistantPanel != null && !assistantListening) startAssistantListening() }, 350L)
                            }
                        }
                        fallbackAttempted = false; pendingFallbackText = ""
                    }
                    override fun onError(utteranceId: String?) { handler.post { setAssistantSpeaking(false) }; retryWithLocalArabicVoice() }
                    override fun onError(utteranceId: String?, errorCode: Int) { handler.post { setAssistantSpeaking(false) }; retryWithLocalArabicVoice() }
                })
                if (pendingFallbackText.isNotBlank()) speak(pendingFallbackText)
            }
        }
        startForeground(4107, buildNotification())
        // Background speech/playback actions may use this service while the bubble is disabled.
        // Restore the overlay only when the user explicitly enabled it.
        if (prefs().getBoolean("overlayEnabled", false) &&
            (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))) showBubble()
        handler.removeCallbacks(fullscreenCheck)
        handler.postDelayed(fullscreenCheck, 1200L)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ANSWERED -> {
                handler.removeCallbacks(reshowBubble)
                // Do not tear down time-critical controls while adhan/reminder audio is active.
                if (adhanPlaying || reminderCardVisible || assistantSpeaking) {
                    hideQuickMenu()
                } else hideBubble()
            }
            ACTION_TEST_BUBBLE -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
                    if (bubble == null) showBubble()
                    if (!prefs().getBoolean("overlayEnabled", false)) handler.postDelayed({ if (!prefs().getBoolean("overlayEnabled", false)) hideBubble() }, 20000L)
                }
            }
            ACTION_HIDE_PANEL -> hideAssistantOverlay()
            ACTION_START_ASSISTANT_LISTENING -> startAssistantListening()
            ACTION_STOP_ASSISTANT_LISTENING -> stopAssistantListening()
            ACTION_ASSISTANT_MIC_PERMISSION_RESULT -> {
                if (intent.getBooleanExtra(EXTRA_ASSISTANT_MIC_GRANTED, false)) {
                    if (quickAskVoicePending && quickAsk?.isShowing == true) {
                        quickAskVoicePending = false
                        startQuickAskVoice()
                    } else startAssistantListening()
                } else {
                    quickAskVoicePending = false
                    quickAskVoiceFail?.invoke("لم يُمنح إذن الميكروفون. يمكنك الكتابة بدلًا من ذلك.")
                    overlaySpeechStatus("لم يُمنح إذن الميكروفون. يمكنك تفعيله من إعدادات التطبيق.")
                }
            }
            ACTION_STOP_SPEECH -> stopAssistantSpeech()
            ACTION_SET_BUBBLE_STATE -> setBubbleState(intent.getStringExtra(EXTRA_BUBBLE_STATE) ?: "idle")
            ACTION_DATA_UPDATED -> refreshBubbleIndicator()
            ACTION_REFRESH_BUBBLE_CONFIG -> {
                hideQuickMenu()
                if (prefs().getBoolean("overlayEnabled", false) &&
                    (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) &&
                    !prefs().getBoolean("bubbleHideGamesEnabled", false) && !prefs().getBoolean("bubbleHideFullscreenEnabled", false)) {
                    setBubbleHiddenByFullscreen(false)
                    if (bubble == null) showBubble()
                }
                updateLivePrayerCountdown()
            }
            ACTION_RESTORE_AFTER_BOOT -> {
                if (prefs().getBoolean("overlayEnabled", false) &&
                    (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))) {
                    if (bubble == null) showBubble()
                    handler.postDelayed({
                        if (bubble == null && prefs().getBoolean("overlayEnabled", false)) showBubble()
                        val result = if (bubble != null) "bubble_shown" else "bubble_not_visible"
                        prefs().edit().putString("lastBootRestoreStatus", result)
                            .putLong("lastBootRestoreVerifiedAt", System.currentTimeMillis()).apply()
                    }, 1400L)
                } else {
                    prefs().edit().putString("lastBootRestoreStatus", "blocked_or_disabled").apply()
                    stopSelf()
                }
            }
            ACTION_SPEAK_TEST -> speak("مرحبًا بك في الإصلاح. هذا اختبار لصوت المساعد العربي.")
            ACTION_SPEAK_TEXT -> speak(intent.getStringExtra(EXTRA_SPEAK_TEXT) ?: "")
            ACTION_ADHAN_STARTED -> applyAdhanBubbleState(true)
            ACTION_ADHAN_STOPPED -> applyAdhanBubbleState(false)
            ACTION_SHOW_REMINDER -> {
                val temporaryTest = intent.getBooleanExtra(EXTRA_TEMPORARY_TEST, false)
                val title = intent.getStringExtra(EXTRA_REMINDER_TITLE) ?: "تذكير الصلاة"
                val body = intent.getStringExtra(EXTRA_REMINDER_TEXT) ?: ""
                if (body.isNotBlank() && ensureBubbleForTimedEvent(temporaryTest)) {
                    showPrayerReminder(title, body, true)
                    if (temporaryTest && !prefs().getBoolean("overlayEnabled", false)) handler.postDelayed({ if (!prefs().getBoolean("overlayEnabled", false)) hideBubble() }, 15000L)
                }
            }
            ACTION_SHOW_FOR_EVENT -> {
                val temporaryTest = intent.getBooleanExtra(EXTRA_TEMPORARY_TEST, false)
                handler.removeCallbacks(reshowBubble)
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))
                    showFollowupOverlay(intent.getStringExtra(EXTRA_FOLLOWUP_TEXT).orEmpty())
                if (temporaryTest && !prefs().getBoolean("overlayEnabled", false)) handler.postDelayed({ if (!prefs().getBoolean("overlayEnabled", false)) { closeAllMiniWindows(); hideBubble() } }, 15000L)
            }
            ACTION_MOVE_BUBBLE_LEFT -> moveBubbleToLeftEdge()
            else -> if (prefs().getBoolean("overlayEnabled", false) && bubble == null &&
                (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))) showBubble()
        }
        return START_STICKY
    }

    private fun applyAdhanBubbleState(active: Boolean) {
        adhanPlaying = active
        prefs().edit().putBoolean("adhanPlaying", active).apply()
        if (active) {
            handler.removeCallbacks(fadeBubbleWhenIdle)
            bubble?.alpha = 1f
            // ACTION_ANSWERED can hide the main bubble without stopping this service.
            ensureBubbleForTimedEvent()
            bubble?.invalidate()
            showAdhanMuteBubble()
        } else {
            bubble?.invalidate()
            hideAdhanMuteBubble()
            scheduleIdleBubbleFade()
        }
    }

    /** Restore the anchor after an earlier ACTION_ANSWERED hid it; timed overlays depend on it. */
    private fun ensureBubbleForTimedEvent(allowWhenDisabled: Boolean = false): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) return false
        val enabled = getSharedPreferences("alislah_native", MODE_PRIVATE).getBoolean("overlayEnabled", false)
        if (!enabled && !allowWhenDisabled) return false
        if (bubble == null) showBubble()
        return bubble != null
    }

    private fun hideBubble() {
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        params = null
        hideCloseButton()
        bubbleHint?.dismiss(); bubbleHint = null
        hideQuickMenu()
        hideReminderViews()
        hideAdhanMuteBubble()
        hideAssistantStopBubble()
        closeAllMiniWindows()
    }

    private fun hideQuickMenu() {
        quickMenu?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        quickMenu = null
        quickMenuParams = null
    }

    private fun miniWindowTitle(command: String): String = when (command) {
        "plan" -> "المهام والخطة"
        "behavior" -> "تحليل العادات"
        "settings" -> "الإعدادات"
        "family" -> "الأسرة"
        "prayer" -> "الصلاة والأذان"
        "habits" -> "العادات"
        "voice" -> "صوت المساعد"
        "eye" -> "راحة العين"
        "question" -> "سؤال متابعة"
        "content" -> "زادك اليوم"
        "miniDashboard" -> "لوحة يومي المصغرة"
        "testcenter" -> "اختبار الميزات"
        else -> "المساعد الذكي"
    }

    /** A compact independent preview window for each side bubble; it can be expanded,
     * moved, pinned, reordered, previewed, or opened as a full interactive section. */
    private fun openMiniWindow(command: String) {
        if (bubble == null) showBubble()
        if (bubble == null) { launchMainApp(); return }
        val key = command.take(32)
        miniWindows[key]?.let { existing ->
            existing.root.visibility = View.VISIBLE
            bringMiniWindowToFront(key)
            return
        }
        if (miniWindows.size >= 6) {
            android.widget.Toast.makeText(this, "يمكن فتح ست نوافذ عائمة في الوقت نفسه. أغلقي نافذة أولًا.", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        val d = resources.displayMetrics.density
        val width = (270*d).toInt().coerceAtMost((resources.displayMetrics.widthPixels-16*d).toInt())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((10*d).toInt(), (8*d).toInt(), (10*d).toInt(), (9*d).toInt())
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = 16*d
                setStroke((1.2f*d).toInt().coerceAtLeast(1), Color.rgb(190,219,207))
            }
            elevation = 28*d
            setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                    val window = miniWindows[key]
                    if (window != null && !window.pinned) closeMiniWindow(key)
                    true
                } else false
            }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.rgb(23,107,91))
            setPadding((6*d).toInt(), (3*d).toInt(), (4*d).toInt(), (3*d).toInt())
        }
        val title = TextView(this).apply {
            text = "ALISLAH · ${miniWindowTitle(command)}"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, (38*d).toInt(), 1f)
        }
        val body = TextView(this).apply {
            text = miniWindowSummary(command)
            textSize = 13f
            setTextColor(Color.rgb(38,55,48))
            setPadding((5*d).toInt(), (10*d).toInt(), (5*d).toInt(), (8*d).toInt())
            maxLines = 3
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        fun miniButton(label: String, color: Int, action: () -> Unit): TextView = TextView(this).apply {
            text = label
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding((7*d).toInt(), (7*d).toInt(), (7*d).toInt(), (7*d).toInt())
            background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = 9*d; setColor(color) }
            setOnClickListener { action() }
        }
        lateinit var lp: WindowManager.LayoutParams
        val expand = miniButton("توسيع", Color.rgb(76,107,95)) {
            val item = miniWindows[key] ?: return@miniButton
            item.expanded = !item.expanded
            item.body.maxLines = if (item.expanded) 12 else 3
            item.body.text = miniWindowSummary(command)
            lp.height = if (item.expanded) (250*d).toInt() else (190*d).toInt()
            (header.getChildAt(1) as? TextView)?.text = expandLabelPlaceholder(item.expanded)
            try { windowManager.updateViewLayout(root, lp) } catch (_: Exception) { }
            persistMiniWindowState()
        }
        val moveFront = miniButton("↑", Color.rgb(78,94,105)) { bringMiniWindowToFront(key) }
        val moveBack = miniButton("↓", Color.rgb(78,94,105)) { sendMiniWindowToBack(key) }
        val open = miniButton("فتح كامل", Color.rgb(23,107,91)) {
            showAssistantOverlay(command)
        }
        val refresh = miniButton("تحديث", Color.rgb(76,107,95)) {
            miniWindows[key]?.body?.text = miniWindowSummary(command)
        }
        val resize = miniButton("↘", Color.rgb(78,94,105)) { }
        footer.addView(refresh, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = (4*d).toInt() })
        footer.addView(open, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = (4*d).toInt(); marginEnd = (4*d).toInt() })
        footer.addView(resize, LinearLayout.LayoutParams((40*d).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT))
        val pin = miniButton("📍", Color.rgb(67,91,105)) {
            val item = miniWindows[key] ?: return@miniButton
            item.pinned = !item.pinned
            (header.getChildAt(4) as? TextView)?.text = if (item.pinned) "📌" else "📍"
            (header.getChildAt(4) as? TextView)?.contentDescription = if (item.pinned) "إلغاء تثبيت النافذة" else "تثبيت النافذة"
            persistMiniWindowState()
        }
        val close = miniButton("×", Color.rgb(168,54,49)) { closeMiniWindow(key) }
        header.addView(title)
        header.addView(expand, LinearLayout.LayoutParams((49*d).toInt(), (38*d).toInt()))
        header.addView(moveFront, LinearLayout.LayoutParams((28*d).toInt(), (38*d).toInt()))
        header.addView(moveBack, LinearLayout.LayoutParams((28*d).toInt(), (38*d).toInt()))
        header.addView(pin, LinearLayout.LayoutParams((38*d).toInt(), (38*d).toInt()))
        header.addView(close, LinearLayout.LayoutParams((34*d).toInt(), (38*d).toInt()))
        root.addView(header)
        root.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(footer)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val index = miniWindows.size
        val savedWidth = prefs().getInt("miniWindow_${key}_w", width).coerceIn((210*d).toInt(), (screenW-16*d).toInt().coerceAtLeast((210*d).toInt()))
        val savedHeight = prefs().getInt("miniWindow_${key}_h", (190*d).toInt()).coerceIn((145*d).toInt(), (screenH-50*d).toInt().coerceAtLeast((145*d).toInt()))
        lp = WindowManager.LayoutParams(savedWidth, savedHeight, type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            val savedX = prefs().getInt("miniWindow_${key}_x", -1)
            val savedY = prefs().getInt("miniWindow_${key}_y", -1)
            x = if (savedX >= 0) savedX.coerceIn(0,(screenW-savedWidth).coerceAtLeast(0)) else (screenW-savedWidth-(12*d).toInt()).coerceAtLeast(0)
            y = if (savedY >= 0) savedY.coerceIn(0,(screenH-(170*d).toInt()).coerceAtLeast(0)) else ((90*d).toInt()+(index*(24*d).toInt())).coerceAtMost((screenH-(170*d).toInt()).coerceAtLeast(0))
        }
        val savedExpanded = prefs().getBoolean("miniWindow_${key}_expanded", false)
        val savedPinned = prefs().getBoolean("miniWindow_${key}_pinned", false)
        body.maxLines = if (savedExpanded) 12 else 3
        val window = MiniOverlayWindow(key, command, root, lp, body, savedExpanded, savedPinned)
        expand.text = expandLabelPlaceholder(savedExpanded)
        pin.text = if (savedPinned) "📌" else "📍"
        try {
            windowManager.addView(root, lp)
            miniWindows[key] = window
            resize.setOnTouchListener(object : View.OnTouchListener {
                var downX = 0f; var downY = 0f; var startW = 0; var startH = 0
                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> { downX=event.rawX; downY=event.rawY; startW=lp.width; startH=if(lp.height>0)lp.height else root.height; return true }
                        MotionEvent.ACTION_MOVE -> {
                            lp.width=(startW+event.rawX-downX).toInt().coerceIn((210*d).toInt(),(resources.displayMetrics.widthPixels-16*d).toInt().coerceAtLeast((210*d).toInt()))
                            lp.height=(startH+event.rawY-downY).toInt().coerceIn((145*d).toInt(),(resources.displayMetrics.heightPixels-50*d).toInt().coerceAtLeast((145*d).toInt()))
                            try { windowManager.updateViewLayout(root,lp) } catch (_: Exception) { }
                            return true
                        }
                        MotionEvent.ACTION_UP -> {
                            prefs().edit().putInt("miniWindow_${key}_w",lp.width).putInt("miniWindow_${key}_h",lp.height).apply()
                            persistMiniWindowState(); return true
                        }
                        MotionEvent.ACTION_CANCEL -> return true
                    }
                    return false
                }
            })
            title.setOnTouchListener(object : View.OnTouchListener {
                var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> { downX=event.rawX; downY=event.rawY; startX=lp.x; startY=lp.y; return true }
                        MotionEvent.ACTION_MOVE -> {
                            lp.x=(startX+event.rawX-downX).toInt().coerceIn(0,(resources.displayMetrics.widthPixels-lp.width).coerceAtLeast(0))
                            lp.y=(startY+event.rawY-downY).toInt().coerceIn(0,(resources.displayMetrics.heightPixels-(100*d).toInt()).coerceAtLeast(0))
                            try { windowManager.updateViewLayout(root,lp) } catch (_: Exception) { }
                            return true
                        }
                        MotionEvent.ACTION_UP -> { prefs().edit().putInt("miniWindow_${key}_x",lp.x).putInt("miniWindow_${key}_y",lp.y).apply(); persistMiniWindowState(); return true }
                        MotionEvent.ACTION_CANCEL -> return true
                    }
                    return false
                }
            })
            persistMiniWindowState()
        } catch (_: Exception) {
            miniWindows.remove(key)
            persistMiniWindowState()
            launchMainApp()
        }
    }

    private fun persistMiniWindowState() {
        val state = org.json.JSONArray()
        miniWindows.values.forEach { item ->
            state.put(org.json.JSONObject()
                .put("command", item.command)
                .put("expanded", item.expanded)
                .put("pinned", item.pinned)
                .put("x", item.params.x)
                .put("y", item.params.y)
                .put("width", item.params.width)
                .put("height", item.params.height))
            prefs().edit()
                .putBoolean("miniWindow_${item.id}_expanded", item.expanded)
                .putBoolean("miniWindow_${item.id}_pinned", item.pinned)
                .putInt("miniWindow_${item.id}_w", item.params.width)
                .putInt("miniWindow_${item.id}_h", item.params.height)
                .putInt("miniWindow_${item.id}_x", item.params.x)
                .putInt("miniWindow_${item.id}_y", item.params.y).apply()
        }
        prefs().edit().putString("miniWindowsOpen", state.toString()).apply()
    }

    private fun restoreMiniWindows() {
        if (miniWindowsRestored || !prefs().getBoolean("overlayEnabled", false)) return
        miniWindowsRestored = true
        val saved = try { org.json.JSONArray(prefs().getString("miniWindowsOpen", "[]") ?: "[]") } catch (_: Exception) { org.json.JSONArray() }
        for (i in 0 until minOf(saved.length(), 6)) {
            val command = saved.optJSONObject(i)?.optString("command", "")?.take(32).orEmpty()
            if (command.isNotBlank()) openMiniWindow(command)
        }
    }

    private fun expandLabelPlaceholder(expanded: Boolean): String = if (expanded) "طي" else "توسيع"

    private fun miniWindowSummary(command: String): String {
        val data = try { org.json.JSONObject(prefs().getString("alislah_app_data", "{}") ?: "{}") } catch (_: Exception) { org.json.JSONObject() }
        val tasks = data.optJSONArray("tasks") ?: org.json.JSONArray()
        val habits = data.optJSONArray("habits") ?: org.json.JSONArray()
        val family = data.optJSONObject("family") ?: org.json.JSONObject()
        val events = family.optJSONArray("events") ?: org.json.JSONArray()
        val openTasks = (0 until tasks.length()).mapNotNull { tasks.optJSONObject(it) }.filter { !it.optBoolean("done", false) }
        return when (command) {
            "plan" -> "المهام غير المنجزة: ${openTasks.size}\n" + openTasks.take(3).joinToString("\n") { "• ${it.optString("text", "مهمة")}" }.ifBlank { "لا توجد مهام معلّقة." }
            "habits" -> "لديك ${habits.length()} عادات محفوظة. افتحي الصفحة لتسجيل إنجاز عادات اليوم ومراجعة السجل."
            "family" -> "المواعيد الأسرية المحفوظة: ${events.length()}. افتحي الصفحة لإدارة أفراد الأسرة والروتين والمواعيد."
            "prayer" -> "إعدادات الصلاة ومواقيت المدينة والأذان والتذكيرات محفوظة داخل صفحة الصلاة."
            "behavior" -> "تحليل العادات والاستخدام محلي أولًا؛ لا تُرسل بياناتك إلى الذكاء الاصطناعي إلا وفق موافقتك."
            "settings" -> "إدارة الخصوصية والصوت والأذونات والنسخ الاحتياطي وإعدادات الفقاعة."
            "voice" -> "يمكنك بدء الاستماع من زر الميكروفون في النافذة الكاملة، وإيقاف الصوت بزر الإيقاف المستقل."
            "eye" -> "إدارة استراحة العين وفلتر الألوان من صفحة الإعدادات."
            "question" -> "سؤال متابعة: ما أكثر شيء يشغل وقتك الآن؟"
            "content" -> "زادك اليوم: آية وحديث وفائدة عملية محفوظة داخل التطبيق وتعمل دون إنترنت. افتحي النافذة الكاملة لقراءتها أو الاستماع إليها."
            "miniDashboard" -> "المهام غير المنجزة: ${openTasks.size}\nالعادات: ${habits.length()}\nالمواعيد الأسرية: ${events.length()}\nافتحي لوحة يومي للاطلاع على الأولويات والخط الزمني."
            "testcenter" -> "مركز اختبار حقيقي لميزات ALISLAH: 14 تصنيفًا، اختبارات ربط آلية، وتأكيد يدوي من الهاتف. افتحي النافذة الكاملة لعرض النتائج والتقرير."
            else -> "المساعد الذكي جاهز. افتحي النافذة الكاملة للكتابة أو التحدث."
        }
    }

    private fun bringMiniWindowToFront(key: String) {
        val item = miniWindows[key] ?: return
        try {
            windowManager.removeView(item.root)
            windowManager.addView(item.root, item.params)
            // Keep the LinkedHashMap order identical to the visible front-to-back order.
            miniWindows.remove(key)
            miniWindows[key] = item
            // The anchor remains the topmost touch target, independent of window order.
            bubble?.let { main -> params?.let { mainLp -> windowManager.removeView(main); windowManager.addView(main, mainLp) } }
            persistMiniWindowState()
        } catch (_: Exception) { }
    }

    private fun sendMiniWindowToBack(key: String) {
        val item = miniWindows[key] ?: return
        val ordered = miniWindows.values.toList()
        try {
            ordered.forEach { try { windowManager.removeView(it.root) } catch (_: Exception) { } }
            val sequence = listOf(item) + ordered.filter { it.id != key }
            sequence.forEach { windowManager.addView(it.root, it.params) }
            miniWindows.clear()
            sequence.forEach { miniWindows[it.id] = it }
            bubble?.let { main -> params?.let { mainLp -> windowManager.removeView(main); windowManager.addView(main, mainLp) } }
            persistMiniWindowState()
        } catch (_: Exception) { }
    }

    private fun closeMiniWindow(key: String) {
        val item = miniWindows.remove(key) ?: return
        try { windowManager.removeView(item.root) } catch (_: Exception) { }
        persistMiniWindowState()
    }

    private fun closeAllMiniWindows(clearSaved: Boolean = true) {
        miniWindows.values.toList().forEach { item -> try { windowManager.removeView(item.root) } catch (_: Exception) { } }
        miniWindows.clear()
        if (clearSaved) prefs().edit().putString("miniWindowsOpen", "[]").apply()
    }

    /** A separate, temporary mute bubble appears beside the main bubble only while adhan is playing. */
    private fun showAdhanMuteBubble() {
        if (!adhanPlaying || bubble == null) return
        val existing = adhanMuteBubble
        if (existing != null) { syncAdhanMuteBubble(); existing.visibility = View.VISIBLE; syncAssistantStopBubble(); return }
        val d = resources.displayMetrics.density
        val size = (42*d).toInt()
        val view = TextView(this).apply {
            text = "🔇"
            textSize = 19f
            gravity = Gravity.CENTER
            contentDescription = "إيقاف الأذان"
            setTextColor(Color.WHITE)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(176,48,43))
                setStroke((2*d).toInt().coerceAtLeast(1), Color.WHITE)
            }
            elevation = 24*d
            setOnClickListener { stopAdhanFromBubble() }
        }
        val lp = overlayWindowParams(size, size)
        try {
            windowManager.addView(view, lp)
            adhanMuteBubble = view
            adhanMuteParams = lp
            syncAdhanMuteBubble()
            syncAssistantStopBubble()
        } catch (_: Exception) {
            adhanMuteBubble = null
            adhanMuteParams = null
        }
    }

    private fun syncAdhanMuteBubble() {
        val view = adhanMuteBubble ?: return
        val lp = adhanMuteParams ?: return
        val main = bubble ?: return
        val d = resources.displayMetrics.density
        val (screenW, screenH) = realScreenSize()
        val location = IntArray(2)
        main.getLocationOnScreen(location)
        val centerX = location[0] + main.width/2
        val centerY = location[1] + main.height/2
        val edge = (main as? MainBubbleView)?.capsuleEdge ?: "circle"
        val gap = (6*d).toInt()
        val bottomDocked = edge == "bottom" || (edge == "circle" && centerY > screenH * 0.82f)
        val x = when (edge) {
            "top", "bottom" -> centerX - lp.width/2
            "left" -> location[0] + main.width + gap
            "right" -> location[0] - lp.width - gap
            else -> if ((params?.x ?: 0) < 0) location[0] + main.width + gap else location[0] - lp.width - gap
        }
        val y = when {
            edge == "top" -> location[1] + main.height + gap
            bottomDocked -> location[1] - lp.height - gap
            else -> centerY - lp.height/2
        }
        lp.x = x.coerceIn(0, (screenW-lp.width).coerceAtLeast(0))
        lp.y = y.coerceIn(0, (screenH-lp.height).coerceAtLeast(0))
        try { windowManager.updateViewLayout(view, lp) } catch (_: Exception) { }
    }

    private fun hideAdhanMuteBubble() {
        adhanMuteBubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        adhanMuteBubble = null
        adhanMuteParams = null
        syncAssistantStopBubble()
    }

    /** Independent stop control for assistant speech; it never controls the adhan player. */
    private fun showAssistantStopBubble() {
        if (!assistantSpeaking || reminderSpeechActive || bubble == null) return
        if (assistantStopBubble != null) { syncAssistantStopBubble(); assistantStopBubble?.visibility = View.VISIBLE; return }
        val d = resources.displayMetrics.density
        val size = (42*d).toInt()
        val view = TextView(this).apply {
            text = "■"
            textSize = 17f
            gravity = Gravity.CENTER
            contentDescription = "إيقاف صوت المساعد"
            setTextColor(Color.WHITE)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(23, 107, 91))
                setStroke((2*d).toInt().coerceAtLeast(1), Color.WHITE)
            }
            elevation = 25*d
            setOnClickListener { stopAssistantSpeech() }
        }
        val lp = overlayWindowParams(size, size)
        try {
            windowManager.addView(view, lp)
            assistantStopBubble = view
            assistantStopParams = lp
            syncAssistantStopBubble()
        } catch (_: Exception) { assistantStopBubble = null; assistantStopParams = null }
    }

    private fun syncAssistantStopBubble() {
        val view = assistantStopBubble ?: return
        val lp = assistantStopParams ?: return
        val main = bubble ?: return
        val d = resources.displayMetrics.density
        val (screenW, screenH) = realScreenSize()
        val loc = IntArray(2); main.getLocationOnScreen(loc)
        val centerX = loc[0] + main.width/2
        val centerY = loc[1] + main.height/2
        val gap = (7*d).toInt()
        val bothControls = adhanMuteBubble?.visibility == View.VISIBLE
        if (bothControls) {
            val muteLp = adhanMuteParams
            if (muteLp != null) {
                lp.x = muteLp.x.coerceIn(0, (screenW-lp.width).coerceAtLeast(0))
                val below = muteLp.y + muteLp.height + gap
                lp.y = if (below + lp.height <= screenH) below else (muteLp.y - lp.height - gap).coerceAtLeast(0)
            } else {
                lp.x = (centerX - lp.width/2).coerceIn(0, (screenW-lp.width).coerceAtLeast(0))
                lp.y = (centerY - lp.height/2).coerceIn(0, (screenH-lp.height).coerceAtLeast(0))
            }
        } else {
            val left = if (centerX > screenW/2) loc[0] - lp.width - gap else loc[0] + main.width + gap
            lp.x = left.coerceIn(0, (screenW-lp.width).coerceAtLeast(0))
            lp.y = (centerY - lp.height/2).coerceIn(0, (screenH-lp.height).coerceAtLeast(0))
        }
        try { windowManager.updateViewLayout(view, lp) } catch (_: Exception) { }
    }

    private fun hideAssistantStopBubble() {
        assistantStopBubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        assistantStopBubble = null
        assistantStopParams = null
    }

    private fun overlayWindowParams(width: Int, height: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(
            width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.LEFT }
    }

    private fun showPrayerReminder(title: String, body: String, readAloud: Boolean) {
        if (body.isBlank()) return
        currentReminderTitle = title.take(100)
        currentReminderText = body.take(700)
        reminderCardVisible = true
        handler.removeCallbacks(fadeBubbleWhenIdle)
        bubble?.alpha = 1f
        ensureReminderViews()
        reminderCardView?.visibility = View.VISIBLE
        reminderArrowView?.visibility = View.VISIBLE
        reminderArrowView?.text = "⌃"
        syncReminderOverlay(params)
        if (readAloud) {
            reminderSpeechActive = true
            reminderStopView?.visibility = View.VISIBLE
            speak("${currentReminderTitle}. ${currentReminderText}")
        }
    }

    private fun ensureReminderViews() {
        val d = resources.displayMetrics.density
        if (reminderCardView == null) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding((14*d).toInt(), (10*d).toInt(), (14*d).toInt(), (11*d).toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.WHITE)
                    cornerRadius = 18*d
                    setStroke((1.2f*d).toInt().coerceAtLeast(1), Color.rgb(190, 219, 207))
                }
                elevation = 22*d
                isClickable = true
            }
            val titleView = TextView(this).apply {
                textSize = 13f
                setTextColor(Color.rgb(23, 107, 91))
                typeface = Typeface.DEFAULT_BOLD
                text = currentReminderTitle
                maxLines = 1
            }
            val bodyView = TextView(this).apply {
                textSize = 14f
                setTextColor(Color.rgb(35, 53, 47))
                text = currentReminderText
                maxLines = 6
                ellipsize = android.text.TextUtils.TruncateAt.END
                setLineSpacing((2*d), 1f)
                setPadding(0, (5*d).toInt(), 0, 0)
            }
            card.addView(titleView)
            card.addView(bodyView)
            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                visibility = View.GONE
                setPadding(0, (8*d).toInt(), 0, 0)
            }
            fun responseButton(label: String, done: Boolean, color: Int) = TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = 10*d
                    setColor(color)
                }
                setPadding((10*d).toInt(), (8*d).toInt(), (10*d).toInt(), (8*d).toInt())
                isClickable = true
                isFocusable = true
                setOnClickListener { recordPrayerResponseFromReminder(done) }
            }
            val yes = responseButton("نعم، صليت", true, Color.rgb(23, 125, 86))
            val no = responseButton("ليس بعد", false, Color.rgb(170, 92, 38))
            val answer = TextView(this).apply {
                text = "أجب الآن"
                textSize = 12f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE); setPadding((12*d).toInt(), (8*d).toInt(), (12*d).toInt(), (8*d).toInt())
                background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = 10*d; setColor(Color.rgb(23,107,91)) }
                setOnClickListener { stopReminderSpeech(); reminderCardVisible = false; hideReminderViews(); showAssistantOverlay("followup") }
            }
            actions.addView(yes, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = (5*d).toInt() })
            actions.addView(no, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = (5*d).toInt() })
            actions.addView(answer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            card.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            reminderActionBar = actions
            card.tag = Pair(titleView, bodyView)
            card.setOnTouchListener(object : View.OnTouchListener {
                var downX = 0f
                var downY = 0f
                var swiped = false
                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; swiped = false; return true }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = event.rawX - downX
                            val dy = event.rawY - downY
                            if (kotlin.math.abs(dx) > 18*d || kotlin.math.abs(dy) > 18*d) swiped = true
                            return true
                        }
                        MotionEvent.ACTION_UP -> {
                            val dx = event.rawX - downX
                            val dy = event.rawY - downY
                            if (swiped && (kotlin.math.abs(dx) > 48*d || kotlin.math.abs(dy) > 48*d)) {
                                hideReminderCardOnly()
                                return true
                            }
                            return false
                        }
                        MotionEvent.ACTION_CANCEL -> { swiped = false; return true }
                    }
                    return false
                }
            })
            reminderCardView = card
            reminderCardParams = overlayWindowParams((resources.displayMetrics.widthPixels - (24*d).toInt()).coerceAtMost((320*d).toInt()), WindowManager.LayoutParams.WRAP_CONTENT)
            try {
                windowManager.addView(card, reminderCardParams)
                card.post { syncReminderOverlay(params) }
            } catch (_: Exception) { reminderCardView = null; reminderCardParams = null; reminderActionBar = null }
        }
        val tag = reminderCardView?.tag as? Pair<*, *>
        (tag?.first as? TextView)?.text = currentReminderTitle
        (tag?.second as? TextView)?.text = currentReminderText
        reminderActionBar?.visibility = if (currentReminderTitle.contains("بعد صلاة") || currentReminderTitle.contains("سؤال متابعة")) View.VISIBLE else View.GONE
        reminderActionBar?.let { bar ->
            val isQuestion = currentReminderTitle.contains("سؤال متابعة")
            for (i in 0 until bar.childCount) {
                val child = bar.getChildAt(i)
                child.visibility = if (isQuestion) (if (i == 2) View.VISIBLE else View.GONE) else (if (i < 2) View.VISIBLE else View.GONE)
            }
        }

        if (reminderArrowView == null) {
            val arrow = TextView(this).apply {
                text = if (reminderCardVisible) "⌃" else "⌄"
                textSize = 22f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                contentDescription = "فتح أو إخفاء تذكير الصلاة"
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    setCornerRadii(floatArrayOf(0f,0f,0f,0f,10*d,10*d,10*d,10*d))
                    setColor(Color.rgb(23,107,91))
                }
                elevation = 22*d
                setOnClickListener {
                    reminderCardVisible = !reminderCardVisible
                    reminderCardView?.visibility = if (reminderCardVisible) View.VISIBLE else View.GONE
                    text = if (reminderCardVisible) "⌃" else "⌄"
                    syncReminderOverlay(params)
                }
            }
            reminderArrowView = arrow
            reminderArrowParams = overlayWindowParams((42*d).toInt(), (30*d).toInt())
            try { windowManager.addView(arrow, reminderArrowParams) } catch (_: Exception) { reminderArrowView = null; reminderArrowParams = null }
        }

        if (reminderStopView == null) {
            val stop = TextView(this).apply {
                text = "■"
                textSize = 16f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                contentDescription = "إيقاف قراءة التذكير"
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(Color.rgb(176, 48, 43))
                    setStroke((1.5f*d).toInt().coerceAtLeast(1), Color.WHITE)
                }
                elevation = 24*d
                setOnClickListener { stopReminderSpeech() }
            }
            reminderStopView = stop
            reminderStopParams = overlayWindowParams((36*d).toInt(), (36*d).toInt())
            try { windowManager.addView(stop, reminderStopParams) } catch (_: Exception) { reminderStopView = null; reminderStopParams = null }
        }
        reminderCardView?.visibility = if (reminderCardVisible) View.VISIBLE else View.GONE
        reminderArrowView?.visibility = View.VISIBLE
        reminderStopView?.visibility = if (reminderSpeechActive) View.VISIBLE else View.GONE
    }

    private fun hideReminderCardOnly() {
        reminderCardVisible = false
        reminderCardView?.visibility = View.GONE
        // A swipe dismisses the whole floating reminder control, but never its library entry.
        reminderArrowView?.visibility = View.GONE
        scheduleIdleBubbleFade()
    }

    private fun setAssistantSpeaking(active: Boolean) {
        assistantSpeaking = active
        if (active) { handler.removeCallbacks(fadeBubbleWhenIdle); bubble?.alpha = 1f }
        bubble?.let { (it as? MainBubbleView)?.setSpeaking(active) }
        if (active && !reminderSpeechActive) showAssistantStopBubble() else hideAssistantStopBubble()
        if (!active) scheduleIdleBubbleFade()
    }

    private fun stopAssistantSpeech() {
        autoListenAfterSpeech = false
        pendingFallbackText = ""
        fallbackAttempted = true
        reminderSpeechActive = false
        try { assistantWebView?.evaluateJavascript("window.AlishlahNeuralVoice&&window.AlishlahNeuralVoice.stop()", null) } catch (_: Exception) { }
        try { tts?.stop() } catch (_: Exception) { }
        try { OptionalVoicePackBridge.stop(this) } catch (_: Exception) { }
        setAssistantSpeaking(false)
        reminderStopView?.visibility = View.GONE
    }

    private fun stopReminderSpeech() {
        pendingFallbackText = ""
        fallbackAttempted = true
        reminderSpeechActive = false
        try { assistantWebView?.evaluateJavascript("window.AlishlahNeuralVoice&&window.AlishlahNeuralVoice.stop()", null) } catch (_: Exception) { }
        try { tts?.stop() } catch (_: Exception) { }
        setAssistantSpeaking(false)
        reminderStopView?.visibility = View.GONE
    }

    /** The reminder's yes/no actions are real prayer-log responses, not decorative buttons. */
    private fun recordPrayerResponseFromReminder(done: Boolean) {
        val name = currentReminderTitle.substringAfter("بعد صلاة", "").trim()
            .substringBefore(" ").take(20).ifBlank { "الصلاة" }
        val response = Intent(this, PrayerResponseReceiver::class.java).apply {
            action = PrayerResponseReceiver.ACTION_RESPONSE
            putExtra(PrayerResponseReceiver.EXTRA_NAME, name)
            putExtra(PrayerResponseReceiver.EXTRA_DONE, done)
        }
        try { sendBroadcast(response) } catch (_: Exception) { }
        stopReminderSpeech()
        reminderCardVisible = false
        hideReminderViews()
    }

    private fun hideReminderViews() {
        reminderCardView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        reminderArrowView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        reminderStopView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        reminderCardView = null; reminderCardParams = null
        reminderArrowView = null; reminderArrowParams = null
        reminderStopView = null; reminderStopParams = null
        reminderActionBar = null
    }

    /** Keep reminder controls attached to the actual rendered centre of the main orbital anchor. */
    private fun syncReminderOverlay(anchor: WindowManager.LayoutParams?) {
        val wm = try { windowManager } catch (_: Exception) { return }
        val main = bubble
        val a = anchor ?: params ?: return
        val d = resources.displayMetrics.density
        val (screenW, screenH) = realScreenSize()
        val location = IntArray(2)
        if (main != null && main.width > 0 && main.height > 0) main.getLocationOnScreen(location) else { location[0] = a.x; location[1] = a.y }
        val left = location[0]
        val top = location[1]
        val width = main?.width?.takeIf { it > 0 } ?: a.width
        val height = main?.height?.takeIf { it > 0 } ?: a.height
        val centerX = left + width/2
        val docked = (main as? MainBubbleView)?.dockedAtCamera == true
        val onLeft = centerX < screenW/2
        val arrowLp = reminderArrowParams
        val arrow = reminderArrowView
        if (arrowLp != null && arrow != null) {
            val arrowW = arrowLp.width
            val arrowH = arrowLp.height
            arrowLp.x = if (docked) centerX - arrowW/2 else if (onLeft) left + width - arrowW/2 else left - arrowW/2
            arrowLp.x = arrowLp.x.coerceIn(0, (screenW-arrowW).coerceAtLeast(0))
            arrowLp.y = (top + height - (2*d).toInt()).coerceIn(0, (screenH-arrowH).coerceAtLeast(0))
            try { wm.updateViewLayout(arrow, arrowLp) } catch (_: Exception) { }
        }
        val cardLp = reminderCardParams
        val card = reminderCardView
        if (cardLp != null && card != null) {
            val cardW = cardLp.width
            val measuredH = card.height.takeIf { it > 0 } ?: (150*d).toInt()
            cardLp.x = if (docked) centerX - cardW/2 else if (onLeft) (16*d).toInt() else screenW-cardW-(16*d).toInt()
            cardLp.x = cardLp.x.coerceIn(0, (screenW-cardW).coerceAtLeast(0))
            val below = top + height + (34*d).toInt()
            val above = top - measuredH - (12*d).toInt()
            cardLp.y = if (below + measuredH <= screenH - (8*d).toInt()) below else above.coerceAtLeast((8*d).toInt())
            try { wm.updateViewLayout(card, cardLp) } catch (_: Exception) { }
        }
        val stopLp = reminderStopParams
        val stop = reminderStopView
        if (stopLp != null && stop != null) {
            stopLp.x = (centerX - stopLp.width/2).coerceIn(0, (screenW-stopLp.width).coerceAtLeast(0))
            stopLp.y = if (docked) (top + (2*d).toInt()) else (top - stopLp.height + (3*d).toInt()).coerceAtLeast(0)
            try { wm.updateViewLayout(stop, stopLp) } catch (_: Exception) { }
        }
    }

    /** Read the rendered bubble position so the orbit follows its real on-screen centre, not stale window coordinates. */
    private fun anchorScreenCenter(anchor: WindowManager.LayoutParams): Pair<Float, Float> {
        val main = bubble
        if (main != null && main.width > 0 && main.height > 0) {
            val location = IntArray(2)
            main.getLocationOnScreen(location)
            return Pair(location[0] + main.width / 2f, location[1] + main.height / 2f)
        }
        return Pair(anchor.x + anchor.width / 2f, anchor.y + anchor.height / 2f)
    }

    private fun anchorCenterX(anchor: WindowManager.LayoutParams): Float = anchorScreenCenter(anchor).first
    private fun anchorCenterY(anchor: WindowManager.LayoutParams): Float = anchorScreenCenter(anchor).second

    private fun syncQuickMenuToAnchor(anchor: WindowManager.LayoutParams) {
        val menuLp = quickMenuParams ?: return
        val menu = quickMenu ?: return
        val (screenW, screenH) = realScreenSize()
        val x = (anchorCenterX(anchor).toInt() - menuLp.width / 2).coerceIn(-(menuLp.width / 2), screenW - (menuLp.width / 2))
        val y = (anchorCenterY(anchor).toInt() - menuLp.height / 2).coerceIn(-(menuLp.height / 2), screenH - (menuLp.height / 2))
        if (menuLp.x != x || menuLp.y != y) {
            menuLp.x = x; menuLp.y = y
            try { windowManager.updateViewLayout(menu, menuLp) } catch (_: Exception) { }
        }
    }

    private fun hasUsageStatsPermission(): Boolean {
        return try {
            val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) { false }
    }

    private fun setBubbleHiddenByFullscreen(hidden: Boolean) {
        if (bubbleHiddenByFullscreen == hidden) return
        bubbleHiddenByFullscreen = hidden
        bubble?.visibility = if (hidden) View.INVISIBLE else View.VISIBLE
        if (hidden) { hideQuickMenu(); quickAsk?.hide(); bubbleHint?.dismiss() }
        if (!hidden) bubble?.alpha = 1f
    }

    private fun quickAskRect(): Rect {
        val (screenW, screenH) = realScreenSize()
        val d = resources.displayMetrics.density
        val margin = (12 * d).toInt()
        val width = (screenW - 2 * margin).coerceAtLeast((220 * d).toInt())
        val bottomInset = navigationBarBottomInset(screenW, screenH)
        val safeHeight = (screenH - bottomInset - 2 * margin).coerceAtLeast((220 * d).toInt())
        val height = minOf((460 * d).toInt(), safeHeight)
        val centerY = params?.let { it.y + it.height / 2 } ?: screenH / 2
        val below = centerY + (90 * d).toInt()
        val maxTop = (screenH - bottomInset - height - margin).coerceAtLeast(margin)
        val top = if (below + height <= screenH - margin) below else (centerY - height - (90 * d).toInt()).coerceAtLeast(margin)
        val safeTop = top.coerceIn(margin, maxTop)
        return Rect(margin, safeTop, margin + width, safeTop + height)
    }

    private fun showQuickAsk() {
        hideQuickMenu()
        if (bubble == null) showBubble()
        if (bubble == null || bubbleHiddenByFullscreen) return
        if (quickAsk == null) {
            quickAsk = QuickAsk(
                this, windowManager,
                endpoint = { prefs().getString("assistantEndpoint", "https://alislah-ai.zitroun2222.workers.dev/") ?: "https://alislah-ai.zitroun2222.workers.dev/" },
                onOpenFull = { question ->
                    val i = Intent(this, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        putExtra("openAssistant", true)
                        putExtra("prefillText", question.take(1000))
                    }
                    try { startActivity(i) } catch (_: Exception) { }
                },
                onSpeak = { answer -> speak(answer.take(700)) },
                onVoice = { ok, fail ->
                    quickAskVoiceOk = ok; quickAskVoiceFail = fail
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        quickAskVoicePending = true
                        launchMainAppWithAction("requestOverlayAssistantMic")
                        fail("افتحي إذن الميكروفون من نافذة التطبيق، أو اكتبي سؤالك هنا.")
                    } else startQuickAskVoice()
                },
                onClosed = { stopQuickAskVoice(); quickAskVoicePending = false }
            )
        }
        quickAsk?.show(quickAskRect())
    }

    private fun startQuickAskVoice() {
        if (quickAsk?.isShowing != true) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            quickAskVoiceFail?.invoke("خدمة تحويل الكلام إلى نص غير متاحة على هذا الهاتف.")
            return
        }
        stopQuickAskVoice()
        try {
            val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            quickAskRecognizer = recognizer
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { quickAskVoiceFail?.invoke("أستمع الآن…") }
                override fun onBeginningOfSpeech() { }
                override fun onRmsChanged(rmsdB: Float) { }
                override fun onBufferReceived(buffer: ByteArray?) { }
                override fun onEndOfSpeech() { }
                override fun onError(error: Int) {
                    quickAskVoiceFail?.invoke(when (error) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "إذن الميكروفون غير متاح."
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "لم ألتقط كلامًا واضحًا. حاولي مرة أخرى."
                        else -> "تعذر تحويل الكلام إلى نص؛ يمكنك الكتابة بدلًا من ذلك."
                    })
                    stopQuickAskVoice()
                }
                override fun onResults(results: Bundle?) {
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                    if (heard.isNotBlank() && executeOfflineVoiceCommand(heard)) {
                        quickAskVoiceFail?.invoke("تم تنفيذ الأمر محليًا دون إنترنت.")
                        quickAsk?.hide()
                    } else if (heard.isNotBlank()) quickAskVoiceOk?.invoke(heard.take(1000)) else quickAskVoiceFail?.invoke("لم ألتقط كلامًا واضحًا.")
                    stopQuickAskVoice()
                }
                override fun onPartialResults(partialResults: Bundle?) { }
                override fun onEvent(eventType: Int, params: Bundle?) { }
            })
            val request = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-DZ")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-DZ")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            recognizer.startListening(request)
        } catch (_: Exception) {
            quickAskVoiceFail?.invoke("تعذر تشغيل الميكروفون. يمكنك كتابة السؤال.")
            stopQuickAskVoice()
        }
    }

    private fun stopQuickAskVoice() {
        try { quickAskRecognizer?.cancel() } catch (_: Exception) { }
        try { quickAskRecognizer?.destroy() } catch (_: Exception) { }
        quickAskRecognizer = null
    }

    private fun showQuickMenu(anchor: WindowManager.LayoutParams) {
        if (quickMenu != null) { hideQuickMenu(); return }
        val d = resources.displayMetrics.density
        val item = (52 * d).toInt()
        val radius = (prefs().getInt("bubbleOrbitRadiusDp", 116).coerceIn(100, 150) * d).toInt()
        orbitRotation = prefs().getFloat("bubbleOrbitRotation", orbitRotation.toFloat()).toDouble()
        val size = (radius * 2 + item + 12*d).toInt()
        val menu = FrameLayout(this).apply {
            elevation = 24*d
            isClickable = true
            // Empty space inside the orbit is outside the side bubbles: close the group.
            setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                    hideQuickMenu()
                    true
                } else true
            }
        }
        // A continuous orbit guide sits behind the action bubbles. The screen edge clips
        // the off-screen half naturally, instead of hiding individual bubbles in code.
        val orbitTrack = object : View(this) {
            private val baseTrack = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(105, 23, 220, 170)
                style = android.graphics.Paint.Style.STROKE
                strokeWidth = (2.4f * d).coerceAtLeast(1f)
            }
            private val glowTrack = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(165, 90, 255, 218)
                style = android.graphics.Paint.Style.STROKE
                strokeWidth = (4.2f * d).coerceAtLeast(2f)
                maskFilter = android.graphics.BlurMaskFilter(5f * d, android.graphics.BlurMaskFilter.Blur.NORMAL)
            }
            private val energyTrack = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                style = android.graphics.Paint.Style.STROKE
                strokeWidth = (3f * d).coerceAtLeast(1.5f)
                strokeCap = android.graphics.Paint.Cap.ROUND
            }
            override fun onDraw(canvas: android.graphics.Canvas) {
                super.onDraw(canvas)
                val cx = width / 2f; val cy = height / 2f
                val oval = android.graphics.RectF(cx-radius, cy-radius, cx+radius, cy+radius)
                canvas.drawCircle(cx, cy, radius.toFloat(), glowTrack)
                canvas.drawCircle(cx, cy, radius.toFloat(), baseTrack)
                val phase = (android.os.SystemClock.uptimeMillis() / 12L % 360L).toFloat()
                energyTrack.shader = android.graphics.SweepGradient(cx, cy,
                    intArrayOf(Color.TRANSPARENT, Color.rgb(40,255,210), Color.rgb(255,220,105), Color.TRANSPARENT),
                    floatArrayOf(0f, .34f, .68f, 1f))
                canvas.save()
                canvas.rotate(phase, cx, cy)
                canvas.drawArc(oval, -48f, 108f, false, energyTrack)
                canvas.rotate(176f, cx, cy)
                canvas.drawArc(oval, -34f, 72f, false, energyTrack)
                canvas.restore()
                postInvalidateDelayed(180L)
            }
        }
        menu.addView(orbitTrack, FrameLayout.LayoutParams(size, size))
        data class BubbleAction(val icon: String, val label: String, val command: String, val color: Int)
        val baseActions = listOf(
            BubbleAction("💬", "المساعد", "ask", Color.rgb(23,107,91)),
            BubbleAction("❓", "سؤال متابعة", "question", Color.rgb(65,120,155)),
            BubbleAction("🗓", "لوحة يومي المصغرة", "miniDashboard", Color.rgb(66,123,103)),
            BubbleAction("📋", "الخطة", "plan", Color.rgb(43,112,190)),
            BubbleAction("📊", "التحليل", "behavior", Color.rgb(117,76,175)),
            BubbleAction("⚙", "الإعدادات", "settings", Color.rgb(82,98,105)),
            BubbleAction("👨‍👩‍👧", "الأسرة", "family", Color.rgb(190,117,47)),
            BubbleAction("🕌", "الصلاة", "prayer", Color.rgb(16,130,100)),
            BubbleAction("📚", "زادك اليوم", "content", Color.rgb(128,91,46)),
            BubbleAction("✓", "العادات", "habits", Color.rgb(40,130,145)),
            BubbleAction("🔊", "صوت المساعد", "voice", Color.rgb(32,128,145)),
            BubbleAction("👁", "راحة العين", "eye", Color.rgb(55,125,119)),
            BubbleAction("✓", "إنجاز مهمة", "quickComplete", Color.rgb(28,145,90)),
            BubbleAction("⏰", "تأجيل مهمة", "quickPostpone", Color.rgb(173,115,35)),
            BubbleAction("🧪", "اختبار الميزات", "testcenter", Color.rgb(31,117,145)),
            BubbleAction("⊗", "إغلاق النوافذ", "closeWindows", Color.rgb(190,55,55))
        )
        val usage = try {
            val saved = org.json.JSONObject(prefs().getString("bubbleOrbitUsage", "{}") ?: "{}")
            val map = HashMap<String, Int>(); val keys = saved.keys()
            while (keys.hasNext()) { val key = keys.next(); map[key] = saved.optInt(key, 0) }
            map
        } catch (_: Exception) { emptyMap<String, Int>() }
        val nextPrayer = Snapshot.nextPrayer(this)
        val prayerSoon = nextPrayer != null && nextPrayer.second - System.currentTimeMillis() in 1L..(15L*60L*1000L)
        val order = BubbleOrbitRules.order(baseActions.map { it.command }, usage, prayerSoon)
        val actions = baseActions.sortedBy { order.indexOf(it.command).let { index -> if (index < 0) Int.MAX_VALUE else index } }
        val buttons = mutableListOf<TextView>()
        actions.forEach { a ->
            val b = TextView(this).apply {
                text = a.icon; textSize = 21f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                contentDescription = a.label
                background = android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                    intArrayOf(Color.argb(245, 8, 48, 43), a.color, Color.argb(238, 4, 28, 31))
                ).apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setGradientType(android.graphics.drawable.GradientDrawable.RADIAL_GRADIENT)
                    setGradientRadius(68f * d)
                    setStroke((2*d).toInt(), Color.argb(230, 174, 255, 229))
                }
                elevation = 12*d
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
                    clipToOutline = true
                }
                setOnClickListener {
                    performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
                    try {
                        val counts = org.json.JSONObject(prefs().getString("bubbleOrbitUsage", "{}") ?: "{}")
                        counts.put(a.command, (counts.optInt(a.command, 0) + 1).coerceAtMost(100000))
                        prefs().edit().putString("bubbleOrbitUsage", counts.toString()).apply()
                    } catch (_: Exception) { }
                    hideQuickMenu()
                    when (a.command) {
                        "closeWindows" -> { hideQuickMenu(); hideAssistantOverlay(); hideReminderViews(); closeAllMiniWindows() }
                        "quickComplete", "quickPostpone" -> showTaskQuickAction(a.command)
                        "ask" -> showQuickAsk()
                        "question" -> showAssistantOverlay(a.command)
                        "content" -> showAssistantOverlay("content")
                        else -> openMiniWindow(a.command)
                    }
                }
            }
            buttons.add(b); menu.addView(b, FrameLayout.LayoutParams(item,item))
        }
        fun placeButtons(rotation: Double) {
            val centerX = size/2.0
            val centerY = size/2.0
            // All bubbles remain in the orbit. The overlay window itself is positioned
            // around the true main-bubble centre and is clipped by the physical screen edge.
            // This avoids abrupt visibility toggles and makes rotation visually continuous.
            buttons.forEachIndexed { i,b ->
                val angle = (-Math.PI/2.0) + (2.0*Math.PI * i/buttons.size) + rotation
                val x = (centerX + radius*kotlin.math.cos(angle) - item/2).toInt()
                val y = (centerY + radius*kotlin.math.sin(angle) - item/2).toInt()
                val lp = b.layoutParams as FrameLayout.LayoutParams
                lp.leftMargin=x; lp.topMargin=y; b.layoutParams=lp
                b.visibility = View.VISIBLE
            }
        }
        placeButtons(orbitRotation)
        // Rotate by the actual polar angle around the main bubble, not a dx/dy approximation.
        buttons.forEach { button ->
            var downAngle = 0f
            var downRotation = orbitRotation
            var sideDragged = false
            var sideMoved = false
            button.setOnTouchListener { v, ev ->
                val centerX = anchorCenterX(anchor)
                val centerY = anchorCenterY(anchor)
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sideDragged = false
                        sideMoved = false
                        downAngle = Math.toDegrees(kotlin.math.atan2((ev.rawY-centerY).toDouble(), (ev.rawX-centerX).toDouble())).toFloat()
                        downRotation = orbitRotation
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val nowAngle = Math.toDegrees(kotlin.math.atan2((ev.rawY-centerY).toDouble(), (ev.rawX-centerX).toDouble())).toFloat()
                        var delta = nowAngle - downAngle
                        if (delta > 180f) delta -= 360f
                        if (delta < -180f) delta += 360f
                        if (kotlin.math.abs(delta) > 5f) sideMoved = true
                        sideDragged = sideMoved && prefs().getBoolean("bubbleSideRotationEnabled", true)
                        if (sideDragged) {
                            orbitRotation = downRotation + Math.toRadians(delta.toDouble())
                            prefs().edit().putFloat("bubbleOrbitRotation", orbitRotation.toFloat()).apply()
                            placeButtons(orbitRotation)
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> { if (!sideMoved) v.performClick(); true }
                    MotionEvent.ACTION_CANCEL -> true
                    else -> true
                }
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        // Keep the overlay centre exactly on the main bubble, even when this means
        // a negative window coordinate. FLAG_LAYOUT_NO_LIMITS lets the display clip
        // the off-screen half naturally without shifting the orbit away from its anchor.
        val x = anchorCenterX(anchor).toInt() - size/2
        val y = anchorCenterY(anchor).toInt() - size/2
        val lp = WindowManager.LayoutParams(size,size,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply {
            gravity=Gravity.TOP or Gravity.LEFT; this.x=x; this.y=y
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            windowManager.addView(menu, lp)
            menu.setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_OUTSIDE || event.actionMasked == MotionEvent.ACTION_DOWN) {
                    hideQuickMenu()
                    true
                } else true
            }
            quickMenu = menu
            quickMenuParams = lp
            // Keep the main bubble above the menu window so it remains clickable.
            // Otherwise the transparent center of the menu window intercepts taps.
            bubble?.let { main ->
                val mainLp = params
                if (mainLp != null) {
                    try { windowManager.removeView(main) } catch (_: Exception) {}
                    try { windowManager.addView(main, mainLp) } catch (_: Exception) {}
                }
            }
        } catch (_: Exception) {}
    }

    private fun prefs() = getSharedPreferences("alislah_native", MODE_PRIVATE)

    /** Prefer a natural network Arabic voice; retain an installed offline Arabic voice as a real fallback. */
    private fun configureAssistantVoice() {
        val engine = tts ?: return
        try {
            val voices = engine.voices.orEmpty().filter { it.locale.language.equals("ar", true) }
            val wantedFemale = prefs().getString("assistantVoiceGender", "female") != "male"
            val hints = if (wantedFemale) listOf("female", "woman", "amira", "salma", "hoda", "laila", "sara") else listOf("male", "man", "ahmed", "hamza", "omar")
            fun score(v: android.speech.tts.Voice) = hints.any { v.name.contains(it, true) }
            networkArabicVoice = voices.filter { it.isNetworkConnectionRequired }
                .sortedWith(compareByDescending<android.speech.tts.Voice> { score(it) }.thenByDescending { it.quality }).firstOrNull()
            localArabicVoice = voices.filter { !it.isNetworkConnectionRequired }
                .sortedWith(compareByDescending<android.speech.tts.Voice> { score(it) }.thenByDescending { it.quality }).firstOrNull()
            // Network voice first for natural speech; if unavailable, use local Arabic immediately.
            val preferred = networkArabicVoice ?: localArabicVoice
            if (preferred != null) engine.voice = preferred else engine.language = Locale("ar")
            engine.setPitch(1.0f)
            engine.setSpeechRate(0.96f)
        } catch (_: Exception) {
            try { engine.language = Locale("ar"); engine.setPitch(1.0f) } catch (_: Exception) { }
        }
    }

    private fun speak(text: String) {
        val clean = text.trim().take(700)
        if (clean.isBlank()) return
        pendingFallbackText = clean
        fallbackAttempted = false
        if (!ttsReady) return
        configureAssistantVoice()
        val quranLike = clean.contains("﴿") || clean.contains("﴾") || clean.contains("سورة ") ||
            (clean.count { it in "ًٌٍَُِّْٰ" } >= 5 && clean.length >= 24)
        val speechText = if (quranLike) clean.replace("﴿", "، ").replace("﴾", "، ").replace("ۖ", "، ").replace("ۗ", "، ") else clean
        // The selected engine controls assistant speech and displayed Quran verses alike.
        // Gender selection applies only to the legacy Android TTS engine.
        val neuralEligible = prefs().getString("assistantVoiceEngine", "old") == "neural"
        val web = assistantWebView
        if (neuralEligible && web != null && overlayPageReady) {
            try {
                setAssistantSpeaking(true)
                web.evaluateJavascript("(function(){if(window.AlishlahNeuralVoice){window.AlishlahNeuralVoice.speak(" + org.json.JSONObject.quote(speechText) + ");return true;}return false;})()") { result ->
                    if (result != "true") handler.post { setAssistantSpeaking(false); speakWithAndroidTts(speechText, quranLike) }
                }
                return
            } catch (_: Exception) { setAssistantSpeaking(false) }
        }
        speakWithAndroidTts(speechText, quranLike)
    }

    private fun applyAssistantAudioAttributes() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val unified = prefs().getString("audioControlMode", "current") == "unified"
            val attrs = AudioAttributes.Builder()
                .setUsage(if (unified) AudioAttributes.USAGE_MEDIA else AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            try { tts?.setAudioAttributes(attrs) } catch (_: Exception) { }
        }
    }

    private fun speakWithAndroidTts(speechText: String, quranLike: Boolean) {
        try {
            applyAssistantAudioAttributes()
            tts?.setSpeechRate(if (quranLike) 0.78f else 0.96f)
            tts?.speak(speechText, TextToSpeech.QUEUE_FLUSH, null, "alislah_voice")
        } catch (_: Exception) { retryWithLocalArabicVoice() }
    }

    /** A failed/missing online voice never silences the assistant: retry once with offline Arabic TTS. */
    private fun retryWithLocalArabicVoice() {
        if (fallbackAttempted) return
        val text = pendingFallbackText
        val local = localArabicVoice
        if (text.isBlank() || local == null) return
        fallbackAttempted = true
        try {
            applyAssistantAudioAttributes()
            tts?.voice = local
            tts?.setPitch(1.0f)
            val quranLike = text.contains("﴿") || text.contains("﴾") || text.contains("سورة ") ||
                (text.count { it in "ًٌٍَُِّْٰ" } >= 5 && text.length >= 24)
            tts?.setSpeechRate(if (quranLike) 0.78f else 0.96f)
            val speechText = if (quranLike) text.replace("﴿", "، ").replace("﴾", "، ").replace("ۖ", "، ").replace("ۗ", "، ") else text
            tts?.speak(speechText, TextToSpeech.QUEUE_FLUSH, null, "alislah_voice_local_fallback")
        } catch (_: Exception) { }
    }

    private fun speakLatestReply() {
        val web = assistantWebView ?: return
        web.evaluateJavascript("(function(){var x=document.querySelector('#messages .bubble.assistant:last-child');return x?(x.innerText||x.textContent||''):''})()") { raw ->
            val value = try { org.json.JSONTokener(raw ?: "").nextValue() as? String ?: "" } catch (_: Exception) { "" }
            if (value.isNotBlank() && value != lastSpokenReply && !value.contains("أحاول الاتصال")) {
                lastSpokenReply = value
                if (prefs().getString("voiceMode", "both") != "text") { autoListenAfterSpeech = true; speak(value) }
            }
        }
    }

    private fun showCloseButton(anchor: WindowManager.LayoutParams) {
        if (closeButton != null) return
        val size = (38 * resources.displayMetrics.density).toInt()
        val xButton = TextView(this).apply {
            text = "×"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(180, 35, 24))
                setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
            }
            contentDescription = "إغلاق الفقاعة العائمة"
            setOnClickListener {
                getSharedPreferences("alislah_native", MODE_PRIVATE).edit().putBoolean("overlayEnabled", false).apply()
                handler.removeCallbacks(reshowBubble)
                stopSelf()
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val cp = WindowManager.LayoutParams(size, size, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (anchor.x + 42 * resources.displayMetrics.density).toInt()
            y = (anchor.y - 12 * resources.displayMetrics.density).toInt().coerceAtLeast(0)
        }
        try { windowManager.addView(xButton, cp); closeButton = xButton; closeParams = cp } catch (_: Exception) {}
    }

    private fun hideCloseButton() {
        closeButton?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        closeButton = null
        closeParams = null
    }

    /** Three-dimensional plasma/glass renderer; preserves the original touch bounds and dock geometry. */
    private inner class MainBubbleView(context: android.content.Context) : View(context) {
        var capsuleEdge: String = "top"
        val dockedAtCamera: Boolean get() = capsuleEdge != "circle"
        private val density = resources.displayMetrics.density
        private val fill = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(7, 77, 62); style = android.graphics.Paint.Style.FILL
        }
        private val stroke = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(105, 255, 208); style = android.graphics.Paint.Style.STROKE
            strokeWidth = (1.7f * density).coerceAtLeast(1f)
        }
        private val markPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textAlign = android.graphics.Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
        }
        private val wavePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; strokeWidth = (3.2f * density).coerceAtLeast(2f)
            strokeCap = android.graphics.Paint.Cap.ROUND
        }
        private val plasmaGlow = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            style = android.graphics.Paint.Style.STROKE; strokeCap = android.graphics.Paint.Cap.ROUND
            strokeWidth = 3.2f * density
            maskFilter = android.graphics.BlurMaskFilter(7f * density, android.graphics.BlurMaskFilter.Blur.NORMAL)
        }
        private val plasmaLine = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            style = android.graphics.Paint.Style.STROKE; strokeCap = android.graphics.Paint.Cap.ROUND
            strokeWidth = 1.7f * density
        }
        private val glassHighlight = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            style = android.graphics.Paint.Style.STROKE; strokeWidth = 1.1f * density
            color = Color.argb(190, 225, 255, 246)
        }
        @Volatile private var mode: String = "idle"
        @Volatile private var badgeCount: Int = 0
        private val badgeFill = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(190,45,52); style = android.graphics.Paint.Style.FILL }
        private val badgeText = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = android.graphics.Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
        private val prayerRingPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { style = android.graphics.Paint.Style.STROKE; strokeCap = android.graphics.Paint.Cap.ROUND; strokeWidth = 3f * density }
        @Volatile private var prayerRingFraction = 0f
        @Volatile private var prayerRingUrgent = false
        fun setPrayerRing(fraction: Float, urgent: Boolean) { prayerRingFraction = fraction.coerceIn(0f,1f); prayerRingUrgent = urgent; postInvalidate() }
        fun setSpeaking(active: Boolean) { setBubbleMode(if (active) "speaking" else if (assistantListening) "listening" else "idle") }
        fun setBubbleMode(value: String) { mode = value; postInvalidate() }
        fun setBadge(value: Int) { badgeCount = value.coerceAtLeast(0); postInvalidate() }

        override fun onDraw(canvas: android.graphics.Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            val cx = w / 2f; val cy = h / 2f
            val radius = minOf(w, h) / 2f - stroke.strokeWidth
            val circle = capsuleEdge == "circle"
            val shapePath = if (circle) null else android.graphics.Path().apply {
                val r = minOf(w,h)/2f
                when (capsuleEdge) {
                    "bottom" -> { moveTo(r,0f); quadTo(0f,0f,0f,r); lineTo(0f,h); lineTo(w,h); lineTo(w,r); quadTo(w,0f,w-r,0f); close() }
                    "left" -> { moveTo(0f,0f); lineTo(w-r,0f); quadTo(w,0f,w,r); lineTo(w,h-r); quadTo(w,h,w-r,h); lineTo(0f,h); close() }
                    "right" -> { moveTo(r,0f); quadTo(0f,0f,0f,r); lineTo(0f,h-r); quadTo(0f,h,r,h); lineTo(w,h); lineTo(w,0f); close() }
                    else -> { moveTo(0f,0f); lineTo(w,0f); lineTo(w,h-r); quadTo(w,h,w-r,h); lineTo(r,h); quadTo(0f,h,0f,h-r); close() }
                }
            }
            if (circle) canvas.drawCircle(cx,cy,radius,fill) else canvas.drawPath(shapePath!!,fill)
            val save = canvas.save()
            if (circle) canvas.clipPath(android.graphics.Path().apply { addCircle(cx,cy,radius,android.graphics.Path.Direction.CW) }) else canvas.clipPath(shapePath!!)

            // Deep emerald body with a moving cyan/gold plasma core.
            val phase = android.os.SystemClock.uptimeMillis() / if (mode == "idle") 95L else 38L
            val drift = kotlin.math.sin(phase / 19.0).toFloat()
            val core = android.graphics.RadialGradient(cx + drift*radius*.22f, cy-radius*.18f, radius*1.35f,
                intArrayOf(Color.argb(230,25,255,177), Color.argb(150,0,145,126), Color.argb(245,2,31,39)),
                floatArrayOf(0f,.48f,1f), android.graphics.Shader.TileMode.CLAMP)
            val corePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { shader = core }
            canvas.drawCircle(cx,cy,radius*1.45f,corePaint)

            // Curved plasma filaments orbit inside the glass shell.
            for (i in 0..2) {
                val angle = phase.toFloat() * (if (i % 2 == 0) 0.55f else -0.42f) + i*118f
                val path = android.graphics.Path()
                val startX = cx + kotlin.math.cos(Math.toRadians(angle.toDouble())).toFloat()*radius*.82f
                val startY = cy + kotlin.math.sin(Math.toRadians(angle.toDouble())).toFloat()*radius*.82f
                path.moveTo(startX,startY)
                path.cubicTo(cx-radius*.95f, cy-radius*.28f + i*radius*.18f,
                    cx+radius*.95f, cy+radius*.35f - i*radius*.16f,
                    cx + kotlin.math.cos(Math.toRadians((angle+155).toDouble())).toFloat()*radius*.78f,
                    cy + kotlin.math.sin(Math.toRadians((angle+155).toDouble())).toFloat()*radius*.78f)
                val tint = if (i == 1) Color.rgb(255,220,112) else Color.rgb(68,255,218)
                plasmaGlow.color = tint; plasmaLine.color = Color.argb(210, tint shr 16 and 255, tint shr 8 and 255, tint and 255)
                canvas.drawPath(path,plasmaGlow); canvas.drawPath(path,plasmaLine)
            }
            // Glass reflections and a bright upper-left specular highlight.
            val gloss = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                shader = android.graphics.LinearGradient(cx-radius,cy-radius,cx+radius,cy+radius,
                    intArrayOf(Color.argb(135,255,255,255),Color.argb(8,255,255,255),Color.argb(42,255,255,255)),
                    null,android.graphics.Shader.TileMode.CLAMP)
            }
            canvas.drawCircle(cx,cy,radius*.99f,gloss)
            canvas.drawOval(android.graphics.RectF(cx-radius*.68f,cy-radius*.78f,cx+radius*.12f,cy-radius*.38f),glassHighlight)
            canvas.restoreToCount(save)
            if (circle) canvas.drawCircle(cx,cy,radius,stroke) else canvas.drawPath(shapePath!!,stroke)

            if (prayerRingFraction > 0f) {
                prayerRingPaint.color = if (prayerRingUrgent) Color.rgb(255,202,82) else Color.rgb(110,255,205)
                val rr = minOf(w,h)*.46f
                canvas.drawArc(android.graphics.RectF(cx-rr,cy-rr,cx+rr,cy+rr),-90f,360f*prayerRingFraction,false,prayerRingPaint)
            }
            when (mode) {
                "speaking" -> {
                    val count=5; val spacing=7f*density; val t=android.os.SystemClock.uptimeMillis()/115.0
                    for (i in 0 until count) { val wave=kotlin.math.abs(kotlin.math.sin(t+i*.82)); val bh=(5f+wave.toFloat()*13f)*density; val x=cx+(i-(count-1)/2f)*spacing; canvas.drawLine(x,cy-bh/2f,x,cy+bh/2f,wavePaint) }
                    postInvalidateDelayed(85L)
                }
                "listening" -> {
                    markPaint.textSize=22f*density; canvas.drawText("🎙",cx,cy-(markPaint.ascent()+markPaint.descent())/2f,markPaint)
                    if (android.os.SystemClock.uptimeMillis()/180L%2L==0L) canvas.drawCircle(cx+15*density,cy-13*density,3.5f*density,badgeFill)
                    postInvalidateDelayed(180L)
                }
                "thinking", "waiting" -> {
                    val t=android.os.SystemClock.uptimeMillis()/260L
                    for(i in 0..2){ val a=if(t%3L==i.toLong())255 else 125; val p=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(a,255,255,255)}; canvas.drawCircle(cx+(i-1)*9f*density,cy,3f*density,p) }
                    postInvalidateDelayed(220L)
                }
                else -> { markPaint.textSize=25f*density; canvas.drawText("✦",cx,cy-(markPaint.ascent()+markPaint.descent())/2f,markPaint); postInvalidateDelayed(420L) }
            }
            if (badgeCount > 0) { val bx=(w-10*density).coerceAtLeast(10*density); val by=9*density; val br=9.5f*density; canvas.drawCircle(bx,by,br,badgeFill); badgeText.textSize=(if(badgeCount>9)8f else 10f)*density; canvas.drawText(if(badgeCount>9)"9+" else badgeCount.toString(),bx,by-(badgeText.ascent()+badgeText.descent())/2f,badgeText) }
        }
    }

    private data class NavigationBarGeometry(val edge: String, val inset: Int)

    /** Resolve the real navigation-bar edge; Android can move it to a landscape side on some devices. */
    private fun navigationBarGeometry(screenW: Int, screenH: Int): NavigationBarGeometry {
        fun dimension(name: String): Int {
            val id = resources.getIdentifier(name, "dimen", "android")
            return if (id == 0) 0 else try { resources.getDimensionPixelSize(id) } catch (_: Exception) { 0 }
        }
        fun systemBoolean(name: String): Boolean? {
            val id = resources.getIdentifier(name, "bool", "android")
            return if (id == 0) null else try { resources.getBoolean(id) } catch (_: Exception) { null }
        }
        val maxInset = (96 * resources.displayMetrics.density).toInt().coerceAtLeast(1)
        if (screenW <= screenH) {
            val inset = (dimension("navigation_bar_height").takeIf { it > 0 }
                ?: dimension("navigation_bar_height_landscape").takeIf { it > 0 }
                ?: (24 * resources.displayMetrics.density).toInt()).coerceIn(0, maxInset)
            return NavigationBarGeometry("bottom", inset)
        }
        val rotation = try { windowManager.defaultDisplay.rotation } catch (_: Exception) { Surface.ROTATION_90 }
        val canMove = systemBoolean("config_navBarCanMove") ?: false
        // On some OEM builds config_navBarCanMove is missing or reports the wrong value.
        // Compare real display size with app-usable size to detect a side navigation strip.
        val sideDifference = try {
            val real = DisplayMetrics(); val usable = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(real)
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getMetrics(usable)
            (real.widthPixels - usable.widthPixels).coerceAtLeast(0)
        } catch (_: Exception) { 0 }
        val heightDifference = try {
            val real = DisplayMetrics(); val usable = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(real)
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getMetrics(usable)
            (real.heightPixels - usable.heightPixels).coerceAtLeast(0)
        } catch (_: Exception) { 0 }
        val sideBarDetected = sideDifference >= (18 * resources.displayMetrics.density).toInt() &&
            sideDifference > heightDifference
        if ((canMove || sideBarDetected) && (rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270)) {
            val width = (sideDifference.takeIf { sideBarDetected && it > 0 }
                ?: dimension("navigation_bar_width").takeIf { it > 0 }
                ?: (24 * resources.displayMetrics.density).toInt()).coerceIn(0, maxInset)
            if (width > 0) {
                val edge = if (rotation == Surface.ROTATION_270) "left" else "right"
                return NavigationBarGeometry(edge, width)
            }
        }
        val landscapeHeight = dimension("navigation_bar_height_landscape").takeIf { it > 0 }
            ?: dimension("navigation_bar_height").takeIf { it > 0 }
            ?: (24 * resources.displayMetrics.density).toInt()
        return NavigationBarGeometry("bottom", landscapeHeight.coerceIn(0, maxInset))
    }

    /** Dock the main bubble to an edge, centring a half-circle on the system navigation-bar boundary. */
    private fun dockMainBubble(view: MainBubbleView, lp: WindowManager.LayoutParams, edge: String,
                               screenW: Int, screenH: Int, anchorX: Int, anchorY: Int) {
        val d = resources.displayMetrics.density
        val landscape = screenW > screenH
        val circle = (58 * d).toInt()
        val thickness = (52 * d).toInt()
        val capsuleLength = (90 * d).toInt()
        val navigation = navigationBarGeometry(screenW, screenH)
        val cutoutWidth = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try { windowManager.defaultDisplay.cutout?.boundingRects?.filter { it.width() > 0 && it.height() > 0 }?.maxByOrNull { it.width() * it.height() }?.width() ?: 0 } catch (_: Exception) { 0 }
        } else 0
        when (edge) {
            "top" -> {
                view.capsuleEdge = "top"
                lp.width = if (!landscape) (cutoutWidth + (24*d).toInt()).coerceIn((42*d).toInt(), (78*d).toInt()) + (30*d).toInt() else capsuleLength
                lp.height = thickness
                val center = if (!landscape) cameraCenterX(screenW) else anchorX
                lp.x = (center - lp.width/2).coerceIn(0, (screenW-lp.width).coerceAtLeast(0)); lp.y = 0
            }
            "left", "right" -> {
                if (landscape && navigation.edge == edge) {
                    // System navigation buttons occupy this side: align the bubble centre with
                    // the app/navigation boundary so exactly the exposed half remains tappable.
                    view.capsuleEdge = "circle"
                    lp.width = circle; lp.height = circle
                    val boundary = if (edge == "left") navigation.inset else screenW - navigation.inset
                    lp.x = boundary - circle/2
                    lp.y = (anchorY-circle/2).coerceIn(0, (screenH-circle).coerceAtLeast(0))
                } else if (landscape) {
                    view.capsuleEdge = edge
                    lp.width = thickness; lp.height = capsuleLength
                    lp.x = if (edge == "left") 0 else screenW - thickness
                    lp.y = (anchorY - capsuleLength/2).coerceIn(0, (screenH-capsuleLength).coerceAtLeast(0))
                } else {
                    view.capsuleEdge = "circle"
                    lp.width = circle; lp.height = circle
                    lp.x = if (edge == "left") -(circle/2) else screenW - circle/2
                    lp.y = (anchorY-circle/2).coerceIn(0, (screenH-circle).coerceAtLeast(0))
                }
            }
            else -> {
                view.capsuleEdge = "circle"
                lp.width = circle; lp.height = circle
                lp.x = (anchorX-circle/2).coerceIn(-(circle/2), (screenW-circle/2))
                val boundary = if (navigation.edge == "bottom") screenH - navigation.inset else screenH
                lp.y = boundary - circle/2
            }
        }
        view.requestLayout()
    }

    /** Height occupied by a bottom navigation bar; side bars are handled by navigationBarGeometry(). */
    private fun navigationBarBottomInset(screenW: Int, screenH: Int): Int {
        val navigation = navigationBarGeometry(screenW, screenH)
        return if (navigation.edge == "bottom") navigation.inset else 0
    }

    private fun edgeDistances(centerX: Float, centerY: Float, screenW: Int, screenH: Int): List<Pair<String, Float>> {
        val navigation = navigationBarGeometry(screenW, screenH)
        val leftBoundary = if (navigation.edge == "left") navigation.inset else 0
        val rightBoundary = if (navigation.edge == "right") screenW - navigation.inset else screenW
        val bottomBoundary = if (navigation.edge == "bottom") screenH - navigation.inset else screenH
        return listOf(
            "left" to kotlin.math.abs(centerX - leftBoundary),
            "right" to kotlin.math.abs(rightBoundary - centerX),
            "top" to kotlin.math.abs(centerY),
            "bottom" to kotlin.math.abs(bottomBoundary - centerY)
        )
    }

    private fun startVoiceTaskFromBubble() {
        hideQuickMenu()
        val launch = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("dz.alislah.app.extra.START_VOICE_TASK", true)
        }
        try { startActivity(launch) } catch (_: Exception) { mainLongPressTriggered = false }
    }

    private fun stopVoiceTaskFromBubble() {
        val stop = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("dz.alislah.app.extra.STOP_VOICE_TASK", true)
        }
        try { startActivity(stop) } catch (_: Exception) { }
    }

    /** Physical display bounds, not app-content bounds: status/navigation bars must not shift the camera anchor. */
    private fun realScreenSize(): Pair<Int, Int> {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        return Pair(metrics.widthPixels, metrics.heightPixels)
    }

    private fun cameraCenterX(screenWidth: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                // DisplayCutout coordinates are physical-display coordinates. Pair them with getRealMetrics().
                @Suppress("DEPRECATION")
                val cutout = windowManager.defaultDisplay.cutout
                val rect = cutout?.boundingRects
                    ?.filter { it.width() > 0 && it.height() > 0 }
                    ?.maxByOrNull { it.width() * it.height() }
                if (rect != null) return rect.centerX().coerceIn(0, screenWidth)
            } catch (_: Exception) { }
        }
        // Android 8.0/8.1 and devices without cutout metadata: use the physical screen centre.
        return screenWidth / 2
    }

    /** Resolve which landscape side contains the physical camera/display cutout. */
    private fun landscapeCameraEdge(screenW: Int, screenH: Int): String {
        if (screenW <= screenH || Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return "left"
        return try {
            @Suppress("DEPRECATION")
            val rect = windowManager.defaultDisplay.cutout?.boundingRects
                ?.filter { it.width() > 0 && it.height() > 0 }
                ?.maxByOrNull { it.width() * it.height() }
            if (rect == null) "left" else if (rect.centerX() < screenW / 2) "left" else "right"
        } catch (_: Exception) { "left" }
    }

    private fun rememberBubbleAnchor(orientation: Int, lp: WindowManager.LayoutParams, screenW: Int, screenH: Int) {
        if (screenW <= 0 || screenH <= 0) return
        val x = ((lp.x + lp.width / 2f) / screenW).coerceIn(0f, 1f)
        val y = ((lp.y + lp.height / 2f) / screenH).coerceIn(0f, 1f)
        if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
            landscapeAnchorXRatio = x; landscapeAnchorYRatio = y
            prefs().edit().putFloat("bubbleLandscapeXRatio", x).putFloat("bubbleLandscapeYRatio", y).apply()
        } else if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            portraitAnchorXRatio = x; portraitAnchorYRatio = y
            prefs().edit().putFloat("bubblePortraitXRatio", x).putFloat("bubblePortraitYRatio", y).apply()
        }
    }

    private fun maybeShowBubbleHint(view: MainBubbleView) {
        val next = Snapshot.nextPrayer(this)
        val now = System.currentTimeMillis()
        val remaining = (next?.second ?: 0L) - now
        val key: String
        val message: String
        if (next != null && remaining in 1L..(15L*60L*1000L)) {
            val minutes = ((remaining + 59_999L) / 60_000L).toInt()
            key = "prayer:${next.second}"
            message = "بعد $minutes د: ${next.first}"
        } else {
            val due = dueTaskCount()
            if (due <= 0) return
            key = "tasks:${Snapshot.todayKey()}"
            message = "لديك $due مهام مستحقة"
        }
        if (prefs().getString("bubbleHintLastKey", "") == key) return
        prefs().edit().putString("bubbleHintLastKey", key).apply()
        val pos = IntArray(2); view.getLocationOnScreen(pos)
        if (bubbleHint == null) bubbleHint = BubbleHint(this, windowManager)
        bubbleHint?.show(message, pos[0], pos[1], view.width, view.height, view.capsuleEdge)
    }

    private fun showBubble() {
        if (bubble != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        // Use the full physical display so the status bar cannot offset the cutout anchor.
        val (screenW, screenH) = realScreenSize()
        lastBubbleScreenWidth = screenW
        lastBubbleScreenHeight = screenH
        lastConfigOrientation = if (screenW > screenH) Configuration.ORIENTATION_LANDSCAPE else Configuration.ORIENTATION_PORTRAIT
        lastDisplayRotation = try { windowManager.defaultDisplay.rotation } catch (_: Exception) { Surface.ROTATION_0 }
        val circleSize = (58 * d).toInt()
        val cameraX = cameraCenterX(screenW)
        val cutoutWidth = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try { windowManager.defaultDisplay.cutout?.boundingRects?.maxByOrNull { it.width() * it.height() }?.width() ?: 0 } catch (_: Exception) { 0 }
        } else 0
        val opening = (cutoutWidth + (24 * d).toInt()).coerceIn((42*d).toInt(), (78*d).toInt())
        val dockWidth = opening + (30 * d).toInt()
        val dockHeight = (52 * d).toInt()
        val view = MainBubbleView(this).apply {
            capsuleEdge = "top"
            contentDescription = "فقاعة ALISLAH؛ أثناء تحدث المساعد اضغط لإيقاف الصوت، والضغط المطوّل للاستماع"
            elevation = 18 * d
            setSpeaking(assistantSpeaking)
        }
        var gestureStartEdge = view.capsuleEdge
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(dockWidth, dockHeight, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = (cameraX - dockWidth / 2).coerceIn(0, (screenW - dockWidth).coerceAtLeast(0))
            y = 0
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        // Restore the user's last edge/position independently for portrait and landscape.
        val landscape = screenW > screenH
        val savedX = prefs().getFloat(if (landscape) "bubbleLandscapeXRatio" else "bubblePortraitXRatio", -1f)
        val savedY = prefs().getFloat(if (landscape) "bubbleLandscapeYRatio" else "bubblePortraitYRatio", -1f)
        val applyLeftEdgeMigration = !prefs().getBoolean("bubbleLeftEdgeMigrationV1", false)
        if (applyLeftEdgeMigration) {
            dockMainBubble(view, lp, "left", screenW, screenH, 0, screenH / 2)
            prefs().edit()
                .putBoolean("bubbleLeftEdgeMigrationV1", true)
                .putBoolean("bubbleInitialAnchorSet", true)
                .putFloat("bubblePortraitXRatio", 0.02f).putFloat("bubblePortraitYRatio", 0.50f)
                .putFloat("bubbleLandscapeXRatio", 0.02f).putFloat("bubbleLandscapeYRatio", 0.50f)
                .apply()
            rememberBubbleAnchor(lastConfigOrientation, lp, screenW, screenH)
        } else if (savedX in 0f..1f && savedY in 0f..1f) {
            val centerX = (savedX * screenW).toInt()
            val centerY = (savedY * screenH).toInt()
            val edge = edgeDistances(centerX.toFloat(), centerY.toFloat(), screenW, screenH).minByOrNull { it.second }?.first ?: "left"
            dockMainBubble(view, lp, edge, screenW, screenH, centerX, centerY)
        } else if (prefs().getBoolean("bubbleUserRequestedLeftEdge", false) || !prefs().getBoolean("bubbleInitialAnchorSet", false)) {
            // New installs start on the left edge; an explicit voice command keeps this preference.
            dockMainBubble(view, lp, "left", screenW, screenH, 0, screenH / 2)
            prefs().edit().putBoolean("bubbleInitialAnchorSet", true).apply()
            rememberBubbleAnchor(lastConfigOrientation, lp, screenW, screenH)
        } else if (landscape) {
            // Existing installs without a saved position retain the camera-side landscape default.
            val cameraSide = landscapeCameraEdge(screenW, screenH)
            dockMainBubble(view, lp, cameraSide, screenW, screenH,
                if (cameraSide == "left") 0 else screenW, screenH / 2)
        }
        view.setBadge(dueTaskCount())
        view.setBubbleMode(bubbleState)
        rememberBubbleAnchor(lastConfigOrientation, lp, screenW, screenH)
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    handler.removeCallbacks(fadeBubbleWhenIdle)
                    restoreAutoHiddenBubble()
                    v.alpha = 1f
                    if (assistantSpeaking) {
                        speakingTapConsumed = true
                        pendingMainTap?.let { handler.removeCallbacks(it) }
                        pendingMainTap = null
                        lastTapAt = 0L
                        stopAssistantSpeech()
                        return@setOnTouchListener true
                    }
                    speakingTapConsumed = false
                    gestureStartEdge = view.capsuleEdge
                    dragged = false; mainLongPressTriggered = false
                    downAt = System.currentTimeMillis(); startX = lp.x; startY = lp.y; touchX = event.rawX; touchY = event.rawY
                    mainLongPressRunnable?.let { handler.removeCallbacks(it) }
                    val longPress = Runnable {
                        val action = prefs().getString("bubbleLongPressAction", "voice") ?: "voice"
                        if (!dragged && bubble === v && action != "none") {
                            mainLongPressTriggered = true
                            longPressTriggeredAction = action
                            pendingMainTap?.let { handler.removeCallbacks(it) }
                            pendingMainTap = null
                            lastTapAt = 0L
                            if (action == "voice") startVoiceTaskFromBubble()
                            else if (action == "menu") showQuickMenu(lp)
                        }
                    }
                    mainLongPressRunnable = longPress
                    handler.postDelayed(longPress, 650L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt(); val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) {
                        if (!dragged) mainLongPressRunnable?.let { handler.removeCallbacks(it) }
                        dragged = true
                        if (mainLongPressTriggered) {
                            if (longPressTriggeredAction == "voice") stopVoiceTaskFromBubble()
                            mainLongPressTriggered = false
                            longPressTriggeredAction = ""
                        }
                    }
                    if (dragged) {
                        pendingMainTap?.let { handler.removeCallbacks(it) }
                        pendingMainTap = null
                        lastTapAt = 0L
                        val (currentW, currentH) = realScreenSize()
                        lp.x = (startX + dx).coerceIn(-(lp.width / 2), currentW - (lp.width / 2))
                        val bottomInset = navigationBarBottomInset(currentW, currentH)
                        lp.y = (startY + dy).coerceIn(0, (currentH-bottomInset-lp.height).coerceAtLeast(0))
                        try { windowManager.updateViewLayout(v, lp) } catch (_: Exception) {}
                        v.post { if (quickMenu != null) syncQuickMenuToAnchor(lp); syncReminderOverlay(lp); syncAdhanMuteBubble(); syncAssistantStopBubble() }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (speakingTapConsumed) { speakingTapConsumed = false; return@setOnTouchListener true }
                    mainLongPressRunnable?.let { handler.removeCallbacks(it) }
                    mainLongPressRunnable = null
                    if (mainLongPressTriggered) {
                        v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                        if (longPressTriggeredAction == "voice") stopVoiceTaskFromBubble()
                        mainLongPressTriggered = false
                        longPressTriggeredAction = ""
                        dragged = false
                        lastTapAt = 0L
                        return@setOnTouchListener true
                    }
                    if (dragged) {
                        val (currentW, currentH) = realScreenSize()
                        val density = resources.displayMetrics.density
                        val swipeDx = event.rawX - touchX
                        val swipeDy = event.rawY - touchY
                        val swipeDistance = kotlin.math.hypot(swipeDx.toDouble(), swipeDy.toDouble())
                        val fastInwardSwipe = System.currentTimeMillis() - downAt <= 480L &&
                            swipeDistance >= 78*d && swipeDistance <= 210*d && when (gestureStartEdge) {
                                "left" -> swipeDx >= 70*d && kotlin.math.abs(swipeDx) > kotlin.math.abs(swipeDy)*1.15f
                                "right" -> swipeDx <= -70*d && kotlin.math.abs(swipeDx) > kotlin.math.abs(swipeDy)*1.15f
                                "top" -> swipeDy >= 70*d && kotlin.math.abs(swipeDy) > kotlin.math.abs(swipeDx)*1.15f
                                "bottom" -> swipeDy <= -70*d && kotlin.math.abs(swipeDy) > kotlin.math.abs(swipeDx)*1.15f
                                else -> false
                            }
                        val centerX = lp.x + lp.width / 2
                        val centerY = lp.y + lp.height / 2
                        val distances = edgeDistances(centerX.toFloat(), centerY.toFloat(), currentW, currentH)
                        val edge = distances.minByOrNull { it.second }?.first ?: "left"
                        dockMainBubble(view, lp, edge, currentW, currentH, centerX, centerY)
                        rememberBubbleAnchor(if (currentW > currentH) Configuration.ORIENTATION_LANDSCAPE else Configuration.ORIENTATION_PORTRAIT, lp, currentW, currentH)
                        try { windowManager.updateViewLayout(v, lp) } catch (_: Exception) {}
                        v.post { if (quickMenu != null) syncQuickMenuToAnchor(lp); syncReminderOverlay(lp); syncAdhanMuteBubble(); syncAssistantStopBubble() }
                        if (fastInwardSwipe) {
                            when (prefs().getString("bubbleSwipeAction", "menu")) {
                                "dashboard" -> openMiniWindow("miniDashboard")
                                "none" -> Unit
                                else -> showQuickMenu(lp)
                            }
                        } else scheduleIdleBubbleFade()
                    } else if (assistantSpeaking) {
                        pendingMainTap?.let { handler.removeCallbacks(it) }
                        pendingMainTap = null
                        lastTapAt = 0L
                        stopAssistantSpeech()
                    } else {
                        v.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
                        val now = System.currentTimeMillis()
                        val doubleTapWindow = 320L
                        if (lastTapAt != 0L && now - lastTapAt <= doubleTapWindow) {
                            pendingMainTap?.let { handler.removeCallbacks(it) }
                            pendingMainTap = null
                            lastTapAt = 0L
                            when (prefs().getString("bubbleDoubleTapAction", "app")) {
                                "menu" -> if (quickMenu != null) hideQuickMenu() else showQuickMenu(lp)
                                "ask" -> showQuickAsk()
                                "none" -> Unit
                                else -> { hideQuickMenu(); openMainApp() }
                            }
                        } else {
                            lastTapAt = now
                            val singleTap = Runnable {
                                if (lastTapAt == now) {
                                    when (prefs().getString("bubbleSingleTapAction", "menu")) {
                                        "app" -> openMainApp()
                                        "none" -> Unit
                                        else -> if (quickMenu != null) hideQuickMenu() else showQuickMenu(lp)
                                    }
                                    lastTapAt = 0L
                                }
                                pendingMainTap = null
                            }
                            pendingMainTap?.let { handler.removeCallbacks(it) }
                            pendingMainTap = singleTap
                            handler.postDelayed(singleTap, doubleTapWindow)
                            scheduleIdleBubbleFade()
                        }
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (speakingTapConsumed) { speakingTapConsumed = false; return@setOnTouchListener true }
                    mainLongPressRunnable?.let { handler.removeCallbacks(it) }
                    mainLongPressRunnable = null
                    if (mainLongPressTriggered && longPressTriggeredAction == "voice") stopVoiceTaskFromBubble()
                    mainLongPressTriggered = false
                    longPressTriggeredAction = ""
                    false
                }
                else -> false
            }
        }
        try {
            windowManager.addView(view, lp); bubble = view; params = lp
            if (adhanPlaying) showAdhanMuteBubble()
            if (assistantSpeaking && !reminderSpeechActive) showAssistantStopBubble()
            if (reminderCardVisible) { ensureReminderViews(); syncReminderOverlay(lp) }
            scheduleIdleBubbleFade()
            updatePrayerRing()
            if (prefs().getBoolean("bubbleHintsEnabled", true)) view.post { maybeShowBubbleHint(view) }
            if (!miniWindowsRestored) handler.post { restoreMiniWindows() }
        } catch (_: Exception) { stopSelf() }
    }

    private fun moveBubbleToLeftEdge() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) return
        if (bubble == null) showBubble()
        val view = bubble as? MainBubbleView ?: return
        val lp = params ?: return
        val (w, h) = realScreenSize()
        dockMainBubble(view, lp, "left", w, h, 0, h / 2)
        bubbleAutoHiddenOrigin = null
        view.alpha = 1f
        try { windowManager.updateViewLayout(view, lp) } catch (_: Exception) { }
        rememberBubbleAnchor(if (w > h) Configuration.ORIENTATION_LANDSCAPE else Configuration.ORIENTATION_PORTRAIT, lp, w, h)
        prefs().edit()
            .putBoolean("bubbleUserRequestedLeftEdge", true)
            .putBoolean("bubbleLeftEdgeMigrationV1", true)
            .putBoolean("bubbleInitialAnchorSet", true)
            .putFloat("bubblePortraitXRatio", 0.02f).putFloat("bubblePortraitYRatio", 0.50f)
            .putFloat("bubbleLandscapeXRatio", 0.02f).putFloat("bubbleLandscapeYRatio", 0.50f)
            .apply()
        view.post { syncReminderOverlay(lp); syncAdhanMuteBubble(); syncAssistantStopBubble() }
    }

    private fun setBubbleState(state: String) {
        bubbleState = when (state) {
            "listening", "thinking", "speaking", "waiting" -> state
            else -> "idle"
        }
        (bubble as? MainBubbleView)?.setBubbleMode(bubbleState)
    }

    private fun dueTaskCount(): Int = try {
        val raw = prefs().getString("alislah_app_data", "{}") ?: "{}"
        val tasks = org.json.JSONObject(raw).optJSONArray("tasks")
        if (tasks == null) 0 else {
            val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
            var count = 0
            for (i in 0 until tasks.length()) {
                val task = tasks.optJSONObject(i) ?: continue
                val date = task.optString("date", "")
                if (!task.optBoolean("done", false) && date.isNotBlank() && date <= today) count++
            }
            count
        }
    } catch (_: Exception) { 0 }

    private var lastLivePrayerAt = 0L
    private var lastLivePrayerName = ""
    private var lastLiveCountdownEnabled = false

    private fun updatePrayerRing() {
        val next = Snapshot.nextPrayer(this)
        val now = System.currentTimeMillis()
        val remaining = (next?.second ?: 0L) - now
        val fraction = if (remaining in 1L..(60L*60L*1000L)) 1f - remaining.toFloat()/(60L*60L*1000L) else 0f
        (bubble as? MainBubbleView)?.setPrayerRing(fraction, remaining in 1L..(15L*60L*1000L))
    }

    private fun updateLivePrayerCountdown() {
        val enabled = prefs().getBoolean("bubbleLiveCountdownEnabled", false)
        if (!enabled) {
            if (lastLiveCountdownEnabled) LiveCountdown.cancel(this)
            lastLiveCountdownEnabled = false
            lastLivePrayerAt = 0L
            lastLivePrayerName = ""
            return
        }
        val next = Snapshot.nextPrayer(this)
        if (next == null) { LiveCountdown.cancel(this); lastLiveCountdownEnabled = true; return }
        if (!lastLiveCountdownEnabled || next.second != lastLivePrayerAt || next.first != lastLivePrayerName) {
            LiveCountdown.update(this, next.first, next.second)
            lastLivePrayerAt = next.second
            lastLivePrayerName = next.first
        }
        lastLiveCountdownEnabled = true
    }

    private fun refreshBubbleIndicator() {
        (bubble as? MainBubbleView)?.setBadge(dueTaskCount())
        bubble?.invalidate()
        updateLivePrayerCountdown()
        updatePrayerRing()
    }

    private fun stopAdhanFromBubble() {
        // Do not hide the stop control optimistically. The player service's onDestroy()
        // sends ACTION_ADHAN_STOPPED after the audio resource has actually been released.
        val stopped = PrayerVoiceService.stopPlayback(this)
        if (!stopped && !prefs().getBoolean("adhanPlaying", false)) {
            adhanPlaying = false
            bubble?.invalidate()
            hideAdhanMuteBubble()
        }
    }

    private fun openMainApp() {
        val launch = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        try { startActivity(launch) } catch (_: Exception) { }
    }

    private fun runOverlayJs(script: String) {
        val web = assistantWebView ?: return
        if (overlayPageReady) web.evaluateJavascript(script, null) else pendingOverlayScripts.addLast(script)
    }

    private fun bubbleBehaviorJson(): String = org.json.JSONObject()
        .put("singleTap", prefs().getString("bubbleSingleTapAction", "menu"))
        .put("doubleTap", prefs().getString("bubbleDoubleTapAction", "app"))
        .put("longPress", prefs().getString("bubbleLongPressAction", "voice"))
        .put("orbitRadiusDp", prefs().getInt("bubbleOrbitRadiusDp", 116).coerceIn(100, 150))
        .put("sideRotation", prefs().getBoolean("bubbleSideRotationEnabled", true))
        .put("hideGames", prefs().getBoolean("bubbleHideGamesEnabled", false))
        .put("swipeAction", prefs().getString("bubbleSwipeAction", "menu")).toString()

    private fun scheduleIdleBubbleFade() {
        handler.removeCallbacks(fadeBubbleWhenIdle)
        handler.postDelayed(fadeBubbleWhenIdle, 2600L)
    }

    private fun saveBubbleBehavior(singleTap: String, doubleTap: String, longPress: String, radius: Int, rotate: Boolean) {
        val single = if (singleTap in listOf("menu", "app", "none")) singleTap else "menu"
        val double = if (doubleTap in listOf("menu", "app", "ask", "none")) doubleTap else "app"
        val long = if (longPress in listOf("voice", "menu", "none")) longPress else "voice"
        prefs().edit().putString("bubbleSingleTapAction", single).putString("bubbleDoubleTapAction", double)
            .putString("bubbleLongPressAction", long).putInt("bubbleOrbitRadiusDp", radius.coerceIn(100, 150))
            .putBoolean("bubbleSideRotationEnabled", rotate).apply()
        hideQuickMenu()
    }

    private fun setOverlayDndMode(enabled: Boolean): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return org.json.JSONObject().put("ok",false).put("unsupported",true).toString()
        val manager = getSystemService(NotificationManager::class.java)
        if (!manager.isNotificationPolicyAccessGranted) return org.json.JSONObject().put("ok",false).put("needsAccess",true).toString()
        return try {
            if (enabled) {
                if (!prefs().getBoolean("dndModeApplied",false)) prefs().edit().putInt("dndPreviousFilter",manager.currentInterruptionFilter).apply()
                manager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                prefs().edit().putBoolean("dndModeApplied",true).apply()
            } else if (prefs().getBoolean("dndModeApplied",false)) {
                manager.setInterruptionFilter(prefs().getInt("dndPreviousFilter",NotificationManager.INTERRUPTION_FILTER_ALL))
                prefs().edit().putBoolean("dndModeApplied",false).apply()
            }
            org.json.JSONObject().put("ok",true).put("enabled",enabled).toString()
        } catch (_: Exception) { org.json.JSONObject().put("ok",false).put("message","تعذر تغيير وضع عدم الإزعاج").toString() }
    }

    inner class OverlayNativeBridge {
        @JavascriptInterface fun getAppDataJson(): String = prefs().getString("alislah_app_data", "{}") ?: "{}"
        @JavascriptInterface fun saveAppDataJson(json: String) { if (json.length <= 2_000_000) { prefs().edit().putString("alislah_app_data", json).apply(); refreshBubbleIndicator() } }
        @JavascriptInterface fun setBubbleState(state: String) { handler.post { this@FloatingBubbleService.setBubbleState(state) } }
        @JavascriptInterface fun getEyeBreakContentCache(): String = prefs().getString("eyeBreakContentCache", "{}") ?: "{}"
        @JavascriptInterface fun saveEyeBreakContentCache(json: String) { if (json.length <= 1_000_000) prefs().edit().putString("eyeBreakContentCache", json).apply() }
        @JavascriptInterface fun getUsageStatsJson(): String = readOverlayUsageJson()
        @JavascriptInterface fun isBubbleOverlay(): Boolean = true
        @JavascriptInterface fun getAudioControlMode(): String = prefs().getString("audioControlMode", "current") ?: "current"
        @JavascriptInterface fun setAudioControlMode(mode: String) { prefs().edit().putString("audioControlMode", if (mode == "unified") "unified" else "current").apply(); handler.post { applyAssistantAudioAttributes() } }
        @JavascriptInterface fun setAssistantVoice(gender: String) { prefs().edit().putString("assistantVoiceGender", if (gender == "male") "male" else "female").apply(); handler.post { configureAssistantVoice() } }
        @JavascriptInterface fun setAssistantVoiceEngine(engine: String) { prefs().edit().putString("assistantVoiceEngine", if (engine == "old") "old" else "neural").apply() }
        @JavascriptInterface fun isMixerTtsInstalled(): Boolean = OptionalVoicePackBridge.isInstalled(this@FloatingBubbleService)
        @JavascriptInterface fun speakMixerTts(text: String) {
            handler.post {
                val clean = text.trim().take(700)
                if (clean.isBlank()) return@post
                val quranLike = clean.contains("﴿") || clean.contains("﴾") || clean.contains("سورة ") ||
                    (clean.count { it in "ًٌٍَُِّْٰ" } >= 5 && clean.length >= 24)
                val sentToPack = OptionalVoicePackBridge.speak(this@FloatingBubbleService, clean)
                val status = if (sentToPack) "تم إرسال النص إلى حزمة الصوت العصبي الاختيارية" else "حزمة الصوت العصبي غير مثبتة؛ سيُستخدم الصوت القديم"
                runOverlayJs("window.dispatchEvent(new CustomEvent('alislah:neural-voice',{detail:{ok:$sentToPack,detail:" + org.json.JSONObject.quote(status) + "}}));")
                if (!sentToPack) {
                    speakWithAndroidTts(clean.replace("﴿", "، ").replace("﴾", "، ").replace("ۖ", "، ").replace("ۗ", "، "), quranLike)
                }
            }
        }
        @JavascriptInterface fun stopMixerTts() { handler.post { OptionalVoicePackBridge.stop(this@FloatingBubbleService); try { tts?.stop() } catch (_: Exception) { } } }
        @JavascriptInterface fun speakDisplayedAyah(text: String) { handler.post { speak(text.trim().take(700)) } }
        @JavascriptInterface fun stopAssistantSpeech() { handler.post { this@FloatingBubbleService.stopAssistantSpeech() } }
        @JavascriptInterface fun onNeuralSpeechResult(success: Boolean, detail: String) {
            if (!success) handler.post {
                val text = pendingFallbackText
                if (text.isNotBlank()) {
                    val quranLike = text.contains("﴿") || text.contains("﴾") || text.contains("سورة ") ||
                        (text.count { it in "ًٌٍَُِّْٰ" } >= 5 && text.length >= 24)
                    speakWithAndroidTts(if (quranLike) text.replace("﴿", "، ").replace("﴾", "، ").replace("ۖ", "، ").replace("ۗ", "، ") else text, quranLike)
                }
            }
        }
        @JavascriptInterface fun setAssistantVoiceMode(mode: String) { prefs().edit().putString("voiceMode", if (mode == "text" || mode == "voice" || mode == "both") mode else "both").apply() }
        @JavascriptInterface fun testAssistantVoice() { handler.post { speak("مرحبًا بك في الإصلاح. صوت المساعد يعمل الآن.") } }
        @JavascriptInterface fun playAdhanTest() { PrayerScheduler.playAdhan(this@FloatingBubbleService, "اختبار") }
        @JavascriptInterface fun stopAdhan() { handler.post { stopAdhanFromBubble() } }
        @JavascriptInterface fun syncPrayerPlan(itemsJson: String, enabled: Boolean) { PrayerScheduler.sync(this@FloatingBubbleService, itemsJson.take(700000), enabled) }
        @JavascriptInterface fun enableBackgroundQuestions(enabled: Boolean) {
            prefs().edit().putBoolean("backgroundQuestionsEnabled", enabled).putBoolean("backgroundQuestionsConfigured", true).apply()
            if (enabled) BackgroundScheduler.scheduleQuestion(this@FloatingBubbleService, System.currentTimeMillis()+4*60*60*1000L) else BackgroundScheduler.cancelQuestion(this@FloatingBubbleService)
        }
        @JavascriptInterface fun getNativeStatus(): String {
            val notifications = getSystemService(NotificationManager::class.java).areNotificationsEnabled()
            val overlay = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this@FloatingBubbleService)
            val power = getSystemService(android.os.PowerManager::class.java)
            return org.json.JSONObject().put("native", true).put("version", try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (_: Exception) { "" })
                .put("notifications", notifications).put("microphone", checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                .put("overlayEnabled", prefs().getBoolean("overlayEnabled", false)).put("overlayPermission", overlay)
                .put("usage", try { val ops = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager; ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == android.app.AppOpsManager.MODE_ALLOWED } catch (_: Exception) { false })
                .put("battery", power.isIgnoringBatteryOptimizations(packageName)).put("questions", prefs().getBoolean("backgroundQuestionsEnabled", false))
                .put("notificationPolicyAccess", Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted)
                .put("dndModeApplied", prefs().getBoolean("dndModeApplied", false)).put("drivingMode", prefs().getBoolean("drivingMode", false)).toString()
        }
        @JavascriptInterface fun getBubbleBehaviorJson(): String = bubbleBehaviorJson()
        @JavascriptInterface fun setBubbleBehavior(singleTap: String, doubleTap: String, longPress: String, radius: Int, rotate: Boolean) { handler.post { saveBubbleBehavior(singleTap,doubleTap,longPress,radius,rotate) } }
        @JavascriptInterface fun setAssistantEndpoint(url: String) {
            val clean = url.trim()
            if (clean.isEmpty() || AssistantRules.isAllowedEndpoint(clean)) prefs().edit().putString("assistantEndpoint", clean.take(300)).apply()
        }
        @JavascriptInterface fun setHideBubbleInFullscreen(enabled: Boolean) {
            prefs().edit().putBoolean("bubbleHideGamesEnabled", enabled).apply()
            handler.post { if (!enabled) setBubbleHiddenByFullscreen(false) }
        }
        @JavascriptInterface fun setBubbleSwipeAction(action: String) {
            prefs().edit().putString("bubbleSwipeAction", if (action in listOf("menu", "dashboard", "none")) action else "menu").apply()
        }
        @JavascriptInterface fun setDrivingMode(enabled: Boolean) { prefs().edit().putBoolean("drivingMode",enabled).apply() }
        @JavascriptInterface fun requestDndAccess() { handler.post { try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { launchMainApp() } } }
        @JavascriptInterface fun setDndMode(enabled: Boolean): String = setOverlayDndMode(enabled)
        @JavascriptInterface fun requestNotificationPermission() { launchMainAppWithAction("requestNotifications") }
        @JavascriptInterface fun openBatterySettings() { handler.post { try { startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { launchMainApp() } } }
        @JavascriptInterface fun openAppSettings() { handler.post { try { startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { launchMainApp() } } }
        @JavascriptInterface fun requestUsagePermission() { handler.post { try { startActivity(Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS).apply { data = android.net.Uri.parse("package:$packageName"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }) } catch (_: Exception) { launchMainApp() } } }
        @JavascriptInterface fun configureEyeBreak(enabled: Boolean, minutes: Int, seconds: Int) {
            prefs().edit().putBoolean("eyeBreakServiceEnabled", enabled).putInt("eyeBreakMinutes", minutes.coerceIn(1,180)).putInt("eyeBreakSeconds", seconds.coerceIn(5,120)).apply()
            handler.post {
                if (!enabled) stopService(Intent(this@FloatingBubbleService, EyeBreakService::class.java))
                else if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this@FloatingBubbleService)) {
                    val i = Intent(this@FloatingBubbleService, EyeBreakService::class.java).putExtra("minutes", minutes).putExtra("seconds", seconds)
                    try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } catch (_: Exception) { launchMainApp() }
                } else launchMainApp()
            }
        }
        @JavascriptInterface fun enableEyeFilter() {
            prefs().edit().putBoolean("eyeFilterEnabled", true).apply()
            handler.post {
                if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this@FloatingBubbleService)) {
                    try { val i = Intent(this@FloatingBubbleService, EyeFilterService::class.java); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } catch (_: Exception) { launchMainApp() }
                } else launchMainApp()
            }
        }
        @JavascriptInterface fun disableEyeFilter() { prefs().edit().putBoolean("eyeFilterEnabled", false).apply(); handler.post { stopService(Intent(this@FloatingBubbleService, EyeFilterService::class.java)) } }
        @JavascriptInterface fun scheduleTaskReminder(id: String, title: String, atMillis: Long) { if (id.isNotBlank()) ReminderStore.schedule(this@FloatingBubbleService, id.take(120), title.take(180), atMillis) }
        @JavascriptInterface fun cancelTaskReminder(id: String) { if (id.isNotBlank()) ReminderStore.cancel(this@FloatingBubbleService, id.take(120)) }
        @JavascriptInterface fun assistantAnswered() {
            handler.post { handler.removeCallbacks(reshowBubble); hideBubble() }
        }
        @JavascriptInterface fun showBubbleForEvent(question: String) { handler.post { showFollowupOverlay(question.take(260)) } }
        @JavascriptInterface fun isSpeechAvailable(): Boolean = android.speech.SpeechRecognizer.isRecognitionAvailable(this@FloatingBubbleService)
        @JavascriptInterface fun startAssistantListening() { handler.post { startAssistantListening() } }
        @JavascriptInterface fun stopAssistantListening() { handler.post { stopAssistantListening() } }
        @JavascriptInterface fun startListening() { launchMainAppWithAction("startListening") }
        @JavascriptInterface fun stopListening() { launchMainAppWithAction("stopListening") }
        @JavascriptInterface fun requestRuntimePermissions() { launchMainAppWithAction("requestRuntimePermissions") }
        @JavascriptInterface fun enableOverlay() { prefs().edit().putBoolean("overlayEnabled", true).apply(); handler.post { showBubble() } }
        @JavascriptInterface fun disableOverlay() { prefs().edit().putBoolean("overlayEnabled", false).apply(); stopSelf() }
        @JavascriptInterface fun saveBackup(filename: String, json: String) {
            if (json.length > 5_000_000) return
            prefs().edit().putString("overlay_backup_pending", json).putString("overlay_backup_name", filename.take(80)).apply()
            launchMainAppWithAction("saveBackup")
        }
    }

    private fun overlaySpeechStatus(message: String) {
        runOverlayJs("window.__alislahOverlaySpeechStatus && window.__alislahOverlaySpeechStatus(" + org.json.JSONObject.quote(message.take(220)) + ");")
    }

    private fun overlaySpeechPartial(text: String) {
        runOverlayJs("window.__alislahOverlaySpeechPartial && window.__alislahOverlaySpeechPartial(" + org.json.JSONObject.quote(text.take(1200)) + ");")
    }

    private fun startAssistantListening() {
        if (assistantPanel == null || assistantWebView == null) return
        if (!overlayPageReady) {
            handler.postDelayed({ if (assistantPanel != null && !assistantListening) startAssistantListening() }, 250L)
            return
        }
        if (assistantListening) {
            overlaySpeechStatus("🎙️ أستمع إليك الآن…")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            overlaySpeechStatus("اسمح لـ ALISLAH باستخدام الميكروفون لبدء المحادثة الصوتية.")
            launchMainAppWithAction("requestOverlayAssistantMic")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            overlaySpeechStatus("خدمة تحويل الكلام إلى نص غير متوفرة على هذا الجهاز. تحقق من خدمة التعرف الصوتي المثبتة.")
            return
        }
        try {
            stopAssistantRecognizer()
            val recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            assistantRecognizer = recognizer
            assistantListening = true
            setBubbleState("listening")
            overlaySpeechStatus("🎙️ أستمع إليك… تحدث الآن")
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    handler.removeCallbacks(assistantNoSpeechTimeout)
                    handler.postDelayed(assistantNoSpeechTimeout, 3000L)
                    overlaySpeechStatus("🎙️ أنا أستمع إليك…")
                }
                override fun onBeginningOfSpeech() { handler.removeCallbacks(assistantNoSpeechTimeout); overlaySpeechStatus("🎙️ أستمع إلى حديثك…") }
                override fun onRmsChanged(rmsdB: Float) { }
                override fun onBufferReceived(buffer: ByteArray?) { }
                override fun onEndOfSpeech() { overlaySpeechStatus("جارٍ فهم كلامك…") }
                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (partial.isNotBlank()) { handler.removeCallbacks(assistantNoSpeechTimeout); overlaySpeechPartial(partial) }
                }
                override fun onEvent(eventType: Int, params: Bundle?) { }
                override fun onError(error: Int) {
                    handler.removeCallbacks(assistantNoSpeechTimeout)
                    assistantListening = false
                    setBubbleState("idle")
                    val message = when (error) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "إذن الميكروفون غير متاح. اسمح به من إعدادات التطبيق."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "تعذر الاتصال بخدمة التعرف على الكلام. تحقق من الإنترنت أو خدمة الصوت المثبتة."
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "لم ألتقط كلامًا واضحًا. اضغط على فقاعة المساعد الجانبية وحاول مجددًا."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "خدمة التعرف الصوتي مشغولة. حاول بعد لحظة."
                        SpeechRecognizer.ERROR_CLIENT -> "حدث خطأ من جهة جلسة التعرف الصوتي (الرمز 5). أعد المحاولة، وإذا تكرر فتحقق من خدمة التعرف الصوتي الافتراضية في الهاتف."
                        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED -> "خدمة التعرف الصوتي لا تدعم العربية الجزائرية على هذا الجهاز. جرّب تحديث خدمة التعرف أو اختيار العربية المتاحة."
                        SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> "حزمة اللغة العربية غير متاحة حاليًا في خدمة التعرف الصوتي. تحقق من الإنترنت أو نزّل اللغة إن كان ذلك متاحًا."
                        else -> "توقف الاستماع (رمز $error). اضغط الميكروفون لإعادة المحاولة."
                    }
                    overlaySpeechStatus(if (error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) "انتهى الاستماع بعد 3 ثوانٍ من الصمت." else message)
                    stopAssistantRecognizer()
                }
                override fun onResults(results: Bundle?) {
                    handler.removeCallbacks(assistantNoSpeechTimeout)
                    assistantListening = false
                    setBubbleState("thinking")
                    val transcript = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                    if (transcript.isNotBlank() && executeOfflineVoiceCommand(transcript)) {
                        overlaySpeechStatus("تم تنفيذ الأمر محليًا دون اتصال بالإنترنت.")
                        setBubbleState("idle")
                    } else if (transcript.isNotBlank()) {
                        overlaySpeechStatus("فهمت كلامك؛ أجهز الرد…")
                        runOverlayJs("window.__alislahOverlaySpeechResult && window.__alislahOverlaySpeechResult(" + org.json.JSONObject.quote(transcript.take(1200)) + ");")
                    } else overlaySpeechStatus("لم أتعرف على كلامك. اضغط الميكروفون وحاول مجددًا.")
                    stopAssistantRecognizer()
                }
            })
            val request = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-DZ")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-DZ")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
            }
            recognizer.startListening(request)
            handler.removeCallbacks(assistantNoSpeechTimeout)
            handler.postDelayed(assistantNoSpeechTimeout, 3000L)
        } catch (_: Exception) {
            assistantListening = false
            setBubbleState("idle")
            stopAssistantRecognizer()
            overlaySpeechStatus("تعذر تشغيل الميكروفون. تحقق من الإذن وخدمة التعرف الصوتي.")
        }
    }

    private fun stopAssistantListening() {
        handler.removeCallbacks(assistantNoSpeechTimeout)
        if (!assistantListening) {
            stopAssistantRecognizer()
            return
        }
        assistantListening = false
        setBubbleState("idle")
        try { assistantRecognizer?.stopListening() } catch (_: Exception) { }
        overlaySpeechStatus("توقف الاستماع. جارٍ إكمال تحويل الكلام…")
    }

    private fun stopAssistantRecognizer() {
        handler.removeCallbacks(assistantNoSpeechTimeout)
        try { assistantRecognizer?.cancel() } catch (_: Exception) { }
        try { assistantRecognizer?.destroy() } catch (_: Exception) { }
        assistantRecognizer = null
    }

    private fun launchMainAppWithAction(action: String) {
        handler.post {
            val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("overlayBridgeAction", action)
            try { startActivity(intent) } catch (_: Exception) { }
        }
    }

    private fun launchMainApp() {
        val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try { startActivity(intent) } catch (_: Exception) { }
    }

    private fun readOverlayUsageJson(): String {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        val allowed = appOps.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == android.app.AppOpsManager.MODE_ALLOWED
        val result = org.json.JSONObject().put("permission", allowed)
        val apps = org.json.JSONArray()
        if (allowed) {
            try {
                val manager = getSystemService(Context.USAGE_STATS_SERVICE) as android.app.usage.UsageStatsManager
                val calendar = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY,0); set(java.util.Calendar.MINUTE,0); set(java.util.Calendar.SECOND,0); set(java.util.Calendar.MILLISECOND,0) }
                val stats: List<android.app.usage.UsageStats> = manager.queryAndAggregateUsageStats(calendar.timeInMillis, System.currentTimeMillis())?.values?.toList() ?: emptyList()
                val grouped = stats.filter { it.totalTimeInForeground > 0 && it.packageName != packageName }
                    .groupBy { it.packageName }.map { (pkg, rows) -> pkg to rows.sumOf { it.totalTimeInForeground } }
                    .sortedByDescending { it.second }.take(20)
                for ((pkg, millis) in grouped) {
                    val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg,0)).toString() } catch (_: Exception) { pkg }
                    apps.put(org.json.JSONObject().put("packageName",pkg).put("name",label).put("minutes",(millis/60000.0).toInt()))
                }
            } catch (_: Exception) { }
        }
        return result.put("apps",apps).put("foreground",org.json.JSONObject().put("name","غير متاح").put("packageName","").put("approximate",true)).put("collectedAt",System.currentTimeMillis()).toString()
    }

    private fun executeOfflineVoiceCommand(raw: String): Boolean {
        val command = OfflineCommandRouter.parse(raw) ?: return false
        when (command.type) {
            OfflineCommandRouter.Type.OPEN_TAB -> {
                val i = Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    putExtra("openTab", command.value)
                }
                try { startActivity(i) } catch (_: Exception) { return false }
            }
            OfflineCommandRouter.Type.READ_ZAD -> {
                showAssistantOverlay("content")
                handler.postDelayed({ runOverlayJs("document.getElementById('contentRead')?.click();") }, 900L)
            }
            OfflineCommandRouter.Type.STOP_ADHAN -> stopAdhanFromBubble()
            OfflineCommandRouter.Type.STOP_ASSISTANT -> stopAssistantSpeech()
            OfflineCommandRouter.Type.MOVE_BUBBLE_LEFT -> moveBubbleToLeftEdge()
        }
        return true
    }

    private fun showFollowupOverlay(question: String = "ما أكثر شيء يشغل وقتك الآن؟") {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            launchMainApp(); return
        }
        if (!prefs().getBoolean("overlayEnabled", false)) { launchMainApp(); return }
        if (bubble == null) showBubble()
        if (bubble == null) { launchMainApp(); return }
        showPrayerReminder("سؤال متابعة", question.ifBlank { "ما أكثر شيء يشغل وقتك الآن؟" }, true)
    }

    /** Opens a compact task picker inside the existing floating web panel, then executes the chosen action locally. */
    private fun showTaskQuickAction(command: String) {
        val mode = if (command == "quickComplete") "complete" else "postpone"
        showAssistantOverlay("plan")
        fun present(attempt: Int) {
            val web = assistantWebView
            if (web == null || !overlayPageReady) {
                if (attempt < 20) handler.postDelayed({ present(attempt + 1) }, 250L)
                else overlaySpeechStatus("تعذر تحميل قائمة المهام. افتحي نافذة المهام ثم أعيدي المحاولة.")
                return
            }
            web.evaluateJavascript("window.__alislahShowQuickTaskAction && window.__alislahShowQuickTaskAction(" + org.json.JSONObject.quote(mode) + ")", null)
        }
        handler.postDelayed({ present(0) }, 450L)
    }

    private fun showAssistantOverlay(command: String = "ask") {
        hideQuickMenu()
        if (command == "ask" || command == "plan") setBubbleState("waiting")
        else setBubbleState("idle")
        lastSpokenReply = ""
        if (assistantPanel != null) {
            assistantPanel?.visibility = View.VISIBLE
            if (activeOverlayCommand != command) {
                activeOverlayCommand = command
                // Keep the same WebView alive: switching side bubbles changes the view in-place,
                // avoiding a destroyed/recreated window, white flash, and overlapping overlays.
                val root = assistantPanel as? LinearLayout
                (root?.getChildAt(0) as? LinearLayout)?.let { bar ->
                    (bar.getChildAt(0) as? TextView)?.text = when (command) {
                        "prayer" -> "ALISLAH · الصلاة والأذان"
                        "plan" -> "ALISLAH · المهام والخطة"
                        "behavior" -> "ALISLAH · تحليل العادات"
                        "habits" -> "ALISLAH · العادات"
                        "family" -> "ALISLAH · الأسرة"
                        "settings" -> "ALISLAH · الإعدادات"
                        "voice" -> "ALISLAH · صوت المساعد"
                        "eye" -> "ALISLAH · راحة العين"
                        else -> "ALISLAH · المساعد الذكي"
                    }
                }
                // The ribbon belongs to the previous panel; hide it rather than show stale actions.
                root?.getChildAt(1)?.visibility = View.GONE
                val target = overlayTargetFor(command)
                runOverlayJs("window.__alislahOverlayTarget='$target';if(typeof tab==='function')tab('$target');else document.querySelectorAll('.view').forEach(x=>x.classList.toggle('active',x.id==='$target'))")
                handler.removeCallbacks(pollReply)
                if (target == "assistant" && command != "question") handler.postDelayed(pollReply, 700L)
            }
            if (command != "ask") { assistantListening = false; stopAssistantRecognizer() }
            if (command == "question" || command == "followup") { autoListenAfterSpeech = true; speak("ما أكثر شيء يشغل وقتك الآن؟") }
            selectOverlaySection(command)
            if (command == "ask") handler.postDelayed({ startAssistantListening() }, 300L)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("openAssistant", true)
            }
            startActivity(launch)
            return
        }
        val density = resources.displayMetrics.density
        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val panelWidth = (screenWidth - 82 * density).toInt().coerceAtLeast((245 * density).toInt())
        val panelHeight = (screenHeight * 0.72f).toInt().coerceAtMost((screenHeight - 28 * density).toInt()).coerceAtLeast((360 * density).toInt())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            elevation = 18 * density
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = 18 * density
                setStroke((1 * density).toInt(), Color.rgb(220, 231, 226))
            }
            clipToOutline = true
            // Android delivers ACTION_OUTSIDE because the window watches outside touches.
            setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_OUTSIDE && !assistantPanelPinned) {
                    hideAssistantOverlay()
                    true
                } else event.actionMasked == MotionEvent.ACTION_OUTSIDE
            }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((12*density).toInt(), (5*density).toInt(), (8*density).toInt(), (5*density).toInt())
            setBackgroundColor(Color.rgb(23, 107, 91))
        }
        val title = TextView(this).apply {
            text = "ALISLAH · اسألي هنا"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, (44*density).toInt(), 1f)
        }
        val microphone = TextView(this).apply {
            text = "🎙"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = "بدء الاستماع للمساعد"
            layoutParams = LinearLayout.LayoutParams((44*density).toInt(), (44*density).toInt())
            setOnClickListener { startAssistantListening() }
        }
        assistantPanelPinned = prefs().getBoolean("overlayPanelPinned", false)
        val pin = TextView(this).apply {
            text = if (assistantPanelPinned) "📌" else "📍"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = if (assistantPanelPinned) "إلغاء تثبيت النافذة" else "تثبيت النافذة"
            layoutParams = LinearLayout.LayoutParams((42*density).toInt(), (44*density).toInt())
            setOnClickListener {
                assistantPanelPinned = !assistantPanelPinned
                prefs().edit().putBoolean("overlayPanelPinned", assistantPanelPinned).apply()
                text = if (assistantPanelPinned) "📌" else "📍"
                contentDescription = if (assistantPanelPinned) "إلغاء تثبيت النافذة" else "تثبيت النافذة"
            }
        }
        val close = TextView(this).apply {
            text = "×"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = "إغلاق نافذة المساعد"
            layoutParams = LinearLayout.LayoutParams((44*density).toInt(), (44*density).toInt())
            setOnClickListener { hideAssistantOverlay() }
        }
        bar.addView(title); bar.addView(microphone); bar.addView(pin); bar.addView(close); root.addView(bar)
        // A distinct tool ribbon belongs to the selected side bubble; the circular bubble layout remains unchanged.
        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((7*density).toInt(), (6*density).toInt(), (7*density).toInt(), (6*density).toInt())
            setBackgroundColor(Color.rgb(231, 242, 237))
        }
        fun addTool(label: String, js: String) {
            val button = TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(20, 91, 76))
                setPadding((8*density).toInt(), (8*density).toInt(), (8*density).toInt(), (8*density).toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.WHITE); cornerRadius = 11*density
                    setStroke((1*density).toInt(), Color.rgb(195, 219, 208))
                }
                setOnClickListener { runOverlayJs(js) }
            }
            tools.addView(button, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = (3*density).toInt(); marginEnd = (3*density).toInt()
            })
        }
        when (command) {
            "prayer" -> {
                title.text = "ALISLAH · الصلاة والأذان"
                addTool("تحديث المواقيت", "document.getElementById('prayerRefresh')?.click()")
                addTool("تشغيل/إيقاف الصوت", "document.getElementById('prayerAdhanEnabled')?.click()")
                addTool("اختبار الصوت", "document.getElementById('prayerAdhanTest')?.click()")
            }
            "plan" -> {
                title.text = "ALISLAH · المهام والخطة"
                addTool("المهام", "if(typeof tab==='function')tab('tasks')")
                addTool("إضافة مهمة", "document.getElementById('taskText')?.focus()")
                addTool("المساعد", "if(typeof tab==='function')tab('assistant')")
            }
            "behavior" -> {
                title.text = "ALISLAH · تحليل العادات"
                addTool("تحليل الآن", "document.getElementById('analyzeBehavior')?.click()")
                addTool("العادات", "if(typeof tab==='function')tab('habits')")
            }
            "habits" -> {
                title.text = "ALISLAH · العادات"
                addTool("إضافة عادة", "document.getElementById('habitText')?.focus()")
                addTool("تحليل", "if(typeof tab==='function')tab('behavior')")
            }
            "family" -> {
                title.text = "ALISLAH · الأسرة"
                addTool("المساعد", "if(typeof tab==='function')tab('assistant')")
                addTool("المهام", "if(typeof tab==='function')tab('tasks')")
            }
            "settings" -> {
                title.text = "ALISLAH · الإعدادات"
                addTool("حفظ الإعدادات", "document.getElementById('saveSettings')?.click()")
                addTool("الصلاة", "if(typeof tab==='function')tab('prayer')")
            }
            else -> {
                title.text = "ALISLAH · المساعد الذكي"
                addTool("سؤال جديد", "document.getElementById('chatText')?.focus()")
                addTool("الخطة", "if(typeof tab==='function')tab('tasks')")
                addTool("تحليل", "if(typeof tab==='function')tab('behavior')")
            }
        }
        root.addView(tools)
        overlayPageReady = false
        pendingOverlayScripts.clear()
        val web = WebView(this).apply {
            addJavascriptInterface(OverlayNativeBridge(), "AndroidUsage")
            addJavascriptInterface(object {
                @JavascriptInterface fun getAppDataJson(): String = prefs().getString("alislah_app_data", "{}") ?: "{}"
                @JavascriptInterface fun getEyeBreakContentCache(): String = prefs().getString("eyeBreakContentCache", "{}") ?: "{}"
                @JavascriptInterface fun saveAppDataJson(json: String) { if (json.length <= 2_000_000) { prefs().edit().putString("alislah_app_data", json).apply(); refreshBubbleIndicator() } }
        @JavascriptInterface fun setBubbleState(state: String) { handler.post { this@FloatingBubbleService.setBubbleState(state) } }
                @JavascriptInterface fun saveEyeBreakContentCache(json: String) { if (json.length <= 1_000_000) prefs().edit().putString("eyeBreakContentCache", json).apply() }
            }, "ALISLAHStore")
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    val hasAudio = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    if (hasAudio && request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else request.deny()
                }
            }
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    val script = """(function(){
                      document.querySelector('header.top')?.style.setProperty('display','none','important');
                      document.querySelector('.hero')?.style.setProperty('display','none','important');
                      document.querySelector('.stats')?.style.setProperty('display','none','important');
                      document.querySelector('.tabs')?.style.setProperty('display','none','important');
                      const target = window.__alislahOverlayTarget || 'assistant';
                      document.querySelectorAll('.view').forEach(x=>x.classList.toggle('active',x.id===target));
                      document.querySelectorAll('#alislahFloat,#alislahCheckin,.footer,#nativeOverlayControls').forEach(x=>x.style.display='none');
                      const app=document.querySelector('.app'); if(app){app.style.cssText='padding:0;margin:0;max-width:none;width:100%;';}
                      const chat=document.querySelector('#assistant .chat'); if(chat){chat.style.cssText='min-height:0;height:auto;padding:5px;margin:0;';}
                      const msgs=document.getElementById('messages'); if(msgs){msgs.style.cssText='min-height:45px;max-height:105px;overflow-y:auto;padding:5px;margin:0;';}
                      const form=document.getElementById('chatForm'); if(form){form.style.cssText='display:flex;gap:5px;margin:5px 0 0;';}
                      const input=document.getElementById('chatText'); if(input){input.placeholder='اكتبي سؤالك هنا…';input.style.minHeight='38px';}
                      const consent=document.getElementById('chatConsentWrap'); if(consent) consent.style.display='none';
                      const panel=document.getElementById(target); if(panel){panel.style.setProperty('margin','0','important');panel.style.setProperty('padding','8px','important');panel.style.setProperty('overflow-y','auto','important');}
                      document.body.style.cssText='margin:0;padding:0;background:#f3f7f5;overflow-y:auto;overflow-x:hidden;';
                      document.documentElement.style.cssText='height:100%;overflow:auto;';
                    })();"""
                    val loadedView = view ?: return
                    loadedView.evaluateJavascript(script) {
                        overlayPageReady = true
                        loadedView.evaluateJavascript("(function(){var x=document.querySelector('#messages .bubble.assistant:last-child');return x?(x.innerText||x.textContent||''):''})()") { rawReply ->
                            lastSpokenReply = try { org.json.JSONTokener(rawReply ?: "").nextValue() as? String ?: "" } catch (_: Exception) { "" }
                        }
                        while (pendingOverlayScripts.isNotEmpty()) {
                            val next = pendingOverlayScripts.removeFirst()
                            loadedView.evaluateJavascript(next, null)
                        }
                    }
                }
            }
        }
        assistantWebView = web
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val resizeHandle = TextView(this).apply {
            text = "⋰  تغيير الحجم"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(65, 105, 91))
            setBackgroundColor(Color.rgb(235, 244, 239))
            contentDescription = "اسحب لتغيير حجم النافذة"
            setPadding(0, (3*density).toInt(), 0, (3*density).toInt())
        }
        root.addView(resizeHandle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (28*density).toInt()))
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val anchor = params
        val minPanelWidth = (250*density).toInt()
        val minPanelHeight = (300*density).toInt()
        val maxPanelWidth = (screenWidth - 16*density).toInt().coerceAtLeast(minPanelWidth)
        val maxPanelHeight = (screenHeight - 24*density).toInt().coerceAtLeast(minPanelHeight)
        val savedWidth = prefs().getInt("overlayPanelWidth", panelWidth).coerceIn(minPanelWidth, maxPanelWidth)
        val savedHeight = prefs().getInt("overlayPanelHeight", panelHeight).coerceIn(minPanelHeight, maxPanelHeight)
        val savedXRatio = prefs().getFloat("overlayPanelXRatio", -1f)
        val savedYRatio = prefs().getFloat("overlayPanelYRatio", -1f)
        val lp = WindowManager.LayoutParams(savedWidth, savedHeight, type, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (savedXRatio in 0f..1f) (savedXRatio*screenWidth).toInt().coerceIn(0, (screenWidth-savedWidth).coerceAtLeast(0)) else (anchor?.x ?: 10).coerceIn(0, (screenWidth-savedWidth).coerceAtLeast(0))
            y = if (savedYRatio in 0f..1f) (savedYRatio*screenHeight).toInt().coerceIn(0, (screenHeight-savedHeight).coerceAtLeast(0)) else ((anchor?.y ?: (screenHeight/3)) + (70*density).toInt()).coerceIn(0, (screenHeight-savedHeight).coerceAtLeast(0))
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        fun savePanelGeometry() {
            val w = resources.displayMetrics.widthPixels.coerceAtLeast(1)
            val h = resources.displayMetrics.heightPixels.coerceAtLeast(1)
            prefs().edit()
                .putInt("overlayPanelWidth", lp.width)
                .putInt("overlayPanelHeight", lp.height)
                .putFloat("overlayPanelXRatio", lp.x.toFloat()/w)
                .putFloat("overlayPanelYRatio", lp.y.toFloat()/h)
                .apply()
        }
        title.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { startX = lp.x; startY = lp.y; touchX = event.rawX; touchY = event.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    if (!assistantPanelPinned) {
                        val maxX = (resources.displayMetrics.widthPixels-lp.width).coerceAtLeast(0)
                        val maxY = (resources.displayMetrics.heightPixels-lp.height).coerceAtLeast(0)
                        lp.x = (startX + event.rawX-touchX).toInt().coerceIn(0,maxX)
                        lp.y = (startY + event.rawY-touchY).toInt().coerceIn(0,maxY)
                        try { windowManager.updateViewLayout(root,lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> { savePanelGeometry(); true }
                MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
        resizeHandle.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { startX=lp.width; startY=lp.height; touchX=event.rawX; touchY=event.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    val maxW=(resources.displayMetrics.widthPixels-16*density).toInt().coerceAtLeast(minPanelWidth)
                    val maxH=(resources.displayMetrics.heightPixels-24*density).toInt().coerceAtLeast(minPanelHeight)
                    lp.width=(startX+event.rawX-touchX).toInt().coerceIn(minPanelWidth,maxW)
                    lp.height=(startY+event.rawY-touchY).toInt().coerceIn(minPanelHeight,maxH)
                    lp.x=lp.x.coerceIn(0,(resources.displayMetrics.widthPixels-lp.width).coerceAtLeast(0))
                    lp.y=lp.y.coerceIn(0,(resources.displayMetrics.heightPixels-lp.height).coerceAtLeast(0))
                    try { windowManager.updateViewLayout(root,lp) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> { savePanelGeometry(); true }
                MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
        try {
            windowManager.addView(root, lp)
            assistantPanel = root
            savePanelGeometry()
            activeOverlayCommand = command
            val target = when(command) {
                "settings" -> "settings"
                "behavior" -> "behavior"
                "plan" -> "tasks"
                "family" -> "family"
                "prayer" -> "prayer"
                "habits" -> "habits"
                "eye" -> "settings"
                "voice" -> "assistant"
                "content" -> "more"
                else -> "assistant"
            }
            web.loadUrl("file:///android_asset/index.html")
            web.postVisualStateCallback(0L, object : WebView.VisualStateCallback() {
                override fun onComplete(requestId: Long) {
                    runOverlayJs("window.__alislahOverlayTarget='$target';if(typeof tab==='function'){tab('$target')}else{document.querySelectorAll('.view').forEach(x=>x.classList.toggle('active',x.id==='$target'))}")
                    if (target == "assistant" && command != "question") { handler.removeCallbacks(pollReply); handler.postDelayed(pollReply, 700L) }
                    if (command == "question" || command == "followup") { autoListenAfterSpeech = true; speak("ما أكثر شيء يشغل وقتك الآن؟") }
                    selectOverlaySection(command)
                    if (command == "ask") handler.postDelayed({ startAssistantListening() }, 550L)
                }
            })
        } catch (_: Exception) {
            assistantPanel = null
            assistantWebView = null
            activeOverlayCommand = null
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("openAssistant", true)
            }
            startActivity(launch)
        }
    }

    private fun overlayTargetFor(command: String): String = when (command) {
        "settings", "eye" -> "settings"
        "behavior" -> "behavior"
        "plan" -> "tasks"
        "miniDashboard" -> "tasks"
        "testcenter" -> "testcenter"
        "family" -> "family"
        "prayer" -> "prayer"
        "habits" -> "habits"
        "voice", "question", "followup", "ask" -> "assistant"
        "content" -> "more"
        else -> "assistant"
    }

    private fun selectOverlaySection(command: String) {
        val js = when(command) {
            "testcenter" -> "window.ALI?.tab?.('testcenter');"
            "settings" -> "if(typeof tab==='function')tab('settings');else document.querySelector('[data-tab=\"settings\"]')?.click();"
            "behavior" -> "if(typeof tab==='function')tab('behavior');else document.querySelector('[data-tab=\"behavior\"]')?.click();"
            "plan", "miniDashboard" -> "if(typeof tab==='function')tab('tasks');else document.querySelector('[data-tab=\"tasks\"]')?.click();"
            "family" -> "if(typeof tab==='function')tab('family');else document.querySelector('[data-tab=\"family\"]')?.click();"
            "prayer" -> "if(typeof tab==='function')tab('prayer');else document.querySelector('[data-tab=\"prayer\"]')?.click();"
            "habits" -> "if(typeof tab==='function')tab('habits');else document.querySelector('[data-tab=\"habits\"]')?.click();"
            "eye" -> "if(typeof tab==='function')tab('settings');else document.querySelector('[data-tab=\"settings\"]')?.click();setTimeout(()=>document.getElementById('eyeBreakEnabled')?.scrollIntoView({block:'center'}),180);"
            "voice" -> "if(typeof tab==='function')tab('assistant');else document.querySelector('[data-tab=\"assistant\"]')?.click();setTimeout(()=>document.getElementById('alislahVoiceGender')?.scrollIntoView({block:'center'}),180);"
            "question", "followup" -> "if(typeof tab==='function')tab('assistant');if(window.__alislahShowFollowupQuestion)window.__alislahShowFollowupQuestion('ما أكثر شيء يشغل وقتك الآن؟');var q=document.getElementById('chatText');if(q)q.focus();"
            "content" -> "if(typeof tab==='function')tab('more');setTimeout(function(){document.getElementById('alislahContentPanel')?.scrollIntoView({block:'center'});},180);"
            else -> "if(typeof tab==='function')tab('assistant');else document.querySelector('[data-tab=\"assistant\"]')?.click();document.getElementById('chatText')?.focus();"
        }
        runOverlayJs(js)
    }

    private fun hideAssistantOverlay() {
        autoListenAfterSpeech = false
        assistantListening = false
        stopAssistantRecognizer()
        handler.removeCallbacks(pollReply)
        overlayPageReady = false
        pendingOverlayScripts.clear()
        assistantWebView?.stopLoading()
        assistantWebView?.destroy()
        assistantWebView = null
        assistantPanel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        assistantPanel = null
        activeOverlayCommand = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel("alislah_bubble", "فقاعة ALISLAH", NotificationManager.IMPORTANCE_LOW).apply { description = "إبقاء الفقاعة العائمة متاحة فوق التطبيقات" })
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "alislah_bubble").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("فقاعة ALISLAH مفعّلة").setContentText("ضغط مطوّل لإضافة مهمة صوتيًا، ضغطة للفقاعات الجانبية، وضغطتان لفتح التطبيق").setContentIntent(open).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("فقاعة ALISLAH مفعّلة").setContentText("ضغط مطوّل لإضافة مهمة صوتيًا، ضغطة للفقاعات الجانبية، وضغطتان لفتح التطبيق").setContentIntent(open).setOngoing(true).build()
        }
    }

    private var pendingDisplayReflow: Runnable? = null

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Android may deliver the configuration callback before WindowManager has
        // published the new physical display metrics/rotation. Reflow only after
        // those values have settled, otherwise the old geometry gets cached again.
        pendingDisplayReflow?.let { handler.removeCallbacks(it) }
        val snapshot = Configuration(newConfig)
        val task = Runnable {
            pendingDisplayReflow = null
            applyDisplayConfiguration(snapshot)
        }
        pendingDisplayReflow = task
        handler.postDelayed(task, 350L)
    }

    private fun applyDisplayConfiguration(newConfig: Configuration) {
        restoreAutoHiddenBubble()
        val main = bubble ?: return
        val lp = params ?: return
        val wasMenuVisible = quickMenu != null
        val openCommand = activeOverlayCommand
        hideQuickMenu()
        // The orbit is display-relative, not a physical direction that should
        // survive a 90/180/270 degree turn. Start from its canonical layout.
        orbitRotation = 0.0

        val d = resources.displayMetrics.density
        val (newW, newH) = realScreenSize()
        val oldW = lastBubbleScreenWidth.takeIf { it > 0 } ?: newW
        val oldH = lastBubbleScreenHeight.takeIf { it > 0 } ?: newH
        val oldCenterX = (lp.x + lp.width / 2f).coerceIn(0f, oldW.toFloat())
        val oldCenterY = (lp.y + lp.height / 2f).coerceIn(0f, oldH.toFloat())
        val xRatio = if (oldW > 0) oldCenterX / oldW else 0.5f
        val yRatio = if (oldH > 0) oldCenterY / oldH else 0.5f
        val oldOrientation = lastConfigOrientation.takeIf { it != Configuration.ORIENTATION_UNDEFINED }
            ?: if (oldW > oldH) Configuration.ORIENTATION_LANDSCAPE else Configuration.ORIENTATION_PORTRAIT
        rememberBubbleAnchor(oldOrientation, lp, oldW, oldH)
        val newOrientation = if (newW > newH) Configuration.ORIENTATION_LANDSCAPE else Configuration.ORIENTATION_PORTRAIT

        // Rotate within the same orientation, but restore a separate saved anchor when
        // switching between portrait and landscape.
        val newRotation = try { windowManager.defaultDisplay.rotation } catch (_: Exception) { lastDisplayRotation }
        val rotationDelta = (newRotation - lastDisplayRotation + 4) % 4
        val mappedRatios = when (rotationDelta) {
            1 -> Pair(1f - yRatio, xRatio)       // 90 degrees clockwise
            2 -> Pair(1f - xRatio, 1f - yRatio)  // 180 degrees
            3 -> Pair(yRatio, 1f - xRatio)       // 270 degrees clockwise
            else -> Pair(xRatio, yRatio)
        }
        val savedRatios = if (newOrientation == Configuration.ORIENTATION_LANDSCAPE) {
            if (oldOrientation != newOrientation && landscapeAnchorXRatio != null && landscapeAnchorYRatio != null)
                Pair(landscapeAnchorXRatio!!, landscapeAnchorYRatio!!) else mappedRatios
        } else {
            if (oldOrientation != newOrientation && portraitAnchorXRatio != null && portraitAnchorYRatio != null)
                Pair(portraitAnchorXRatio!!, portraitAnchorYRatio!!) else mappedRatios
        }
        val mappedX = savedRatios.first * newW
        val mappedY = savedRatios.second * newH
        lastDisplayRotation = newRotation
        lastConfigOrientation = newOrientation
        val nearest = edgeDistances(mappedX, mappedY, newW, newH).minByOrNull { it.second }?.first ?: "left"
        val mainView = main as? MainBubbleView
        if (mainView != null) {
            dockMainBubble(mainView, lp, nearest, newW, newH, mappedX.toInt(), mappedY.toInt())
        }
        lastBubbleScreenWidth = newW
        lastBubbleScreenHeight = newH
        rememberBubbleAnchor(newOrientation, lp, newW, newH)
        try { windowManager.updateViewLayout(main, lp) } catch (_: Exception) { }
        main.invalidate()
        syncReminderOverlay(lp)
        syncAdhanMuteBubble()
        syncAssistantStopBubble()
        if (wasMenuVisible) showQuickMenu(lp)
        if (quickAsk?.isShowing == true) quickAsk?.place(quickAskRect())
        if (openCommand != null) {
            val panel = assistantPanel
            val panelLp = panel?.layoutParams as? WindowManager.LayoutParams
            if (panel != null && panelLp != null) {
                val minW=(250*d).toInt(); val minH=(300*d).toInt()
                panelLp.width = panelLp.width.coerceIn(minW,(newW-16*d).toInt().coerceAtLeast(minW))
                panelLp.height = panelLp.height.coerceIn(minH,(newH-24*d).toInt().coerceAtLeast(minH))
                if (assistantPanelPinned) {
                    panelLp.x = (prefs().getFloat("overlayPanelXRatio",0.5f)*newW).toInt().coerceIn(0,(newW-panelLp.width).coerceAtLeast(0))
                    panelLp.y = (prefs().getFloat("overlayPanelYRatio",0.25f)*newH).toInt().coerceIn(0,(newH-panelLp.height).coerceAtLeast(0))
                } else {
                    panelLp.x = (lp.x + lp.width / 2 - panelLp.width / 2).coerceIn(0, (newW - panelLp.width).coerceAtLeast(0))
                    panelLp.y = (lp.y + lp.height / 2 + (18 * d).toInt()).coerceIn(0, (newH - panelLp.height).coerceAtLeast(0))
                }
                try { windowManager.updateViewLayout(panel, panelLp) } catch (_: Exception) { }
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(reshowBubble)
        handler.removeCallbacks(fullscreenCheck)
        handler.removeCallbacks(pollReply)
        mainLongPressRunnable?.let { handler.removeCallbacks(it) }
        pendingDisplayReflow?.let { handler.removeCallbacks(it) }
        pendingDisplayReflow = null
        pendingMainTap?.let { handler.removeCallbacks(it) }
        pendingMainTap = null
        hideCloseButton()
        hideQuickMenu()
        hideReminderViews()
        hideAdhanMuteBubble()
        hideAssistantStopBubble()
        stopAssistantListening()
        hideAssistantOverlay()
        quickAsk?.hide()
        quickAsk = null
        stopQuickAskVoice()
        closeAllMiniWindows(clearSaved = false)
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        tts = null
        if (liveInstance === this) liveInstance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        @Volatile private var liveInstance: FloatingBubbleService? = null
        fun refreshLiveIndicator() { liveInstance?.let { service -> service.handler.post { service.refreshBubbleIndicator() } } }
        fun setLiveBubbleState(state: String) { liveInstance?.let { service -> service.handler.post { service.setBubbleState(state) } } }
        fun showPrayerReminder(context: Context, title: String, text: String, temporaryTest: Boolean = false) {
            if (text.isBlank()) return
            val prefs = context.getSharedPreferences("alislah_native", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("overlayEnabled", false) && !temporaryTest) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) return
            val running = liveInstance
            if (running != null) {
                running.handler.post {
                    if (running.ensureBubbleForTimedEvent(temporaryTest)) running.showPrayerReminder(title, text, true)
                    if (temporaryTest && !prefs.getBoolean("overlayEnabled", false)) running.handler.postDelayed({ if (!prefs.getBoolean("overlayEnabled", false)) running.hideBubble() }, 15000L)
                }
                return
            }
            val intent = Intent(context, FloatingBubbleService::class.java).apply {
                action = ACTION_SHOW_REMINDER
                putExtra(EXTRA_REMINDER_TITLE, title.take(100))
                putExtra(EXTRA_REMINDER_TEXT, text.take(700))
                putExtra(EXTRA_TEMPORARY_TEST, temporaryTest)
            }
            try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent) } catch (_: Exception) { }
        }
        fun showFollowupQuestion(context: Context, question: String, temporaryTest: Boolean = false) {
            val prefs = context.getSharedPreferences("alislah_native", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("overlayEnabled", false) && !temporaryTest) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) return
            val intent = Intent(context, FloatingBubbleService::class.java).apply {
                action = ACTION_SHOW_FOR_EVENT
                putExtra(EXTRA_FOLLOWUP_TEXT, question.take(260))
                putExtra(EXTRA_TEMPORARY_TEST, temporaryTest)
            }
            try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent) } catch (_: Exception) { }
        }
        fun notifyAdhanPlaybackState(context: Context, active: Boolean) {
            liveInstance?.let { service ->
                service.handler.post { service.applyAdhanBubbleState(active) }
                return
            }
            val prefs = context.getSharedPreferences("alislah_native", Context.MODE_PRIVATE)
            if (!prefs.getBoolean("overlayEnabled", false)) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) return
            val intent = Intent(context, FloatingBubbleService::class.java).apply {
                action = if (active) ACTION_ADHAN_STARTED else ACTION_ADHAN_STOPPED
            }
            try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent) } catch (_: Exception) { }
        }
        const val ACTION_SET_BUBBLE_STATE = "dz.alislah.app.ACTION_SET_BUBBLE_STATE"
        const val ACTION_DATA_UPDATED = "dz.alislah.app.ACTION_DATA_UPDATED"
        const val ACTION_REFRESH_BUBBLE_CONFIG = "dz.alislah.app.ACTION_REFRESH_BUBBLE_CONFIG"
        const val ACTION_RESTORE_AFTER_BOOT = "dz.alislah.app.ACTION_RESTORE_AFTER_BOOT"
        const val ACTION_TEST_BUBBLE = "dz.alislah.app.ACTION_TEST_BUBBLE"
        const val EXTRA_BUBBLE_STATE = "dz.alislah.app.EXTRA_BUBBLE_STATE"
        const val ACTION_ANSWERED = "dz.alislah.app.ACTION_ASSISTANT_ANSWERED"
        const val ACTION_SHOW_FOR_EVENT = "dz.alislah.app.ACTION_SHOW_BUBBLE_FOR_EVENT"
        const val ACTION_MOVE_BUBBLE_LEFT = "dz.alislah.app.ACTION_MOVE_BUBBLE_LEFT"
        const val EXTRA_FOLLOWUP_TEXT = "followup_text"
        const val ACTION_HIDE_PANEL = "dz.alislah.app.ACTION_HIDE_PANEL"
        const val ACTION_SPEAK_TEST = "dz.alislah.app.ACTION_SPEAK_TEST"
        const val ACTION_SPEAK_TEXT = "dz.alislah.app.ACTION_SPEAK_TEXT"
        const val ACTION_START_ASSISTANT_LISTENING = "dz.alislah.app.ACTION_START_ASSISTANT_LISTENING"
        const val ACTION_STOP_ASSISTANT_LISTENING = "dz.alislah.app.ACTION_STOP_ASSISTANT_LISTENING"
        const val ACTION_ASSISTANT_MIC_PERMISSION_RESULT = "dz.alislah.app.ACTION_ASSISTANT_MIC_PERMISSION_RESULT"
        const val EXTRA_ASSISTANT_MIC_GRANTED = "assistant_mic_granted"
        const val ACTION_STOP_SPEECH = "dz.alislah.app.ACTION_STOP_SPEECH"
        const val ACTION_ADHAN_STARTED = "dz.alislah.app.ACTION_ADHAN_STARTED"
        const val ACTION_ADHAN_STOPPED = "dz.alislah.app.ACTION_ADHAN_STOPPED"
        const val ACTION_SHOW_REMINDER = "dz.alislah.app.ACTION_SHOW_PRAYER_REMINDER"
        const val EXTRA_REMINDER_TITLE = "reminder_title"
        const val EXTRA_REMINDER_TEXT = "reminder_text"
        const val EXTRA_TEMPORARY_TEST = "temporary_test"
        const val EXTRA_SPEAK_TEXT = "speak_text"
    }
}
