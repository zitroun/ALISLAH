package dz.alislah.app

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView

/** A short, dismissible context hint beside the existing green bubble. */
class BubbleHint(private val context: Context, private val wm: WindowManager) {
    private val density = context.resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())
    private val remove = Runnable { dismiss() }
    private var shown: View? = null

    fun show(text: String, bubbleX: Int, bubbleY: Int, bubbleWidth: Int, bubbleHeight: Int, edge: String) {
        dismiss()
        val pill = TextView(context).apply {
            this.text = text
            textSize = 12.5f
            setTextColor(Color.WHITE)
            setPadding((14*density).toInt(), (8*density).toInt(), (14*density).toInt(), (8*density).toInt())
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 16f*density
                setColor(Color.argb(238, 12, 40, 34))
            }
            elevation = 10f*density
            alpha = 0f
            isClickable = true
            setOnClickListener { dismiss() }
        }
        pill.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val gap=(8*density).toInt(); val width=pill.measuredWidth; val height=pill.measuredHeight
        var x=bubbleX; var y=bubbleY+(bubbleHeight-height)/2
        when(edge) {
            "left" -> x=bubbleX+bubbleWidth+gap
            "right" -> x=bubbleX-gap-width
            "bottom" -> { x=bubbleX+(bubbleWidth-width)/2; y=bubbleY-height-gap }
            else -> { x=bubbleX+(bubbleWidth-width)/2; y=bubbleY+bubbleHeight+gap }
        }
        val screenW=context.resources.displayMetrics.widthPixels
        val screenH=context.resources.displayMetrics.heightPixels
        val lp=WindowManager.LayoutParams(width,height,
            if(android.os.Build.VERSION.SDK_INT>=android.os.Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.LEFT; this.x=x.coerceIn(0,(screenW-width).coerceAtLeast(0)); this.y=y.coerceIn(0,(screenH-height).coerceAtLeast(0)) }
        try {
            wm.addView(pill,lp); shown=pill
            if(android.animation.ValueAnimator.areAnimatorsEnabled()) pill.animate().alpha(1f).setDuration(160L).start()
            handler.postDelayed(remove,3000L)
        } catch(e:Exception) { Log.w("ALISLAH-Bubble","hint show",e) }
    }

    fun dismiss() {
        handler.removeCallbacks(remove)
        val v=shown ?: return
        shown=null
        try { wm.removeView(v) } catch(e:Exception) { Log.w("ALISLAH-Bubble","hint dismiss",e) }
    }
}
