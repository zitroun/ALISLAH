package dz.alislah.app

import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings tile for the ALISLAH floating assistant. */
class BubbleTileService : TileService() {
    override fun onStartListening() { super.onStartListening(); refreshTile() }

    override fun onClick() {
        super.onClick()
        val prefs = getSharedPreferences("alislah_native", MODE_PRIVATE)
        val enabled = prefs.getBoolean("overlayEnabled", false)
        if (enabled) {
            prefs.edit().putBoolean("overlayEnabled", false).apply()
            stopService(Intent(this, FloatingBubbleService::class.java))
            SystemBubble.cancel(this)
        } else {
            prefs.edit().putBoolean("overlayEnabled", true).apply()
            if (prefs.getString("bubbleMode", "custom") == "system") {
                if (!SystemBubble.post(this)) {
                    prefs.edit().putBoolean("overlayEnabled", false).apply()
                    SystemBubble.openSettings(this)
                }
            } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
                try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(Intent(this, FloatingBubbleService::class.java)) else startService(Intent(this, FloatingBubbleService::class.java)) }
                catch (_: Exception) { prefs.edit().putBoolean("overlayEnabled", false).apply() }
            } else {
                prefs.edit().putBoolean("overlayEnabled", false).apply()
                val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { startActivityAndCollapse(i) } catch (_: Exception) { }
            }
        }
        refreshTile()
    }

    private fun refreshTile() {
        val tile = qsTile ?: return
        val enabled = getSharedPreferences("alislah_native", MODE_PRIVATE).getBoolean("overlayEnabled", false)
        tile.state = if (enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "ALISLAH"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.contentDescription = if (enabled) "إيقاف فقاعة ALISLAH" else "تشغيل فقاعة ALISLAH"
        }
        tile.updateTile()
    }
}
