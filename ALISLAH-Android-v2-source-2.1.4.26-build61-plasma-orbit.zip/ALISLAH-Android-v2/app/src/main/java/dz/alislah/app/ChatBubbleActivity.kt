package dz.alislah.app

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Content of the Android system bubble: a short chat with the same assistant endpoint as the other panels. */
class ChatBubbleActivity : Activity() {
    private val history = ArrayList<Pair<String, String>>()
    private var thread: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var status: TextView? = null
    private var input: EditText? = null
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val density = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 250, 248))
            setPadding((12 * density).toInt(), (12 * density).toInt(), (12 * density).toInt(), (12 * density).toInt())
        }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        thread = list
        val sv = ScrollView(this).apply { addView(list) }
        scroll = sv
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val statusLine = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(91, 111, 103))
        }
        status = statusLine
        root.addView(statusLine)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val field = EditText(this).apply {
            hint = "اكتب سؤالك…"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            maxLines = 3
        }
        input = field
        row.addView(field, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Button(this).apply {
            text = "إرسال"
            setOnClickListener { send() }
        })
        root.addView(row)
        setContentView(root)
        addMessage(false, "مرحباً بك في مساعد ALISLAH.")
    }

    private fun send() {
        val field = input ?: return
        val question = AssistantRules.cleanQuestion(field.text?.toString())
        if (question == null) {
            status?.text = "اكتب سؤالك أولاً."
            return
        }
        if (busy) return
        field.setText("")
        addMessage(true, question)
        busy = true
        status?.text = "جارٍ التفكير…"
        val endpoint = getSharedPreferences("alislah_native", Context.MODE_PRIVATE).getString("assistantEndpoint", "https://alislah-ai.zitroun2222.workers.dev/") ?: "https://alislah-ai.zitroun2222.workers.dev/"
        AssistantClient.ask(endpoint, question, history.toList()) { reply, error ->
            busy = false
            if (reply != null) {
                addMessage(false, reply)
                history.add(Pair("user", question))
                history.add(Pair("assistant", reply))
                while (history.size > 8) history.removeAt(0)
                status?.text = ""
            } else {
                status?.text = error ?: "تعذّر الحصول على إجابة."
            }
        }
    }

    private fun addMessage(fromUser: Boolean, text: String) {
        val list = thread ?: return
        val density = resources.displayMetrics.density
        val bubble = TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(if (fromUser) Color.WHITE else Color.rgb(18, 48, 42))
            setPadding((12 * density).toInt(), (8 * density).toInt(), (12 * density).toInt(), (8 * density).toInt())
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 14f * density
                setColor(if (fromUser) Color.rgb(23, 107, 91) else Color.rgb(232, 243, 239))
            }
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = if (fromUser) Gravity.END else Gravity.START
            topMargin = (6 * density).toInt()
        }
        list.addView(bubble, lp)
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }
}
