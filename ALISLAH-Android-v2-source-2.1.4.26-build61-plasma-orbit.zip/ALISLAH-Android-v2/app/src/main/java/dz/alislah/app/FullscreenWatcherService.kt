package dz.alislah.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityManager
import android.view.accessibility.AccessibilityWindowInfo

/** Opt-in fullscreen detector. It reads only active window bounds, never screen content. */
class FullscreenWatcherService : AccessibilityService() {
    override fun onServiceConnected() {
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_WINDOWS_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 120
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") {
            FullscreenState.update(pkg, false)
            return
        }
        FullscreenState.update(pkg, isFullscreenNow())
    }

    override fun onInterrupt() { }
    override fun onDestroy() { FullscreenState.update("", false); super.onDestroy() }

    private fun isFullscreenNow(): Boolean {
        val all = windows ?: return false
        val dm = resources.displayMetrics
        val bounds = Rect()
        for (window in all) {
            if (window.type != AccessibilityWindowInfo.TYPE_APPLICATION || !window.isActive) continue
            window.getBoundsInScreen(bounds)
            return bounds.left <= 0 && bounds.top <= 0 && bounds.right >= dm.widthPixels && bounds.bottom >= dm.heightPixels
        }
        return false
    }
}

object FullscreenState {
    @Volatile var active: Boolean = false
    @Volatile var pkg: String? = null
    fun update(packageName: String, fullscreen: Boolean) { pkg = packageName; active = fullscreen }
}

object AccessibilityChecks {
    fun isEnabled(context: Context): Boolean {
        val manager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false
        val expected = FullscreenWatcherService::class.java.name
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
            it.resolveInfo.serviceInfo.packageName == context.packageName && it.resolveInfo.serviceInfo.name == expected
        }
    }
}
