package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings

/** Plays the recorded adhan as a media-playback foreground service so it works with the app closed. */
class PrayerVoiceService : Service() {
    private var player: MediaPlayer? = null
    private var focusRequest: AudioFocusRequest? = null
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var ended = false

    override fun onCreate() {
        super.onCreate()
        liveInstance = this
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            endAdhan()
            return START_NOT_STICKY
        }
        val name = (intent?.getStringExtra(EXTRA_NAME) ?: "").take(30)
        if (!goForeground(name)) {
            PrayerScheduler.postAdhanFallback(this, name)
            stopSelf()
            return START_NOT_STICKY
        }
        startPlayback()
        return START_NOT_STICKY
    }

    private fun updateFloatingBubbleAdhanState(active: Boolean) {
        val nativePrefs = getSharedPreferences("alislah_native", Context.MODE_PRIVATE)
        nativePrefs.edit().putBoolean("adhanPlaying", active).apply()
        FloatingBubbleService.notifyAdhanPlaybackState(this, active)
    }

    private fun goForeground(name: String): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "الأذان", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 7501,
            Intent(this, PrayerVoiceService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val open = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("openTab", "prayer")
        }
        val openPi = PendingIntent.getActivity(this, 7502, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val title = if (name == "اختبار") "اختبار صوت الأذان" else "حان وقت صلاة $name"
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_pause), "إيقاف الأذان", stopPi
        ).build()
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText("اضغطي «إيقاف الأذان» لإنهاء الصوت")
            .setContentIntent(openPi)
            .addAction(stopAction)
            .setOngoing(true)
            .build()
        return try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(NOTIF_ID, n)
            true
        } catch (_: Exception) { false }
    }

    private fun startPlayback() {
        ended = false
        try { player?.release() } catch (_: Exception) { }
        player = null
        val unified = getSharedPreferences("alislah_native", MODE_PRIVATE).getString("audioControlMode", "current") == "unified"
        val attrs = AudioAttributes.Builder()
            .setUsage(if (unified) AudioAttributes.USAGE_MEDIA else AudioAttributes.USAGE_ALARM)
            .setContentType(if (unified) AudioAttributes.CONTENT_TYPE_SPEECH else AudioAttributes.CONTENT_TYPE_MUSIC).build()
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT).setAudioAttributes(attrs).build()
        focusRequest = request
        try { audio.requestAudioFocus(request) } catch (_: Exception) { }
        val p = MediaPlayer.create(this, R.raw.adhan, attrs, AudioManager.AUDIO_SESSION_ID_GENERATE)
        if (p == null) { endAdhan(); return }
        player = p
        try { p.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK) } catch (_: Exception) { }
        p.setOnCompletionListener { endAdhan() }
        p.setOnErrorListener { _, _, _ -> endAdhan(); true }
        p.start()
        updateFloatingBubbleAdhanState(true)
        handler.postDelayed({ endAdhan() }, 5 * 60 * 1000L)
    }

    private fun endAdhan() {
        if (ended) return
        ended = true
        handler.removeCallbacksAndMessages(null)
        updateFloatingBubbleAdhanState(false)
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
        focusRequest?.let {
            try { (getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocusRequest(it) } catch (_: Exception) { }
        }
        focusRequest = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) { }
        stopSelf()
    }

    override fun onDestroy() {
        // stopService() is the most reliable stop path for a foreground player when
        // the request originates from a background overlay (Android 8+ restrictions).
        // Run the exact same cleanup path as the notification's stop action.
        endAdhan()
        if (liveInstance === this) liveInstance = null
        super.onDestroy()
    }

    companion object {
        @Volatile private var liveInstance: PrayerVoiceService? = null
        const val EXTRA_NAME = "prayer_name"
        const val ACTION_STOP = "dz.alislah.app.ACTION_STOP_ADHAN"
        private const val CHANNEL = "alislah_adhan_playing"
        private const val NOTIF_ID = 4108

        /** Stop the actual foreground playback service; do not rely on a background startService call. */
        fun stopPlayback(context: Context): Boolean {
            val running = liveInstance
            if (running != null) {
                running.handler.post { running.endAdhan() }
                return true
            }
            return try {
                val stopped = context.stopService(Intent(context, PrayerVoiceService::class.java))
                if (!stopped) {
                    context.getSharedPreferences("alislah_native", Context.MODE_PRIVATE)
                        .edit().putBoolean("adhanPlaying", false).apply()
                    FloatingBubbleService.notifyAdhanPlaybackState(context, false)
                }
                stopped
            } catch (_: Exception) {
                false
            }
        }
    }
}
