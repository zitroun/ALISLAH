package dz.alislah.app

/** Stable adaptive ordering for the existing ALISLAH orbit; keeps the close-all action last. */
object BubbleOrbitRules {
    fun order(actions: List<String>, usage: Map<String, Int>, prayerSoon: Boolean): List<String> {
        val close = actions.filter { it == "closeWindows" }
        val body = actions.filterNot { it == "closeWindows" || (prayerSoon && it == "prayer") }
        val ranked = body.withIndex().sortedWith(
            compareByDescending<IndexedValue<String>> { usage[it.value] ?: 0 }
                .thenBy { it.index }
        ).map { it.value }
        return (if (prayerSoon && "prayer" in actions) listOf("prayer") else emptyList()) + ranked + close
    }
}
