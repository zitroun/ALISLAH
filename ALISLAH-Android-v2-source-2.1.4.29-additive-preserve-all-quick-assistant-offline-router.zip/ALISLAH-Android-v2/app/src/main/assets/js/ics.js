/* Calendar export: tasks to an iCalendar (.ics) file. Pure functions, no DOM. */
(function(root){
  'use strict';
  var enc=typeof TextEncoder!=='undefined'?new TextEncoder():null;
  function pad(n){return String(n).padStart(2,'0')}
  function esc(s){return String(s==null?'':s).replace(/\\/g,'\\\\').replace(/;/g,'\\;').replace(/,/g,'\\,').replace(/\r?\n/g,'\\n')}
  function fold(line){
    var out=[],cur='',bytes=0;
    for(var ch of line){
      var cp=ch.codePointAt(0);var b=enc?enc.encode(ch).length:(cp<=0x7f?1:cp<=0x7ff?2:cp<=0xffff?3:4);
      if(bytes+b>75){out.push(cur);cur=' ';bytes=1}
      cur+=ch;bytes+=b;
    }
    out.push(cur);
    return out.join('\r\n');
  }
  function build(tasks,now){
    var n=now||new Date();
    var stamp=n.getUTCFullYear()+pad(n.getUTCMonth()+1)+pad(n.getUTCDate())+'T'+pad(n.getUTCHours())+pad(n.getUTCMinutes())+pad(n.getUTCSeconds())+'Z';
    var lines=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//ALISLAH//AR//','CALSCALE:GREGORIAN','METHOD:PUBLISH','X-WR-CALNAME:ALISLAH'];
    (tasks||[]).forEach(function(t,i){
      if(!t||typeof t.text!=='string'||!t.text.trim()||!/^\d{4}-\d{2}-\d{2}$/.test(t.date||''))return;
      var day=t.date.replace(/-/g,'');
      var uid=String(t.id||('t'+i)).replace(/[^A-Za-z0-9_-]/g,'')||('t'+i);
      lines.push('BEGIN:VEVENT','UID:'+uid+'@alislah','DTSTAMP:'+stamp,'SUMMARY:'+esc(t.text.trim().slice(0,180)));
      if(/^\d{2}:\d{2}$/.test(t.time||'')){
        lines.push('DTSTART:'+day+'T'+t.time.replace(':','')+'00','DURATION:PT30M');
      }else{
        lines.push('DTSTART;VALUE=DATE:'+day);
      }
      if(t.priority)lines.push('CATEGORIES:'+esc(t.priority));
      lines.push('STATUS:CONFIRMED');if(t.done)lines.push('X-ALISLAH-DONE:TRUE');
      lines.push('END:VEVENT');
    });
    lines.push('END:VCALENDAR');
    return lines.map(fold).join('\r\n')+'\r\n';
  }
  var api={build:build,esc:esc,fold:fold};
  root.ALI_ICS=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
