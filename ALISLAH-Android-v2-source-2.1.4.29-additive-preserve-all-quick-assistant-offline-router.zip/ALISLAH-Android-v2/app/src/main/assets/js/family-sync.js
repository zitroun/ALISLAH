/* Family sync (2.1.4.28). The household's data is encrypted on this phone with a passphrase you choose,
   then stored as an opaque blob on a server you deploy. The server never sees the data or the passphrase. */
(function (root) {
  'use strict';
  var enc = new TextEncoder(), dec = new TextDecoder();
  var CODE_RE = /^[A-Za-z0-9_-]{22}$/;
  var ITER = 200000;
  function b64u(bytes) {
    var s = '';
    for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function unb64u(str) {
    var s = atob(String(str).replace(/-/g, '+').replace(/_/g, '/'));
    var out = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
    return out;
  }
  function newCode() { return b64u(crypto.getRandomValues(new Uint8Array(16))); }
  function validCode(code) { return CODE_RE.test(String(code || '')); }
  function validEndpoint(url) { return /^https:\/\/[^\s]+$/.test(String(url || '').trim()); }
  async function deriveKey(pass, salt) {
    var base = await crypto.subtle.importKey('raw', enc.encode(pass), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', salt: salt, iterations: ITER, hash: 'SHA-256' },
      base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }
  /** Encrypts text. The family code is bound to the ciphertext, so a blob cannot be moved to another family. */
  async function seal(text, pass, code) {
    if (!validCode(code)) throw new Error('code');
    if (!pass || pass.length < 8) throw new Error('passphrase');
    var salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
    var key = await deriveKey(pass, salt);
    var ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv, additionalData: enc.encode(code) }, key, enc.encode(text)));
    return JSON.stringify({ v: 1, salt: b64u(salt), iv: b64u(iv), ct: b64u(ct) });
  }
  async function open(blob, pass, code) {
    var o = JSON.parse(blob);
    if (!o || o.v !== 1) throw new Error('format');
    var key = await deriveKey(pass, unb64u(o.salt));
    var pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64u(o.iv), additionalData: enc.encode(code) }, key, unb64u(o.ct));
    return dec.decode(pt);
  }
  var api = { newCode: newCode, validCode: validCode, validEndpoint: validEndpoint, seal: seal, open: open, b64u: b64u, unb64u: unb64u, ITER: ITER };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.ALI_SYNC = api;
  if (typeof document === 'undefined') return;

  function $(id) { return document.getElementById(id); }
  function say(text) { var s = $('syncStatus'); if (s) s.textContent = text; }
  function versions() { try { return JSON.parse(localStorage.getItem('alislah_sync_versions') || '{}') || {}; } catch (e) { return {}; } }
  function setVersion(code, v) { var m = versions(); m[code] = v; try { localStorage.setItem('alislah_sync_versions', JSON.stringify(m)); } catch (e) { /* storage full */ } }
  function urlFor(code) { return String(localStorage.getItem('alislah_sync_endpoint') || '').replace(/\/+$/, '') + '/v1/family/' + code; }
  async function call(method, url, body) {
    var ctrl = new AbortController(), timer = setTimeout(function () { ctrl.abort(); }, 20000);
    try {
      var r = await fetch(url, { method: method, mode: 'cors', cache: 'no-store', signal: ctrl.signal,
        headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
      var j = null;
      try { j = await r.json(); } catch (e) { j = null; }
      return { status: r.status, body: j };
    } finally { clearTimeout(timer); }
  }
  function inputs() {
    return { code: $('syncCode').value.trim(), pass: $('syncPass').value, endpoint: $('syncEndpoint').value.trim() };
  }
  async function push() {
    var f = inputs();
    if (!validCode(f.code)) return say('أنشئي رمز أسرة أولاً.');
    if (!validEndpoint(f.endpoint)) return say('عنوان الخادم يجب أن يبدأ بـ https://');
    if (!window.ALI_SYNC_BRIDGE) return say('المزامنة غير متاحة في هذه الصفحة.');
    if (!f.pass || f.pass.length < 8) return say('كلمة السر 8 أحرف على الأقل. إن ضاعت لا تُستعاد البيانات.');
    say('جارٍ الرفع…');
    try {
      var blob = await seal(window.ALI_SYNC_BRIDGE.snapshot(), f.pass, f.code);
      var res = await call('PUT', urlFor(f.code), { baseVersion: versions()[f.code] || 0, blob: blob });
      if (res.status === 200) { setVersion(f.code, res.body.version); say('تم الرفع. النسخة رقم ' + res.body.version + '.'); }
      else if (res.status === 409) say('يوجد على الخادم نسخة أحدث من جهاز آخر. اسحبيها أولاً ثم ارفعي.');
      else say('تعذر الرفع (رمز ' + res.status + ').');
    } catch (e) { say('تعذر الاتصال بالخادم. تحققي من الإنترنت والعنوان.'); }
  }
  var armedFor = '';
  async function pull() {
    var f = inputs();
    if (!validCode(f.code)) return say('أدخلي رمز الأسرة.');
    if (!validEndpoint(f.endpoint)) return say('عنوان الخادم يجب أن يبدأ بـ https://');
    if (!f.pass) return say('أدخلي كلمة السر.');
    if (armedFor !== f.code) { armedFor = f.code; return say('هذا يستبدل بياناتكِ الحالية على هذا الجهاز. اضغطي «سحب النسخة» مرة أخرى للتأكيد.'); }
    armedFor = '';
    say('جارٍ السحب…');
    try {
      var res = await call('GET', urlFor(f.code));
      if (res.status === 404) return say('لا توجد نسخة لهذا الرمز بعد.');
      if (res.status !== 200) return say('تعذر السحب (رمز ' + res.status + ').');
      var text = await open(res.body.blob, f.pass, f.code);
      await window.ALI_SYNC_BRIDGE.restore(text);
      setVersion(f.code, res.body.version);
      say('تم السحب وتطبيق النسخة رقم ' + res.body.version + '.');
    } catch (e) { say('كلمة السر غير صحيحة أو النسخة تالفة.'); }
  }
  function init() {
    if (!$('syncCode')) return;
    $('syncCode').value = localStorage.getItem('alislah_sync_code') || '';
    $('syncEndpoint').value = localStorage.getItem('alislah_sync_endpoint') || '';
    $('syncNewCode').onclick = function () {
      var c = newCode(); $('syncCode').value = c; localStorage.setItem('alislah_sync_code', c);
      say('رمز جديد أُنشئ. احفظيه لتستعمليه على أجهزتكِ الأخرى.');
    };
    $('syncCode').onchange = function () { localStorage.setItem('alislah_sync_code', this.value.trim()); };
    $('syncEndpoint').onchange = function () { localStorage.setItem('alislah_sync_endpoint', this.value.trim()); };
    $('syncPush').onclick = push;
    $('syncPull').onclick = pull;
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})(typeof window !== 'undefined' ? window : globalThis);
