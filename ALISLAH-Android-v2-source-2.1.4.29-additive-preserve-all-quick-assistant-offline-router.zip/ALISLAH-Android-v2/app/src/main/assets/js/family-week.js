/* Family week (2.1.4.28): what the household finished in the last seven days, and the kids' stars. */
(function (root) {
  'use strict';
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function keyOf(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  /** True when the day key (YYYY-MM-DD) falls within the last `days` days, today included. */
  function inLastDays(key, now, days) {
    if (typeof key !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(key)) return false;
    var t = new Date(key + 'T12:00:00');
    var n = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 12);
    var diff = Math.round((n - t) / 86400000);
    return diff >= 0 && diff < days;
  }
  /**
   * input: { kidsDone: {dayKey: [activity titles]}, tasks: [...], prayerLog: [...] }
   * Counts only what is dated inside the last seven days. Unfinished prayers are not counted.
   */
  function weeklySummary(input, now) {
    now = now || new Date();
    input = input || {};
    var kids = input.kidsDone || {}, tasks = input.tasks || [], log = input.prayerLog || [];
    var kidsCount = 0, tasksCount = 0, seen = {}, prayerCount = 0;
    Object.keys(kids).forEach(function (k) {
      if (inLastDays(k, now, 7)) kidsCount += Array.isArray(kids[k]) ? kids[k].length : 0;
    });
    tasks.forEach(function (t) { if (t && t.done && inLastDays(t.date, now, 7)) tasksCount++; });
    log.forEach(function (x) {
      if (!x || x.done === false) return;
      var key = x.day || String(x.date || '').slice(0, 10);
      if (!inLastDays(key, now, 7)) return;
      var id = key + '|' + (x.name || '');
      if (!seen[id]) { seen[id] = true; prayerCount++; }
    });
    return { kidsDone: kidsCount, tasksDone: tasksCount, prayersLogged: prayerCount };
  }
  /** Stars: one per finished activity in the last seven days. */
  function stars(kidsDone, now) {
    return weeklySummary({ kidsDone: kidsDone }, now).kidsDone;
  }
  var api = { weeklySummary: weeklySummary, stars: stars, inLastDays: inLastDays, keyOf: keyOf };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.ALI_FAMILY_WEEK = api;
  if (typeof document === 'undefined') return;

  function readJSON(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key) || 'null') || fallback; } catch (e) { return fallback; }
  }
  function render() {
    var box = document.getElementById('familyWeek');
    if (!box) return;
    var data = readJSON('alislah_v2', {});
    var s = weeklySummary({ kidsDone: readJSON('alislah_kids_done', {}), tasks: data.tasks || [], prayerLog: data.prayerLog || [] }, new Date());
    box.textContent = '';
    var title = document.createElement('h3'); title.textContent = 'تقرير الأسرة للأيام السبعة الأخيرة';
    var lines = [
      'المهام المنجزة: ' + s.tasksDone,
      'الصلوات المسجلة: ' + s.prayersLogged,
      'أنشطة الأطفال المنجزة: ' + s.kidsDone
    ];
    box.appendChild(title);
    lines.forEach(function (t) { var p = document.createElement('p'); p.className = 'muted'; p.style.margin = '4px 0'; p.textContent = t; box.appendChild(p); });
    box.style.display = '';
  }
  api.refresh = render;
  function start() { render(); setInterval(render, 60000); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})(typeof window !== 'undefined' ? window : globalThis);
