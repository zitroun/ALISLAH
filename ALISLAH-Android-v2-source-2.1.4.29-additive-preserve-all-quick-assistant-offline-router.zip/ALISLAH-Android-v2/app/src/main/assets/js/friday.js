/* Friday card on the dashboard (2.1.4.28). Shows the usual Friday reminders on Fridays only. */
(function (root) {
  'use strict';
  function fridayReminders(dayIndex) {
    if (dayIndex !== 5) return [];
    return ['قراءة سورة الكهف قبل نهاية يوم الجمعة.', 'الإكثار من الصلاة على النبي ﷺ.', 'الاغتسال والتطيّب والتبكير إلى الصلاة.'];
  }
  var api = { fridayReminders: fridayReminders };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.ALI_FRIDAY = api;
  if (typeof document === 'undefined') return;
  function render() {
    var box = document.getElementById('fridayCard');
    if (!box) return;
    var items = fridayReminders(new Date().getDay());
    box.textContent = '';
    if (items.length === 0) { box.style.display = 'none'; return; }
    var title = document.createElement('b'); title.textContent = 'جمعة مباركة';
    var list = document.createElement('ul'); list.className = 'friday-list';
    items.forEach(function (t) { var li = document.createElement('li'); li.textContent = t; list.appendChild(li); });
    box.appendChild(title); box.appendChild(list); box.style.display = '';
  }
  function start() { render(); setInterval(render, 60000); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})(typeof window !== 'undefined' ? window : globalThis);
