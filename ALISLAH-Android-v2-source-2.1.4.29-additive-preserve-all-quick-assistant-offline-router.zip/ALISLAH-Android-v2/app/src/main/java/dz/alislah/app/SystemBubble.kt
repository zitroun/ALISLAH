package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.LocusId
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.os.Build
import android.provider.Settings
import android.util.Log

/**
 * Android's own bubbles (Bubbles API, Android 11 and later). The system draws and positions them.
 * The user picks this mode in the bubble settings, and the bubble needs bubbles to be allowed for ALISLAH.
 */
object SystemBubble {
    const val CHANNEL = "alislah_bubbles"
    private const val NOTIFICATION_ID = 9470
    private const val SHORTCUT_ID = "alislah_assistant_bubble"
    private const val TAG = "ALISLAH-Bubble"

    fun supported(): Boolean = Build.VERSION.SDK_INT >= 30

    fun allowed(context: Context): Boolean {
        if (!supported()) return false
        val nm = context.getSystemService(NotificationManager::class.java) ?: return false
        return try {
            nm.areBubblesAllowed()
        } catch (e: Exception) {
            false
        }
    }

    /** Publishes the chat bubble. The notification is hidden from the shade and only the bubble stays. */
    fun post(context: Context) {
        if (!supported()) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        ensureChannel(nm)
        pushShortcut(context)
        val density = context.resources.displayMetrics.density
        val target = Intent(context, ChatBubbleActivity::class.java).setAction(Intent.ACTION_VIEW)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pi = PendingIntent.getActivity(context, 9471, target, flags)
        val metadata = Notification.BubbleMetadata.Builder(pi, Icon.createWithResource(context, R.mipmap.ic_launcher))
            .setDesiredHeight((480 * density).toInt())
            .setSuppressNotification(true)
            .setAutoExpandBubble(false)
            .build()
        val n = Notification.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("المساعد السريع")
            .setContentText("اضغطي الفقاعة لتسألي")
            .setShortcutId(SHORTCUT_ID)
            .setBubbleMetadata(metadata)
            .build()
        try {
            nm.notify(NOTIFICATION_ID, n)
        } catch (e: SecurityException) {
            Log.w(TAG, "system bubble: notifications are not allowed")
        }
    }

    fun cancel(context: Context) {
        context.getSystemService(NotificationManager::class.java)?.cancel(NOTIFICATION_ID)
    }

    /** Opens the bubble settings for ALISLAH, falling back to the notification settings on older systems. */
    fun openSettings(context: Context) {
        val bubbles = Intent(Settings.ACTION_APP_NOTIFICATION_BUBBLE_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(bubbles)
        } catch (e: Exception) {
            val general = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(general)
            } catch (inner: Exception) {
                Log.w(TAG, "no settings screen for bubbles", inner)
            }
        }
    }

    private fun ensureChannel(nm: NotificationManager) {
        if (nm.getNotificationChannel(CHANNEL) != null) return
        val channel = NotificationChannel(CHANNEL, "فقاعات المساعد", NotificationManager.IMPORTANCE_DEFAULT)
        channel.setAllowBubbles(true)
        nm.createNotificationChannel(channel)
    }

    /** Bubbles need a conversation-style shortcut on Android 11 and later. */
    private fun pushShortcut(context: Context) {
        val sm = context.getSystemService(ShortcutManager::class.java) ?: return
        val intent = Intent(context, ChatBubbleActivity::class.java).setAction(Intent.ACTION_VIEW)
        val info = ShortcutInfo.Builder(context, SHORTCUT_ID)
            .setShortLabel("المساعد السريع")
            .setIcon(Icon.createWithResource(context, R.mipmap.ic_launcher))
            .setIntent(intent)
            .setLongLived(true)
            .setLocusId(LocusId(SHORTCUT_ID))
            .setCategories(setOf("android.shortcut.conversation"))
            .build()
        try {
            sm.pushDynamicShortcut(info)
        } catch (e: Exception) {
            Log.w(TAG, "shortcut for the bubble", e)
        }
    }
}
