package dz.alislah.app

/** Rules for the native quick assistant: question limits, endpoint checks, retries and messages. Pure, unit-tested. */
object AssistantRules {
    const val MAX_QUESTION_CHARS = 1000
    const val MAX_REPLY_BYTES = 64 * 1024
    const val MAX_ATTEMPTS = 3
    const val MIN_GAP_MS = 1500L

    /** The question with spaces collapsed, or null when nothing is left to ask. */
    fun cleanQuestion(raw: String?): String? {
        val text = raw?.replace(Regex("\\s+"), " ")?.trim() ?: return null
        if (text.isEmpty()) return null
        return text.take(MAX_QUESTION_CHARS)
    }

    /** Only HTTPS endpoints without credentials are accepted. */
    fun isAllowedEndpoint(url: String?): Boolean {
        val u = url?.trim().orEmpty()
        if (!u.startsWith("https://") || u.length > 300) return false
        if (u.any { it.isWhitespace() }) return false
        val host = u.removePrefix("https://").substringBefore('/')
        return host.isNotEmpty() && !host.contains('@')
    }

    /** Timeouts, rate limits and server errors are worth another attempt. Client errors are not. */
    fun shouldRetry(status: Int): Boolean = status == 408 || status == 425 || status == 429 || status >= 500

    /** Pause before the next attempt, growing with each attempt. */
    fun backoffMs(attempt: Int): Long = 800L * (attempt + 1)

    /** A short Arabic message for an HTTP status. */
    fun messageForStatus(status: Int): String = when {
        status == 429 -> "الخدمة مشغولة الآن. انتظري لحظات ثم أعيدي المحاولة."
        status == 401 || status == 403 -> "رفضت الخدمة الطلب. تحققي من إعدادات المساعد."
        status == 404 -> "عنوان خدمة المساعد غير صحيح."
        status >= 500 -> "خادم المساعد متعطّل مؤقتاً. أعيدي المحاولة بعد قليل."
        else -> "تعذّر الوصول إلى المساعد (رمز $status)."
    }

    /** Reads the reply or the error from the worker's JSON body. Returns Pair(reply, error). */
    fun parseReply(body: String): Pair<String?, String?> {
        return try {
            val o = org.json.JSONObject(body)
            val reply = o.optString("reply", "").trim()
            val error = o.optString("error", "").trim()
            when {
                reply.isNotEmpty() -> Pair(reply.take(8000), null)
                error.isNotEmpty() -> Pair(null, error.take(300))
                else -> Pair(null, "الخدمة لم تُرجع إجابة صالحة.")
            }
        } catch (e: Exception) {
            Pair(null, "الخدمة لم تُرجع إجابة صالحة.")
        }
    }
}
