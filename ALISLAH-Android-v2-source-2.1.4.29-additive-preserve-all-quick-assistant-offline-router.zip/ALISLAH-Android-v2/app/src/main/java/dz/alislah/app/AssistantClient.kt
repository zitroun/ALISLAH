package dz.alislah.app

import android.os.Handler
import android.os.Looper
import android.util.Log
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.util.concurrent.Executors

/**
 * Sends one question to the assistant endpoint on a background thread and returns the answer on the main thread.
 * The question text is never logged.
 */
object AssistantClient {
    private const val TAG = "ALISLAH-Assistant"
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var lastStart = 0L

    private class Attempt(val reply: String?, val error: String?, val retryable: Boolean)

    fun ask(
        endpoint: String,
        question: String,
        history: List<Pair<String, String>>,
        callback: (String?, String?) -> Unit
    ) {
        val cleaned = AssistantRules.cleanQuestion(question)
        if (cleaned == null) {
            main.post { callback(null, "أدخل سؤالك أولاً.") }
            return
        }
        if (!AssistantRules.isAllowedEndpoint(endpoint)) {
            main.post { callback(null, "عنوان خدمة المساعد غير صالح. تحققي من الإعدادات.") }
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastStart < AssistantRules.MIN_GAP_MS) {
            main.post { callback(null, "انتظري لحظة قبل السؤال التالي.") }
            return
        }
        lastStart = now
        val past = history.takeLast(8)
        executor.execute {
            var last = Attempt(null, "تعذّر الوصول إلى المساعد.", false)
            for (attempt in 0 until AssistantRules.MAX_ATTEMPTS) {
                last = attemptOnce(endpoint, cleaned, past)
                if (last.reply != null || !last.retryable) break
                if (attempt < AssistantRules.MAX_ATTEMPTS - 1) {
                    try {
                        Thread.sleep(AssistantRules.backoffMs(attempt))
                    } catch (e: InterruptedException) {
                        break
                    }
                }
            }
            val reply = last.reply
            val error = last.error
            main.post { callback(reply, error) }
        }
    }

    private fun attemptOnce(endpoint: String, question: String, history: List<Pair<String, String>>): Attempt {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL(endpoint).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 30_000
            conn.doOutput = true
            conn.useCaches = false
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("Accept", "application/json")
            val payload = org.json.JSONObject()
            payload.put("message", question)
            val hist = org.json.JSONArray()
            for (pair in history) {
                hist.put(org.json.JSONObject().put("role", pair.first).put("content", pair.second))
            }
            payload.put("history", hist)
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val status = conn.responseCode
            val stream: InputStream? = if (status in 200..299) conn.inputStream else conn.errorStream
            val body = readLimited(stream)
            if (status in 200..299) {
                val parsed = AssistantRules.parseReply(body)
                Attempt(parsed.first, parsed.second, false)
            } else {
                Attempt(null, AssistantRules.messageForStatus(status), AssistantRules.shouldRetry(status))
            }
        } catch (e: SocketTimeoutException) {
            Attempt(null, "انتهت مهلة الاتصال بالمساعد. تحققي من الإنترنت.", true)
        } catch (e: Exception) {
            Log.w(TAG, "assistant request failed: ${e.javaClass.simpleName}")
            Attempt(null, "تعذّر الاتصال بالمساعد. تحققي من الإنترنت.", true)
        } finally {
            conn?.disconnect()
        }
    }

    private fun readLimited(stream: InputStream?): String {
        if (stream == null) return ""
        val out = ByteArrayOutputStream()
        stream.use { input ->
            val buffer = ByteArray(4096)
            while (out.size() < AssistantRules.MAX_REPLY_BYTES) {
                val n = input.read(buffer)
                if (n < 0) break
                out.write(buffer, 0, minOf(n, AssistantRules.MAX_REPLY_BYTES - out.size()))
            }
        }
        return String(out.toByteArray(), Charsets.UTF_8)
    }
}
