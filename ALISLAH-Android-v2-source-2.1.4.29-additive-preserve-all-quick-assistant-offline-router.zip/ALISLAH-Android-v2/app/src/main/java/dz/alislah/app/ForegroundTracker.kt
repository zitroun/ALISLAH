package dz.alislah.app

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo

/**
 * Finds the app in front from usage events and checks whether it is a game or a video app.
 * Needs the usage-access permission. Without it, nothing is reported and the bubble stays visible.
 */
object ForegroundTracker {
    private const val WINDOW_MS = 20_000L
    private val categoryCache = HashMap<String, Boolean>()

    fun currentPackage(context: Context): String? {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return null
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - WINDOW_MS, now) ?: return null
        val list = ArrayList<Triple<String, Int, Long>>()
        val event = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            list.add(Triple(event.packageName ?: "", event.eventType, event.timeStamp))
        }
        return FullscreenRules.lastForeground(list)
    }

    fun isGameOrVideo(context: Context, pkg: String): Boolean {
        categoryCache[pkg]?.let { return it }
        val value = try {
            val category = context.packageManager.getApplicationInfo(pkg, 0).category
            category == ApplicationInfo.CATEGORY_GAME || category == ApplicationInfo.CATEGORY_VIDEO
        } catch (e: Exception) {
            false
        }
        categoryCache[pkg] = value
        return value
    }
}
