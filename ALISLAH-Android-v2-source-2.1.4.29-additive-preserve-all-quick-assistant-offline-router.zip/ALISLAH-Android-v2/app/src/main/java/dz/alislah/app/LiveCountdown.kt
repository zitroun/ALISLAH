package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

/** An ongoing notification that counts down to the next prayer. Opt-in from the bubble settings. */
object LiveCountdown {
    const val CHANNEL = "alislah_live"
    private const val NOTIFICATION_ID = 9460

    fun update(context: Context, prayerName: String, atMs: Long) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val channel = NotificationChannel(CHANNEL, "العد التنازلي للصلاة", NotificationManager.IMPORTANCE_LOW)
            channel.setShowBadge(false)
            nm.createNotificationChannel(channel)
        }
        val open = PendingIntent.getActivity(
            context,
            9461,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("الصلاة القادمة: $prayerName")
            .setContentText("العد التنازلي حتى الأذان")
            .setWhen(atMs)
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .build()
        try {
            nm.notify(NOTIFICATION_ID, n)
        } catch (e: SecurityException) {
            // notifications were not allowed; the bubble still works
        }
    }

    fun cancel(context: Context) {
        context.getSystemService(NotificationManager::class.java)?.cancel(NOTIFICATION_ID)
    }

    /** Shows the countdown when it is enabled, otherwise removes it. */
    fun refresh(context: Context) {
        val next = if (BubbleSettings.liveCountdown(context)) PrayerScheduler.nextAdhan(context) else null
        if (next == null) cancel(context) else update(context, next.first, next.second)
    }
}
