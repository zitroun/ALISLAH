package dz.alislah.app

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Lightweight native assistant panel: a short conversation, an input line, voice, and a way to open the full chat.
 * It avoids loading the whole web app for quick questions.
 */
class QuickAsk(
    private val context: Context,
    private val wm: WindowManager,
    private val endpoint: () -> String,
    private val onOpenFull: (String) -> Unit,
    private val onSpeak: (String) -> Unit,
    private val onVoice: (ok: (String) -> Unit, fail: (String) -> Unit) -> Unit,
    private val onClosed: () -> Unit
) {
    private val density = context.resources.displayMetrics.density
    private val history = ArrayList<Pair<String, String>>()
    private var root: LinearLayout? = null
    private var windowParams: WindowManager.LayoutParams? = null
    private var thread: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var status: TextView? = null
    private var input: EditText? = null
    private var speakOn = false
    private var busy = false
    private var panelWidth = 0

    val isShowing: Boolean
        get() = root != null

    private fun dp(n: Int): Int = (n * density).toInt()

    private fun isDark(): Boolean =
        (context.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES

    private fun cardColor(): Int = if (isDark()) 0xFF14241F.toInt() else 0xFFFFFFFF.toInt()
    private fun textColor(): Int = if (isDark()) 0xFFE4F2EC.toInt() else 0xFF12302A.toInt()
    private fun mutedColor(): Int = if (isDark()) 0xFF9BB2A9.toInt() else 0xFF5B6F67.toInt()
    private fun lineColor(): Int = if (isDark()) 0xFF23403A.toInt() else 0xFFDBE7E2.toInt()
    private fun fieldColor(): Int = if (isDark()) 0xFF101F1A.toInt() else 0xFFF7FBF9.toInt()
    private fun assistantBubble(): Int = if (isDark()) 0xFF1B3229.toInt() else 0xFFE8F3EF.toInt()

    private fun rounded(radius: Float, color: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radius
        setColor(color)
    }

    private fun actionText(label: String, onClick: () -> Unit): TextView = TextView(context).apply {
        text = label
        textSize = 13f
        setTextColor(Color.rgb(15, 107, 88))
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(8), dp(10), dp(8))
        setOnClickListener { onClick() }
    }

    fun show(rect: Rect) {
        if (isShowing) return
        panelWidth = rect.width()
        val column = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(20f * density, cardColor()).apply { setStroke(dp(1), lineColor()) }
            elevation = 16f * density
            isFocusableInTouchMode = true
            setOnKeyListener { _, code, ev ->
                if (code == KeyEvent.KEYCODE_BACK && ev.action == KeyEvent.ACTION_UP) {
                    hide()
                    true
                } else {
                    false
                }
            }
        }

        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(
            TextView(context).apply {
                text = "المساعد السريع"
                textSize = 16f
                setTextColor(textColor())
                setTypeface(null, Typeface.BOLD)
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        header.addView(actionText("✕") { hide() })
        column.addView(header)

        val list = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        thread = list
        val sv = ScrollView(context).apply { addView(list) }
        scroll = sv
        column.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val statusLine = TextView(context).apply {
            textSize = 12f
            setTextColor(mutedColor())
        }
        status = statusLine
        column.addView(statusLine)

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val field = EditText(context).apply {
            hint = "اكتب سؤالك…"
            setHintTextColor(mutedColor())
            setTextColor(textColor())
            textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            maxLines = 3
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(14f * density, fieldColor()).apply { setStroke(dp(1), lineColor()) }
            setOnTouchListener { v, ev ->
                if (ev.actionMasked == MotionEvent.ACTION_UP) {
                    this@QuickAsk.setFocusable(true)
                    v.requestFocus()
                    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT)
                }
                false
            }
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    send()
                    true
                } else {
                    false
                }
            }
        }
        input = field
        row.addView(field, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(
            TextView(context).apply {
                text = "🎙"
                textSize = 18f
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(6), dp(8), dp(6))
                setOnClickListener {
                    onVoice(
                        { heard -> field.setText(heard); setStatus("") },
                        { msg -> setStatus(msg) }
                    )
                }
            }
        )
        row.addView(
            TextView(context).apply {
                text = "إرسال"
                textSize = 14f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(9), dp(14), dp(9))
                background = rounded(14f * density, Color.rgb(23, 107, 91))
                setOnClickListener { send() }
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                leftMargin = dp(6)
            }
        )
        column.addView(row)

        val footer = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val speakToggle = actionText("🔊 قراءة الردود: إيقاف") { }
        speakToggle.setOnClickListener {
            speakOn = !speakOn
            speakToggle.text = if (speakOn) "🔊 قراءة الردود: تشغيل" else "🔊 قراءة الردود: إيقاف"
        }
        footer.addView(speakToggle, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        footer.addView(actionText("فتح المحادثة الكاملة") {
            onOpenFull(input?.text?.toString()?.trim().orEmpty())
            hide()
        })
        column.addView(footer)

        val height = minOf(rect.height(), dp(460))
        val params = WindowManager.LayoutParams(
            rect.width(),
            height,
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = rect.left
            y = rect.top
        }
        try {
            wm.addView(column, params)
            root = column
            windowParams = params
            addMessage(false, "مرحباً! اطرح سؤالك وسأحاول مساعدتك.")
        } catch (e: Exception) {
            Log.w(TAG, "quick panel show", e)
        }
    }

    /** Moves and resizes the open panel, for example after a rotation. */
    fun place(rect: Rect) {
        val r = root ?: return
        val lp = windowParams ?: return
        panelWidth = rect.width()
        lp.width = rect.width()
        lp.height = minOf(rect.height(), dp(460))
        lp.x = rect.left
        lp.y = rect.top
        try {
            wm.updateViewLayout(r, lp)
        } catch (e: Exception) {
            Log.w(TAG, "quick panel place", e)
        }
    }

    /** The window only takes keyboard input while the user is typing. Otherwise taps pass through to the app below. */
    private fun setFocusable(on: Boolean) {
        val r = root ?: return
        val lp = windowParams ?: return
        val flag = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        lp.flags = if (on) lp.flags and flag.inv() else lp.flags or flag
        try {
            wm.updateViewLayout(r, lp)
        } catch (e: Exception) {
            Log.w(TAG, "quick panel focus", e)
        }
    }

    private fun setStatus(text: String) {
        status?.text = text
    }

    private fun send() {
        val field = input ?: return
        val question = AssistantRules.cleanQuestion(field.text?.toString())
        if (question == null) {
            setStatus("أدخل سؤالك أولاً.")
            return
        }
        if (busy) return
        field.setText("")
        addMessage(true, question)
        busy = true
        setStatus("جارٍ التفكير…")
        AssistantClient.ask(endpoint(), question, history.toList()) { reply, error ->
            busy = false
            if (!isShowing) return@ask
            if (reply != null) {
                addMessage(false, reply)
                history.add(Pair("user", question))
                history.add(Pair("assistant", reply))
                while (history.size > 8) history.removeAt(0)
                setStatus("")
                if (speakOn) onSpeak(reply)
            } else {
                setStatus(error ?: "تعذّر الحصول على إجابة.")
            }
        }
    }

    private fun addMessage(fromUser: Boolean, text: String) {
        val list = thread ?: return
        val bubble = TextView(context).apply {
            this.text = text
            textSize = 15f
            setLineSpacing(0f, 1.2f)
            setTextColor(if (fromUser) Color.WHITE else textColor())
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(14f * density, if (fromUser) Color.rgb(23, 107, 91) else assistantBubble())
            maxWidth = (panelWidth * 0.85f).toInt()
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = if (fromUser) Gravity.END else Gravity.START
            topMargin = dp(6)
        }
        list.addView(bubble, lp)
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
    }

    fun hide() {
        val r = root ?: return
        root = null
        windowParams = null
        try {
            wm.removeView(r)
        } catch (e: Exception) {
            Log.w(TAG, "quick panel hide", e)
        }
        onClosed()
    }

    companion object {
        private const val TAG = "ALISLAH-Assistant"
    }
}
