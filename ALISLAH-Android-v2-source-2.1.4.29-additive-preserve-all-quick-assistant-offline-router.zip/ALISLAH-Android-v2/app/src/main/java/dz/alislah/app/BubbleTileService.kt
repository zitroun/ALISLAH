package dz.alislah.app

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings tile that shows or hides the bubble. It needs no permission beyond the bubble's own. */
class BubbleTileService : TileService() {
    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
    }

    override fun onClick() {
        super.onClick()
        val intent = Intent(this, FloatingBubbleService::class.java)
        if (FloatingBubbleService.running) {
            stopService(intent)
        } else {
            try {
                startForegroundService(intent)
            } catch (e: Exception) {
                // the system may refuse; the tile then stays off
            }
        }
        refreshTile()
    }

    private fun refreshTile() {
        val tile = qsTile ?: return
        tile.state = if (FloatingBubbleService.running) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "ALISLAH"
        tile.updateTile()
    }
}
