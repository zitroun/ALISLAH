package dz.alislah.app

import android.util.Log

/** Records an exception that is deliberately ignored, without its message, so failures stay visible in logcat. */
object AppLog {
    fun ignored(e: Throwable) {
        Log.w("ALISLAH", "ignored ${e.javaClass.simpleName}")
    }
}
