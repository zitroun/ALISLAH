package dz.alislah.app

/** Decides when the bubble steps aside for a full-screen app. Pure, unit-tested. */
object FullscreenRules {
    /** Event type of an app coming to the front (the same value as UsageEvents.Event.ACTIVITY_RESUMED). */
    const val RESUMED = 1

    /** Hide only when the feature is on, the app in front is a game or video app, and it is not this app. */
    fun shouldHide(enabled: Boolean, foregroundPkg: String?, ownPkg: String, isGameOrVideo: Boolean): Boolean {
        if (!enabled || foregroundPkg.isNullOrEmpty() || foregroundPkg == ownPkg) return false
        return isGameOrVideo
    }

    /** The package that most recently came to the front, from (package, eventType, timestamp) triples. */
    fun lastForeground(events: List<Triple<String, Int, Long>>): String? =
        events.filter { it.second == RESUMED && it.first.isNotEmpty() }.maxByOrNull { it.third }?.first

    /** The accessibility watcher reports an app that covers the whole screen (never this app). */
    fun shouldHideForFullscreen(enabled: Boolean, fullscreenActive: Boolean, pkg: String?, ownPkg: String): Boolean =
        enabled && fullscreenActive && !pkg.isNullOrEmpty() && pkg != ownPkg
}
