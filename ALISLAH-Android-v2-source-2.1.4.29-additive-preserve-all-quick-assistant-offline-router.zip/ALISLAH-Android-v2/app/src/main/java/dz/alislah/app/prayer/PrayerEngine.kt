package dz.alislah.app.prayer

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

/** A calculation method: solar angles for Fajr and Isha, or a fixed delay after Maghrib for Isha. */
data class PrayerMethod(
    val fajrAngle: Double,
    val ishaAngle: Double,
    val ishaMinutesAfterMaghrib: Int? = null
)

object PrayerMethods {
    val ALGERIA = PrayerMethod(18.0, 17.0)
    val MWL = PrayerMethod(18.0, 17.0)
    val MAKKAH = PrayerMethod(18.5, 0.0, 90)
    val EGYPT = PrayerMethod(19.5, 17.5)
    val TUNISIA = PrayerMethod(18.0, 18.0)
    val MOROCCO = PrayerMethod(19.0, 17.0)
    val ISNA = PrayerMethod(15.0, 15.0)
    val FRANCE = PrayerMethod(12.0, 12.0)
    val KARACHI = PrayerMethod(18.0, 18.0)

    fun byKey(key: String): PrayerMethod = when (key) {
        "mwl" -> MWL
        "makkah" -> MAKKAH
        "egypt" -> EGYPT
        "tunisia" -> TUNISIA
        "morocco" -> MOROCCO
        "isna" -> ISNA
        "france" -> FRANCE
        "karachi" -> KARACHI
        else -> ALGERIA
    }
}

/** Prayer times of one civil day. At high latitudes a time can fall after midnight, so each keeps its own date. */
data class PrayerTimes(
    val fajr: LocalDateTime,
    val sunrise: LocalDateTime,
    val dhuhr: LocalDateTime,
    val asr: LocalDateTime,
    val maghrib: LocalDateTime,
    val isha: LocalDateTime,
    val highLatitude: Boolean,
    val approximate: Boolean
)

/**
 * Solar prayer-time calculation. A line-by-line port of the verified web implementation
 * (prayer-data.js), tested against NOAA values in PrayerEngineTest.
 */
object PrayerEngine {
    private class Sun(val decl: Double, val eqt: Double)

    private class Hours(
        var fajr: Double,
        var sunrise: Double,
        var dhuhr: Double,
        var asr: Double,
        var maghrib: Double,
        var isha: Double
    )

    private fun rad(d: Double): Double = d * PI / 180.0
    private fun deg(r: Double): Double = r * 180.0 / PI
    private fun sinD(d: Double): Double = sin(rad(d))
    private fun cosD(d: Double): Double = cos(rad(d))
    private fun tanD(d: Double): Double = tan(rad(d))
    private fun asinD(x: Double): Double = deg(asin(x))
    private fun acosD(x: Double): Double = deg(acos(x))
    private fun atan2D(y: Double, x: Double): Double = deg(atan2(y, x))
    private fun acotD(x: Double): Double = deg(atan(1.0 / x))
    private fun fixAngle(a: Double): Double = a - 360.0 * floor(a / 360.0)
    private fun fixHour(a: Double): Double = a - 24.0 * floor(a / 24.0)

    private fun julian(year: Int, month: Int, day: Int): Double {
        var y = year.toDouble()
        var m = month.toDouble()
        if (month <= 2) {
            y -= 1.0
            m += 12.0
        }
        val a = floor(y / 100.0)
        val b = 2.0 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716.0)) + floor(30.6001 * (m + 1.0)) + day + b - 1524.5
    }

    private fun sunPosition(jd: Double): Sun {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sinD(g) + 0.020 * sinD(2.0 * g))
        val e = 23.439 - 0.00000036 * d
        val ra = atan2D(cosD(e) * sinD(l), cosD(l)) / 15.0
        return Sun(asinD(sinD(e) * sinD(l)), q / 15.0 - fixHour(ra))
    }

    /** Hours after local midnight for one day, before the zone correction is applied by the caller. */
    private fun hoursFor(
        year: Int,
        month: Int,
        day: Int,
        lat: Double,
        lon: Double,
        tz: Double,
        method: PrayerMethod
    ): Hours {
        val jd = julian(year, month, day) - lon / (15.0 * 24.0)
        val shift = tz - lon / 15.0

        fun mid(t: Double): Double = fixHour(12.0 - sunPosition(jd + t).eqt)

        fun angleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val decl = sunPosition(jd + t).decl
            val noon = mid(t)
            val v = (-sinD(angle) - sinD(decl) * sinD(lat)) / (cosD(decl) * cosD(lat))
            if (v < -1.0 || v > 1.0) return Double.NaN
            val h = acosD(v) / 15.0
            return noon + (if (ccw) -h else h)
        }

        fun asrTime(factor: Double, t: Double): Double {
            val decl = sunPosition(jd + t).decl
            return angleTime(-acotD(factor + tanD(abs(lat - decl))), t, false)
        }

        fun shifted(x: Double): Double = if (x.isNaN()) x else x + shift

        var fajr = 5.0
        var sunrise = 6.0
        var dhuhr = 12.0
        var asr = 13.0
        var maghrib = 18.0
        var isha = 18.0
        for (i in 0 until 3) {
            val nFajr = angleTime(method.fajrAngle, fajr / 24.0, true)
            val nSunrise = angleTime(0.833, sunrise / 24.0, true)
            val nDhuhr = mid(dhuhr / 24.0)
            val nAsr = asrTime(1.0, asr / 24.0)
            val nMaghrib = angleTime(0.833, maghrib / 24.0, false)
            val nIsha = if (method.ishaMinutesAfterMaghrib != null) 0.0 else angleTime(method.ishaAngle, isha / 24.0, false)
            fajr = shifted(nFajr)
            sunrise = shifted(nSunrise)
            dhuhr = shifted(nDhuhr)
            asr = shifted(nAsr)
            maghrib = shifted(nMaghrib)
            isha = shifted(nIsha)
        }
        val minutes = method.ishaMinutesAfterMaghrib
        if (minutes != null) isha = maghrib + minutes / 60.0
        return Hours(fajr, sunrise, dhuhr, asr, maghrib, isha)
    }

    private fun offsetHours(date: LocalDate, zone: ZoneId): Double =
        zone.rules.getOffset(date.atTime(12, 0)).totalSeconds / 3600.0

    /**
     * Prayer times for one day at a location.
     * Standard angles are used when the sun reaches them. Otherwise (summer nights in Northern Europe)
     * the "one-seventh of the night" rule applies. Latitudes beyond 65 degrees use 65 and are flagged approximate.
     * Returns null only when sunrise or sunset does not exist even at the clamped latitude.
     */
    fun compute(
        date: LocalDate,
        lat: Double,
        lon: Double,
        zone: ZoneId,
        method: PrayerMethod,
        adjustments: Map<String, Int>
    ): PrayerTimes? {
        var approximate = false
        var latUsed = lat
        if (abs(latUsed) > 65.0) {
            latUsed = if (latUsed > 0) 65.0 else -65.0
            approximate = true
        }
        val tz = offsetHours(date, zone)
        val h = hoursFor(date.year, date.monthValue, date.dayOfMonth, latUsed, lon, tz, method)
        if (h.sunrise.isNaN() || h.maghrib.isNaN()) return null
        // An angle solution is valid only in its own part of the day.
        if (!(h.isha > h.maghrib && h.isha < 24.0)) h.isha = Double.NaN
        if (!(h.fajr < h.sunrise && h.fajr > 0.0)) h.fajr = Double.NaN

        val next = date.plusDays(1)
        val tomorrowTz = offsetHours(next, zone)
        val tomorrow = hoursFor(next.year, next.monthValue, next.dayOfMonth, latUsed, lon, tomorrowTz, method)
        val night = (tomorrow.sunrise + 24.0) - h.maghrib
        val seventh = night / 7.0
        var highLatitude = false
        if (h.fajr.isNaN()) {
            h.fajr = h.sunrise - seventh
            highLatitude = true
        }
        if (h.isha.isNaN()) {
            h.isha = h.maghrib + seventh
            highLatitude = true
        }
        val values = doubleArrayOf(h.fajr, h.sunrise, h.dhuhr, h.asr, h.maghrib, h.isha)
        if (values.any { it.isNaN() }) return null

        val start = date.atStartOfDay()
        fun at(v: Double, key: String): LocalDateTime =
            start.plusMinutes(Math.round(v * 60.0) + (adjustments[key] ?: 0).toLong())

        return PrayerTimes(
            fajr = at(h.fajr, "Fajr"),
            sunrise = at(h.sunrise, "Sunrise"),
            dhuhr = at(h.dhuhr, "Dhuhr"),
            asr = at(h.asr, "Asr"),
            maghrib = at(h.maghrib, "Maghrib"),
            isha = at(h.isha, "Isha"),
            highLatitude = highLatitude,
            approximate = approximate
        )
    }

    /** Qibla bearing in degrees clockwise from true north (great-circle bearing to the Kaaba). */
    fun qiblaBearing(lat: Double, lon: Double): Double {
        val kaabaLat = 21.4225
        val kaabaLon = 39.8262
        val dl = rad(kaabaLon - lon)
        val y = sin(dl) * cos(rad(kaabaLat))
        val x = cos(rad(lat)) * sin(rad(kaabaLat)) - sin(rad(lat)) * cos(rad(kaabaLat)) * cos(dl)
        return (deg(atan2(y, x)) + 360.0) % 360.0
    }
}
