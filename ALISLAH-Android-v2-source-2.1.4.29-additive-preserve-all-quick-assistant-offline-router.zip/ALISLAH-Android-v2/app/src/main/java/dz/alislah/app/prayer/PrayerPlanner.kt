package dz.alislah.app.prayer

import java.time.Instant
import java.time.ZoneId

/** One alarm of the plan. kind is "adhan", "before" or "after". */
data class PlannedAlarm(val kind: String, val name: String, val atMillis: Long)

/** Builds the reminder plan natively, so it can be rebuilt without the web layer or an open app. */
object PrayerPlanner {
    private val ORDER = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
    private val NAMES = mapOf(
        "Fajr" to "الفجر",
        "Dhuhr" to "الظهر",
        "Asr" to "العصر",
        "Maghrib" to "المغرب",
        "Isha" to "العشاء"
    )

    /** Alarms for the next [days] days, sorted by time, all strictly after [nowMillis]. */
    fun build(
        lat: Double,
        lon: Double,
        methodKey: String,
        adjustments: Map<String, Int>,
        beforeMinutes: Int,
        afterMinutes: Int,
        followup: Boolean,
        nowMillis: Long,
        zone: ZoneId,
        days: Int
    ): List<PlannedAlarm> {
        val method = PrayerMethods.byKey(methodKey)
        val today = Instant.ofEpochMilli(nowMillis).atZone(zone).toLocalDate()
        val out = ArrayList<PlannedAlarm>()
        for (i in 0 until days) {
            val date = today.plusDays(i.toLong())
            val times = PrayerEngine.compute(date, lat, lon, zone, method, adjustments) ?: continue
            val byKey = mapOf(
                "Fajr" to times.fajr,
                "Dhuhr" to times.dhuhr,
                "Asr" to times.asr,
                "Maghrib" to times.maghrib,
                "Isha" to times.isha
            )
            for (key in ORDER) {
                val at = byKey.getValue(key).atZone(zone).toInstant().toEpochMilli()
                val name = NAMES[key] ?: key
                out.add(PlannedAlarm("adhan", name, at))
                if (beforeMinutes > 0) out.add(PlannedAlarm("before", name, at - beforeMinutes * 60_000L))
                if (followup && afterMinutes > 0) out.add(PlannedAlarm("after", name, at + afterMinutes * 60_000L))
            }
        }
        return out.filter { it.atMillis > nowMillis }.sortedBy { it.atMillis }
    }
}
