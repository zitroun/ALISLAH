package dz.alislah.app

import android.content.Context
import android.os.Build
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView

/** A small pill beside the bubble that says one useful thing for three seconds. */
class BubbleHint(private val context: Context, private val wm: WindowManager) {
    private val density = context.resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())
    private val remove = Runnable { dismiss() }
    private var shown: View? = null

    fun show(text: String, bubbleX: Int, bubbleY: Int, bubbleSize: Int, leftDock: Boolean) {
        dismiss()
        val pill = TextView(context).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.WHITE)
            val h = (8f * density).toInt()
            val v = (7f * density).toInt()
            setPadding(h * 2, v, h * 2, v)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 16f * density
                setColor(Color.argb(232, 12, 40, 34))
            }
            elevation = 10f * density
            alpha = 0f
        }
        pill.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val gap = (8f * density).toInt()
        val width = pill.measuredWidth
        val height = pill.measuredHeight
        val posX = if (leftDock) bubbleX + bubbleSize + gap else bubbleX - gap - width
        val posY = bubbleY + (bubbleSize - height) / 2
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            (if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = posX
            y = posY
        }
        try {
            wm.addView(pill, lp)
            shown = pill
            if (android.animation.ValueAnimator.areAnimatorsEnabled()) {
                pill.animate().alpha(1f).setDuration(180L).start()
            } else {
                pill.alpha = 1f
            }
            handler.postDelayed(remove, 3000L)
        } catch (e: Exception) {
            Log.w(TAG, "hint show", e)
        }
    }

    fun dismiss() {
        handler.removeCallbacks(remove)
        val v = shown ?: return
        shown = null
        try {
            wm.removeView(v)
        } catch (e: Exception) {
            Log.w(TAG, "hint dismiss", e)
        }
    }

    companion object {
        private const val TAG = "ALISLAH-Bubble"
    }
}
