package dz.alislah.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityManager
import android.view.accessibility.AccessibilityWindowInfo

/**
 * Tells the bubble when an app covers the whole screen. It reads window bounds only:
 * the service does not retrieve window content and sends nothing anywhere.
 */
class FullscreenWatcherService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return
        FullscreenState.update(pkg, isFullscreenNow())
    }

    override fun onInterrupt() {
        // nothing to interrupt: the service gives no spoken feedback
    }

    override fun onDestroy() {
        FullscreenState.update("", false)
        super.onDestroy()
    }

    private fun isFullscreenNow(): Boolean {
        val all = windows ?: return false
        val dm = resources.displayMetrics
        val bounds = Rect()
        for (w in all) {
            if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION || !w.isActive) continue
            w.getBoundsInScreen(bounds)
            return bounds.left <= 0 && bounds.top <= 0 && bounds.right >= dm.widthPixels && bounds.bottom >= dm.heightPixels
        }
        return false
    }
}

/** The latest answer from the accessibility watcher, read by the bubble. */
object FullscreenState {
    @Volatile
    var active = false

    @Volatile
    var pkg: String? = null

    fun update(newPkg: String, fullscreen: Boolean) {
        pkg = newPkg
        active = fullscreen
    }
}

/** Whether the user has granted the accessibility permission to ALISLAH. */
object AccessibilityChecks {
    fun isEnabled(context: Context): Boolean {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false
        val expected = FullscreenWatcherService::class.java.name
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
            it.resolveInfo.serviceInfo.packageName == context.packageName && it.resolveInfo.serviceInfo.name == expected
        }
    }
}
