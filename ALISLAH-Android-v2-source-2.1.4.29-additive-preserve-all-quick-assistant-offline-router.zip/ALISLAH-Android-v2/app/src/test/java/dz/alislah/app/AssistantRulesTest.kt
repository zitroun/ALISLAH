package dz.alislah.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AssistantRulesTest {

    @Test
    fun questionsAreTrimmedAndCollapsed() {
        assertEquals("ما أفضل وقت للمذاكرة؟", AssistantRules.cleanQuestion("  ما   أفضل\nوقت للمذاكرة؟  "))
        assertNull(AssistantRules.cleanQuestion("   "))
        assertNull(AssistantRules.cleanQuestion(null))
    }

    @Test
    fun questionsAreCapped() {
        val long = "أ".repeat(AssistantRules.MAX_QUESTION_CHARS + 50)
        assertEquals(AssistantRules.MAX_QUESTION_CHARS, AssistantRules.cleanQuestion(long)!!.length)
    }

    @Test
    fun onlySafeHttpsEndpointsAreAccepted() {
        assertTrue(AssistantRules.isAllowedEndpoint("https://alislah-ai.example.workers.dev/"))
        assertFalse(AssistantRules.isAllowedEndpoint("http://example.com/"))
        assertFalse(AssistantRules.isAllowedEndpoint("https://user:secret@example.com/"))
        assertFalse(AssistantRules.isAllowedEndpoint("https://exa mple.com/"))
        assertFalse(AssistantRules.isAllowedEndpoint(""))
        assertFalse(AssistantRules.isAllowedEndpoint(null))
    }

    @Test
    fun onlyTemporaryFailuresAreRetried() {
        assertTrue(AssistantRules.shouldRetry(429))
        assertTrue(AssistantRules.shouldRetry(503))
        assertTrue(AssistantRules.shouldRetry(408))
        assertFalse(AssistantRules.shouldRetry(400))
        assertFalse(AssistantRules.shouldRetry(404))
        assertFalse(AssistantRules.shouldRetry(200))
    }

    @Test
    fun backoffGrows() {
        assertTrue(AssistantRules.backoffMs(1) > AssistantRules.backoffMs(0))
    }

    @Test
    fun repliesAndErrorsAreRead() {
        assertEquals(Pair("مرحباً", null), AssistantRules.parseReply("{\"reply\":\"مرحباً\"}"))
        assertEquals(Pair(null, "انتهت الحصة"), AssistantRules.parseReply("{\"error\":\"انتهت الحصة\"}"))
        assertEquals(Pair(null, "الخدمة لم تُرجع إجابة صالحة."), AssistantRules.parseReply("<html>not json</html>"))
    }

    @Test
    fun statusMessagesAreFriendly() {
        assertTrue(AssistantRules.messageForStatus(429).contains("مشغولة"))
        assertTrue(AssistantRules.messageForStatus(503).contains("متعطّل"))
        assertTrue(AssistantRules.messageForStatus(404).contains("غير صحيح"))
    }
}
