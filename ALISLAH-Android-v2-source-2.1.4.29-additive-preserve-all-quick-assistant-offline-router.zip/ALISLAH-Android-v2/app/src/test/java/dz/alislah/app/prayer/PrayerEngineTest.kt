package dz.alislah.app.prayer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

class PrayerEngineTest {

    private fun minutesOf(t: LocalDateTime): Int = t.hour * 60 + t.minute

    private fun assertNear(label: String, expectedHhmm: String, actual: LocalDateTime, tolerance: Int) {
        val parts = expectedHhmm.split(":")
        val expected = parts[0].toInt() * 60 + parts[1].toInt()
        val diff = Math.abs(minutesOf(actual) - expected)
        assertTrue("$label: expected $expectedHhmm but was ${actual.toLocalTime()}", diff <= tolerance)
    }

    @Test
    fun algiersMatchesTheReferenceCalculation() {
        val zone = ZoneId.of("Africa/Algiers")
        val t = PrayerEngine.compute(LocalDate.of(2026, 10, 31), 36.75, 3.06, zone, PrayerMethods.ALGERIA, emptyMap())
        assertNotNull(t)
        val times = t!!
        assertNear("fajr", "05:43", times.fajr, 2)
        assertNear("dhuhr", "12:31", times.dhuhr, 2)
        assertNear("asr", "15:29", times.asr, 2)
        assertNear("maghrib", "17:52", times.maghrib, 2)
        assertNear("isha", "19:14", times.isha, 2)
        assertFalse(times.highLatitude)
        assertFalse(times.approximate)
    }

    @Test
    fun tiaretStaysOnTheStandardRuleInSummer() {
        val zone = ZoneId.of("Africa/Algiers")
        val t = PrayerEngine.compute(LocalDate.of(2026, 6, 21), 35.37, 1.32, zone, PrayerMethods.ALGERIA, emptyMap())
        assertNotNull(t)
        assertFalse(t!!.highLatitude)
        assertFalse(t.approximate)
    }

    @Test
    fun summerNightsInNorthernEuropeStillHaveTimes() {
        val paris = PrayerEngine.compute(LocalDate.of(2026, 6, 21), 48.86, 2.35, ZoneId.of("Europe/Paris"), PrayerMethods.MWL, emptyMap())
        assertNotNull("paris", paris)
        val p = paris!!
        assertTrue(p.highLatitude)
        assertTrue(p.fajr.isBefore(p.sunrise))
        assertTrue(p.isha.isAfter(p.maghrib))
        assertNear("paris fajr", "04:40", p.fajr, 3)
        assertNear("paris isha", "23:05", p.isha, 3)

        val london = PrayerEngine.compute(LocalDate.of(2026, 6, 21), 51.51, -0.13, ZoneId.of("Europe/London"), PrayerMethods.MWL, emptyMap())
        assertNotNull("london", london)
        assertNear("london fajr", "03:40", london!!.fajr, 3)
        assertNear("london isha", "22:25", london.isha, 3)
    }

    @Test
    fun latitudesBeyond65DegreesAreFlaggedApproximate() {
        val t = PrayerEngine.compute(LocalDate.of(2026, 6, 21), 69.65, 18.96, ZoneId.of("Europe/Oslo"), PrayerMethods.MWL, emptyMap())
        assertNotNull(t)
        assertTrue(t!!.approximate)
    }

    @Test
    fun adjustmentsShiftOnlyTheirPrayer() {
        val zone = ZoneId.of("Africa/Algiers")
        val base = PrayerEngine.compute(LocalDate.of(2026, 10, 31), 36.75, 3.06, zone, PrayerMethods.ALGERIA, emptyMap())!!
        val shifted = PrayerEngine.compute(LocalDate.of(2026, 10, 31), 36.75, 3.06, zone, PrayerMethods.ALGERIA, mapOf("Dhuhr" to 2))!!
        assertEquals(2L, Duration.between(base.dhuhr, shifted.dhuhr).toMinutes())
        assertEquals(base.fajr, shifted.fajr)
    }

    @Test
    fun qiblaFromTiaretIsAboutOneHundredTwoDegrees() {
        val bearing = PrayerEngine.qiblaBearing(35.37, 1.32)
        assertTrue("bearing $bearing", Math.abs(bearing - 102.1) < 0.5)
    }
}
