package dz.alislah.app.prayer

import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class PrayerPlannerTest {

    @Test
    fun thirtyDaysAreSortedFutureAndComplete() {
        val zone = ZoneId.of("Africa/Algiers")
        val now = LocalDate.of(2026, 11, 17).atTime(8, 0).atZone(zone).toInstant().toEpochMilli()
        val plan = PrayerPlanner.build(35.37, 1.32, "algeria", emptyMap(), 10, 20, true, now, zone, 30)
        assertTrue(plan.isNotEmpty())
        assertTrue(plan.all { it.atMillis > now })
        assertTrue(plan.zipWithNext().all { (a, b) -> a.atMillis <= b.atMillis })
        val adhans = plan.count { it.kind == "adhan" }
        // today has four prayers left after 08:00, then five prayers for each of the next 29 days
        assertTrue("adhans $adhans", adhans == 149)
        assertTrue(plan.any { it.kind == "before" })
        assertTrue(plan.any { it.kind == "after" })
    }

    @Test
    fun disabledExtrasLeaveOnlyTheAdhan() {
        val zone = ZoneId.of("Africa/Algiers")
        val now = LocalDate.of(2026, 11, 17).atTime(8, 0).atZone(zone).toInstant().toEpochMilli()
        val plan = PrayerPlanner.build(35.37, 1.32, "algeria", emptyMap(), 0, 0, false, now, zone, 3)
        assertTrue(plan.all { it.kind == "adhan" })
    }

    @Test
    fun clockTimesStayOnTheWallClockAcrossTheDstChange() {
        val zone = ZoneId.of("Europe/Paris")
        val start = LocalDate.of(2026, 3, 27).atTime(0, 0).atZone(zone).toInstant().toEpochMilli()
        val plan = PrayerPlanner.build(48.86, 2.35, "mwl", emptyMap(), 0, 0, false, start, zone, 5)
        val dhuhrHours = plan.filter { it.name == "الظهر" }
            .map { Instant.ofEpochMilli(it.atMillis).atZone(zone).toLocalTime().hour }
        assertTrue("dhuhr hours $dhuhrHours", dhuhrHours.all { it == 12 || it == 13 })
    }
}
