package dz.alislah.app

import org.junit.Assert.assertEquals
import org.junit.Test

class OfflineCommandRouterTest {
    @Test fun opensPrayerAndMainSectionsOffline() {
        assertEquals("prayer", OfflineCommandRouter.parse("افتح صفحة الصلاة")?.value)
        assertEquals("tasks", OfflineCommandRouter.parse("افتح المهام")?.value)
        assertEquals("family", OfflineCommandRouter.parse("افتح صفحة الأسرة")?.value)
        assertEquals("qibla", OfflineCommandRouter.parse("افتح القبلة")?.value)
        assertEquals("adhkar", OfflineCommandRouter.parse("افتح صفحة الأذكار")?.value)
        assertEquals("more", OfflineCommandRouter.parse("افتح زادك اليوم")?.value)
    }

    @Test fun readsZadAndRunsDeviceActionsOffline() {
        assertEquals(OfflineCommandRouter.Type.READ_ZAD, OfflineCommandRouter.parse("اقرأ زادك اليوم")?.type)
        assertEquals(OfflineCommandRouter.Type.MOVE_BUBBLE_LEFT, OfflineCommandRouter.parse("انقل الفقاعة الرئيسية إلى الحافة اليسرى")?.type)
        assertEquals(OfflineCommandRouter.Type.STOP_ADHAN, OfflineCommandRouter.parse("أغلق الأذان")?.type)
        assertEquals(OfflineCommandRouter.Type.STOP_ASSISTANT, OfflineCommandRouter.parse("أوقف صوت المساعد")?.type)
    }
}
