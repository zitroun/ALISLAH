/* Family sync server (2.1.4.28), reference for a Cloudflare Worker with a KV namespace bound as FAMILY_SYNC.
   It stores only encrypted blobs. It never sees the household's data or the passphrase. */
const CODE = /^[A-Za-z0-9_-]{22}$/;
const MAX_BYTES = 2 * 1024 * 1024;
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, PUT, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
};
function json(status, body) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' },
  });
}
export async function handle(request, kv) {
  if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
  const match = /^\/v1\/family\/([A-Za-z0-9_-]{22})$/.exec(new URL(request.url).pathname);
  if (!match || !CODE.test(match[1])) return json(404, { error: 'not found' });
  const key = 'family:' + match[1];
  if (request.method === 'GET') {
    const record = await kv.get(key, 'json');
    return record ? json(200, record) : json(404, { error: 'no snapshot' });
  }
  if (request.method === 'PUT') {
    if (Number(request.headers.get('content-length') || 0) > MAX_BYTES) return json(413, { error: 'too large' });
    const text = await request.text();
    if (text.length > MAX_BYTES) return json(413, { error: 'too large' });
    let body;
    try { body = JSON.parse(text); } catch { return json(400, { error: 'bad json' }); }
    if (!body || typeof body.blob !== 'string' || !Number.isInteger(body.baseVersion) || body.baseVersion < 0) {
      return json(400, { error: 'bad body' });
    }
    const current = await kv.get(key, 'json');
    const version = current ? current.version : 0;
    if (body.baseVersion !== version) return json(409, { error: 'version conflict', version });
    const record = { version: version + 1, updatedAt: new Date().toISOString(), blob: body.blob };
    await kv.put(key, JSON.stringify(record));
    return json(200, { version: record.version, updatedAt: record.updatedAt });
  }
  return json(405, { error: 'method not allowed' });
}
export default {
  fetch(request, env) { return handle(request, env.FAMILY_SYNC); },
};
