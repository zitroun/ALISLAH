"""Visual check (2.1.4.26): compares screenshots with a baseline and fails when too many pixels changed.
Usage: python3 tests/visual/compare.py <baselineDir> <currentDir>   (VISUAL_LIMIT defaults to 1%)."""
import os, sys
from PIL import Image, ImageChops

base, cur = sys.argv[1], sys.argv[2]
limit = float(os.environ.get('VISUAL_LIMIT', '0.01'))
problems = []
checked = 0
for name in sorted(os.listdir(base)):
    if not name.endswith('.png'):
        continue
    checked += 1
    other = os.path.join(cur, name)
    if not os.path.exists(other):
        problems.append((name, 'missing'))
        continue
    a = Image.open(os.path.join(base, name)).convert('RGB')
    b = Image.open(other).convert('RGB')
    if a.size != b.size:
        problems.append((name, 'size'))
        continue
    diff = ImageChops.difference(a, b).convert('L').point(lambda v: 255 if v > 16 else 0)
    changed = a.size[0] * a.size[1] - diff.histogram()[0]
    share = changed / (a.size[0] * a.size[1])
    if share > limit:
        problems.append((name, round(share * 100, 2)))
print('visual check: %d views compared' % checked, '- all within limit' if not problems else problems)
sys.exit(1 if problems else 0)
