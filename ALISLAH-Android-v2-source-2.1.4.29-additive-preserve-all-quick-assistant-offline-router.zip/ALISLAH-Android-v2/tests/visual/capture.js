// Visual check (2.1.4.26). Captures the main views at 390px into a folder.
// Usage: CHROMIUM_PATH=<optional> node tests/visual/capture.js <outDir>
// Then:  python3 tests/visual/compare.py <baselineDir> <outDir>
const path = require('path');
const fs = require('fs');
const { chromium } = require('playwright');
(async () => {
  const out = process.argv[2] || '/tmp/visual-current';
  const index = path.resolve(__dirname, '../../app/src/main/assets/index.html');
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const page = await browser.newPage({ viewport: { width: 390, height: 844 } });
  await page.goto('file://' + index);
  await page.waitForTimeout(700);
  const views = ['tasks', 'habits', 'prayer', 'family', 'assistant', 'behavior', 'settings', 'more',
    'dashboard', 'adhkar', 'qibla', 'worship', 'calendar', 'report', 'focustimer', 'zakat'];
  for (const v of views) {
    await page.evaluate((name) => ALI.tab(name), v);
    await page.waitForTimeout(300);
    await page.screenshot({ path: path.join(out, v + '.png') });
  }
  await browser.close();
  console.log('captured ' + views.length + ' views into ' + out);
})();
