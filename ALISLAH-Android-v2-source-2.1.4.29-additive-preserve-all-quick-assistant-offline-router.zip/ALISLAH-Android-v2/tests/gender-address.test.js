const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const gender = require('../app/src/main/assets/js/gender.js');
const cases = [
  ['ابدأ الآن', 'ابدئي الآن'],
  ['أضف مهمة', 'أضيفي مهمة'],
  ['أنتَ صديقي', 'أنتِ صديقتي'],
  ['تريد المساعدة', 'تريدين المساعدة'],
  ['افتح الإعدادات', 'افتحي الإعدادات']
];
for (const [masculine, feminine] of cases) {
  if (gender.toFemale(masculine) !== feminine) throw new Error('female conversion failed: ' + masculine);
  if (gender.toMale(feminine) !== masculine) throw new Error('male conversion failed: ' + feminine);
}
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const main = fs.readFileSync(path.join(root, 'app/src/main/assets/js/main.js'), 'utf8');
const tools = fs.readFileSync(path.join(root, 'app/src/main/assets/js/tools.js'), 'utf8');
if (!html.includes('id=\"addressGender\"') || !html.includes('id=\"welcomeGender\"')) throw new Error('gender selectors missing from UI');
if (!main.includes('window.ALI_G.set(data.settings.addressGender') || !main.includes('RETRY_STATUS')) throw new Error('gender or retry integration missing');
if (!tools.includes("S().addressGender=g") || !tools.includes("$('#addressGender').value")) throw new Error('settings gender persistence missing');
console.log('Gender address conversion and integration tests passed.');
