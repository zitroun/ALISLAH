from pathlib import Path
root = Path(__file__).resolve().parents[1]
html = (root / 'app/src/main/assets/index.html').read_text(encoding='utf-8')
js = (root / 'app/src/main/assets/js/main.js').read_text(encoding='utf-8')
native = (root / 'app/src/main/java/dz/alislah/app/MainActivity.kt').read_text(encoding='utf-8')
ics = (root / 'app/src/main/assets/js/ics.js').read_text(encoding='utf-8')
assert 'id="exportTasksCalendar"' in html
assert '<script src="js/ics.js"></script>' in html
assert "bindClick('#exportTasksCalendar',exportTasksCalendar)" in js
assert "AndroidUsage.saveCalendar" in js
assert '@JavascriptInterface fun saveCalendar(filename: String, content: String)' in native
assert 'type = "text/calendar"' in native
assert 'STATUS:CONFIRMED' in ics
print('calendar export contracts OK')
