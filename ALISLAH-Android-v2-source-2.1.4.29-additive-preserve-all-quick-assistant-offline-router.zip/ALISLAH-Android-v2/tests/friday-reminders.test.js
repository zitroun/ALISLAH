const assert = require('assert');
const F = require('../app/src/main/assets/js/friday.js');
assert.deepStrictEqual(F.fridayReminders(1), []);
assert.strictEqual(F.fridayReminders(5).length, 3);
assert.ok(F.fridayReminders(5)[0].includes('الكهف'));
console.log('friday-reminders: all checks pass');
