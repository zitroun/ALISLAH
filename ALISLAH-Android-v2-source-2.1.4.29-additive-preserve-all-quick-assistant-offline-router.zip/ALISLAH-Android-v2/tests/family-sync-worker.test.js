const assert = require('assert');
(async () => {
  const W = await import('../worker/family-sync/worker.mjs');
  const store = new Map();
  const kv = {
    async get(k, type) { const v = store.get(k); if (v === undefined) return null; return type === 'json' ? JSON.parse(v) : v; },
    async put(k, v) { store.set(k, v); },
  };
  const code = 'abcdefghijklmnopqrstuv';
  const url = 'https://example.test/v1/family/' + code;
  let r = await W.handle(new Request(url), kv);
  assert.strictEqual(r.status, 404, 'nothing stored yet');
  r = await W.handle(new Request(url, { method: 'PUT', body: JSON.stringify({ baseVersion: 0, blob: '{}' }) }), kv);
  assert.strictEqual(r.status, 200); assert.strictEqual((await r.json()).version, 1);
  r = await W.handle(new Request(url, { method: 'PUT', body: JSON.stringify({ baseVersion: 0, blob: '{}' }) }), kv);
  assert.strictEqual(r.status, 409, 'an older copy cannot overwrite a newer one');
  r = await W.handle(new Request(url, { method: 'PUT', body: JSON.stringify({ baseVersion: 1, blob: '{"v":1}' }) }), kv);
  assert.strictEqual((await r.json()).version, 2);
  r = await W.handle(new Request(url), kv);
  const got = await r.json();
  assert.strictEqual(got.version, 2); assert.strictEqual(got.blob, '{"v":1}');
  r = await W.handle(new Request('https://example.test/v1/family/short'), kv);
  assert.strictEqual(r.status, 404, 'malformed codes are refused');
  r = await W.handle(new Request(url, { method: 'PUT', body: 'not json' }), kv);
  assert.strictEqual(r.status, 400);
  r = await W.handle(new Request(url, { method: 'PUT', body: JSON.stringify({ baseVersion: 2, blob: 'x'.repeat(2 * 1024 * 1024 + 1) }) }), kv);
  assert.strictEqual(r.status, 413, 'oversized snapshots are refused');
  r = await W.handle(new Request(url, { method: 'OPTIONS' }), kv);
  assert.strictEqual(r.status, 204);
  console.log('family-sync worker: all checks pass');
})().catch((e) => { console.error(e); process.exit(1); });
