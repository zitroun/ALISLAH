const assert = require('assert');
const Z = require('../app/src/main/assets/js/zakat.js');
// cash above the gold nisab: 2.5% is due
let r = Z.zakat({ cash: 2000000, goldPrice: 15000 });
assert.strictEqual(r.nisab, 1275000); assert.strictEqual(r.eligible, true); assert.strictEqual(r.due, 50000);
// debts bring the net wealth below the nisab
r = Z.zakat({ cash: 2000000, debts: 1000000, goldPrice: 15000 });
assert.strictEqual(r.eligible, false); assert.strictEqual(r.due, 0);
// the silver basis reaches the nisab where gold does not
r = Z.zakat({ cash: 150000, silverPrice: 200, nisabBasis: 'silver' });
assert.strictEqual(r.eligible, true); assert.strictEqual(r.due, 3750);
r = Z.zakat({ cash: 150000, silverPrice: 200, goldPrice: 15000, nisabBasis: 'gold' });
assert.strictEqual(r.eligible, false);
// no prices, no nisab, nothing due
r = Z.zakat({ cash: 500000 });
assert.strictEqual(r.nisab, 0); assert.strictEqual(r.eligible, false);
// fitra: people times the amount each, times the price of the staple
const f = Z.fitra({ people: 4, kgEach: 2.5, pricePerKg: 300 });
assert.strictEqual(f.kgTotal, 10); assert.strictEqual(f.amount, 3000);
assert.strictEqual(Z.fitra({ people: 0, pricePerKg: 300 }).amount, 0);
console.log('zakat-calc: all checks pass');
