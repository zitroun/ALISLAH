// node tests/ics.test.js — the calendar file must be valid RFC 5545 text
const assert=require('assert');
const I=require('../app/src/main/assets/js/ics.js');
const out=I.build([
  {id:'a1',text:'ترتيب المطبخ, والخزانة;مهم',date:'2026-11-16',time:'18:00',priority:'مهمة جدًا',done:false},
  {id:'b2',text:'شراء الخضار',date:'2026-11-17',time:'',priority:'عادية',done:true},
  {id:'bad',text:'',date:'2026-11-17'},
  {id:'c3',text:'x'.repeat(200),date:'bad-date'}
],new Date(Date.UTC(2026,10,16,9,0,0)));
const lines=out.split('\r\n').filter(Boolean);
assert.strictEqual(lines[0],'BEGIN:VCALENDAR');
assert.strictEqual(lines[lines.length-1],'END:VCALENDAR');
assert.strictEqual(out.split('BEGIN:VEVENT').length-1,2,'two valid events, invalid ones skipped');
assert(out.includes('DTSTART:20261116T180000'),'timed task');
assert(out.includes('DTSTART;VALUE=DATE:20261117'),'all-day task');
assert(out.includes('STATUS:CONFIRMED') && out.includes('X-ALISLAH-DONE:TRUE'));
assert(!out.includes('STATUS:COMPLETED'),'VEVENT must not use the VTODO COMPLETED status');
assert(out.includes('SUMMARY:ترتيب المطبخ\\, والخزانة\\;مهم'),'commas and semicolons escaped');
for (const l of lines) assert(Buffer.byteLength(l,'utf8')<=75,'line over 75 octets: '+l.slice(0,30));
console.log('ics tests OK');
