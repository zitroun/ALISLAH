const assert = require('assert');
const W = require('../app/src/main/assets/js/family-week.js');
const now = new Date(2026, 10, 22, 10, 0);
const kidsDone = { '2026-11-22': ['صيد الألوان', 'غناء الحروف'], '2026-11-16': ['تلوين'], '2026-11-10': ['قديم'] };
const tasks = [
  { date: '2026-11-21', done: true }, { date: '2026-11-21', done: false },
  { date: '2026-11-15', done: true }, { done: true }
];
const prayerLog = [
  { name: 'الفجر', day: '2026-11-22', done: true }, { name: 'الظهر', day: '2026-11-22', done: true },
  { name: 'الفجر', day: '2026-11-22', done: true },
  { name: 'العصر', day: '2026-11-20', done: false },
  { name: 'المغرب', date: '2026-11-21T18:00:00.000Z' },
  { name: 'الفجر', day: '2026-11-01', done: true }
];
const s = W.weeklySummary({ kidsDone, tasks, prayerLog }, now);
assert.deepStrictEqual(s, { kidsDone: 3, tasksDone: 1, prayersLogged: 3 });
assert.strictEqual(W.stars(kidsDone, now), 3);
assert.strictEqual(W.inLastDays('2026-11-16', now, 7), true, 'six days ago is inside the week');
assert.strictEqual(W.inLastDays('2026-11-15', now, 7), false, 'seven days ago is outside');
assert.strictEqual(W.inLastDays('2026-11-23', now, 7), false, 'the future is not counted');
assert.strictEqual(W.inLastDays('bad', now, 7), false);
assert.deepStrictEqual(W.weeklySummary({}, now), { kidsDone: 0, tasksDone: 0, prayersLogged: 0 });
console.log('family-week: all checks pass');
