from pathlib import Path
root=Path(__file__).resolve().parents[1]
js=(root/'app/src/main/assets/js/dashboard.js').read_text(encoding='utf-8')
html=(root/'app/src/main/assets/index.html').read_text(encoding='utf-8')
css=(root/'app/src/main/assets/app.css').read_text(encoding='utf-8')
checks={
 'context banner is accessible and visible':'dashboardContextText' in html and 'aria-live="polite"' in html,
 'context uses time of day':'morning' in js and 'evening' in js and 'night' in js,
 'context detects overdue and busy days':"late.length" in js and "due.length>=4" in js,
 'notifications prioritize overdue tasks':"rows.sort(function(a,b)" in js and "x.kind==='red'?0" in js,
 'evening summary includes upcoming tasks':'أقرب مهام الأيام القادمة' in js,
 'context refreshes on prayer and app visibility':'visibilitychange' in js and "alislah:prayer-updated" in js,
 'accessibility focus outlines are present':'focus-visible' in css and 'alislah-accessible' in css,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
if not all(checks.values()): raise SystemExit('Dashboard context checks failed')
