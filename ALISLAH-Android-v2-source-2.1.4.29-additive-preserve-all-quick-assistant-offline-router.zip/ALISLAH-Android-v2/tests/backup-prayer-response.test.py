from pathlib import Path

root = Path(__file__).resolve().parents[1]
main = (root / "app/src/main/assets/js/main.js").read_text(encoding="utf-8")
prayer = (root / "app/src/main/assets/js/prayer.js").read_text(encoding="utf-8")
checks = {
    "backup import validates and keeps explicit yes/no prayer answers": "const prayerResponses=" in main and "done:p.done===true" in main,
    "backup import returns prayer responses to restore": "prayerLog,prayerResponses,checkins" in main,
    "restore writes both completed prayer log and answer history": "prayerLog:c.prayerLog,prayerResponses:c.prayerResponses" in main,
    "negative answer remains separate from completed prayers": "done?'done':'not-yet'" in prayer and "done!==false" in prayer,
    "answer history remains bounded": ".slice(-1500)" in main and "d.prayerResponses=d.prayerResponses.slice(-1500)" in prayer,
}
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if not all(checks.values()):
    raise SystemExit("Prayer response backup checks failed")
