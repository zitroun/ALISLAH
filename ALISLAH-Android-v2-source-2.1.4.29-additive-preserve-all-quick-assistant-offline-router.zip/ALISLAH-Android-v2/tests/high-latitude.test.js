// node tests/high-latitude.test.js — summer nights in Northern Europe must still produce prayer times
const assert=require('assert');
const P=require('../app/src/main/assets/js/prayer-data.js');
const hr=d=>d.getHours()+d.getMinutes()/60;
const cases=[['Paris','Europe/Paris',48.86,2.35],['London','Europe/London',51.51,-0.13],['Oslo','Europe/Oslo',59.91,10.75],['Stockholm','Europe/Stockholm',59.33,18.07],['Reykjavik','Atlantic/Reykjavik',64.15,-21.94],['Tromso','Europe/Oslo',69.65,18.96]];
for(const [n,tz,la,lo] of cases){
  process.env.TZ=tz;
  const t=P.compute(new Date(2026,5,21,12),la,lo,'mwl');
  assert(t,n+': no times on 21 June');
  assert(t.Fajr<t.Sunrise&&t.Sunrise<t.Dhuhr&&t.Dhuhr<t.Asr&&t.Asr<t.Maghrib&&t.Maghrib<t.Isha,n+': order');
  assert(hr(t.Fajr)>1&&hr(t.Fajr)<5,n+": fajr "+hr(t.Fajr).toFixed(2));
  const ih=hr(t.Isha); assert(ih>20.5||ih<2,n+': isha '+ih.toFixed(2)); // at 64 N the Isha can fall just after midnight
  assert.strictEqual(t.highLat,true,n+': high-latitude rule expected in June');
}
process.env.TZ='Europe/Oslo';
assert.strictEqual(P.compute(new Date(2026,5,21,12),69.65,18.96,'mwl').approx,true,'Tromso must be flagged approx');
const winter=P.compute(new Date(2026,11,21,12),59.91,10.75,'mwl');
assert(winter&&!winter.highLat,'Oslo in December uses the normal angle rule');
process.env.TZ='Africa/Algiers';
const tiaret=P.compute(new Date(2026,5,21,12),35.37,1.32,'algeria');
assert(tiaret&&!tiaret.highLat&&!tiaret.approx,'Tiaret stays on the standard rule');
console.log('high-latitude tests OK');
