const assert = require('assert');
const A = require('../app/src/main/assets/js/prayer-anchor.js');
assert.strictEqual(A.shiftHHMM('12:30', 10), '12:40');
assert.strictEqual(A.shiftHHMM('23:55', 10), '00:05', 'wraps past midnight');
assert.strictEqual(A.shiftHHMM('05:00', -30), '04:30');
assert.strictEqual(A.shiftHHMM('12:00', 0), '12:00');
assert.strictEqual(A.shiftHHMM('bad', 5), '');
console.log('prayer-anchor: all checks pass');
