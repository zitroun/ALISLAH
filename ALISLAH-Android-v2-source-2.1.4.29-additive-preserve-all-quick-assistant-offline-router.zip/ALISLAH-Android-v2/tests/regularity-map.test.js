const assert = require('assert');
const G = require('../app/src/main/assets/js/regularity.js');
const entries = [
  { name: 'الفجر', day: '2026-11-03', done: true }, { name: 'الظهر', day: '2026-11-03', done: true },
  { name: 'الفجر', day: '2026-11-03', done: true },
  { name: 'العصر', day: '2026-11-04', done: false },
  { name: 'الفجر', date: '2026-11-05T10:00:00.000Z' },
  { name: 'الفجر', day: '2026-10-30', done: true }
];
assert.deepStrictEqual(G.dayScores(entries, 2026, 10), { '2026-11-03': 2, '2026-11-05': 1 });
assert.strictEqual(G.level(0), 0); assert.strictEqual(G.level(2), 1); assert.strictEqual(G.level(4), 2); assert.strictEqual(G.level(5), 3);
assert.strictEqual(G.monthLength(2026, 1), 28); assert.strictEqual(G.monthLength(2028, 1), 29);
assert.strictEqual(G.dayKey(2026, 10, 3), '2026-11-03');
console.log('regularity-map: all checks pass');
