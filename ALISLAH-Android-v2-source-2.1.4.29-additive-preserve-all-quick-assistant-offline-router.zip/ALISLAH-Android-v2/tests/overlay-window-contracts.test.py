from pathlib import Path
root = Path(__file__).resolve().parents[1]
bubble = (root / "app/src/main/java/dz/alislah/app/FloatingBubbleService.kt").read_text(encoding="utf-8")
checks = {
    "overlay window can be pinned and unpinned": 'putBoolean("overlayPanelPinned"' in bubble and 'إلغاء تثبيت النافذة' in bubble,
    "outside touch only closes unpinned overlay": 'ACTION_OUTSIDE && !assistantPanelPinned' in bubble,
    "overlay title supports dragging": 'title.setOnTouchListener' in bubble and 'windowManager.updateViewLayout(root,lp)' in bubble,
    "overlay has a resize handle": 'اسحب لتغيير حجم النافذة' in bubble and 'resizeHandle.setOnTouchListener' in bubble,
    "overlay geometry persists": 'overlayPanelWidth' in bubble and 'overlayPanelHeight' in bubble and 'overlayPanelXRatio' in bubble and 'overlayPanelYRatio' in bubble,
    "overlay resizing is bounded": 'coerceIn(minPanelWidth,maxW)' in bubble and 'coerceIn(minPanelHeight,maxH)' in bubble,
    "existing separate portrait and landscape bubble anchors remain": 'bubblePortraitXRatio' in bubble and 'bubbleLandscapeXRatio' in bubble,
}
failed=[]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
    if not ok: failed.append(name)
if failed: raise SystemExit("Overlay window contract check failed: " + ", ".join(failed))
