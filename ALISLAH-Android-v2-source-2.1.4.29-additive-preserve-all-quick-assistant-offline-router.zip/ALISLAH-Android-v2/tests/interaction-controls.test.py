from pathlib import Path
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/dz/alislah/app/MainActivity.kt').read_text(encoding='utf-8')
bubble=(root/'app/src/main/java/dz/alislah/app/FloatingBubbleService.kt').read_text(encoding='utf-8')
html=(root/'app/src/main/assets/index.html').read_text(encoding='utf-8')
js=(root/'app/src/main/assets/js/dashboard.js').read_text(encoding='utf-8')
mainjs=(root/'app/src/main/assets/js/main.js').read_text(encoding='utf-8')
manifest=(root/'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
checks={
 'DND is explicitly permission-gated':'isNotificationPolicyAccessGranted' in main and 'ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS' in main,
 'DND stores and restores the previous interruption filter':'dndPreviousFilter' in main and 'setInterruptionFilter(previous)' in main,
 'DND permission is declared':'android.permission.ACCESS_NOTIFICATION_POLICY' in manifest,
 'bubble gesture settings are saved with validated choices':'bubbleSingleTapAction' in main and 'bubbleLongPressAction' in main and 'coerceIn(100, 150)' in main,
 'orbit radius and rotation persist':'bubbleOrbitRadiusDp' in bubble and 'bubbleOrbitRotation' in bubble,
 'single/double/long press actions are configurable':'bubbleDoubleTapAction' in bubble and 'bubbleLongPressAction' in bubble and 'bubbleSingleTapAction' in bubble,
 'window close action keeps the main bubble alive':'closeWindows' in bubble and 'hideAssistantOverlay()' in bubble,
 'dashboard exposes driving and bubble preferences':'dashboardDrivingToggle' in html and 'bubbleConfigSave' in html,
 'driving mode is a manual local preference':'drivingMode' in js and 'alislah-driving-mode' in js,
 'primary views support guarded horizontal swipe navigation':"const swipeTabs=['tasks','habits','prayer','family','more'" in mainjs and 'touchstart' in mainjs and 'touchend' in mainjs and 'touchcancel' in mainjs,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
if not all(checks.values()): raise SystemExit('Interaction control checks failed')
