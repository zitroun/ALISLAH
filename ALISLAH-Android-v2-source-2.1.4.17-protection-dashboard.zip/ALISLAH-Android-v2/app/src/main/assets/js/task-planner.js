(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.ALISLAHTaskPlanner = api;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
  const TIME_RE = /^(?:[01]\d|2[0-3]):[0-5]\d$/;
  const DAY_START = 6 * 60;
  const DAY_END = 22 * 60;
  const STEP = 15;

  function validDate(value) {
    if (typeof value !== 'string' || !DATE_RE.test(value)) return false;
    const [year, month, day] = value.split('-').map(Number);
    const date = new Date(year, month - 1, day);
    return date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day;
  }

  function toMinutes(value) {
    if (typeof value !== 'string' || !TIME_RE.test(value)) return null;
    const [hours, minutes] = value.split(':').map(Number);
    return hours * 60 + minutes;
  }

  function toTime(minutes) {
    return `${String(Math.floor(minutes / 60)).padStart(2, '0')}:${String(minutes % 60).padStart(2, '0')}`;
  }

  function durationOf(task) {
    const value = Number(task && task.durationMin);
    return Number.isFinite(value) ? Math.max(5, Math.min(480, value)) : 30;
  }

  function isActive(task) {
    return !!task && task.done !== true && task.completed !== true && task.status !== 'done';
  }

  function conflicts(candidate, tasks, excludeId) {
    if (!candidate || !validDate(candidate.date)) return [];
    const start = toMinutes(candidate.time);
    if (start === null) return [];
    const end = start + durationOf(candidate);
    if (end > 24 * 60) return [];
    return (Array.isArray(tasks) ? tasks : []).filter(task => {
      if (!isActive(task) || task.id === excludeId || task.id === candidate.id) return false;
      if (task.date !== candidate.date) return false;
      const otherStart = toMinutes(task.time);
      if (otherStart === null) return false;
      const otherEnd = otherStart + durationOf(task);
      return start < otherEnd && otherStart < end;
    });
  }

  function localDate(now) {
    const d = new Date(now);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }

  function addDays(dateString, amount) {
    const [year, month, day] = dateString.split('-').map(Number);
    const d = new Date(year, month - 1, day + amount);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }

  function findNextSlot(tasks, date, preferredTime, durationMin, nowValue, excludeId) {
    if (!validDate(date)) return null;
    const duration = Math.max(5, Math.min(480, Number(durationMin) || 30));
    const now = Number.isFinite(Number(nowValue)) ? Number(nowValue) : Date.now();
    const preferred = toMinutes(preferredTime);
    let first = preferred === null ? 9 * 60 : preferred;
    if (date === localDate(now)) {
      const nowMinutes = new Date(now).getHours() * 60 + new Date(now).getMinutes();
      first = Math.max(first, Math.ceil((nowMinutes + 5) / STEP) * STEP);
    }
    first = Math.max(DAY_START, Math.ceil(first / STEP) * STEP);
    const latestStart = Math.min(DAY_END - duration, 24 * 60 - duration);
    for (let minute = first; minute <= latestStart; minute += STEP) {
      const candidate = { id: '__slot_candidate__', date, time: toTime(minute), durationMin: duration };
      if (!conflicts(candidate, tasks, excludeId).length) return candidate.time;
    }
    return null;
  }

  function findPostponeSlot(tasks, task, today, nowValue, delayMinutes = 60) {
    if (!task || !validDate(today)) return null;
    const now = Number.isFinite(Number(nowValue)) ? Number(nowValue) : Date.now();
    let date = validDate(task.date) && task.date >= today ? task.date : today;
    const oldMinutes = toMinutes(task.time);
    const delay = Math.max(15, Math.min(24 * 60, Number(delayMinutes) || 60));
    let preferredMinutes = oldMinutes === null ? 9 * 60 : oldMinutes + delay;
    if (date === localDate(now)) {
      const nowMinutes = new Date(now).getHours() * 60 + new Date(now).getMinutes();
      preferredMinutes = Math.max(preferredMinutes, Math.ceil((nowMinutes + delay) / STEP) * STEP);
    }
    let preferred = preferredMinutes >= 24 * 60 ? '24:00' : toTime(preferredMinutes);
    if (toMinutes(preferred) === null || toMinutes(preferred) >= DAY_END) {
      date = addDays(date, 1);
      preferred = '09:00';
    }
    for (let offset = 0; offset < 30; offset++) {
      const targetDate = offset ? addDays(date, offset) : date;
      const targetTime = findNextSlot(tasks, targetDate, offset ? '09:00' : preferred,
        durationOf(task), now, task.id);
      if (targetTime) return { date: targetDate, time: targetTime };
    }
    return null;
  }

  function rescheduleOverdue(tasks, today, nowValue) {
    const list = Array.isArray(tasks) ? tasks : [];
    if (!validDate(today)) return [];
    const now = Number.isFinite(Number(nowValue)) ? Number(nowValue) : Date.now();
    const overdue = list.filter(task => isActive(task) && validDate(task.date) && task.date < today)
      .sort((a, b) => {
        const priority = value => value === 'مهمة جدًا' ? 0 : value === 'عادية' ? 1 : 2;
        return priority(a.priority) - priority(b.priority) || String(a.date).localeCompare(String(b.date));
      });
    const changes = [];
    for (const task of overdue) {
      const old = { date: task.date, time: task.time || '' };
      const duration = durationOf(task);
      let targetDate = today;
      let targetTime = null;
      const preferred = toMinutes(old.time) === null ? '09:00' : old.time;
      for (let offset = 0; offset < 30 && !targetTime; offset++) {
        targetDate = addDays(today, offset);
        targetTime = findNextSlot(list, targetDate, offset === 0 ? preferred : '09:00', duration, now, task.id);
      }
      if (!targetTime) continue;
      task.date = targetDate;
      task.time = targetTime;
      task.autoRescheduled = { fromDate: old.date, fromTime: old.time, on: today };
      changes.push({ id: task.id, text: String(task.text || '').slice(0, 180), from: old, to: { date: targetDate, time: targetTime } });
    }
    return changes;
  }

  return { validDate, toMinutes, toTime, durationOf, conflicts, findNextSlot, findPostponeSlot, rescheduleOverdue, addDays };
});
