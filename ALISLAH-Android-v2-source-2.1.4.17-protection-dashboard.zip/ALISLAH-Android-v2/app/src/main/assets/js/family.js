/* Family tab: ideas, kids activities, members with routines & stars, family events. */
(function(){
  'use strict';
  var A=window.ALI,FD=window.ALI_FAMILY,$=function(s){return document.querySelector(s)};
  if(!A||!FD||!$('#family'))return;
  var esc=A.esc;
  var F=function(){return A.data.family};
  var dayNum=function(){var d=new Date();return Math.floor(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())/86400000)};
  var selMember='',kidsShift=0,sub='ideas';

  /* ---------- ideas + kids ---------- */
  function renderIdea(){
    var x=FD.ideas[(dayNum()+(Number(A.data.idea)||0))%FD.ideas.length];
    $('#idea').innerHTML='<div class="grow"><div class="title">'+esc(x[0])+'</div><div class="muted">'+esc(x[1])+'</div></div>';
  }
  function renderKids(){
    var age=$('#kidsAge').value,list=FD.kids.filter(function(k){return !age||k.a===age});
    var start=(dayNum()+kidsShift*3)%list.length,out=[];
    for(var i=0;i<Math.min(3,list.length);i++)out.push(list[(start+i)%list.length]);
    $('#kidsList').innerHTML=out.map(function(k){return '<div class="item"><div class="grow"><div class="title">'+esc(k.t)+'</div><div class="muted">'+esc(k.d)+'</div></div></div>'}).join('');
  }
  $('#nextIdea').onclick=function(){A.recordUndo('تغيير فكرة الأسرة',['idea']);A.data.idea=(Number(A.data.idea)||0)+1;A.save();renderIdea()};
  $('#nextKids').onclick=function(){kidsShift++;renderKids()};
  $('#kidsAge').onchange=function(){kidsShift=0;renderKids()};

  /* ---------- sub tabs ---------- */
  function showSub(n){
    sub=n;
    document.querySelectorAll('#famTabs button').forEach(function(b){b.classList.toggle('on',b.dataset.sub===n)});
    document.querySelectorAll('.fam-sub').forEach(function(p){p.classList.toggle('hidden',p.id!=='fam-'+n)});
    if(n==='people')renderPeople();if(n==='events')renderEvents();if(n==='protection')renderProtection();
  }
  document.querySelectorAll('#famTabs button').forEach(function(b){b.onclick=function(){showSub(b.dataset.sub)}});

  /* ---------- members, routines, stars ---------- */
  function key(m,i){return m.id+'|'+i.id}
  function starsOf(m,onlyToday){
    var log=F().routineLog,n=0,t=A.today();
    Object.keys(log).forEach(function(day){
      if(onlyToday&&day!==t)return;
      Object.keys(log[day]).forEach(function(k){if(k.indexOf(m.id+'|')===0&&log[day][k])n++});
    });
    return n;
  }
  function renderPeople(){
    var box=$('#fam-people'),f=F();
    if(selMember&&!f.members.some(function(m){return m.id===selMember}))selMember='';
    if(!selMember&&f.members.length)selMember=f.members[0].id;
    var chips=f.members.map(function(m){return '<button type="button" class="mem-chip'+(m.id===selMember?' on':'')+'" data-id="'+esc(m.id)+'"><span>'+esc(m.emoji)+'</span>'+esc(m.name)+'</button>'}).join('');
    box.innerHTML='<div class="panel"><h3>👨‍👩‍👧 أفراد الأسرة</h3>'+(f.members.length?'<div class="mem-row">'+chips+'</div>':'<div class="empty"><span class="ei">👨‍👩‍👧</span>أضيفي أفراد أسرتك لتنشئي لهم روتينًا ونجومًا.</div>')+
      '<details class="opts" '+(f.members.length?'':'open')+'><summary>إضافة فرد</summary><div class="field" style="margin-top:8px"><input id="memName" maxlength="30" placeholder="الاسم" aria-label="اسم الفرد"><select id="memEmoji" aria-label="الرمز" style="width:84px">'+FD.emojis.map(function(e){return '<option>'+e+'</option>'}).join('')+'</select></div><div class="field"><select id="memRole" aria-label="الدور"><option value="child">طفل</option><option value="parent">والد / والدة</option></select><button class="btn primary" id="memAdd" type="button">إضافة</button></div></details></div><div id="memPanel"></div>';
    box.querySelectorAll('.mem-chip').forEach(function(b){b.onclick=function(){selMember=b.dataset.id;renderPeople()}});
    $('#memAdd').onclick=function(){
      var name=$('#memName').value.trim().slice(0,30);if(!name){A.toast('اكتبي الاسم');return}
      if(f.members.length>=12){A.toast('الحد الأقصى 12 فردًا');return}
      var role=$('#memRole').value,m={id:A.uid(),name:name,emoji:$('#memEmoji').value,role:role,goal:20,reward:'',base:0},d=FD.members[role];
      A.recordUndo('إضافة فرد للأسرة',['family']);f.members.push(m);f.routines[m.id]={morning:d.morning.map(function(t){return{id:A.uid(),text:t}}),evening:d.evening.map(function(t){return{id:A.uid(),text:t}})};
      selMember=m.id;A.save();renderPeople();A.toast('تمت إضافة '+name);
    };
    renderMemberPanel();
  }
  function renderMemberPanel(){
    var host=$('#memPanel'),f=F(),m=f.members.find(function(x){return x.id===selMember});
    if(!m){host.innerHTML='';return}
    var r=f.routines[m.id]=f.routines[m.id]||{morning:[],evening:[]},today=A.today();
    f.routineLog[today]=f.routineLog[today]||{};
    var total=starsOf(m,false),todayN=starsOf(m,true),since=Math.max(0,total-(Number(m.base)||0)),goal=Math.max(1,Number(m.goal)||20),pct=Math.min(100,Math.round(since/goal*100));
    function group(title,icon,part){
      var items=r[part];
      return '<h4 style="margin:14px 0 6px">'+icon+' '+title+'</h4>'+(items.length?items.map(function(i){
        var on=!!f.routineLog[today][key(m,i)];
        return '<div class="item'+(on?' done':'')+'"><input class="check rt" type="checkbox" data-i="'+esc(i.id)+'" '+(on?'checked':'')+' aria-label="'+esc(i.text)+'"><div class="grow"><div class="title">'+esc(i.text)+'</div></div><button class="mini del rtdel" type="button" data-p="'+part+'" data-i="'+esc(i.id)+'" aria-label="حذف">✕</button></div>';
      }).join(''):'<div class="muted">لا توجد بنود.</div>')+'<div class="field" style="margin-top:8px"><input class="rtnew" data-p="'+part+'" maxlength="60" placeholder="بند جديد" aria-label="بند جديد"><button class="btn soft rtadd" data-p="'+part+'" type="button">+</button></div>';
    }
    host.innerHTML='<div class="panel"><div class="row"><h3 style="margin:0">'+esc(m.emoji)+' '+esc(m.name)+'</h3><span class="chip gold">⭐ '+todayN+' اليوم · '+total+' الكل</span></div>'+
      '<div class="reward"><div class="muted" style="margin-bottom:6px">'+(m.reward?'المكافأة: <b>'+esc(m.reward)+'</b>':'حدّدي مكافأة لتحفيز '+esc(m.name))+' — '+since+'/'+goal+' نجمة</div><div class="progress"><span style="width:'+pct+'%"></span></div>'+(since>=goal&&m.reward?'<div class="notice info" style="margin-top:10px">🎉 وصل '+esc(m.name)+' إلى الهدف! <button class="btn soft" id="rwClaim" type="button" style="margin-inline-start:8px">تم تسليم المكافأة</button></div>':'')+'</div>'+
      group('روتين الصباح','🌅','morning')+group('روتين المساء','🌙','evening')+
      '<details class="opts" style="margin-top:14px"><summary>المكافأة والإعدادات</summary><div class="field two" style="margin-top:8px"><label class="fld" style="margin:0"><span>المكافأة</span><input id="rwText" maxlength="60" value="'+esc(m.reward||'')+'" placeholder="مثال: نزهة"></label><label class="fld" style="margin:0"><span>عدد النجوم</span><input id="rwGoal" type="number" min="1" max="1000" value="'+goal+'"></label></div><div class="field" style="margin-top:8px"><button class="btn soft" id="rwSave" type="button" style="flex:1">حفظ</button><button class="btn danger" id="memDel" type="button" style="flex:1">حذف الفرد</button></div></details></div>';
    host.querySelectorAll('.rt').forEach(function(c){c.onchange=function(){A.recordUndo(c.checked?'إنجاز بند روتين':'إلغاء إنجاز بند روتين',['family']);var k=m.id+'|'+c.dataset.i;if(c.checked)f.routineLog[today][k]=true;else delete f.routineLog[today][k];A.save();renderMemberPanel()}});
    host.querySelectorAll('.rtdel').forEach(function(b){b.onclick=async function(){var item=r[b.dataset.p].find(function(i){return i.id===b.dataset.i});if(!item)return;if(!(await A.ui.confirm('حذف بند الروتين؟','حذف',true,item.text+'\nيمكنك التراجع بعد الحذف.')))return;A.recordUndo('حذف بند روتين',['family']);r[b.dataset.p]=r[b.dataset.p].filter(function(i){return i.id!==b.dataset.i});A.save();renderMemberPanel()}});
    host.querySelectorAll('.rtadd').forEach(function(b){b.onclick=function(){var inp=host.querySelector('.rtnew[data-p="'+b.dataset.p+'"]'),t=inp.value.trim().slice(0,60);if(!t)return;if(r[b.dataset.p].length>=20){A.toast('الحد الأقصى 20 بندًا');return}A.recordUndo('إضافة بند روتين',['family']);r[b.dataset.p].push({id:A.uid(),text:t});A.save();renderMemberPanel()}});
    var claim=$('#rwClaim');if(claim)claim.onclick=function(){A.recordUndo('تسجيل تسليم مكافأة',['family']);m.base=total;A.save();A.toast('هنيئًا لـ '+m.name+' 🎉');renderMemberPanel()};
    $('#rwSave').onclick=function(){A.recordUndo('تعديل إعدادات المكافأة',['family']);m.reward=$('#rwText').value.trim().slice(0,60);m.goal=Math.max(1,Math.min(1000,Number($('#rwGoal').value)||20));A.save();renderMemberPanel();A.toast('تم الحفظ')};
    $('#memDel').onclick=async function(){if(!(await A.ui.confirm('حذف '+m.name+'؟','حذف',true,'سيُحذف روتينه ونجومه.')))return;A.recordUndo('حذف فرد من الأسرة',['family']);f.members=f.members.filter(function(x){return x.id!==m.id});delete f.routines[m.id];Object.keys(f.routineLog).forEach(function(d){Object.keys(f.routineLog[d]).forEach(function(k){if(k.indexOf(m.id+'|')===0)delete f.routineLog[d][k]})});f.events.forEach(function(e){if(e.who===m.id)e.who=''});selMember='';A.save();renderPeople()};
  }

  /* ---------- events ---------- */
  var REM={'':'بدون تذكير','15':'قبلها بـ15 دقيقة','60':'قبلها بساعة','1440':'قبلها بيوم'};
  function evTime(ev){var t=new Date(ev.date+'T'+(ev.time||'09:00')+':00').getTime();return t-(Number(ev.remind)||0)*60000}
  function scheduleEv(ev){
    A.cancelTaskReminder('ev-'+ev.id);
    if(ev.done||ev.remind===''||!ev.remind)return;
    var at=evTime(ev);if(isFinite(at)&&at>Date.now())A.nat('scheduleTaskReminder','ev-'+ev.id,'📌 '+ev.title,at);
  }
  function renderEvents(){
    var box=$('#fam-events'),f=F(),today=A.today();
    var evs=f.events.slice().sort(function(a,b){return (a.date+(a.time||'')).localeCompare(b.date+(b.time||''))});
    var up=evs.filter(function(e){return e.date>=today}),past=evs.filter(function(e){return e.date<today}).slice(-5).reverse();
    function row(e){
      var who=f.members.find(function(m){return m.id===e.who});
      return '<div class="item'+(e.done?' done':'')+'"><input class="check evc" type="checkbox" data-id="'+esc(e.id)+'" '+(e.done?'checked':'')+' aria-label="تم: '+esc(e.title)+'"><div class="grow"><div class="title">'+esc(e.title)+'</div><div class="meta"><span class="chip gray">📅 '+esc(e.date===today?'اليوم':e.date)+'</span>'+(e.time?'<span class="chip gray">⏰ '+esc(e.time)+'</span>':'')+(who?'<span class="chip">'+esc(who.emoji)+' '+esc(who.name)+'</span>':'')+(e.remind?'<span class="chip gray">🔔 '+esc(REM[e.remind])+'</span>':'')+'</div></div><button class="mini del evd" type="button" data-id="'+esc(e.id)+'" aria-label="حذف الموعد">🗑️</button></div>';
    }
    box.innerHTML='<div class="panel"><h3>🗓️ مواعيد الأسرة</h3><form id="evForm" autocomplete="off"><div class="field"><input id="evTitle" maxlength="80" required placeholder="موعد جديد، مثال: اجتماع المدرسة"><button class="btn primary" type="submit">إضافة</button></div><div class="field two"><input id="evDate" type="date" aria-label="التاريخ" value="'+today+'"><input id="evTime" type="time" aria-label="الوقت (اختياري)"></div><div class="field two"><select id="evWho" aria-label="الفرد"><option value="">الأسرة كلها</option>'+f.members.map(function(m){return '<option value="'+esc(m.id)+'">'+esc(m.emoji)+' '+esc(m.name)+'</option>'}).join('')+'</select><select id="evRemind" aria-label="التذكير">'+Object.keys(REM).map(function(k){return '<option value="'+k+'">'+REM[k]+'</option>'}).join('')+'</select></div></form>'+
      '<div class="list">'+(up.length?up.map(row).join(''):'<div class="empty"><span class="ei">🗓️</span>لا توجد مواعيد قادمة.</div>')+'</div></div>'+(past.length?'<details class="panel fold"><summary>مواعيد سابقة</summary><div class="list">'+past.map(row).join('')+'</div></details>':'');
    $('#evForm').onsubmit=function(e){
      e.preventDefault();var title=$('#evTitle').value.trim().slice(0,80);if(!title)return;
      if(f.events.length>=500){A.toast('امتلأت قائمة المواعيد');return}
      var ev={id:A.uid(),title:title,date:$('#evDate').value||today,time:$('#evTime').value||'',who:$('#evWho').value,remind:$('#evRemind').value,done:false};
      A.recordUndo('إضافة موعد أسري',['family']);f.events.push(ev);scheduleEv(ev);A.save();renderEvents();A.toast(ev.remind?'أُضيف الموعد مع تذكير':'أُضيف الموعد');if(ev.remind&&A.NATIVE)setTimeout(function(){try{var s=A.nativeStatus();if(s&&s.notifications===false)A.nat('requestNotificationPermission')}catch(x){}},900);
    };
    box.querySelectorAll('.evc').forEach(function(c){c.onchange=function(){var ev=f.events.find(function(x){return x.id===c.dataset.id});if(ev){A.recordUndo(c.checked?'إنجاز موعد أسري':'إعادة فتح موعد أسري',['family']);ev.done=c.checked;scheduleEv(ev);A.save();renderEvents()}}});
    box.querySelectorAll('.evd').forEach(function(b){b.onclick=async function(){var ev=f.events.find(function(x){return x.id===b.dataset.id});if(!ev)return;if(!(await A.ui.confirm('حذف الموعد؟','حذف',true,ev.title)))return;A.recordUndo('حذف موعد أسري',['family']);A.cancelTaskReminder('ev-'+ev.id);f.events=f.events.filter(function(x){return x.id!==ev.id});A.save();renderEvents()}});
  }


  /* ---------- child protection controls ---------- */
  var launchableApps=[];
  function controls(){
    var c=F().controls;
    if(!c||typeof c!=='object')c=F().controls={enabled:false,dailyLimitMinutes:0,blockedApps:[],blockedSites:[]};
    c.blockedApps=Array.isArray(c.blockedApps)?c.blockedApps:[];
    c.blockedSites=Array.isArray(c.blockedSites)?c.blockedSites:[];
    return c;
  }
  function packageName(x){return typeof x==='string'?x:String(x&&x.packageName||'')}
  function renderProtection(){
    var c=controls(),enabled=$('#childProtectionEnabled'),limit=$('#childDailyLimit');
    if(!enabled)return;
    enabled.checked=!!c.enabled;limit.value=String(Math.max(0,Math.min(1440,Number(c.dailyLimitMinutes)||0)));
    renderBlockedApps();renderBlockedSites();loadLaunchableApps();refreshProtectionStatus();
    enabled.onchange=function(){A.recordUndo('تغيير إعدادات حماية الطفل',['family']);c.enabled=enabled.checked;A.save();refreshProtectionStatus();A.toast(c.enabled?'تم تفعيل قواعد حماية الطفل':'تم إيقاف قواعد حماية الطفل')};
    limit.onchange=function(){A.recordUndo('تعديل وقت استخدام الطفل',['family']);c.dailyLimitMinutes=Math.max(0,Math.min(1440,Number(limit.value)||0));limit.value=String(c.dailyLimitMinutes);A.save();A.toast('تم حفظ الحد اليومي')};
    $('#childUsagePermission').onclick=function(){A.nat('requestUsagePermission');A.toast('امنحي ALISLAH إذن الوصول إلى بيانات الاستخدام ثم عودي إلى هذه الصفحة')};
    $('#childAccessibilitySettings').onclick=function(){A.nat('openAccessibilitySettings');A.toast('ابحثي عن «حماية الطفل من ALISLAH» وفعّليها يدويًا')};
    $('#childAppAdd').onclick=function(){
      var pkg=$('#childAppPicker').value;if(!pkg){A.toast('اختاري تطبيقًا أولًا');return}
      var app=launchableApps.find(function(x){return x.packageName===pkg});if(!app||c.blockedApps.some(function(x){return packageName(x)===pkg})){A.toast('هذا التطبيق مضاف بالفعل');return}
      if(c.blockedApps.length>=50){A.toast('الحد الأقصى 50 تطبيقًا');return}
      A.recordUndo('إضافة تطبيق محظور',['family']);c.blockedApps.push({packageName:app.packageName,label:app.label});A.save();renderBlockedApps();A.toast('أُضيف التطبيق إلى قائمة الحظر')
    };
    $('#childSiteForm').onsubmit=function(e){e.preventDefault();var value=$('#childSiteInput').value.trim().toLowerCase().replace(/^https?:\/\//,'').replace(/^www\./,'').split('/')[0];if(!/^(?=.{4,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(value)){A.toast('اكتبي نطاقًا صحيحًا مثل example.com');return}if(c.blockedSites.indexOf(value)>=0){A.toast('الموقع موجود بالفعل');return}if(c.blockedSites.length>=50){A.toast('الحد الأقصى 50 موقعًا');return}A.recordUndo('إضافة موقع محظور',['family']);c.blockedSites.push(value);$('#childSiteInput').value='';A.save();renderBlockedSites()};
  }
  function loadLaunchableApps(){
    var picker=$('#childAppPicker');if(!picker)return;picker.innerHTML='<option value="">اختاري تطبيقًا</option>';
    try{
      var raw=A.nat('getLaunchableAppsJson');launchableApps=JSON.parse(raw||'[]');if(!Array.isArray(launchableApps))launchableApps=[];
      launchableApps.sort(function(a,b){return String(a.label).localeCompare(String(b.label),'ar')});
      launchableApps.forEach(function(app){var opt=document.createElement('option');opt.value=app.packageName;opt.textContent=app.label+' · '+app.packageName;picker.appendChild(opt)});
      if(!launchableApps.length){picker.innerHTML='<option value="">القائمة متاحة في تطبيق Android فقط</option>'}
    }catch(e){launchableApps=[];picker.innerHTML='<option value="">تعذر تحميل التطبيقات</option>'}
  }
  function renderBlockedApps(){
    var box=$('#childBlockedApps'),c=controls();if(!box)return;
    box.innerHTML=c.blockedApps.length?c.blockedApps.map(function(x){var pkg=packageName(x),label=typeof x==='object'&&x.label?x.label:pkg;return '<div class="item"><div class="grow"><div class="title">'+esc(label)+'</div><div class="muted">'+esc(pkg)+'</div></div><button class="mini del child-app-remove" data-pkg="'+esc(pkg)+'" type="button" aria-label="إزالة التطبيق">✕</button></div>'}).join(''):'<div class="empty">لا توجد تطبيقات محظورة.</div>';
    box.querySelectorAll('.child-app-remove').forEach(function(b){b.onclick=function(){var pkg=b.dataset.pkg;A.recordUndo('إزالة تطبيق محظور',['family']);c.blockedApps=c.blockedApps.filter(function(x){return packageName(x)!==pkg});A.save();renderBlockedApps()}})
  }
  function renderBlockedSites(){
    var box=$('#childBlockedSites'),c=controls();if(!box)return;
    box.innerHTML=c.blockedSites.length?c.blockedSites.map(function(site){return '<div class="item"><div class="grow"><div class="title" dir="ltr">'+esc(site)+'</div></div><button class="mini del child-site-remove" data-site="'+esc(site)+'" type="button" aria-label="إزالة الموقع">✕</button></div>'}).join(''):'<div class="empty">لا توجد مواقع محظورة.</div>';
    box.querySelectorAll('.child-site-remove').forEach(function(b){b.onclick=function(){A.recordUndo('إزالة موقع محظور',['family']);c.blockedSites=c.blockedSites.filter(function(x){return x!==b.dataset.site});A.save();renderBlockedSites()}})
  }
  function refreshProtectionStatus(){
    var box=$('#childPermissionStatus');if(!box)return;var status={};try{status=A.nativeStatus()||{}}catch(e){}
    var items=[];items.push((status.usage?'✅':'⚠️')+' إذن بيانات الاستخدام '+(status.usage?'ممنوح':'غير ممنوح'));items.push((status.childProtectionAccessibility?'✅':'⚠️')+' خدمة إمكانية الوصول '+(status.childProtectionAccessibility?'مفعلة':'غير مفعلة'));
    if(!status.native)items.push('افتحي تطبيق Android لإدارة الصلاحيات');
    box.textContent=items.join(' · ')+(controls().enabled?' · القواعد مفعلة':' · القواعد متوقفة');
  }

  function init(){
    renderIdea();renderKids();
    F().events.forEach(scheduleEv);
    window.ALI_FAMILY_EVENTS=function(){return F().events};
  }
  window.__alislahResync=(function(prev){return function(){try{prev&&prev()}catch(e){}renderIdea();if(sub==='people')renderPeople();if(sub==='events')renderEvents()}})(window.__alislahResync);
  window.addEventListener('focus',function(){if(sub==='protection')refreshProtectionStatus()});
  document.addEventListener('visibilitychange',function(){if(!document.hidden&&sub==='protection')refreshProtectionStatus()});
  init();
})();
