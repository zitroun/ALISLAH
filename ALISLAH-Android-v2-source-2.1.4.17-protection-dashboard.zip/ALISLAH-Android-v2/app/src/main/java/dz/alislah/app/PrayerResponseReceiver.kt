package dz.alislah.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

/** Stores the user's explicit answer to a post-prayer notification for the app to consume. */
class PrayerResponseReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != ACTION_RESPONSE) return
        val name = (intent.getStringExtra(EXTRA_NAME) ?: "").trim().take(20)
        if (name.isBlank()) return
        val done = intent.getBooleanExtra(EXTRA_DONE, false)
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val pending = try { JSONArray(prefs.getString(KEY_PENDING, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        while (pending.length() >= MAX_PENDING) pending.remove(0)
        pending.put(JSONObject().put("name", name).put("done", done).put("at", System.currentTimeMillis()))
        prefs.edit().putString(KEY_PENDING, pending.toString()).apply()

        // A notification action is an explicit user interaction; bring the prayer log into view.
        try {
            val open = Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                putExtra("openTab", "prayer")
            }
            context.startActivity(open)
        } catch (_: Exception) { }
    }

    companion object {
        const val ACTION_RESPONSE = "dz.alislah.app.ACTION_PRAYER_RESPONSE"
        const val EXTRA_NAME = "prayer_name"
        const val EXTRA_DONE = "prayer_done"
        private const val PREFS = "alislah_prayer_response"
        private const val KEY_PENDING = "pending"
        private const val MAX_PENDING = 20
    }
}
