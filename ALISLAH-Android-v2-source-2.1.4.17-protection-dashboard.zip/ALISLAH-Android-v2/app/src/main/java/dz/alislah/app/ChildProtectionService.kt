package dz.alislah.app

import android.accessibilityservice.AccessibilityService
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Process
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.ArrayDeque
import java.util.Calendar
import java.util.Locale

/**
 * Optional, parent-enabled on-device guard.
 * It reads only the saved ALISLAH family.controls settings and the currently visible
 * browser address-bar text. Nothing is uploaded. The parent must explicitly enable
 * this service in Android Accessibility settings.
 */
class ChildProtectionService : AccessibilityService() {
    private var lastActionAt = 0L
    private val homePackages = mutableSetOf<String>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            @Suppress("DEPRECATION")
            packageManager.queryIntentActivities(home, 0).forEach { homePackages.add(it.activityInfo.packageName) }
        } catch (_: Exception) { }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return

        val foreground = event.packageName?.toString().orEmpty()
        if (foreground.isBlank() || isExemptPackage(foreground)) return

        val controls = readControls() ?: return
        if (!controls.optBoolean("enabled", false)) return

        val blockedApps = readStringSet(controls.optJSONArray("blockedApps"))
        if (foreground in blockedApps) {
            blockCurrentApp("هذا التطبيق ضمن قائمة الحظر العائلية")
            return
        }

        val limitMinutes = controls.optInt("dailyLimitMinutes", 0).coerceIn(0, 1440)
        if (limitMinutes > 0 && hasUsagePermission()) {
            val used = todayForegroundMinutes()
            if (used >= limitMinutes && !homePackages.contains(foreground)) {
                blockCurrentApp("انتهى وقت استخدام الهاتف المحدد اليوم")
                return
            }
        }

        val sites = readStringSet(controls.optJSONArray("blockedSites"))
        if (sites.isNotEmpty() && isLikelyBrowser(foreground) &&
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            val urlText = readVisibleAddressText()
            if (urlText.isNotBlank() && sites.any { domain -> containsDomain(urlText, domain) }) {
                blockCurrentApp("هذا الموقع ضمن قائمة الحظر العائلية")
            }
        }
    }

    private fun readControls(): JSONObject? = try {
        val saved = getSharedPreferences("alislah_native", Context.MODE_PRIVATE)
            .getString("alislah_app_data", "{}") ?: "{}"
        JSONObject(saved).optJSONObject("family")?.optJSONObject("controls")
    } catch (_: Exception) { null }

    private fun readStringSet(array: JSONArray?): Set<String> {
        val result = linkedSetOf<String>()
        if (array == null) return result
        for (i in 0 until array.length()) {
            val item = array.opt(i)
            val value = if (item is JSONObject) {
                item.optString("packageName", item.optString("domain", ""))
            } else item?.toString().orEmpty()
            val clean = value.trim().lowercase(Locale.ROOT).take(253)
            if (clean.isNotBlank()) result.add(clean)
        }
        return result
    }

    private fun isExemptPackage(pkg: String): Boolean {
        return pkg == packageName || pkg == "android" || pkg == "com.android.systemui" ||
            pkg == "com.android.settings" || homePackages.contains(pkg) ||
            pkg.startsWith("com.android.inputmethod") || pkg.contains("keyboard")
    }

    private fun hasUsagePermission(): Boolean = try {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    } catch (_: Exception) { false }

    private fun todayForegroundMinutes(): Int = try {
        val now = System.currentTimeMillis()
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val stats = manager.queryAndAggregateUsageStats(start, now)
        val total = (stats?.values ?: emptyList()).filter {
            it.packageName != packageName && it.packageName != "android" &&
                it.packageName != "com.android.systemui" && it.packageName != "com.android.settings" &&
                !homePackages.contains(it.packageName)
        }.sumOf { it.totalTimeInForeground }
        (total / 60_000L).toInt()
    } catch (_: Exception) { 0 }

    private fun isLikelyBrowser(pkg: String): Boolean {
        val p = pkg.lowercase(Locale.ROOT)
        return listOf("chrome", "browser", "firefox", "opera", "brave", "edge", "vivaldi", "samsung.internet").any { p.contains(it) }
    }

    /** Scan a bounded number of accessibility nodes and read address-bar-like fields only. */
    private fun readVisibleAddressText(): String {
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return ""
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        val output = StringBuilder()
        try {
            queue.add(root)
            var visited = 0
            while (queue.isNotEmpty() && visited < 140) {
                val node = queue.removeFirst()
                visited++
                try {
                    val id = node.viewIdResourceName?.lowercase(Locale.ROOT).orEmpty()
                    val text = (node.text?.toString() ?: node.contentDescription?.toString()).orEmpty().take(500)
                    val looksLikeAddress = id.contains("url") || id.contains("location") || id.contains("address") ||
                        text.matches(Regex("(?is).*?(https?://|www\\.)[a-z0-9.-]+\\.[a-z]{2,}.*"))
                    if (looksLikeAddress && text.isNotBlank()) output.append(' ').append(text)
                    for (i in 0 until node.childCount) {
                        val child = node.getChild(i)
                        if (child != null) queue.add(child)
                    }
                } catch (_: Exception) { }
                finally { try { node.recycle() } catch (_: Exception) { } }
            }
        } finally {
            while (queue.isNotEmpty()) try { queue.removeFirst().recycle() } catch (_: Exception) { }
        }
        return output.toString().take(2500)
    }

    private fun containsDomain(visibleText: String, configured: String): Boolean {
        val domain = configured.lowercase(Locale.ROOT).trim()
            .removePrefix("https://").removePrefix("http://").removePrefix("www.").substringBefore('/')
        if (domain.length < 4 || !domain.contains('.')) return false
        val text = visibleText.lowercase(Locale.ROOT)
        return Regex("(?<![a-z0-9.-])(?:www\\.)?${Regex.escape(domain)}(?![a-z0-9.-])").containsMatchIn(text)
    }

    private fun blockCurrentApp(message: String) {
        val now = System.currentTimeMillis()
        if (now - lastActionAt < 2500L) return
        lastActionAt = now
        try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (_: Exception) { }
        try { Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show() } catch (_: Exception) { }
    }

    override fun onInterrupt() { }
}
