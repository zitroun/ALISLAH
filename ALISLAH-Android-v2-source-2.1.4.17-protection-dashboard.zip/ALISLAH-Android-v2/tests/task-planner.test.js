'use strict';
const assert = require('node:assert/strict');
const planner = require('../app/src/main/assets/js/task-planner.js');

const base = [
  { id: 'a', text: 'اجتماع', date: '2026-11-13', time: '09:00', durationMin: 60, done: false },
  { id: 'b', text: 'مهمة مكتملة', date: '2026-11-13', time: '10:00', durationMin: 60, done: true },
  { id: 'c', text: 'موعد آخر', date: '2026-11-13', time: '11:00', durationMin: 30, done: false }
];

assert.equal(planner.validDate('2026-02-28'), true);
assert.equal(planner.validDate('2026-02-30'), false);
assert.equal(planner.toMinutes('23:59'), 1439);
assert.equal(planner.toMinutes('24:00'), null);
assert.equal(planner.conflicts({ id: 'new', date: '2026-11-13', time: '09:30', durationMin: 30 }, base).length, 1);
assert.equal(planner.conflicts({ id: 'new', date: '2026-11-13', time: '10:00', durationMin: 30 }, base).length, 0);
assert.equal(planner.conflicts({ id: 'new', date: '2026-11-14', time: '09:30', durationMin: 30 }, base).length, 0);
assert.equal(planner.findNextSlot(base, '2026-11-13', '09:00', 30, new Date(2026, 10, 13, 8, 0).getTime()), '10:00');
assert.equal(planner.findNextSlot(base, '2026-11-13', '09:00', 30, new Date(2026, 10, 13, 8, 0).getTime(), 'a'), '09:00');

const overdue = [
  { id: 'old1', text: 'مهمة قديمة', date: '2026-11-10', time: '09:00', durationMin: 30, done: false, priority: 'مهمة جدًا' },
  { id: 'old2', text: 'مهمة أقدم', date: '2026-11-11', time: '09:00', durationMin: 30, done: false, priority: 'عادية' },
  { id: 'done', text: 'مكتملة', date: '2026-11-10', time: '09:00', done: true }
];
const now = new Date(2026, 10, 13, 8, 0).getTime();
const changes = planner.rescheduleOverdue(overdue, '2026-11-13', now);
assert.equal(changes.length, 2);
assert.equal(overdue[0].date, '2026-11-13');
assert.equal(overdue[1].date, '2026-11-13');
assert.notEqual(overdue[0].time, overdue[1].time);
assert.deepEqual(overdue[0].autoRescheduled.fromDate, '2026-11-10');
assert.equal(overdue[2].date, '2026-11-10');
assert.equal(planner.conflicts(overdue[0], overdue).length, 0);
assert.equal(planner.conflicts(overdue[1], overdue).length, 0);


const postponeTasks = [
  { id: 'late', text: 'مهمة متأخرة', date: '2026-11-10', time: '09:00', durationMin: 30, done: false },
  { id: 'busy', text: 'موعد مشغول', date: '2026-11-13', time: '10:00', durationMin: 60, done: false }
];
const postponed = planner.findPostponeSlot(postponeTasks, postponeTasks[0], '2026-11-13', new Date(2026, 10, 13, 8, 0).getTime(), 60);
assert.deepEqual(postponed, { date: '2026-11-13', time: '11:00' });
const endOfDay = planner.findPostponeSlot([], { id: 'night', date: '2026-11-13', time: '21:30', durationMin: 30 }, '2026-11-13', new Date(2026, 10, 13, 21, 0).getTime(), 60);
assert.deepEqual(endOfDay, { date: '2026-11-14', time: '09:00' });

console.log('Task planner tests passed.');
