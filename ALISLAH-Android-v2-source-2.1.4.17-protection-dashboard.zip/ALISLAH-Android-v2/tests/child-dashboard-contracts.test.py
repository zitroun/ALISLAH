from pathlib import Path

root = Path(__file__).resolve().parents[1]
manifest = (root / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
service = (root / "app/src/main/java/dz/alislah/app/ChildProtectionService.kt").read_text(encoding="utf-8")
activity = (root / "app/src/main/java/dz/alislah/app/MainActivity.kt").read_text(encoding="utf-8")
bubble = (root / "app/src/main/java/dz/alislah/app/FloatingBubbleService.kt").read_text(encoding="utf-8")
family = (root / "app/src/main/assets/js/family.js").read_text(encoding="utf-8")
index = (root / "app/src/main/assets/index.html").read_text(encoding="utf-8")
dashboard = (root / "app/src/main/assets/js/dashboard.js").read_text(encoding="utf-8")
main = (root / "app/src/main/assets/js/main.js").read_text(encoding="utf-8")
checks = {
    "accessibility service is system-bound": 'android.permission.BIND_ACCESSIBILITY_SERVICE' in manifest and '.ChildProtectionService' in manifest,
    "service checks parent opt-in": 'optBoolean("enabled", false)' in service,
    "app block list enforced locally": 'foreground in blockedApps' in service and 'GLOBAL_ACTION_HOME' in service,
    "daily usage cap uses UsageStats": 'queryAndAggregateUsageStats' in service and 'dailyLimitMinutes' in service,
    "site filter scans only address-like fields": 'looksLikeAddress' in service and 'isLikelyBrowser' in service,
    "native permission settings are explicit": 'ACTION_ACCESSIBILITY_SETTINGS' in activity and 'requestUsagePermission' in activity,
    "installed launcher apps list is available": 'getLaunchableAppsJson' in activity,
    "family protection UI exists": 'id="fam-protection"' in index and 'renderProtection()' in family,
    "dashboard screen is included": 'id="dashboard"' in index and 'js/dashboard.js' in index,
    "dashboard adds task and habit records": 'A.data.tasks.push(task)' in dashboard and 'A.data.habits.push' in dashboard,
    "dashboard has search timeline and activity": 'dashboardSearch' in dashboard and 'renderTimeline' in dashboard and 'renderActivity' in dashboard,
    "dashboard combines family events into timeline": "موعد أسري" in dashboard and 'dashboardTimeline' in index,
    "dashboard shows and refreshes next prayer": 'renderPrayer' in dashboard and 'ALI_NEXT_PRAYER' in dashboard and 'dashboardPrayerPanel' in index and 'alislah:prayer-updated' in dashboard,
    "dashboard preferences persisted": 'data.dashboard' in main and 'activityLog' in main,
    "screen-time limitations are disclosed": 'إحصاءات Android' in index and 'ليست قفلًا غير قابل للتجاوز' in index,
    "bubble distinguishes listening thinking and speaking": 'setBubbleMode' in bubble and '"listening"' in bubble and '"thinking"' in bubble and '"speaking"' in bubble,
    "bubble persists orientation-specific position": 'bubblePortraitXRatio' in bubble and 'bubbleLandscapeXRatio' in bubble and 'putFloat("bubblePortraitXRatio"' in bubble,
    "bubble shows due-task badge": 'setBadge(dueTaskCount())' in bubble and 'badgeCount > 0' in bubble,
    "source privacy disclosure exists": 'لا يتم إرسال أسماء التطبيقات أو المواقع إلى الإنترنت' in index,
    "private signing material is excluded from the source package": not (root / "debug.keystore").exists() and 'secrets.ALISLAH_KEYSTORE_BASE64' in (root / ".github/workflows/build-android-2.1.4.17.yml").read_text(encoding="utf-8"),
}
failed = []
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
    if not ok:
        failed.append(name)
if failed:
    raise SystemExit("Child/dashboard contract checks failed: " + ", ".join(failed))
