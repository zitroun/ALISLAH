from pathlib import Path
root = Path(__file__).resolve().parents[1]
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
scheduler = (root / 'app/src/main/java/dz/alislah/app/PrayerScheduler.kt').read_text(encoding='utf-8')
receiver = (root / 'app/src/main/java/dz/alislah/app/PrayerResponseReceiver.kt').read_text(encoding='utf-8')
activity = (root / 'app/src/main/java/dz/alislah/app/MainActivity.kt').read_text(encoding='utf-8')
prayer = (root / 'app/src/main/assets/js/prayer.js').read_text(encoding='utf-8')
bubble = (root / 'app/src/main/java/dz/alislah/app/FloatingBubbleService.kt').read_text(encoding='utf-8')
main = (root / 'app/src/main/assets/js/main.js').read_text(encoding='utf-8')
checks = {
    'prayer response receiver registered and non-exported': '.PrayerResponseReceiver' in manifest and 'android:exported="false"' in manifest,
    'post-prayer notification offers both answers': 'نعم، صليت' in scheduler and 'ليس بعد' in scheduler,
    'prayer responses are stored by an explicit receiver': 'ACTION_RESPONSE' in receiver and 'EXTRA_DONE' in receiver and 'putExtra(PrayerResponseReceiver.EXTRA_DONE, done)' in scheduler,
    'native bridge consumes queued prayer answers': 'consumePrayerResponsesJson' in activity,
    'web prayer log accepts native responses idempotently': 'ALI_PRAYER_RECORD_NATIVE' in prayer and 'consumeNativePrayerResponses' in prayer,
    'adhan mute bubble adapts to top and bottom edges': 'bottomDocked' in bubble and 'edge == "top"' in bubble,
    'floating orbit exposes complete and postpone task actions': 'quickComplete' in bubble and 'quickPostpone' in bubble and 'showTaskQuickAction' in bubble,
    'task picker completes or postpones real records locally': '__alislahShowQuickTaskAction' in main and 'completeTask(current,true)' in main and 'findPostponeSlot' in main,
    'new task planner is included': (root / 'app/src/main/assets/js/task-planner.js').is_file(),
}
failed=[]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
    if not ok: failed.append(name)
if failed: raise SystemExit('Feature contract check failed: ' + ', '.join(failed))
