from pathlib import Path
root = Path(__file__).resolve().parents[1]
bubble = (root / "app/src/main/java/dz/alislah/app/FloatingBubbleService.kt").read_text(encoding="utf-8")
voice = (root / "app/src/main/java/dz/alislah/app/PrayerVoiceService.kt").read_text(encoding="utf-8")
main = (root / "app/src/main/java/dz/alislah/app/MainActivity.kt").read_text(encoding="utf-8")
js = (root / "app/src/main/assets/js/dashboard.js").read_text(encoding="utf-8")
html = (root / "app/src/main/assets/index.html").read_text(encoding="utf-8")
checks = {
    "mini window expansion control is added to exactly one parent": "header.addView(expand" in bubble and "footer.addView(expand" not in bubble,
    "edge capsule auto-hides partially when idle and restores on touch": "bubbleAutoHiddenOrigin" in bubble and "restoreAutoHiddenBubble()" in bubble and "lp.x -= (lp.width - remain)" in bubble and "lp.y -= (lp.height - remain)" in bubble,
    "inward swipe opens the selected quick action": "fastInwardSwipe" in bubble and "bubbleSwipeAction" in bubble and "showQuickMenu(lp)" in bubble,
    "mini window footer uses a separate refresh control": "footer.addView(refresh" in bubble and "footer.addView(open" in bubble,
    "mini window pin state updates the pin control rather than the reorder control": "header.getChildAt(4)" in bubble,
    "independent mini windows restore their saved state": "persistMiniWindowState()" in bubble and "restoreMiniWindows()" in bubble and 'putString("miniWindowsOpen"' in bubble,
    "mini window expand and pin state persist": 'miniWindow_${key}_expanded' in bubble and 'miniWindow_${key}_pinned' in bubble,
    "mini windows have a real resize handle with saved width and height": 'resize.setOnTouchListener' in bubble and 'miniWindow_${key}_w' in bubble and 'miniWindow_${key}_h' in bubble,
    "up to six independent mini windows are supported": 'miniWindows.size >= 6' in bubble and 'miniWindows[key] = window' in bubble,
    "mini windows can be moved to front or back": 'bringMiniWindowToFront(key)' in bubble and 'sendMiniWindowToBack(key)' in bubble,
    "mini window command, order, dimensions and position persist": 'putString("miniWindowsOpen", state.toString())' in bubble and '.put("command"' in bubble and '.put("width"' in bubble and '.put("height"' in bubble and 'restoreMiniWindows()' in bubble,
    "outside taps close only unpinned mini windows": 'ACTION_OUTSIDE' in bubble and '!window.pinned' in bubble,
    "question and follow-up commands show a visible question and return to listening": 'window.__alislahShowFollowupQuestion' in bubble and 'command == "question" || command == "followup"' in bubble and 'autoListenAfterSpeech = true' in bubble,
    "adhan mute button stops the real playback service": 'setOnClickListener { stopAdhanFromBubble() }' in bubble and 'running.handler.post { running.endAdhan() }' in voice,
    "main app adhan stop uses the same service-level stop path": 'PrayerVoiceService.stopPlayback(this@MainActivity)' in main,
    "adhan stop state is synchronized directly with the live bubble": 'notifyAdhanPlaybackState(this, active)' in voice and 'applyAdhanBubbleState(active)' in bubble,
    "reminder answers are stored by the explicit prayer response receiver": 'recordPrayerResponseFromReminder(done)' in bubble and 'PrayerResponseReceiver.ACTION_RESPONSE' in bubble,
    "dashboard has touch-friendly card ordering": 'data-card-up' in js and 'data-card-down' in js,
    "dashboard notifications include tasks family habits and prayer": 'موعد أسري:' in js and 'عادات لم تُسجّل اليوم' in js and 'اقترب وقت صلاة' in js,
    "search includes behavior usage and worship data": 'A.data.behavior' in js and 'usageProfile.snapshots' in js and 'worship.khatma.log' in js,
    "custom shortcuts include the app's other sections": 'value=\"adhkar\"' in html and 'value=\"focustimer\"' in html,
    "custom shortcuts can be reordered with touch-friendly controls": 'data-shortcut-up' in js and 'data-shortcut-down' in js and 'function move(i,delta)' in js,
    "release version advanced without changing min Android version": 'versionCode 52' in (root / 'app/build.gradle').read_text(encoding='utf-8') and "versionName '2.1.4.22'" in (root / 'app/build.gradle').read_text(encoding='utf-8') and 'minSdk 26' in (root / 'app/build.gradle').read_text(encoding='utf-8'),
}
for name, ok in checks.items(): print(("PASS" if ok else "FAIL") + ": " + name)
if not all(checks.values()): raise SystemExit("Floating bubble recovery checks failed")
