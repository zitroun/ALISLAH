from pathlib import Path
root=Path(__file__).resolve().parents[1]
manifest=(root/"app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
receiver=(root/"app/src/main/java/dz/alislah/app/BackgroundEventsReceiver.kt").read_text(encoding="utf-8")
service=(root/"app/src/main/java/dz/alislah/app/FloatingBubbleService.kt").read_text(encoding="utf-8")
assert "android.permission.RECEIVE_BOOT_COMPLETED" in manifest
assert "android.intent.action.BOOT_COMPLETED" in manifest
assert "Intent.ACTION_BOOT_COMPLETED" in receiver
assert "context.startForegroundService(service)" in receiver
assert "context.startService(service)" in receiver
assert "startForeground(4107, buildNotification())" in service
assert "Settings.canDrawOverlays(this)" in service
print("Boot auto-start contract checks: PASS")
