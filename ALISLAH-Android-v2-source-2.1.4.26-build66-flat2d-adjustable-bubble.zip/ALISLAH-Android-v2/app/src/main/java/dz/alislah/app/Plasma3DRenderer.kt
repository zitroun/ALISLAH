package dz.alislah.app

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*

/** Flat 2D bubble artwork. No OpenGL, perspective, volume, specular highlights or 3D shading. */
internal class Plasma3DView(context: Context, private val compact: Boolean = false) : View(context) {
    @Volatile private var tint: Int = Color.rgb(23, 107, 91)
    @Volatile private var mode: String = "idle"
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val pulse = object : Runnable { override fun run() { invalidate(); handler.postDelayed(this, if (mode == "speaking") 110L else 260L) } }
    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }
    fun setAssistantMode(value: String) { mode=value; invalidate() }
    fun setTint(color: Int) { tint=color; invalidate() }
    fun onResume() { handler.removeCallbacks(pulse); handler.post(pulse) }
    fun onPause() { handler.removeCallbacks(pulse) }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); onResume() }
    override fun onDetachedFromWindow() { onPause(); super.onDetachedFromWindow() }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s=min(width,height).toFloat(); if(s<=0f)return
        val cx=width/2f; val cy=height/2f; val r=s*.47f
        val base=if(compact) tint else Color.rgb(23,107,91)
        paint.style=Paint.Style.FILL; paint.color=base; canvas.drawCircle(cx,cy,r,paint)
        // Flat inset color bands keep the graphic crisp and explicitly 2D.
        paint.color=if(compact) lighten(base,.18f) else Color.rgb(31,132,111)
        canvas.drawArc(cx-r,cy-r,cx+r,cy+r,205f,130f,true,paint)
        paint.color=if(compact) darken(base,.12f) else Color.rgb(15,83,73)
        canvas.drawArc(cx-r,cy-r,cx+r,cy+r,25f,115f,true,paint)
        paint.style=Paint.Style.STROKE; paint.strokeWidth=max(1.4f, s*.025f); paint.color=Color.argb(210,225,255,245)
        canvas.drawCircle(cx,cy,r,paint)
        paint.style=Paint.Style.FILL; paint.color=Color.WHITE
        when(mode){
            "speaking"->{ val t=android.os.SystemClock.uptimeMillis()/120.0; for(i in -2..2){val h=(.12f+abs(sin(t+i*.8)).toFloat()*.20f)*s;paint.strokeWidth=max(2f,s*.055f);paint.strokeCap=Paint.Cap.ROUND;canvas.drawLine(cx+i*s*.105f,cy-h/2f,cx+i*s*.105f,cy+h/2f,paint)} }
            "listening"->{paint.textAlign=Paint.Align.CENTER;paint.textSize=s*.38f;canvas.drawText("🎙",cx,cy-s*(paint.ascent()+paint.descent())/2f,paint)}
            "thinking","waiting"->{for(i in -1..1){paint.alpha=if((android.os.SystemClock.uptimeMillis()/260L)%3L==(i+1).toLong())255 else 135;canvas.drawCircle(cx+i*s*.16f,cy,s*.045f,paint)};paint.alpha=255}
            else->{paint.textAlign=Paint.Align.CENTER;paint.textSize=s*.34f;canvas.drawText("✦",cx,cy-s*(paint.ascent()+paint.descent())/2f,paint)}
        }
    }
    private fun lighten(c:Int,f:Float)=Color.rgb((Color.red(c)+(255-Color.red(c))*f).toInt(),(Color.green(c)+(255-Color.green(c))*f).toInt(),(Color.blue(c)+(255-Color.blue(c))*f).toInt())
    private fun darken(c:Int,f:Float)=Color.rgb((Color.red(c)*(1-f)).toInt(),(Color.green(c)*(1-f)).toInt(),(Color.blue(c)*(1-f)).toInt())
}

/** Flat 2D orbit line with animated dots; intentionally not a 3D torus. */
internal class PlasmaOrbit3DView(context: Context) : View(context) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    private val h=android.os.Handler(android.os.Looper.getMainLooper())
    private val tick=object:Runnable{override fun run(){invalidate();h.postDelayed(this,90L)}}
    init{setLayerType(View.LAYER_TYPE_SOFTWARE,null)}
    override fun onAttachedToWindow(){super.onAttachedToWindow();h.removeCallbacks(tick);h.post(tick)}
    override fun onDetachedFromWindow(){h.removeCallbacks(tick);super.onDetachedFromWindow()}
    override fun onDraw(canvas:Canvas){super.onDraw(canvas);val s=min(width,height).toFloat();if(s<=0)return;val cx=width/2f;val cy=height/2f;val r=s*.39f
      p.style=Paint.Style.STROKE;p.strokeWidth=max(2f,s*.012f);p.color=Color.argb(95,64,220,174);canvas.drawCircle(cx,cy,r,p)
      p.strokeWidth=max(1f,s*.006f);p.color=Color.argb(90,190,255,230);canvas.drawCircle(cx,cy,r*.94f,p)
      p.style=Paint.Style.FILL;val t=android.os.SystemClock.uptimeMillis()/1000.0
      for(i in 0..3){val a=t*-.65+i*Math.PI/2; p.color=if(i%2==0)Color.rgb(50,235,175) else Color.rgb(255,190,90);canvas.drawCircle(cx+cos(a).toFloat()*r,cy+sin(a).toFloat()*r,max(2f,s*.018f),p)}
    }
}
