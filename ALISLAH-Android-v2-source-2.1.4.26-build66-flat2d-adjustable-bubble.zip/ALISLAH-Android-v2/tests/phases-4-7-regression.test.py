from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / 'app/src/main/java/dz/alislah/app/MainActivity.kt').read_text()
bubble = (ROOT / 'app/src/main/java/dz/alislah/app/FloatingBubbleService.kt').read_text()
css = (ROOT / 'app/src/main/assets/app.css').read_text()
js = (ROOT / 'app/src/main/assets/js/main.js').read_text()
gradle = (ROOT / 'app/build.gradle').read_text()
workflow = (ROOT / '.github/workflows/build-android-2.1.4.26-reboot-interactive.yml').read_text()

# Phase 4: feature tests must not permanently enable/disable the user's bubble preference.
feature_tests = main.split('@JavascriptInterface fun runFeatureTest', 1)[1].split('@JavascriptInterface fun getAppDataJson', 1)[0]
assert 'putBoolean("overlayEnabled", true)' not in feature_tests
assert 'ACTION_TEST_BUBBLE' in feature_tests
assert 'temporaryTest = true' in feature_tests
assert 'allowWhenDisabled: Boolean = false' in bubble
assert 'if (!enabled && !allowWhenDisabled) return false' in bubble
assert 'EXTRA_TEMPORARY_TEST' in bubble

# Phase 5: compact-screen, focus and reduced-motion accommodations.
assert '@media(max-width:380px)' in css
assert '@media(prefers-reduced-motion:reduce)' in css
assert '.messages{overscroll-behavior:contain' in css
assert ':focus-visible' in css

# Phase 6: explicit plan requests are converted into scheduled task records.
assert 'async function autoCreateTasksFromPlan(prompt,reply)' in js
assert "createPlannedTasks(unique,'assistant-plan')" in js
assert 'scheduleTaskReminder(task)' in js

# Phase 7: build metadata and protected signing gate remain present.
assert 'versionCode 66' in gradle
assert 'versionName \'2.1.4.26\'' in gradle
assert 'ALISLAH_SIGNING_CERT_SHA256' in workflow
assert 'keytool -list -v -keystore' in workflow
assert 'assembleDebug' in workflow
assert 'verify --verbose --print-certs' in workflow
print('PASS phases 4-7 regression contracts')
