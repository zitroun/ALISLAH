from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'app/src/main/java/dz/alislah/app/FloatingBubbleService.kt').read_text(encoding='utf-8')
r=(root/'app/src/main/java/dz/alislah/app/Plasma3DRenderer.kt').read_text(encoding='utf-8')
assert 'Plasma3DView(context)' in s and 'Plasma3DView(context, compact = true)' in s
assert 'PlasmaOrbit3DView(this)' in s and 'Canvas' in r
assert 'ACTION_SPEAK_TEXT' in s or 'setSpeaking' in s
print('PASS: flat 2D bubble, orbit and assistant-state render contracts')
