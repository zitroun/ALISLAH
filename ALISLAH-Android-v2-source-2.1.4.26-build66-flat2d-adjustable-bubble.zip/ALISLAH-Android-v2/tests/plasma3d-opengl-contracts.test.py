from pathlib import Path
root=Path(__file__).resolve().parents[1]
r=(root/'app/src/main/java/dz/alislah/app/Plasma3DRenderer.kt').read_text(encoding='utf-8')
assert 'class Plasma3DView' in r and 'class PlasmaOrbit3DView' in r
assert 'Canvas' in r and 'drawCircle' in r and 'drawArc' in r
assert 'GLSurfaceView' not in r and 'GLES20' not in r and 'GL_FRAGMENT_SHADER' not in r
print('2D renderer contract: PASS (no OpenGL/3D pipeline)')
