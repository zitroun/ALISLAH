from pathlib import Path
root=Path(__file__).resolve().parents[1]
service=(root/'app/src/main/java/dz/alislah/app/FloatingBubbleService.kt').read_text(encoding='utf-8')
renderer=(root/'app/src/main/java/dz/alislah/app/Plasma3DRenderer.kt').read_text(encoding='utf-8')
html=(root/'app/src/main/assets/index.html').read_text(encoding='utf-8')
js=(root/'app/src/main/assets/js/dashboard.js').read_text(encoding='utf-8')
gradle=(root/'app/build.gradle').read_text(encoding='utf-8')
assert 'class MainBubbleView' in service and 'private val sphere = Plasma3DView(context)' in service
assert 'class PlasmaActionTextView' in service and 'private val plasma = Plasma3DView(context, compact = true)' in service
assert 'PlasmaOrbit3DView(this)' in service and 'drawCircle' in renderer and 'drawArc' in renderer
assert 'GLSurfaceView' not in renderer and 'GLES20' not in renderer and 'sdTorus' not in renderer
assert 'bubbleMainSize' in html and 'bubbleSideSize' in html
assert 'mainSizePercent' in js and 'sideSizePercent' in js
assert 'bubbleMainSizePercent' in service and 'bubbleSideSizePercent' in service
assert 'mainSizePercent: Int' in service and 'sideSizePercent: Int' in service
assert 'setBubbleBehavior(cfg.singleTap,cfg.doubleTap,cfg.longPress,cfg.orbitRadiusDp,cfg.sideRotation,cfg.mainSizePercent,cfg.sideSizePercent)' in js
assert 'versionCode 66' in gradle
main=(root/'app/src/main/java/dz/alislah/app/MainActivity.kt').read_text(encoding='utf-8')
assert 'putInt("bubbleMainSizePercent", mainSizePercent.coerceIn(75,130))' in main
assert 'ACTION_REFRESH_BUBBLE_CONFIG' in main and 'Recreate the existing overlay' in service
assert 'layoutInDisplayCutoutMode' in service and 'FLAG_LAYOUT_NO_LIMITS' in service
print('Flat 2D bubble, adjustable size and orbit contracts: PASS')
