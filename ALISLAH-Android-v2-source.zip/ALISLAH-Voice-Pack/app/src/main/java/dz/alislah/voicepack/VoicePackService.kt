package dz.alislah.voicepack

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import io.flutter.FlutterInjector
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.dart.DartExecutor
import io.flutter.plugin.common.MethodChannel

/** On-demand foreground host for the separately installed offline Arabic Mixer-TTS engine. */
class VoicePackService : Service() {
    private var engine: FlutterEngine? = null
    private var channel: MethodChannel? = null
    private var ready = false
    private var pendingText: String? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopEngine()
                stopSelf(startId)
                return START_NOT_STICKY
            }
            ACTION_SPEAK -> {
                val text = (intent.getStringExtra(EXTRA_TEXT) ?: "").trim().take(700)
                if (text.isBlank()) { stopSelf(startId); return START_NOT_STICKY }
                pendingText = text
                if (!startAsForeground()) {
                    stopSelf(startId)
                    return START_NOT_STICKY
                }
                if (!ensureEngine()) {
                    stopEngineAndService(startId)
                } else if (ready) {
                    speakPending()
                }
            }
            else -> stopSelf(startId)
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground(): Boolean {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "الصوت العصبي ALISLAH", NotificationManager.IMPORTANCE_LOW))
        }
        @Suppress("DEPRECATION")
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }
        val notification = builder
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("صوت ALISLAH العصبي")
            .setContentText("يتم تشغيل الصوت العربي محليًا")
            .setOngoing(true)
            .build()
        return try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(NOTIFICATION_ID, notification)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun ensureEngine(): Boolean {
        if (engine != null && channel != null) return true
        return try {
            val loader = FlutterInjector.instance().flutterLoader()
            loader.startInitialization(applicationContext)
            loader.ensureInitializationComplete(applicationContext, null)
            val flutterEngine = FlutterEngine(this)
            val methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "alislah/mixer_tts")
            methodChannel.setMethodCallHandler { call, result ->
                if (call.method == "onStatus") {
                    val data = call.arguments as? Map<*, *>
                    if (data?.get("ready") == true) {
                        ready = true
                        speakPending()
                    }
                    if (data?.get("finished") == true) {
                        handler.postDelayed({ stopEngineAndService() }, 250L)
                    }
                    result.success(true)
                } else result.notImplemented()
            }
            engine = flutterEngine
            channel = methodChannel
            flutterEngine.dartExecutor.executeDartEntrypoint(
                DartExecutor.DartEntrypoint(loader.findAppBundlePath(), "alislahTtsEntryPoint")
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun speakPending() {
        if (!ready) return
        val text = pendingText ?: return
        pendingText = null
        channel?.invokeMethod("speak", mapOf("text" to text), object : MethodChannel.Result {
            override fun success(result: Any?) { if (result != true) stopEngineAndService() }
            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) { stopEngineAndService() }
            override fun notImplemented() { stopEngineAndService() }
        })
    }

    private fun stopEngineAndService(startId: Int = 0) {
        stopEngine()
        if (startId > 0) stopSelf(startId) else stopSelf()
    }

    private fun stopEngine() {
        pendingText = null
        ready = false
        try { channel?.invokeMethod("stop", null) } catch (_: Exception) { }
        try { engine?.destroy() } catch (_: Exception) { }
        engine = null
        channel = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) { }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopEngine()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "alislah_voice_pack"
        private const val NOTIFICATION_ID = 4910
        const val ACTION_SPEAK = "dz.alislah.voicepack.action.SPEAK"
        const val ACTION_STOP = "dz.alislah.voicepack.action.STOP"
        const val EXTRA_TEXT = "dz.alislah.voicepack.extra.TEXT"
    }
}
