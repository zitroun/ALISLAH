# دمج Mixer-TTS في ALISLAH

- تم إنشاء مصدر Flutter add-to-app مستقل داخل `flutter_tts_module/` مع نقطة دخول صامتة `alislahTtsEntryPoint` وقناة `alislah/mixer_tts`.
- المضيف Android يهيئ FlutterEngine عند أول طلب نطق فقط، ويستدعي MixerTTS مع `speaker: 0` وVocos 22.05 kHz.
- سير GitHub Actions ينشئ Flutter module، وينزّل `mixer128.onnx` و`vocos22.onnx` و`shakkelha.onnx`، ويضمّنهما كأصول داخل APK. بعد اكتمال البناء لا يحتاج الصوت إلى الإنترنت.
- يستخدم Shakkelha تلقائيًا فقط عندما يكون النص العربي خاليًا تمامًا من الحركات؛ أما النص المشكول مسبقًا فيُمرر كما هو حفاظًا على تشكيله.
- محرك Android TTS القديم يبقى خيارًا مستقلًا. زر الإيقاف يوقف المحرك الجديد والقديم.
- لم يُعلن عن الدمج بوصفه مختبرًا بعد؛ يجب تشغيل GitHub Actions ثم اختبار النطق والإيقاف والتحديث على جهاز فعلي قبل اعتماد APK.
