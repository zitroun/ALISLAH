# مفتاح توقيع ALISLAH 2.1.3

- نوع المفتاح: Android DEBUG فقط (للبناء والتجربة والتثبيت اليدوي).
- الملف: `debug.keystore`
- Alias: `androiddebugkey`
- Store password: `android`
- Key password: `android`
- يجب الاحتفاظ بنسخة احتياطية من `debug.keystore` وعدم استبداله في الإصدارات القادمة.
- سير العمل `build-android.yml` ينسخ هذا الملف إلى `$HOME/.android/debug.keystore` قبل تنفيذ `gradle assembleDebug`.
- هذا ليس مفتاح إصدار Google Play. إذا تقرر النشر في Google Play، يجب إنشاء مفتاح Release خاص وآمن وعدم استخدام هذا المفتاح.
