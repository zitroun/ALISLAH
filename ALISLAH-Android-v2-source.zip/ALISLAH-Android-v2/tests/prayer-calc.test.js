// node tests/prayer-calc.test.js  — validates the calculator against an independent NOAA implementation
process.env.TZ='Africa/Algiers';
const P=require('../app/src/main/assets/js/prayer-data.js');
const H=require('../app/src/main/assets/js/hijri.js');
const assert=require('assert');
const rad=d=>d*Math.PI/180,deg=r=>r*180/Math.PI;
// NOAA solar calculator (independent formulation)
function noaa(y,m,d,lat,lon,tz,altDeg){
  const jd=Date.UTC(y,m-1,d,12)/86400000+2440587.5;const T=(jd-2451545)/36525;
  const L0=(280.46646+T*(36000.76983+T*0.0003032))%360;
  const M=357.52911+T*(35999.05029-0.0001537*T);
  const e=0.016708634-T*(0.000042037+0.0000001267*T);
  const C=Math.sin(rad(M))*(1.914602-T*(0.004817+0.000014*T))+Math.sin(rad(2*M))*(0.019993-0.000101*T)+Math.sin(rad(3*M))*0.000289;
  const tl=L0+C,om=125.04-1934.136*T,app=tl-0.00569-0.00478*Math.sin(rad(om));
  const eps0=23+(26+(21.448-T*(46.815+T*(0.00059-T*0.001813)))/60)/60,eps=eps0+0.00256*Math.cos(rad(om));
  const decl=deg(Math.asin(Math.sin(rad(eps))*Math.sin(rad(app))));
  const y2=Math.tan(rad(eps/2))**2;
  const eqt=4*deg(y2*Math.sin(2*rad(L0))-2*e*Math.sin(rad(M))+4*e*y2*Math.sin(rad(M))*Math.cos(2*rad(L0))-0.5*y2*y2*Math.sin(4*rad(L0))-1.25*e*e*Math.sin(2*rad(M)));
  const noon=(720-4*lon-eqt)/60+tz;
  const ha=deg(Math.acos((Math.sin(rad(altDeg))-Math.sin(rad(lat))*Math.sin(rad(decl)))/(Math.cos(rad(lat))*Math.cos(rad(decl)))))/15;
  return{noon,rise:noon-ha,set:noon+ha,decl};
}
const hrs=dt=>dt.getHours()+dt.getMinutes()/60;
let worst=0;
const cities=[['Algiers',36.75,3.06],['Tiaret',35.37,1.32],['Tamanrasset',22.79,5.53],['Annaba',36.90,7.77],['Adrar',27.87,-0.29]];
for(const [name,lat,lon] of cities){
  for(const [y,m,d] of [[2026,1,15],[2026,3,20],[2026,6,21],[2026,10,31],[2026,12,21]]){
    const t=P.compute(new Date(y,m-1,d,12),lat,lon,'algeria');
    const n=noaa(y,m,d,lat,lon,1,-0.833);
    const nf=noaa(y,m,d,lat,lon,1,-18),ni=noaa(y,m,d,lat,lon,1,-17);
    const pairs={Sunrise:[hrs(t.Sunrise),n.rise],Dhuhr:[hrs(t.Dhuhr),n.noon],Maghrib:[hrs(t.Maghrib),n.set],Fajr:[hrs(t.Fajr),nf.rise],Isha:[hrs(t.Isha),ni.set]};
    for(const k in pairs){const diff=Math.abs(pairs[k][0]-pairs[k][1])*60;worst=Math.max(worst,diff);assert(diff<2.5,`${name} ${y}-${m}-${d} ${k} differs by ${diff.toFixed(2)} min`)}
    assert(t.Fajr<t.Sunrise&&t.Sunrise<t.Dhuhr&&t.Dhuhr<t.Asr&&t.Asr<t.Maghrib&&t.Maghrib<t.Isha,'order '+name);
  }
}
console.log('prayer times match NOAA within',worst.toFixed(2),'minutes (worst case)');
// reference sanity: Algiers 31 Oct 2026
const a=P.compute(new Date(2026,9,31,12),36.75,3.06,'algeria');
const f=d=>d.toTimeString().slice(0,5);
console.log('Algiers 2026-10-31:',['Fajr','Sunrise','Dhuhr','Asr','Maghrib','Isha'].map(k=>k+' '+f(a[k])).join(' | '));
// adjustments
const b=P.compute(new Date(2026,9,31,12),36.75,3.06,'algeria',{Dhuhr:2});assert.strictEqual(Math.round((b.Dhuhr-a.Dhuhr)/60000),2);
// qibla
const q=P.qibla(36.75,3.06);assert(q>100&&q<110,'qibla Algiers '+q);const q2=P.qibla(35.37,1.32);console.log('qibla Algiers',q.toFixed(1),'Tiaret',q2.toFixed(1));
assert(Math.abs(P.qibla(21.4225,39.8262+1)-270)<1,'west of kaaba');
// Hijri sanity (Umm al-Qura): 2026-02-18 ≈ 1 Ramadan 1447
const hp=H.parts(new Date(2026,1,18));console.log('hijri 2026-02-18:',JSON.stringify(hp));
assert(hp&&hp.month===9,'Ramadan expected around mid Feb 2026');
// polar guard
assert.strictEqual(P.compute(new Date(2026,5,21,12),89,0,'mwl'),null);
console.log('ALL OK');
