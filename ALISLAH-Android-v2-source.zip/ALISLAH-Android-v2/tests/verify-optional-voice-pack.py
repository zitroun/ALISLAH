from pathlib import Path
root = Path(__file__).resolve().parents[1]
pack = root.parent / 'ALISLAH-Voice-Pack'
checks = {
    'core Gradle has no Flutter project dependency': "project(':flutter')" not in (root / 'app/build.gradle').read_text(encoding='utf-8'),
    'core settings have no Flutter loader': 'include_flutter' not in (root / 'settings.gradle').read_text(encoding='utf-8'),
    'core Activity has no Flutter imports': 'io.flutter' not in (root / 'app/src/main/java/dz/alislah/app/MainActivity.kt').read_text(encoding='utf-8'),
    'optional pack has Flutter module dependency': "implementation project(':flutter')" in (pack / 'app/build.gradle').read_text(encoding='utf-8'),
    'optional pack has exported IPC service': 'android:exported="true"' in (pack / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8'),
    'IPC is signature protected': 'dz.alislah.voicepack.permission.USE' in (pack / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8'),
    'base declares the optional package query': 'dz.alislah.voicepack' in (root / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8'),
    'base has safe legacy voice fallback': 'speakWithLegacyTts' in (root / 'app/src/main/java/dz/alislah/app/MainActivity.kt').read_text(encoding='utf-8'),
    'optional models remain outside base app assets': not list((root / 'app/src/main').rglob('*.onnx')),
    'voice pack uses the same IPC channel': "alislah/mixer_tts" in (pack / 'app/src/main/java/dz/alislah/voicepack/VoicePackService.kt').read_text(encoding='utf-8'),
    'voice module exposes the native Dart entry point': 'alislahTtsEntryPoint' in (root / 'flutter_tts_module/lib/main.dart').read_text(encoding='utf-8'),
    'voice models are declared for the optional module': all(name in (root / 'flutter_tts_module/pubspec.yaml').read_text(encoding='utf-8') for name in ['mixer128.onnx', 'vocos22.onnx', 'shakkelha.onnx']),
    'base and voice pack share the same keystore bytes': (root / 'debug.keystore').read_bytes() == (pack / 'debug.keystore').read_bytes(),
    'voice pack uses the same IPC channel': "alislah/mixer_tts" in (pack / 'app/src/main/java/dz/alislah/voicepack/VoicePackService.kt').read_text(encoding='utf-8'),
    'voice module exposes the native Dart entry point': 'alislahTtsEntryPoint' in (root / 'flutter_tts_module/lib/main.dart').read_text(encoding='utf-8'),
    'voice models are declared for the optional module': all(name in (root / 'flutter_tts_module/pubspec.yaml').read_text(encoding='utf-8') for name in ['mixer128.onnx', 'vocos22.onnx', 'shakkelha.onnx']),
    'base and voice pack share the same keystore bytes': (root / 'debug.keystore').read_bytes() == (pack / 'debug.keystore').read_bytes(),
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
failed = [name for name, ok in checks.items() if not ok]
if failed:
    raise SystemExit('Voice-pack separation preflight failed: ' + ', '.join(failed))
