from pathlib import Path

root = Path(__file__).resolve().parents[1]
activity = (root / 'app/src/main/java/dz/alislah/app/MainActivity.kt').read_text(encoding='utf-8')
bubble = (root / 'app/src/main/java/dz/alislah/app/FloatingBubbleService.kt').read_text(encoding='utf-8')
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
index = (root / 'app/src/main/assets/index.html').read_text(encoding='utf-8')
main_js = (root / 'app/src/main/assets/js/main.js').read_text(encoding='utf-8')
parser = (root / 'app/src/main/assets/js/voice-task-parser.js').read_text(encoding='utf-8')
gradle = (root / 'app/build.gradle').read_text(encoding='utf-8')

checks = {
    'runtime microphone permission': 'android.permission.RECORD_AUDIO' in manifest,
    'live partial speech results': 'RecognizerIntent.EXTRA_PARTIAL_RESULTS, true' in activity and 'onPartialResults' in activity,
    'Arabic-Algerian recognizer locale': 'RecognizerIntent.EXTRA_LANGUAGE, "ar-DZ"' in activity,
    'hold-to-record bubble timer': 'handler.postDelayed(longPress, 650L)' in bubble,
    'release stops bubble recording': 'stopVoiceTaskFromBubble()' in bubble and 'EXTRA_STOP_VOICE_TASK' in activity,
    'landscape navbar edge uses exposed half-circle': 'if (landscape && navigation.edge == edge)' in bubble and 'lp.y = boundary - circle/2' in bubble and 'lp.x = boundary - circle/2' in bubble,
    'microphone remains optional device hardware': 'android.hardware.microphone' in manifest and 'android:required=\"false\"' in manifest,
    'landscape side-navigation detection': 'config_navBarCanMove' in bubble and 'Surface.ROTATION_270' in bubble and 'navigation_bar_width' in bubble,
    'voice task entry in app': 'id="voiceTaskStart"' in index and 'AndroidUsage.startVoiceTask()' in main_js,
    'missing-time prompt': 'id="voiceTaskSheet"' in index and 'حددي وقت المهمة' in index,
    'prayer-relative scheduling hook': 'ALI_PRAYER_TASK_TIME' in parser and 'ALI_PRAYER_TASK_TIME=function' in (root / 'app/src/main/assets/js/prayer.js').read_text(encoding='utf-8'),
    'editable transcript continues receiving new words': 'voiceTaskLastRecognized' in activity and 'voiceTaskUserEdited' in activity,
    're-record button restarts recognition': 'voiceTaskRequiresHold = false' in activity,
    'shared task-list integration': 'addVoiceTask:addVoiceTaskFromTranscript' in main_js and 'scheduleTaskReminder(task)' in main_js,
    'voice parser loaded before main app': index.index('js/voice-task-parser.js') < index.index('js/main.js'),
    'version increment': "versionCode 40" in gradle and "versionName '2.1.4.10'" in gradle,
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit('Voice-task integration checks failed: ' + ', '.join(failed))
