package dz.alislah.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

object TaskReminderScheduler {
    private const val PREFS = "alislah_native"
    private const val KEY = "scheduledTasks"
    private fun requestCode(id: String): Int = (id.hashCode() and 0x7fffffff).coerceAtLeast(1)

    fun schedule(context: Context, id: String, title: String, atMillis: Long) {
        if (id.isBlank() || title.isBlank() || atMillis <= System.currentTimeMillis()) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val saved = try { JSONArray(prefs.getString(KEY, "[]")) } catch (_: Exception) { JSONArray() }
        val next = JSONArray()
        for (i in 0 until saved.length()) {
            val row = saved.optJSONObject(i) ?: continue
            if (row.optString("id") != id) next.put(row)
        }
        next.put(JSONObject().put("id", id).put("title", title.take(160)).put("at", atMillis))
        prefs.edit().putString(KEY, next.toString()).apply()
        setAlarm(context, id, title, atMillis)
    }

    private fun setAlarm(context: Context, id: String, title: String, atMillis: Long) {
        if (atMillis <= System.currentTimeMillis()) return
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, TaskReminderReceiver::class.java).putExtra("taskId", id).putExtra("taskTitle", title.take(160))
        val pi = PendingIntent.getBroadcast(context, requestCode(id), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarm.canScheduleExactAlarms()) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
            else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
            else alarm.setExact(AlarmManager.RTC_WAKEUP, atMillis, pi)
        } catch (_: Exception) { try { alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi) } catch (_: Exception) {} }
    }

    fun cancel(context: Context, id: String) {
        if (id.isBlank()) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val saved = try { JSONArray(prefs.getString(KEY, "[]")) } catch (_: Exception) { JSONArray() }
        val next = JSONArray()
        for (i in 0 until saved.length()) { val row = saved.optJSONObject(i) ?: continue; if (row.optString("id") != id) next.put(row) }
        prefs.edit().putString(KEY, next.toString()).apply()
        val intent = Intent(context, TaskReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(context, requestCode(id), intent, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
        if (pi != null) { (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi); pi.cancel() }
    }

    fun restore(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val saved = try { JSONArray(prefs.getString(KEY, "[]")) } catch (_: Exception) { JSONArray() }
        val now = System.currentTimeMillis(); val next = JSONArray()
        for (i in 0 until saved.length()) {
            val row = saved.optJSONObject(i) ?: continue
            val id = row.optString("id"); val title = row.optString("title"); val at = row.optLong("at")
            if (id.isNotBlank() && at > now) { next.put(row); setAlarm(context, id, title, at) }
        }
        prefs.edit().putString(KEY, next.toString()).apply()
    }
}
