package dz.alislah.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject

/** Keeps task reminders in native storage so they can be re-created after a reboot. */
object ReminderStore {
    private const val PREFS = "alislah_reminders"
    private const val KEY = "items"

    private fun load(context: Context): JSONObject =
        try { JSONObject(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }

    private fun store(context: Context, obj: JSONObject) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, obj.toString()).apply()
    }

    private fun pending(context: Context, id: String, title: String?, flags: Int): PendingIntent? {
        val intent = Intent(context, TaskReminderReceiver::class.java).apply {
            action = TaskReminderReceiver.ACTION_TASK_REMINDER
            putExtra(TaskReminderReceiver.EXTRA_TASK_ID, id)
            if (title != null) putExtra(TaskReminderReceiver.EXTRA_TITLE, title)
        }
        val immutable = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        return PendingIntent.getBroadcast(context, id.hashCode() and 0x7fffffff, intent, flags or immutable)
    }

    fun schedule(context: Context, id: String, title: String, atMillis: Long, persist: Boolean = true) {
        if (atMillis <= System.currentTimeMillis()) return
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(context, id, title, PendingIntent.FLAG_UPDATE_CURRENT) ?: return
        try {
            if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
            else alarm.set(AlarmManager.RTC_WAKEUP, atMillis, pi)
        } catch (_: Exception) { return }
        if (persist) {
            val all = load(context)
            all.put(id, JSONObject().put("title", title).put("at", atMillis))
            store(context, all)
        }
    }

    fun cancel(context: Context, id: String) {
        try {
            val pi = pending(context, id, null, PendingIntent.FLAG_NO_CREATE)
            if (pi != null) {
                (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
                pi.cancel()
            }
        } catch (_: Exception) { }
        remove(context, id)
    }

    fun remove(context: Context, id: String) {
        val all = load(context)
        if (all.has(id)) { all.remove(id); store(context, all) }
    }

    fun rescheduleAll(context: Context) {
        val all = load(context)
        val now = System.currentTimeMillis()
        val ids = all.keys().asSequence().toList()
        for (id in ids) {
            val item = all.optJSONObject(id)
            val at = item?.optLong("at", 0L) ?: 0L
            if (item == null || at <= now) all.remove(id)
            else schedule(context, id, item.optString("title", ""), at, persist = false)
        }
        store(context, all)
    }
}
