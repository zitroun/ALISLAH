package dz.alislah.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews

/** Home-screen widget: next prayer with a live countdown + today's remaining tasks. */
class AlislahWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val views = build(context)
        for (id in appWidgetIds) appWidgetManager.updateAppWidget(id, views)
    }

    companion object {
        fun refreshAll(context: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(context)
                val ids = mgr.getAppWidgetIds(ComponentName(context, AlislahWidgetProvider::class.java))
                if (ids.isEmpty()) return
                val views = build(context)
                for (id in ids) mgr.updateAppWidget(id, views)
            } catch (_: Exception) { }
        }

        private fun build(context: Context): RemoteViews {
            val v = RemoteViews(context.packageName, R.layout.widget_alislah)
            val open = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pi = PendingIntent.getActivity(context, 7600, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            v.setOnClickPendingIntent(R.id.widget_root, pi)

            val next = Snapshot.nextPrayer(context)
            val now = System.currentTimeMillis()
            if (next != null && next.second > now) {
                v.setTextViewText(R.id.widget_prayer, next.first)
                v.setViewVisibility(R.id.widget_countdown, View.VISIBLE)
                v.setChronometerCountDown(R.id.widget_countdown, true)
                v.setChronometer(R.id.widget_countdown, SystemClock.elapsedRealtime() + (next.second - now), null, true)
            } else {
                v.setTextViewText(R.id.widget_prayer, "افتحي التطبيق")
                v.setViewVisibility(R.id.widget_countdown, View.GONE)
            }

            val snap = Snapshot.read(context)
            val line = if (snap.optString("date") == Snapshot.todayKey()) {
                val pending = snap.optInt("pending", 0)
                if (pending == 0) {
                    "لا مهام متبقية اليوم ✅"
                } else {
                    val sb = StringBuilder("متبقٍ ").append(pending).append(" مهام")
                    val top = snap.optJSONArray("top")
                    if (top != null) {
                        for (i in 0 until minOf(top.length(), 2)) sb.append("\n• ").append(top.optString(i))
                    }
                    sb.toString()
                }
            } else {
                "افتحي التطبيق لتحديث مهام اليوم"
            }
            v.setTextViewText(R.id.widget_tasks, line)
            return v
        }
    }
}
