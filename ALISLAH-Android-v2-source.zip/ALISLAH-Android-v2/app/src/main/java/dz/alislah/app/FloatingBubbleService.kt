package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.Surface
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.content.res.Configuration
import android.webkit.WebChromeClient
import android.webkit.PermissionRequest
import android.Manifest
import android.content.pm.PackageManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.view.WindowManager
import android.util.DisplayMetrics
import android.widget.TextView
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class FloatingBubbleService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f
    private var dragged = false
    private var downAt = 0L
    private var lastTapAt = 0L
    private var pendingMainTap: Runnable? = null
    private var lastBubbleScreenWidth = 0
    private var lastBubbleScreenHeight = 0
    private var lastDisplayRotation = Surface.ROTATION_0
    private var orbitRotation = 0.0
    private var closeButton: TextView? = null
    private var closeParams: WindowManager.LayoutParams? = null
    private var quickMenu: View? = null
    private var quickMenuParams: WindowManager.LayoutParams? = null
    private var tts: TextToSpeech? = null
    private var lastSpokenReply = ""
    private var networkArabicVoice: android.speech.tts.Voice? = null
    private var localArabicVoice: android.speech.tts.Voice? = null
    private var pendingFallbackText = ""
    private var fallbackAttempted = false
    private var ttsReady = false
    private val pollReply = object : Runnable { override fun run() { speakLatestReply(); if (assistantPanel != null) handler.postDelayed(this, 1800L) } }
    private var assistantPanel: View? = null
    private var assistantWebView: WebView? = null
    private var activeOverlayCommand: String? = null
    private var overlayPageReady = false
    private val pendingOverlayScripts = ArrayDeque<String>()
    private var adhanPlaying = false
    private var adhanMuteBubble: TextView? = null
    private var adhanMuteParams: WindowManager.LayoutParams? = null
    private var currentReminderTitle = ""
    private var currentReminderText = ""
    private var reminderCardVisible = false
    private var reminderSpeechActive = false
    private var reminderCardView: LinearLayout? = null
    private var reminderCardParams: WindowManager.LayoutParams? = null
    private var reminderArrowView: TextView? = null
    private var reminderArrowParams: WindowManager.LayoutParams? = null
    private var reminderStopView: TextView? = null
    private var reminderStopParams: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private val reshowBubble = Runnable { showBubble() }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                configureAssistantVoice()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { }
                    override fun onDone(utteranceId: String?) {
                        fallbackAttempted = false; pendingFallbackText = ""
                        if (reminderSpeechActive) handler.post { reminderSpeechActive = false; reminderStopView?.visibility = View.GONE }
                    }
                    override fun onError(utteranceId: String?) { retryWithLocalArabicVoice() }
                    override fun onError(utteranceId: String?, errorCode: Int) { retryWithLocalArabicVoice() }
                })
                if (pendingFallbackText.isNotBlank()) speak(pendingFallbackText)
            }
        }
        startForeground(4107, buildNotification())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) showBubble() else stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ANSWERED -> {
                handler.removeCallbacks(reshowBubble)
                hideBubble()
            }
            ACTION_HIDE_PANEL -> hideAssistantOverlay()
            ACTION_STOP_SPEECH -> stopReminderSpeech()
            ACTION_SPEAK_TEST -> speak("مرحبًا بك في الإصلاح. هذا اختبار لصوت المساعد العربي.")
            ACTION_SPEAK_TEXT -> speak(intent.getStringExtra(EXTRA_SPEAK_TEXT) ?: "")
            ACTION_ADHAN_STARTED -> { adhanPlaying = true; bubble?.invalidate(); showAdhanMuteBubble() }
            ACTION_ADHAN_STOPPED -> { adhanPlaying = false; bubble?.invalidate(); hideAdhanMuteBubble() }
            ACTION_SHOW_REMINDER -> {
                val title = intent.getStringExtra(EXTRA_REMINDER_TITLE) ?: "تذكير الصلاة"
                val body = intent.getStringExtra(EXTRA_REMINDER_TEXT) ?: ""
                if (body.isNotBlank()) showPrayerReminder(title, body, true)
            }
            ACTION_SHOW_FOR_EVENT -> {
                handler.removeCallbacks(reshowBubble)
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) showBubble()
            }
            else -> if (bubble == null && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))) showBubble()
        }
        return START_STICKY
    }

    private fun hideBubble() {
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        params = null
        hideCloseButton()
        hideQuickMenu()
        hideReminderViews()
        hideAdhanMuteBubble()
    }

    private fun hideQuickMenu() {
        quickMenu?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        quickMenu = null
        quickMenuParams = null
    }

    /** A separate, temporary mute bubble appears beside the main bubble only while adhan is playing. */
    private fun showAdhanMuteBubble() {
        if (!adhanPlaying || bubble == null) return
        val existing = adhanMuteBubble
        if (existing != null) { syncAdhanMuteBubble(); existing.visibility = View.VISIBLE; return }
        val d = resources.displayMetrics.density
        val size = (42*d).toInt()
        val view = TextView(this).apply {
            text = "🔇"
            textSize = 19f
            gravity = Gravity.CENTER
            contentDescription = "إيقاف الأذان"
            setTextColor(Color.WHITE)
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(176,48,43))
                setStroke((2*d).toInt().coerceAtLeast(1), Color.WHITE)
            }
            elevation = 24*d
            setOnClickListener { stopAdhanFromBubble() }
        }
        val lp = overlayWindowParams(size, size)
        try {
            windowManager.addView(view, lp)
            adhanMuteBubble = view
            adhanMuteParams = lp
            syncAdhanMuteBubble()
        } catch (_: Exception) {
            adhanMuteBubble = null
            adhanMuteParams = null
        }
    }

    private fun syncAdhanMuteBubble() {
        val view = adhanMuteBubble ?: return
        val lp = adhanMuteParams ?: return
        val main = bubble ?: return
        val d = resources.displayMetrics.density
        val (screenW, screenH) = realScreenSize()
        val location = IntArray(2)
        main.getLocationOnScreen(location)
        val centerY = location[1] + main.height/2
        val docked = (main as? MainBubbleView)?.dockedAtCamera == true
        val leftSide = (params?.x ?: 0) < 0
        val x = if (docked) location[0] + main.width + (6*d).toInt()
                else if (leftSide) location[0] + main.width + (6*d).toInt()
                else location[0] - lp.width - (6*d).toInt()
        lp.x = x.coerceIn(0, (screenW-lp.width).coerceAtLeast(0))
        lp.y = (centerY-lp.height/2).coerceIn(0, (screenH-lp.height).coerceAtLeast(0))
        try { windowManager.updateViewLayout(view, lp) } catch (_: Exception) { }
    }

    private fun hideAdhanMuteBubble() {
        adhanMuteBubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        adhanMuteBubble = null
        adhanMuteParams = null
    }

    private fun overlayWindowParams(width: Int, height: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(
            width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.LEFT }
    }

    private fun showPrayerReminder(title: String, body: String, readAloud: Boolean) {
        if (body.isBlank()) return
        currentReminderTitle = title.take(100)
        currentReminderText = body.take(700)
        reminderCardVisible = true
        ensureReminderViews()
        reminderCardView?.visibility = View.VISIBLE
        reminderArrowView?.visibility = View.VISIBLE
        reminderArrowView?.text = "⌃"
        syncReminderOverlay(params)
        if (readAloud) {
            reminderSpeechActive = true
            reminderStopView?.visibility = View.VISIBLE
            speak("${currentReminderTitle}. ${currentReminderText}")
        }
    }

    private fun ensureReminderViews() {
        val d = resources.displayMetrics.density
        if (reminderCardView == null) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding((14*d).toInt(), (10*d).toInt(), (14*d).toInt(), (11*d).toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.WHITE)
                    cornerRadius = 18*d
                    setStroke((1.2f*d).toInt().coerceAtLeast(1), Color.rgb(190, 219, 207))
                }
                elevation = 22*d
                isClickable = true
            }
            val titleView = TextView(this).apply {
                textSize = 13f
                setTextColor(Color.rgb(23, 107, 91))
                typeface = Typeface.DEFAULT_BOLD
                text = currentReminderTitle
                maxLines = 1
            }
            val bodyView = TextView(this).apply {
                textSize = 14f
                setTextColor(Color.rgb(35, 53, 47))
                text = currentReminderText
                maxLines = 6
                ellipsize = android.text.TextUtils.TruncateAt.END
                setLineSpacing((2*d), 1f)
                setPadding(0, (5*d).toInt(), 0, 0)
            }
            card.addView(titleView)
            card.addView(bodyView)
            card.tag = Pair(titleView, bodyView)
            card.setOnTouchListener(object : View.OnTouchListener {
                var downX = 0f
                var downY = 0f
                var swiped = false
                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; swiped = false; return true }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = event.rawX - downX
                            val dy = event.rawY - downY
                            if (kotlin.math.abs(dx) > 18*d || kotlin.math.abs(dy) > 18*d) swiped = true
                            return true
                        }
                        MotionEvent.ACTION_UP -> {
                            val dx = event.rawX - downX
                            val dy = event.rawY - downY
                            if (swiped && (kotlin.math.abs(dx) > 48*d || kotlin.math.abs(dy) > 48*d)) {
                                hideReminderCardOnly()
                                return true
                            }
                            return false
                        }
                        MotionEvent.ACTION_CANCEL -> { swiped = false; return true }
                    }
                    return false
                }
            })
            reminderCardView = card
            reminderCardParams = overlayWindowParams((resources.displayMetrics.widthPixels - (24*d).toInt()).coerceAtMost((320*d).toInt()), WindowManager.LayoutParams.WRAP_CONTENT)
            try { windowManager.addView(card, reminderCardParams) } catch (_: Exception) { reminderCardView = null; reminderCardParams = null }
        }
        val tag = reminderCardView?.tag as? Pair<*, *>
        (tag?.first as? TextView)?.text = currentReminderTitle
        (tag?.second as? TextView)?.text = currentReminderText

        if (reminderArrowView == null) {
            val arrow = TextView(this).apply {
                text = if (reminderCardVisible) "⌃" else "⌄"
                textSize = 22f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                contentDescription = "فتح أو إخفاء تذكير الصلاة"
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    setCornerRadii(floatArrayOf(0f,0f,0f,0f,10*d,10*d,10*d,10*d))
                    setColor(Color.rgb(23,107,91))
                }
                elevation = 22*d
                setOnClickListener {
                    reminderCardVisible = !reminderCardVisible
                    reminderCardView?.visibility = if (reminderCardVisible) View.VISIBLE else View.GONE
                    text = if (reminderCardVisible) "⌃" else "⌄"
                    syncReminderOverlay(params)
                }
            }
            reminderArrowView = arrow
            reminderArrowParams = overlayWindowParams((42*d).toInt(), (30*d).toInt())
            try { windowManager.addView(arrow, reminderArrowParams) } catch (_: Exception) { reminderArrowView = null; reminderArrowParams = null }
        }

        if (reminderStopView == null) {
            val stop = TextView(this).apply {
                text = "■"
                textSize = 16f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                contentDescription = "إيقاف قراءة التذكير"
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(Color.rgb(176, 48, 43))
                    setStroke((1.5f*d).toInt().coerceAtLeast(1), Color.WHITE)
                }
                elevation = 24*d
                setOnClickListener { stopReminderSpeech() }
            }
            reminderStopView = stop
            reminderStopParams = overlayWindowParams((36*d).toInt(), (36*d).toInt())
            try { windowManager.addView(stop, reminderStopParams) } catch (_: Exception) { reminderStopView = null; reminderStopParams = null }
        }
        reminderCardView?.visibility = if (reminderCardVisible) View.VISIBLE else View.GONE
        reminderArrowView?.visibility = View.VISIBLE
        reminderStopView?.visibility = if (reminderSpeechActive) View.VISIBLE else View.GONE
    }

    private fun hideReminderCardOnly() {
        reminderCardVisible = false
        reminderCardView?.visibility = View.GONE
        // A swipe dismisses the whole floating reminder control, but never its library entry.
        reminderArrowView?.visibility = View.GONE
    }

    private fun stopReminderSpeech() {
        pendingFallbackText = ""
        fallbackAttempted = true
        reminderSpeechActive = false
        try { assistantWebView?.evaluateJavascript("window.AlishlahNeuralVoice&&window.AlishlahNeuralVoice.stop()", null) } catch (_: Exception) { }
        try { tts?.stop() } catch (_: Exception) { }
        reminderStopView?.visibility = View.GONE
    }

    private fun hideReminderViews() {
        reminderCardView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        reminderArrowView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        reminderStopView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        reminderCardView = null; reminderCardParams = null
        reminderArrowView = null; reminderArrowParams = null
        reminderStopView = null; reminderStopParams = null
    }

    /** Keep reminder controls attached to the actual rendered centre of the main orbital anchor. */
    private fun syncReminderOverlay(anchor: WindowManager.LayoutParams?) {
        val wm = try { windowManager } catch (_: Exception) { return }
        val main = bubble
        val a = anchor ?: params ?: return
        val d = resources.displayMetrics.density
        val (screenW, screenH) = realScreenSize()
        val location = IntArray(2)
        if (main != null && main.width > 0 && main.height > 0) main.getLocationOnScreen(location) else { location[0] = a.x; location[1] = a.y }
        val left = location[0]
        val top = location[1]
        val width = main?.width?.takeIf { it > 0 } ?: a.width
        val height = main?.height?.takeIf { it > 0 } ?: a.height
        val centerX = left + width/2
        val docked = (main as? MainBubbleView)?.dockedAtCamera == true
        val onLeft = centerX < screenW/2
        val arrowLp = reminderArrowParams
        val arrow = reminderArrowView
        if (arrowLp != null && arrow != null) {
            val arrowW = arrowLp.width
            val arrowH = arrowLp.height
            arrowLp.x = if (docked) centerX - arrowW/2 else if (onLeft) left + width - arrowW/2 else left - arrowW/2
            arrowLp.x = arrowLp.x.coerceIn(0, (screenW-arrowW).coerceAtLeast(0))
            arrowLp.y = (top + height - (2*d).toInt()).coerceIn(0, (screenH-arrowH).coerceAtLeast(0))
            try { wm.updateViewLayout(arrow, arrowLp) } catch (_: Exception) { }
        }
        val cardLp = reminderCardParams
        val card = reminderCardView
        if (cardLp != null && card != null) {
            val cardW = cardLp.width
            val measuredH = card.height.takeIf { it > 0 } ?: (150*d).toInt()
            cardLp.x = if (docked) centerX - cardW/2 else if (onLeft) (16*d).toInt() else screenW-cardW-(16*d).toInt()
            cardLp.x = cardLp.x.coerceIn(0, (screenW-cardW).coerceAtLeast(0))
            val below = top + height + (34*d).toInt()
            val above = top - measuredH - (12*d).toInt()
            cardLp.y = if (below + measuredH <= screenH - (8*d).toInt()) below else above.coerceAtLeast((8*d).toInt())
            try { wm.updateViewLayout(card, cardLp) } catch (_: Exception) { }
        }
        val stopLp = reminderStopParams
        val stop = reminderStopView
        if (stopLp != null && stop != null) {
            stopLp.x = (centerX - stopLp.width/2).coerceIn(0, (screenW-stopLp.width).coerceAtLeast(0))
            stopLp.y = if (docked) (top + (2*d).toInt()) else (top - stopLp.height + (3*d).toInt()).coerceAtLeast(0)
            try { wm.updateViewLayout(stop, stopLp) } catch (_: Exception) { }
        }
    }

    /** Read the rendered bubble position so the orbit follows its real on-screen centre, not stale window coordinates. */
    private fun anchorScreenCenter(anchor: WindowManager.LayoutParams): Pair<Float, Float> {
        val main = bubble
        if (main != null && main.width > 0 && main.height > 0) {
            val location = IntArray(2)
            main.getLocationOnScreen(location)
            return Pair(location[0] + main.width / 2f, location[1] + main.height / 2f)
        }
        return Pair(anchor.x + anchor.width / 2f, anchor.y + anchor.height / 2f)
    }

    private fun anchorCenterX(anchor: WindowManager.LayoutParams): Float = anchorScreenCenter(anchor).first
    private fun anchorCenterY(anchor: WindowManager.LayoutParams): Float = anchorScreenCenter(anchor).second

    private fun syncQuickMenuToAnchor(anchor: WindowManager.LayoutParams) {
        val menuLp = quickMenuParams ?: return
        val menu = quickMenu ?: return
        val (screenW, screenH) = realScreenSize()
        val x = (anchorCenterX(anchor).toInt() - menuLp.width / 2).coerceIn(-(menuLp.width / 2), screenW - (menuLp.width / 2))
        val y = (anchorCenterY(anchor).toInt() - menuLp.height / 2).coerceIn(-(menuLp.height / 2), screenH - (menuLp.height / 2))
        if (menuLp.x != x || menuLp.y != y) {
            menuLp.x = x; menuLp.y = y
            try { windowManager.updateViewLayout(menu, menuLp) } catch (_: Exception) { }
        }
    }

    private fun showQuickMenu(anchor: WindowManager.LayoutParams) {
        if (quickMenu != null) { hideQuickMenu(); return }
        val d = resources.displayMetrics.density
        val item = (52 * d).toInt()
        val radius = (94 * d).toInt()
        val size = (radius * 2 + item + 12*d).toInt()
        val menu = FrameLayout(this).apply { elevation = 24*d }
        // A continuous orbit guide sits behind the action bubbles. The screen edge clips
        // the off-screen half naturally, instead of hiding individual bubbles in code.
        val orbitTrack = object : View(this) {
            private val trackPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(105, 23, 107, 91)
                style = android.graphics.Paint.Style.STROKE
                strokeWidth = (2.2f * d).coerceAtLeast(1f)
            }
            override fun onDraw(canvas: android.graphics.Canvas) {
                super.onDraw(canvas)
                canvas.drawCircle(width / 2f, height / 2f, radius.toFloat(), trackPaint)
            }
        }
        menu.addView(orbitTrack, FrameLayout.LayoutParams(size, size))
        data class BubbleAction(val icon: String, val label: String, val command: String, val color: Int)
        val actions = listOf(
            BubbleAction("💬", "المساعد", "ask", Color.rgb(23,107,91)),
            BubbleAction("📋", "الخطة", "plan", Color.rgb(43,112,190)),
            BubbleAction("📊", "التحليل", "behavior", Color.rgb(117,76,175)),
            BubbleAction("⚙", "الإعدادات", "settings", Color.rgb(82,98,105)),
            BubbleAction("👨‍👩‍👧", "الأسرة", "family", Color.rgb(190,117,47)),
            BubbleAction("🕌", "الصلاة", "prayer", Color.rgb(16,130,100)),
            BubbleAction("✓", "العادات", "habits", Color.rgb(40,130,145)),
            BubbleAction("🔊", "صوت المساعد", "voice", Color.rgb(32,128,145)),
            BubbleAction("👁", "راحة العين", "eye", Color.rgb(55,125,119)),
            BubbleAction("✕", "إغلاق", "close", Color.rgb(190,55,55))
        )
        val buttons = mutableListOf<TextView>()
        actions.forEach { a ->
            val b = TextView(this).apply {
                text = a.icon; textSize = 21f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                contentDescription = a.label
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(a.color); setStroke((2*d).toInt(), Color.WHITE)
                }
                elevation = 8*d
                setOnClickListener {
                    hideQuickMenu()
                    if (a.command == "close") { prefs().edit().putBoolean("overlayEnabled", false).apply(); stopSelf() }
                    else showAssistantOverlay(a.command)
                }
            }
            buttons.add(b); menu.addView(b, FrameLayout.LayoutParams(item,item))
        }
        fun placeButtons(rotation: Double) {
            val centerX = size/2.0
            val centerY = size/2.0
            // All bubbles remain in the orbit. The overlay window itself is positioned
            // around the true main-bubble centre and is clipped by the physical screen edge.
            // This avoids abrupt visibility toggles and makes rotation visually continuous.
            buttons.forEachIndexed { i,b ->
                val angle = (-Math.PI/2.0) + (2.0*Math.PI * i/buttons.size) + rotation
                val x = (centerX + radius*kotlin.math.cos(angle) - item/2).toInt()
                val y = (centerY + radius*kotlin.math.sin(angle) - item/2).toInt()
                val lp = b.layoutParams as FrameLayout.LayoutParams
                lp.leftMargin=x; lp.topMargin=y; b.layoutParams=lp
                b.visibility = View.VISIBLE
            }
        }
        placeButtons(orbitRotation)
        // Rotate by the actual polar angle around the main bubble, not a dx/dy approximation.
        buttons.forEach { button ->
            var downAngle = 0f
            var downRotation = orbitRotation
            var sideDragged = false
            button.setOnTouchListener { v, ev ->
                val centerX = anchorCenterX(anchor)
                val centerY = anchorCenterY(anchor)
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sideDragged = false
                        downAngle = Math.toDegrees(kotlin.math.atan2((ev.rawY-centerY).toDouble(), (ev.rawX-centerX).toDouble())).toFloat()
                        downRotation = orbitRotation
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val nowAngle = Math.toDegrees(kotlin.math.atan2((ev.rawY-centerY).toDouble(), (ev.rawX-centerX).toDouble())).toFloat()
                        var delta = nowAngle - downAngle
                        if (delta > 180f) delta -= 360f
                        if (delta < -180f) delta += 360f
                        if (kotlin.math.abs(delta) > 5f) sideDragged = true
                        if (sideDragged) { orbitRotation = downRotation + Math.toRadians(delta.toDouble()); placeButtons(orbitRotation) }
                        true
                    }
                    MotionEvent.ACTION_UP -> { if (!sideDragged) v.performClick(); true }
                    MotionEvent.ACTION_CANCEL -> true
                    else -> true
                }
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        // Keep the overlay centre exactly on the main bubble, even when this means
        // a negative window coordinate. FLAG_LAYOUT_NO_LIMITS lets the display clip
        // the off-screen half naturally without shifting the orbit away from its anchor.
        val x = anchorCenterX(anchor).toInt() - size/2
        val y = anchorCenterY(anchor).toInt() - size/2
        val lp = WindowManager.LayoutParams(size,size,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply {
            gravity=Gravity.TOP or Gravity.LEFT; this.x=x; this.y=y
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            windowManager.addView(menu, lp)
            quickMenu = menu
            quickMenuParams = lp
            // Keep the main bubble above the menu window so it remains clickable.
            // Otherwise the transparent center of the menu window intercepts taps.
            bubble?.let { main ->
                val mainLp = params
                if (mainLp != null) {
                    try { windowManager.removeView(main) } catch (_: Exception) {}
                    try { windowManager.addView(main, mainLp) } catch (_: Exception) {}
                }
            }
        } catch (_: Exception) {}
    }

    private fun prefs() = getSharedPreferences("alislah_native", MODE_PRIVATE)

    /** Prefer a natural network Arabic voice; retain an installed offline Arabic voice as a real fallback. */
    private fun configureAssistantVoice() {
        val engine = tts ?: return
        try {
            val voices = engine.voices.orEmpty().filter { it.locale.language.equals("ar", true) }
            val wantedFemale = prefs().getString("assistantVoiceGender", "female") != "male"
            val hints = if (wantedFemale) listOf("female", "woman", "amira", "salma", "hoda", "laila", "sara") else listOf("male", "man", "ahmed", "hamza", "omar")
            fun score(v: android.speech.tts.Voice) = hints.any { v.name.contains(it, true) }
            networkArabicVoice = voices.filter { it.isNetworkConnectionRequired }
                .sortedWith(compareByDescending<android.speech.tts.Voice> { score(it) }.thenByDescending { it.quality }).firstOrNull()
            localArabicVoice = voices.filter { !it.isNetworkConnectionRequired }
                .sortedWith(compareByDescending<android.speech.tts.Voice> { score(it) }.thenByDescending { it.quality }).firstOrNull()
            // Network voice first for natural speech; if unavailable, use local Arabic immediately.
            val preferred = networkArabicVoice ?: localArabicVoice
            if (preferred != null) engine.voice = preferred else engine.language = Locale("ar")
            engine.setPitch(1.0f)
            engine.setSpeechRate(0.96f)
        } catch (_: Exception) {
            try { engine.language = Locale("ar"); engine.setPitch(1.0f) } catch (_: Exception) { }
        }
    }

    private fun speak(text: String) {
        val clean = text.trim().take(700)
        if (clean.isBlank()) return
        pendingFallbackText = clean
        fallbackAttempted = false
        if (!ttsReady) return
        configureAssistantVoice()
        val quranLike = clean.contains("﴿") || clean.contains("﴾") || clean.contains("سورة ") ||
            (clean.count { it in "ًٌٍَُِّْٰ" } >= 5 && clean.length >= 24)
        val speechText = if (quranLike) clean.replace("﴿", "، ").replace("﴾", "، ").replace("ۖ", "، ").replace("ۗ", "، ") else clean
        // The selected engine controls assistant speech and displayed Quran verses alike.
        // Gender selection applies only to the legacy Android TTS engine.
        val neuralEligible = prefs().getString("assistantVoiceEngine", "neural") == "neural"
        val web = assistantWebView
        if (neuralEligible && web != null && overlayPageReady) {
            try {
                web.evaluateJavascript("(function(){if(window.AlishlahNeuralVoice){window.AlishlahNeuralVoice.speak(" + org.json.JSONObject.quote(speechText) + ");return true;}return false;})()") { result ->
                    if (result != "true") handler.post { speakWithAndroidTts(speechText, quranLike) }
                }
                return
            } catch (_: Exception) { }
        }
        speakWithAndroidTts(speechText, quranLike)
    }

    private fun speakWithAndroidTts(speechText: String, quranLike: Boolean) {
        try {
            tts?.setSpeechRate(if (quranLike) 0.78f else 0.96f)
            tts?.speak(speechText, TextToSpeech.QUEUE_FLUSH, null, "alislah_voice")
        } catch (_: Exception) { retryWithLocalArabicVoice() }
    }

    /** A failed/missing online voice never silences the assistant: retry once with offline Arabic TTS. */
    private fun retryWithLocalArabicVoice() {
        if (fallbackAttempted) return
        val text = pendingFallbackText
        val local = localArabicVoice
        if (text.isBlank() || local == null) return
        fallbackAttempted = true
        try {
            tts?.voice = local
            tts?.setPitch(1.0f)
            val quranLike = text.contains("﴿") || text.contains("﴾") || text.contains("سورة ") ||
                (text.count { it in "ًٌٍَُِّْٰ" } >= 5 && text.length >= 24)
            tts?.setSpeechRate(if (quranLike) 0.78f else 0.96f)
            val speechText = if (quranLike) text.replace("﴿", "، ").replace("﴾", "، ").replace("ۖ", "، ").replace("ۗ", "، ") else text
            tts?.speak(speechText, TextToSpeech.QUEUE_FLUSH, null, "alislah_voice_local_fallback")
        } catch (_: Exception) { }
    }

    private fun speakLatestReply() {
        val web = assistantWebView ?: return
        web.evaluateJavascript("(function(){var x=document.querySelector('#messages .bubble.assistant:last-child');return x?(x.innerText||x.textContent||''):''})()") { raw ->
            val value = try { org.json.JSONTokener(raw ?: "").nextValue() as? String ?: "" } catch (_: Exception) { "" }
            if (value.isNotBlank() && value != lastSpokenReply && !value.contains("أحاول الاتصال")) { lastSpokenReply = value; if (prefs().getString("voiceMode", "both") != "text") speak(value) }
        }
    }

    private fun showCloseButton(anchor: WindowManager.LayoutParams) {
        if (closeButton != null) return
        val size = (38 * resources.displayMetrics.density).toInt()
        val xButton = TextView(this).apply {
            text = "×"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(180, 35, 24))
                setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
            }
            contentDescription = "إغلاق الفقاعة العائمة"
            setOnClickListener {
                getSharedPreferences("alislah_native", MODE_PRIVATE).edit().putBoolean("overlayEnabled", false).apply()
                handler.removeCallbacks(reshowBubble)
                stopSelf()
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val cp = WindowManager.LayoutParams(size, size, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (anchor.x + 42 * resources.displayMetrics.density).toInt()
            y = (anchor.y - 12 * resources.displayMetrics.density).toInt().coerceAtLeast(0)
        }
        try { windowManager.addView(xButton, cp); closeButton = xButton; closeParams = cp } catch (_: Exception) {}
    }

    private fun hideCloseButton() {
        closeButton?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        closeButton = null
        closeParams = null
    }

    /** Draws the same green main bubble as a half-clipped circle at the sides and a top-flush half-capsule when docked above. */
    private inner class MainBubbleView(context: android.content.Context) : View(context) {
        var dockedAtCamera: Boolean = true
        private val fill = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(23, 107, 91)
            style = android.graphics.Paint.Style.FILL
        }
        private val stroke = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(75, 205, 165)
            style = android.graphics.Paint.Style.STROKE
            strokeWidth = (1.5f * resources.displayMetrics.density).coerceAtLeast(1f)
        }
        private val markPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = android.graphics.Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        override fun onDraw(canvas: android.graphics.Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            if (!dockedAtCamera) {
                val r = minOf(w, h) / 2f - stroke.strokeWidth
                canvas.drawCircle(w / 2f, h / 2f, r, fill)
                canvas.drawCircle(w / 2f, h / 2f, r, stroke)
                markPaint.textSize = 25f * resources.displayMetrics.density
                canvas.drawText("✦", w / 2f, h / 2f - (markPaint.ascent() + markPaint.descent()) / 2f, markPaint)
            } else {
                // A top-flush half-capsule: straight edge against the screen, rounded lower corners.
                // It is deliberately not a U/Dynamic-Island cut-out shape.
                val d = resources.displayMetrics.density
                val radius = minOf(h / 2f, 19f * d)
                val path = android.graphics.Path().apply {
                    moveTo(0f, 0f)
                    lineTo(w, 0f)
                    lineTo(w, h - radius)
                    quadTo(w, h, w - radius, h)
                    lineTo(radius, h)
                    quadTo(0f, h, 0f, h - radius)
                    close()
                }
                canvas.drawPath(path, fill)
                canvas.drawPath(path, stroke)
                markPaint.textSize = 16f * d
                canvas.drawText("✦", w / 2f, h * 0.66f - (markPaint.ascent() + markPaint.descent()) / 2f, markPaint)
            }
        }
    }

    /** Physical display bounds, not app-content bounds: status/navigation bars must not shift the camera anchor. */
    private fun realScreenSize(): Pair<Int, Int> {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        return Pair(metrics.widthPixels, metrics.heightPixels)
    }

    private fun cameraCenterX(screenWidth: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                // DisplayCutout coordinates are physical-display coordinates. Pair them with getRealMetrics().
                @Suppress("DEPRECATION")
                val cutout = windowManager.defaultDisplay.cutout
                val rect = cutout?.boundingRects
                    ?.filter { it.width() > 0 && it.height() > 0 }
                    ?.maxByOrNull { it.width() * it.height() }
                if (rect != null) return rect.centerX().coerceIn(0, screenWidth)
            } catch (_: Exception) { }
        }
        // Android 8.0/8.1 and devices without cutout metadata: use the physical screen centre.
        return screenWidth / 2
    }

    private fun showBubble() {
        if (bubble != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        // Use the full physical display so the status bar cannot offset the cutout anchor.
        val (screenW, screenH) = realScreenSize()
        lastBubbleScreenWidth = screenW
        lastBubbleScreenHeight = screenH
        lastDisplayRotation = try { windowManager.defaultDisplay.rotation } catch (_: Exception) { Surface.ROTATION_0 }
        val circleSize = (58 * d).toInt()
        val cameraX = cameraCenterX(screenW)
        val cutoutWidth = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try { windowManager.defaultDisplay.cutout?.boundingRects?.maxByOrNull { it.width() * it.height() }?.width() ?: 0 } catch (_: Exception) { 0 }
        } else 0
        val opening = (cutoutWidth + (24 * d).toInt()).coerceIn((42*d).toInt(), (78*d).toInt())
        val dockWidth = opening + (30 * d).toInt()
        val dockHeight = (52 * d).toInt()
        val view = MainBubbleView(this).apply {
            dockedAtCamera = true
            contentDescription = "فقاعة ALISLAH الخضراء؛ ضغطة للفقاعات الجانبية وضغطتان لفتح التطبيق"
            elevation = 18 * d
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(dockWidth, dockHeight, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = (cameraX - dockWidth / 2).coerceIn(0, (screenW - dockWidth).coerceAtLeast(0))
            y = 0
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragged = false; downAt = System.currentTimeMillis(); startX = lp.x; startY = lp.y; touchX = event.rawX; touchY = event.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt(); val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) dragged = true
                    if (dragged) {
                        pendingMainTap?.let { handler.removeCallbacks(it) }
                        pendingMainTap = null
                        lastTapAt = 0L
                        val (currentW, currentH) = realScreenSize()
                        lp.x = (startX + dx).coerceIn(-(lp.width / 2), currentW - (lp.width / 2))
                        lp.y = (startY + dy).coerceIn(0, (currentH-lp.height).coerceAtLeast(0))
                        try { windowManager.updateViewLayout(v, lp) } catch (_: Exception) {}
                        v.post { if (quickMenu != null) syncQuickMenuToAnchor(lp); syncReminderOverlay(lp); syncAdhanMuteBubble() }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val heldLong = System.currentTimeMillis() - downAt >= 650L
                    if (dragged) {
                        val (currentW, currentH) = realScreenSize()
                        val density = resources.displayMetrics.density
                        val centerX = lp.x + lp.width / 2
                        val topZone = (76 * density).toInt()
                        val targetCameraX = cameraCenterX(currentW)
                        val nearTopCamera = lp.y <= topZone && kotlin.math.abs(centerX - targetCameraX) <= (90 * density).toInt()
                        if (nearTopCamera) {
                            view.dockedAtCamera = true
                            lp.width = dockWidth; lp.height = dockHeight
                            lp.x = (targetCameraX - dockWidth / 2).coerceIn(0, (currentW - dockWidth).coerceAtLeast(0))
                            lp.y = 0
                        } else {
                            view.dockedAtCamera = false
                            lp.width = circleSize; lp.height = circleSize
                            val onLeft = centerX < currentW / 2
                            lp.x = if (onLeft) -(circleSize / 2) else currentW - (circleSize / 2)
                            lp.y = lp.y.coerceIn(0, (currentH-circleSize).coerceAtLeast(0))
                        }
                        v.requestLayout()
                        try { windowManager.updateViewLayout(v, lp) } catch (_: Exception) {}
                        v.post { if (quickMenu != null) syncQuickMenuToAnchor(lp); syncReminderOverlay(lp); syncAdhanMuteBubble() }
                    } else if (heldLong) {
                        pendingMainTap?.let { handler.removeCallbacks(it) }
                        pendingMainTap = null
                        lastTapAt = 0L
                        showQuickMenu(lp)
                    } else {
                        val now = System.currentTimeMillis()
                        val doubleTapWindow = 320L
                        if (lastTapAt != 0L && now - lastTapAt <= doubleTapWindow) {
                            pendingMainTap?.let { handler.removeCallbacks(it) }
                            pendingMainTap = null
                            lastTapAt = 0L
                            hideQuickMenu()
                            openMainApp()
                        } else {
                            lastTapAt = now
                            val singleTap = Runnable {
                                if (lastTapAt == now) {
                                    if (quickMenu != null) hideQuickMenu() else showQuickMenu(lp)
                                    lastTapAt = 0L
                                }
                                pendingMainTap = null
                            }
                            pendingMainTap?.let { handler.removeCallbacks(it) }
                            pendingMainTap = singleTap
                            handler.postDelayed(singleTap, doubleTapWindow)
                        }
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> false
                else -> false
            }
        }
        try { windowManager.addView(view, lp); bubble = view; params = lp; if (adhanPlaying) showAdhanMuteBubble() } catch (_: Exception) { stopSelf() }
    }

    private fun stopAdhanFromBubble() {
        adhanPlaying = false
        bubble?.invalidate()
        hideAdhanMuteBubble()
        try { startService(Intent(this, PrayerVoiceService::class.java).apply { action = PrayerVoiceService.ACTION_STOP }) } catch (_: Exception) { }
    }

    private fun openMainApp() {
        val launch = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        try { startActivity(launch) } catch (_: Exception) { }
    }

    private fun runOverlayJs(script: String) {
        val web = assistantWebView ?: return
        if (overlayPageReady) web.evaluateJavascript(script, null) else pendingOverlayScripts.addLast(script)
    }

    inner class OverlayNativeBridge {
        @JavascriptInterface fun getAppDataJson(): String = prefs().getString("alislah_app_data", "{}") ?: "{}"
        @JavascriptInterface fun saveAppDataJson(json: String) { if (json.length <= 2_000_000) prefs().edit().putString("alislah_app_data", json).apply() }
        @JavascriptInterface fun getEyeBreakContentCache(): String = prefs().getString("eyeBreakContentCache", "{}") ?: "{}"
        @JavascriptInterface fun saveEyeBreakContentCache(json: String) { if (json.length <= 1_000_000) prefs().edit().putString("eyeBreakContentCache", json).apply() }
        @JavascriptInterface fun getUsageStatsJson(): String = readOverlayUsageJson()
        @JavascriptInterface fun setAssistantVoice(gender: String) { prefs().edit().putString("assistantVoiceGender", if (gender == "male") "male" else "female").apply(); handler.post { configureAssistantVoice() } }
        @JavascriptInterface fun setAssistantVoiceEngine(engine: String) { prefs().edit().putString("assistantVoiceEngine", if (engine == "old") "old" else "neural").apply() }
        @JavascriptInterface fun stopAssistantSpeech() { handler.post { assistantWebView?.evaluateJavascript("window.AlishlahNeuralVoice&&window.AlishlahNeuralVoice.stop()", null); stopReminderSpeech() } }
        @JavascriptInterface fun onNeuralSpeechResult(success: Boolean, detail: String) {
            if (!success) handler.post {
                val text = pendingFallbackText
                if (text.isNotBlank()) {
                    val quranLike = text.contains("﴿") || text.contains("﴾") || text.contains("سورة ") ||
                        (text.count { it in "ًٌٍَُِّْٰ" } >= 5 && text.length >= 24)
                    speakWithAndroidTts(if (quranLike) text.replace("﴿", "، ").replace("﴾", "، ").replace("ۖ", "، ").replace("ۗ", "، ") else text, quranLike)
                }
            }
        }
        @JavascriptInterface fun setAssistantVoiceMode(mode: String) { prefs().edit().putString("voiceMode", if (mode == "text" || mode == "voice" || mode == "both") mode else "both").apply() }
        @JavascriptInterface fun testAssistantVoice() { handler.post { speak("مرحبًا بك في الإصلاح. صوت المساعد يعمل الآن.") } }
        @JavascriptInterface fun playAdhanTest() { PrayerScheduler.playAdhan(this@FloatingBubbleService, "اختبار") }
        @JavascriptInterface fun stopAdhan() { handler.post { stopAdhanFromBubble() } }
        @JavascriptInterface fun syncPrayerPlan(itemsJson: String, enabled: Boolean) { PrayerScheduler.sync(this@FloatingBubbleService, itemsJson.take(700000), enabled) }
        @JavascriptInterface fun enableBackgroundQuestions(enabled: Boolean) {
            prefs().edit().putBoolean("backgroundQuestionsEnabled", enabled).putBoolean("backgroundQuestionsConfigured", true).apply()
            if (enabled) BackgroundScheduler.scheduleQuestion(this@FloatingBubbleService, System.currentTimeMillis()+4*60*60*1000L) else BackgroundScheduler.cancelQuestion(this@FloatingBubbleService)
        }
        @JavascriptInterface fun getNativeStatus(): String {
            val notifications = getSystemService(NotificationManager::class.java).areNotificationsEnabled()
            val overlay = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this@FloatingBubbleService)
            val power = getSystemService(android.os.PowerManager::class.java)
            return org.json.JSONObject().put("native", true).put("version", try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (_: Exception) { "" })
                .put("notifications", notifications).put("microphone", checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                .put("overlayEnabled", prefs().getBoolean("overlayEnabled", false)).put("overlayPermission", overlay)
                .put("usage", try { val ops = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager; ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == android.app.AppOpsManager.MODE_ALLOWED } catch (_: Exception) { false })
                .put("battery", power.isIgnoringBatteryOptimizations(packageName)).put("questions", prefs().getBoolean("backgroundQuestionsEnabled", false)).toString()
        }
        @JavascriptInterface fun requestNotificationPermission() { launchMainAppWithAction("requestNotifications") }
        @JavascriptInterface fun openBatterySettings() { handler.post { try { startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { launchMainApp() } } }
        @JavascriptInterface fun openAppSettings() { handler.post { try { startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { launchMainApp() } } }
        @JavascriptInterface fun requestUsagePermission() { handler.post { try { startActivity(Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS).apply { data = android.net.Uri.parse("package:$packageName"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }) } catch (_: Exception) { launchMainApp() } } }
        @JavascriptInterface fun configureEyeBreak(enabled: Boolean, minutes: Int, seconds: Int) {
            prefs().edit().putBoolean("eyeBreakServiceEnabled", enabled).putInt("eyeBreakMinutes", minutes.coerceIn(1,180)).putInt("eyeBreakSeconds", seconds.coerceIn(5,120)).apply()
            handler.post {
                if (!enabled) stopService(Intent(this@FloatingBubbleService, EyeBreakService::class.java))
                else if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this@FloatingBubbleService)) {
                    val i = Intent(this@FloatingBubbleService, EyeBreakService::class.java).putExtra("minutes", minutes).putExtra("seconds", seconds)
                    try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } catch (_: Exception) { launchMainApp() }
                } else launchMainApp()
            }
        }
        @JavascriptInterface fun enableEyeFilter() {
            prefs().edit().putBoolean("eyeFilterEnabled", true).apply()
            handler.post {
                if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this@FloatingBubbleService)) {
                    try { val i = Intent(this@FloatingBubbleService, EyeFilterService::class.java); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } catch (_: Exception) { launchMainApp() }
                } else launchMainApp()
            }
        }
        @JavascriptInterface fun disableEyeFilter() { prefs().edit().putBoolean("eyeFilterEnabled", false).apply(); handler.post { stopService(Intent(this@FloatingBubbleService, EyeFilterService::class.java)) } }
        @JavascriptInterface fun scheduleTaskReminder(id: String, title: String, atMillis: Long) { if (id.isNotBlank()) ReminderStore.schedule(this@FloatingBubbleService, id.take(120), title.take(180), atMillis) }
        @JavascriptInterface fun cancelTaskReminder(id: String) { if (id.isNotBlank()) ReminderStore.cancel(this@FloatingBubbleService, id.take(120)) }
        @JavascriptInterface fun assistantAnswered() {
            handler.post { handler.removeCallbacks(reshowBubble); hideBubble() }
        }
        @JavascriptInterface fun showBubbleForEvent() { handler.post { showBubble() } }
        @JavascriptInterface fun isSpeechAvailable(): Boolean = android.speech.SpeechRecognizer.isRecognitionAvailable(this@FloatingBubbleService)
        @JavascriptInterface fun startListening() { launchMainAppWithAction("startListening") }
        @JavascriptInterface fun stopListening() { launchMainAppWithAction("stopListening") }
        @JavascriptInterface fun requestRuntimePermissions() { launchMainAppWithAction("requestRuntimePermissions") }
        @JavascriptInterface fun enableOverlay() { prefs().edit().putBoolean("overlayEnabled", true).apply(); handler.post { showBubble() } }
        @JavascriptInterface fun disableOverlay() { prefs().edit().putBoolean("overlayEnabled", false).apply(); stopSelf() }
        @JavascriptInterface fun saveBackup(filename: String, json: String) {
            if (json.length > 5_000_000) return
            prefs().edit().putString("overlay_backup_pending", json).putString("overlay_backup_name", filename.take(80)).apply()
            launchMainAppWithAction("saveBackup")
        }
    }

    private fun launchMainAppWithAction(action: String) {
        handler.post {
            val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("overlayBridgeAction", action)
            try { startActivity(intent) } catch (_: Exception) { }
        }
    }

    private fun launchMainApp() {
        val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try { startActivity(intent) } catch (_: Exception) { }
    }

    private fun readOverlayUsageJson(): String {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        val allowed = appOps.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == android.app.AppOpsManager.MODE_ALLOWED
        val result = org.json.JSONObject().put("permission", allowed)
        val apps = org.json.JSONArray()
        if (allowed) {
            try {
                val manager = getSystemService(Context.USAGE_STATS_SERVICE) as android.app.usage.UsageStatsManager
                val calendar = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY,0); set(java.util.Calendar.MINUTE,0); set(java.util.Calendar.SECOND,0); set(java.util.Calendar.MILLISECOND,0) }
                val stats: List<android.app.usage.UsageStats> = manager.queryAndAggregateUsageStats(calendar.timeInMillis, System.currentTimeMillis())?.values?.toList() ?: emptyList()
                val grouped = stats.filter { it.totalTimeInForeground > 0 && it.packageName != packageName }
                    .groupBy { it.packageName }.map { (pkg, rows) -> pkg to rows.sumOf { it.totalTimeInForeground } }
                    .sortedByDescending { it.second }.take(20)
                for ((pkg, millis) in grouped) {
                    val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg,0)).toString() } catch (_: Exception) { pkg }
                    apps.put(org.json.JSONObject().put("packageName",pkg).put("name",label).put("minutes",(millis/60000.0).toInt()))
                }
            } catch (_: Exception) { }
        }
        return result.put("apps",apps).put("foreground",org.json.JSONObject().put("name","غير متاح").put("packageName","").put("approximate",true)).put("collectedAt",System.currentTimeMillis()).toString()
    }

    private fun showAssistantOverlay(command: String = "ask") {
        lastSpokenReply = ""
        if (assistantPanel != null) {
            assistantPanel?.visibility = View.VISIBLE
            if (activeOverlayCommand != command) {
                activeOverlayCommand = command
                // Keep the same WebView alive: switching side bubbles changes the view in-place,
                // avoiding a destroyed/recreated window, white flash, and overlapping overlays.
                val root = assistantPanel as? LinearLayout
                (root?.getChildAt(0) as? LinearLayout)?.let { bar ->
                    (bar.getChildAt(0) as? TextView)?.text = when (command) {
                        "prayer" -> "ALISLAH · الصلاة والأذان"
                        "plan" -> "ALISLAH · المهام والخطة"
                        "behavior" -> "ALISLAH · تحليل العادات"
                        "habits" -> "ALISLAH · العادات"
                        "family" -> "ALISLAH · الأسرة"
                        "settings" -> "ALISLAH · الإعدادات"
                        "voice" -> "ALISLAH · صوت المساعد"
                        "eye" -> "ALISLAH · راحة العين"
                        else -> "ALISLAH · المساعد الذكي"
                    }
                }
                // The ribbon belongs to the previous panel; hide it rather than show stale actions.
                root?.getChildAt(1)?.visibility = View.GONE
                val target = overlayTargetFor(command)
                runOverlayJs("window.__alislahOverlayTarget='$target';if(typeof tab==='function')tab('$target');else document.querySelectorAll('.view').forEach(x=>x.classList.toggle('active',x.id==='$target'))")
                handler.removeCallbacks(pollReply)
                if (target == "assistant") handler.postDelayed(pollReply, 700L)
            }
            if (command == "question") speak("ما أكثر شيء يشغل وقتك الآن؟")
            selectOverlaySection(command)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("openAssistant", true)
            }
            startActivity(launch)
            return
        }
        val density = resources.displayMetrics.density
        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val panelWidth = (screenWidth - 82 * density).toInt().coerceAtLeast((245 * density).toInt())
        val panelHeight = (screenHeight * 0.72f).toInt().coerceAtMost((screenHeight - 28 * density).toInt()).coerceAtLeast((360 * density).toInt())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            elevation = 18 * density
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = 18 * density
                setStroke((1 * density).toInt(), Color.rgb(220, 231, 226))
            }
            clipToOutline = true
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((12*density).toInt(), (5*density).toInt(), (8*density).toInt(), (5*density).toInt())
            setBackgroundColor(Color.rgb(23, 107, 91))
        }
        val title = TextView(this).apply {
            text = "ALISLAH · اسألي هنا"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, (44*density).toInt(), 1f)
        }
        val close = TextView(this).apply {
            text = "×"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = "إغلاق نافذة المساعد"
            layoutParams = LinearLayout.LayoutParams((44*density).toInt(), (44*density).toInt())
            setOnClickListener { hideAssistantOverlay() }
        }
        bar.addView(title); bar.addView(close); root.addView(bar)
        // A distinct tool ribbon belongs to the selected side bubble; the circular bubble layout remains unchanged.
        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((7*density).toInt(), (6*density).toInt(), (7*density).toInt(), (6*density).toInt())
            setBackgroundColor(Color.rgb(231, 242, 237))
        }
        fun addTool(label: String, js: String) {
            val button = TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(20, 91, 76))
                setPadding((8*density).toInt(), (8*density).toInt(), (8*density).toInt(), (8*density).toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.WHITE); cornerRadius = 11*density
                    setStroke((1*density).toInt(), Color.rgb(195, 219, 208))
                }
                setOnClickListener { runOverlayJs(js) }
            }
            tools.addView(button, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = (3*density).toInt(); marginEnd = (3*density).toInt()
            })
        }
        when (command) {
            "prayer" -> {
                title.text = "ALISLAH · الصلاة والأذان"
                addTool("تحديث المواقيت", "document.getElementById('prayerRefresh')?.click()")
                addTool("تشغيل/إيقاف الصوت", "document.getElementById('prayerAdhanEnabled')?.click()")
                addTool("اختبار الصوت", "document.getElementById('prayerAdhanTest')?.click()")
            }
            "plan" -> {
                title.text = "ALISLAH · المهام والخطة"
                addTool("المهام", "if(typeof tab==='function')tab('tasks')")
                addTool("إضافة مهمة", "document.getElementById('taskText')?.focus()")
                addTool("المساعد", "if(typeof tab==='function')tab('assistant')")
            }
            "behavior" -> {
                title.text = "ALISLAH · تحليل العادات"
                addTool("تحليل الآن", "document.getElementById('analyzeBehavior')?.click()")
                addTool("العادات", "if(typeof tab==='function')tab('habits')")
            }
            "habits" -> {
                title.text = "ALISLAH · العادات"
                addTool("إضافة عادة", "document.getElementById('habitText')?.focus()")
                addTool("تحليل", "if(typeof tab==='function')tab('behavior')")
            }
            "family" -> {
                title.text = "ALISLAH · الأسرة"
                addTool("المساعد", "if(typeof tab==='function')tab('assistant')")
                addTool("المهام", "if(typeof tab==='function')tab('tasks')")
            }
            "settings" -> {
                title.text = "ALISLAH · الإعدادات"
                addTool("حفظ الإعدادات", "document.getElementById('saveSettings')?.click()")
                addTool("الصلاة", "if(typeof tab==='function')tab('prayer')")
            }
            else -> {
                title.text = "ALISLAH · المساعد الذكي"
                addTool("سؤال جديد", "document.getElementById('chatText')?.focus()")
                addTool("الخطة", "if(typeof tab==='function')tab('tasks')")
                addTool("تحليل", "if(typeof tab==='function')tab('behavior')")
            }
        }
        root.addView(tools)
        overlayPageReady = false
        pendingOverlayScripts.clear()
        val web = WebView(this).apply {
            addJavascriptInterface(OverlayNativeBridge(), "AndroidUsage")
            addJavascriptInterface(object {
                @JavascriptInterface fun getAppDataJson(): String = prefs().getString("alislah_app_data", "{}") ?: "{}"
                @JavascriptInterface fun getEyeBreakContentCache(): String = prefs().getString("eyeBreakContentCache", "{}") ?: "{}"
                @JavascriptInterface fun saveAppDataJson(json: String) { if (json.length <= 2_000_000) prefs().edit().putString("alislah_app_data", json).apply() }
                @JavascriptInterface fun saveEyeBreakContentCache(json: String) { if (json.length <= 1_000_000) prefs().edit().putString("eyeBreakContentCache", json).apply() }
            }, "ALISLAHStore")
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    val hasAudio = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    if (hasAudio && request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else request.deny()
                }
            }
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    val script = """(function(){
                      document.querySelector('header.top')?.style.setProperty('display','none','important');
                      document.querySelector('.hero')?.style.setProperty('display','none','important');
                      document.querySelector('.stats')?.style.setProperty('display','none','important');
                      document.querySelector('.tabs')?.style.setProperty('display','none','important');
                      const target = window.__alislahOverlayTarget || 'assistant';
                      document.querySelectorAll('.view').forEach(x=>x.classList.toggle('active',x.id===target));
                      document.querySelectorAll('#alislahFloat,#alislahCheckin,.footer,#nativeOverlayControls').forEach(x=>x.style.display='none');
                      const app=document.querySelector('.app'); if(app){app.style.cssText='padding:0;margin:0;max-width:none;width:100%;';}
                      const chat=document.querySelector('#assistant .chat'); if(chat){chat.style.cssText='min-height:0;height:auto;padding:5px;margin:0;';}
                      const msgs=document.getElementById('messages'); if(msgs){msgs.style.cssText='min-height:45px;max-height:105px;overflow-y:auto;padding:5px;margin:0;';}
                      const form=document.getElementById('chatForm'); if(form){form.style.cssText='display:flex;gap:5px;margin:5px 0 0;';}
                      const input=document.getElementById('chatText'); if(input){input.placeholder='اكتبي سؤالك هنا…';input.style.minHeight='38px';}
                      const consent=document.getElementById('chatConsentWrap'); if(consent) consent.style.display='none';
                      const panel=document.getElementById(target); if(panel){panel.style.setProperty('margin','0','important');panel.style.setProperty('padding','8px','important');panel.style.setProperty('overflow-y','auto','important');}
                      document.body.style.cssText='margin:0;padding:0;background:#f3f7f5;overflow-y:auto;overflow-x:hidden;';
                      document.documentElement.style.cssText='height:100%;overflow:auto;';
                    })();"""
                    val loadedView = view ?: return
                    loadedView.evaluateJavascript(script) {
                        overlayPageReady = true
                        while (pendingOverlayScripts.isNotEmpty()) {
                            val next = pendingOverlayScripts.removeFirst()
                            loadedView.evaluateJavascript(next, null)
                        }
                    }
                }
            }
        }
        assistantWebView = web
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val anchor = params
        val lp = WindowManager.LayoutParams(panelWidth, panelHeight, type, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (anchor?.x ?: 10).coerceAtMost((screenWidth - panelWidth).coerceAtLeast(0))
            y = ((anchor?.y ?: (screenHeight/3)) + (70*density).toInt()).coerceAtMost((screenHeight-panelHeight).coerceAtLeast(0))
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        try {
            windowManager.addView(root, lp)
            assistantPanel = root
            activeOverlayCommand = command
            val target = when(command) {
                "settings" -> "settings"
                "behavior" -> "behavior"
                "plan" -> "tasks"
                "family" -> "family"
                "prayer" -> "prayer"
                "habits" -> "habits"
                "eye" -> "settings"
                "voice" -> "assistant"
                else -> "assistant"
            }
            web.loadUrl("file:///android_asset/index.html")
            web.postVisualStateCallback(0L, object : WebView.VisualStateCallback() {
                override fun onComplete(requestId: Long) {
                    runOverlayJs("window.__alislahOverlayTarget='$target';if(typeof tab==='function'){tab('$target')}else{document.querySelectorAll('.view').forEach(x=>x.classList.toggle('active',x.id==='$target'))}")
                    if (target == "assistant") { handler.removeCallbacks(pollReply); handler.postDelayed(pollReply, 2500L) }
                    selectOverlaySection(command)
                }
            })
        } catch (_: Exception) {
            assistantPanel = null
            assistantWebView = null
            activeOverlayCommand = null
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("openAssistant", true)
            }
            startActivity(launch)
        }
    }

    private fun overlayTargetFor(command: String): String = when (command) {
        "settings", "eye" -> "settings"
        "behavior" -> "behavior"
        "plan" -> "tasks"
        "family" -> "family"
        "prayer" -> "prayer"
        "habits" -> "habits"
        "voice", "question", "ask" -> "assistant"
        else -> "assistant"
    }

    private fun selectOverlaySection(command: String) {
        val js = when(command) {
            "settings" -> "if(typeof tab==='function')tab('settings');else document.querySelector('[data-tab=\"settings\"]')?.click();"
            "behavior" -> "if(typeof tab==='function')tab('behavior');else document.querySelector('[data-tab=\"behavior\"]')?.click();"
            "plan" -> "if(typeof tab==='function')tab('tasks');else document.querySelector('[data-tab=\"tasks\"]')?.click();"
            "family" -> "if(typeof tab==='function')tab('family');else document.querySelector('[data-tab=\"family\"]')?.click();"
            "prayer" -> "if(typeof tab==='function')tab('prayer');else document.querySelector('[data-tab=\"prayer\"]')?.click();"
            "habits" -> "if(typeof tab==='function')tab('habits');else document.querySelector('[data-tab=\"habits\"]')?.click();"
            "eye" -> "if(typeof tab==='function')tab('settings');else document.querySelector('[data-tab=\"settings\"]')?.click();setTimeout(()=>document.getElementById('eyeBreakEnabled')?.scrollIntoView({block:'center'}),180);"
            "voice" -> "if(typeof tab==='function')tab('assistant');else document.querySelector('[data-tab=\"assistant\"]')?.click();setTimeout(()=>document.getElementById('alislahVoiceGender')?.scrollIntoView({block:'center'}),180);"
            "question" -> "if(typeof tab==='function')tab('assistant');var q=document.getElementById('chatText');if(q){q.value='سؤال سريع: ما أكثر شيء يشغل وقتك الآن؟';q.focus();}"
            else -> "if(typeof tab==='function')tab('assistant');else document.querySelector('[data-tab=\"assistant\"]')?.click();document.getElementById('chatText')?.focus();"
        }
        runOverlayJs(js)
    }

    private fun hideAssistantOverlay() {
        handler.removeCallbacks(pollReply)
        overlayPageReady = false
        pendingOverlayScripts.clear()
        assistantWebView?.stopLoading()
        assistantWebView?.destroy()
        assistantWebView = null
        assistantPanel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        assistantPanel = null
        activeOverlayCommand = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel("alislah_bubble", "فقاعة ALISLAH", NotificationManager.IMPORTANCE_LOW).apply { description = "إبقاء الفقاعة العائمة متاحة فوق التطبيقات" })
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "alislah_bubble").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("فقاعة ALISLAH مفعّلة").setContentText("ضغطة لإظهار الفقاعات الجانبية، وضغطتان لفتح التطبيق").setContentIntent(open).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("فقاعة ALISLAH مفعّلة").setContentText("ضغطة لإظهار الفقاعات الجانبية، وضغطتان لفتح التطبيق").setContentIntent(open).setOngoing(true).build()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val main = bubble ?: return
        val lp = params ?: return
        val wasMenuVisible = quickMenu != null
        val openCommand = activeOverlayCommand
        hideQuickMenu()

        val d = resources.displayMetrics.density
        val (newW, newH) = realScreenSize()
        val oldW = lastBubbleScreenWidth.takeIf { it > 0 } ?: newW
        val oldH = lastBubbleScreenHeight.takeIf { it > 0 } ?: newH
        val oldCenterX = (lp.x + lp.width / 2f).coerceIn(0f, oldW.toFloat())
        val oldCenterY = (lp.y + lp.height / 2f).coerceIn(0f, oldH.toFloat())
        val xRatio = if (oldW > 0) oldCenterX / oldW else 0.5f
        val yRatio = if (oldH > 0) oldCenterY / oldH else 0.5f

        // Rotate the old physical position by the actual display-rotation delta before choosing an edge.
        val newRotation = try { windowManager.defaultDisplay.rotation } catch (_: Exception) { lastDisplayRotation }
        val rotationDelta = (newRotation - lastDisplayRotation + 4) % 4
        val mappedRatios = when (rotationDelta) {
            1 -> Pair(1f - yRatio, xRatio)       // 90 degrees clockwise
            2 -> Pair(1f - xRatio, 1f - yRatio)  // 180 degrees
            3 -> Pair(yRatio, 1f - xRatio)       // 270 degrees clockwise
            else -> Pair(xRatio, yRatio)
        }
        val mappedX = mappedRatios.first * newW
        val mappedY = mappedRatios.second * newH
        lastDisplayRotation = newRotation
        val circleSize = (58 * d).toInt()
        val edgeLeft = mappedX
        val edgeRight = newW - mappedX
        val edgeTop = mappedY
        val edgeBottom = newH - mappedY
        val nearest = listOf("left" to edgeLeft, "right" to edgeRight, "top" to edgeTop, "bottom" to edgeBottom).minByOrNull { it.second }?.first ?: "left"
        val mainView = main as? MainBubbleView
        val cutoutWidth = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try { windowManager.defaultDisplay.cutout?.boundingRects?.filter { it.width() > 0 && it.height() > 0 }?.maxByOrNull { it.width() * it.height() }?.width() ?: 0 } catch (_: Exception) { 0 }
        } else 0
        val canDockAtTop = nearest == "top" && newConfig.orientation == Configuration.ORIENTATION_PORTRAIT && cutoutWidth > 0

        if (canDockAtTop && mainView != null) {
            mainView.dockedAtCamera = true
            val opening = (cutoutWidth + (24 * d).toInt()).coerceIn((42 * d).toInt(), (78 * d).toInt())
            lp.width = opening + (30 * d).toInt()
            lp.height = (52 * d).toInt()
            lp.x = (cameraCenterX(newW) - lp.width / 2).coerceIn(0, (newW - lp.width).coerceAtLeast(0))
            lp.y = 0
        } else {
            mainView?.dockedAtCamera = false
            lp.width = circleSize
            lp.height = circleSize
            when (nearest) {
                "left" -> { lp.x = -(circleSize / 2); lp.y = (mappedY - circleSize / 2).toInt().coerceIn(0, (newH - circleSize).coerceAtLeast(0)) }
                "right" -> { lp.x = newW - circleSize / 2; lp.y = (mappedY - circleSize / 2).toInt().coerceIn(0, (newH - circleSize).coerceAtLeast(0)) }
                "top" -> { lp.x = (mappedX - circleSize / 2).toInt().coerceIn(0, (newW - circleSize).coerceAtLeast(0)); lp.y = -(circleSize / 2) }
                else -> { lp.x = (mappedX - circleSize / 2).toInt().coerceIn(0, (newW - circleSize).coerceAtLeast(0)); lp.y = newH - circleSize / 2 }
            }
        }
        lastBubbleScreenWidth = newW
        lastBubbleScreenHeight = newH
        try { windowManager.updateViewLayout(main, lp) } catch (_: Exception) { }
        main.invalidate()
        syncReminderOverlay(lp)
        syncAdhanMuteBubble()
        if (wasMenuVisible) showQuickMenu(lp)
        if (openCommand != null) {
            val panel = assistantPanel
            val panelLp = panel?.layoutParams as? WindowManager.LayoutParams
            if (panel != null && panelLp != null) {
                panelLp.width = (newW - 82 * d).toInt().coerceAtLeast((245 * d).toInt())
                panelLp.height = (newH * 0.72f).toInt().coerceAtMost((newH - 28 * d).toInt()).coerceAtLeast((300 * d).toInt())
                panelLp.x = (lp.x + lp.width / 2 - panelLp.width / 2).coerceIn(0, (newW - panelLp.width).coerceAtLeast(0))
                panelLp.y = (lp.y + lp.height / 2 + (18 * d).toInt()).coerceIn(0, (newH - panelLp.height).coerceAtLeast(0))
                try { windowManager.updateViewLayout(panel, panelLp) } catch (_: Exception) { }
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(reshowBubble)
        handler.removeCallbacks(pollReply)
        pendingMainTap?.let { handler.removeCallbacks(it) }
        pendingMainTap = null
        hideCloseButton()
        hideQuickMenu()
        hideReminderViews()
        hideAdhanMuteBubble()
        hideAssistantOverlay()
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_ANSWERED = "dz.alislah.app.ACTION_ASSISTANT_ANSWERED"
        const val ACTION_SHOW_FOR_EVENT = "dz.alislah.app.ACTION_SHOW_BUBBLE_FOR_EVENT"
        const val ACTION_HIDE_PANEL = "dz.alislah.app.ACTION_HIDE_PANEL"
        const val ACTION_SPEAK_TEST = "dz.alislah.app.ACTION_SPEAK_TEST"
        const val ACTION_SPEAK_TEXT = "dz.alislah.app.ACTION_SPEAK_TEXT"
        const val ACTION_STOP_SPEECH = "dz.alislah.app.ACTION_STOP_SPEECH"
        const val ACTION_ADHAN_STARTED = "dz.alislah.app.ACTION_ADHAN_STARTED"
        const val ACTION_ADHAN_STOPPED = "dz.alislah.app.ACTION_ADHAN_STOPPED"
        const val ACTION_SHOW_REMINDER = "dz.alislah.app.ACTION_SHOW_PRAYER_REMINDER"
        const val EXTRA_REMINDER_TITLE = "reminder_title"
        const val EXTRA_REMINDER_TEXT = "reminder_text"
        const val EXTRA_SPEAK_TEXT = "speak_text"
    }
}
