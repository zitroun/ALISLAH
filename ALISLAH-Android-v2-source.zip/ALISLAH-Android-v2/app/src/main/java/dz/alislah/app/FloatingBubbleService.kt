package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.PermissionRequest
import android.Manifest
import android.content.pm.PackageManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.view.WindowManager
import android.widget.TextView
import android.speech.tts.TextToSpeech
import java.util.Locale

class FloatingBubbleService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f
    private var dragged = false
    private var downAt = 0L
    private var lastTapAt = 0L
    private var closeButton: TextView? = null
    private var closeParams: WindowManager.LayoutParams? = null
    private var quickMenu: View? = null
    private var tts: TextToSpeech? = null
    private var lastSpokenReply = ""
    private val pollReply = object : Runnable { override fun run() { speakLatestReply(); if (assistantPanel != null) handler.postDelayed(this, 1800L) } }
    private var assistantPanel: View? = null
    private var assistantWebView: WebView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val reshowBubble = Runnable { showBubble() }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ar") }
        startForeground(4107, buildNotification())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) showBubble() else stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ANSWERED -> {
                handler.removeCallbacks(reshowBubble)
                hideBubble()
            }
            ACTION_SHOW_FOR_EVENT -> {
                handler.removeCallbacks(reshowBubble)
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) showBubble()
            }
            else -> if (bubble == null && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))) showBubble()
        }
        return START_STICKY
    }

    private fun hideBubble() {
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        params = null
        hideCloseButton()
        hideQuickMenu()
    }

    private fun hideQuickMenu() {
        quickMenu?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        quickMenu = null
    }

    private fun showQuickMenu(anchor: WindowManager.LayoutParams) {
        if (quickMenu != null) { hideQuickMenu(); return }
        val d = resources.displayMetrics.density
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val orbit = (224 * d).toInt()
        val item = (52 * d).toInt()
        val menu = FrameLayout(this).apply { elevation = 24 * d }

        data class BubbleAction(val icon: String, val label: String, val command: String, val color: Int)
        val actions = listOf(
            BubbleAction("💬", "المساعد", "ask", Color.rgb(23,107,91)),
            BubbleAction("📋", "الخطة", "plan", Color.rgb(43,112,190)),
            BubbleAction("📊", "التحليل", "behavior", Color.rgb(117,76,175)),
            BubbleAction("⚙", "الإعدادات", "settings", Color.rgb(82,98,105)),
            BubbleAction("👨‍👩‍👧", "الأسرة", "family", Color.rgb(190,117,47)),
            BubbleAction("🕌", "الصلاة", "prayer", Color.rgb(16,130,100)),
            BubbleAction("✓", "العادات", "habits", Color.rgb(40,130,145)),
            BubbleAction("✕", "إغلاق", "close", Color.rgb(190,55,55))
        )
        val radius = (74 * d).toInt()
        actions.forEachIndexed { index, a ->
            val b = TextView(this).apply {
                text = a.icon
                textSize = 21f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                contentDescription = a.label
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(a.color)
                    setStroke((2*d).toInt(), Color.WHITE)
                }
                elevation = 8*d
                setOnClickListener {
                    hideQuickMenu()
                    if (a.command == "close") {
                        prefs().edit().putBoolean("overlayEnabled", false).apply()
                        stopSelf()
                    } else showAssistantOverlay(a.command)
                }
            }
            val angle = (-Math.PI / 2.0) + (2.0 * Math.PI * index / actions.size)
            val center = orbit / 2
            val left = (center + radius * kotlin.math.cos(angle) - item / 2).toInt().coerceIn(0, orbit-item)
            val top = (center + radius * kotlin.math.sin(angle) - item / 2).toInt().coerceIn(0, orbit-item)
            menu.addView(b, FrameLayout.LayoutParams(item, item).apply {
                leftMargin = left
                topMargin = top
            })
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val x = (anchor.x + anchor.width/2 - orbit/2).coerceIn(0, (screenW-orbit).coerceAtLeast(0))
        val y = (anchor.y + anchor.height/2 - orbit/2).coerceIn(0, (screenH-orbit).coerceAtLeast(0))
        val lp = WindowManager.LayoutParams(orbit, orbit, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }
        try { windowManager.addView(menu, lp); quickMenu = menu } catch (_: Exception) {}
    }

    private fun prefs() = getSharedPreferences("alislah_native", MODE_PRIVATE)

    private fun speak(text: String) {
        val clean = text.trim().take(700)
        if (clean.isNotBlank()) tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "alislah_voice")
    }

    private fun speakLatestReply() {
        val web = assistantWebView ?: return
        web.evaluateJavascript("(function(){var x=document.querySelector('#messages .bubble.assistant:last-child');return x?(x.innerText||x.textContent||''):''})()") { raw ->
            val value = try { org.json.JSONTokener(raw ?: "").nextValue() as? String ?: "" } catch (_: Exception) { "" }
            if (value.isNotBlank() && value != lastSpokenReply && !value.contains("أحاول الاتصال")) { lastSpokenReply = value; if (prefs().getString("voiceMode", "both") != "text") speak(value) }
        }
    }

    private fun showCloseButton(anchor: WindowManager.LayoutParams) {
        if (closeButton != null) return
        val size = (38 * resources.displayMetrics.density).toInt()
        val xButton = TextView(this).apply {
            text = "×"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(180, 35, 24))
                setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
            }
            contentDescription = "إغلاق الفقاعة العائمة"
            setOnClickListener {
                getSharedPreferences("alislah_native", MODE_PRIVATE).edit().putBoolean("overlayEnabled", false).apply()
                handler.removeCallbacks(reshowBubble)
                stopSelf()
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val cp = WindowManager.LayoutParams(size, size, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (anchor.x + 42 * resources.displayMetrics.density).toInt()
            y = (anchor.y - 12 * resources.displayMetrics.density).toInt().coerceAtLeast(0)
        }
        try { windowManager.addView(xButton, cp); closeButton = xButton; closeParams = cp } catch (_: Exception) {}
    }

    private fun hideCloseButton() {
        closeButton?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        closeButton = null
        closeParams = null
    }

    private fun showBubble() {
        if (bubble != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = (58 * resources.displayMetrics.density).toInt()
        val view = TextView(this).apply {
            text = "✦"
            textSize = 23f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(23, 107, 91))
            elevation = 12f
            contentDescription = "فقاعة ALISLAH العائمة؛ اضغطي لفتح المساعد"
            // Rounded drawable without external assets.
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(23, 107, 91))
                setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(size, size, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (12 * resources.displayMetrics.density).toInt()
            y = (220 * resources.displayMetrics.density).toInt()
        }
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragged = false; downAt = System.currentTimeMillis(); startX = lp.x; startY = lp.y; touchX = event.rawX; touchY = event.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt(); val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 6 || kotlin.math.abs(dy) > 6) dragged = true
                    lp.x = startX + dx; lp.y = startY + dy
                    try { windowManager.updateViewLayout(v, lp) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val heldLong = System.currentTimeMillis() - downAt >= 650L
                    if (!dragged && heldLong) {
                        showQuickMenu(lp)
                    } else if (!dragged) {
                        val now = System.currentTimeMillis()
                        if (now - lastTapAt in 1..360) {
                            lastTapAt = 0L
                            hideQuickMenu()
                            hideAssistantOverlay()
                            val launch = Intent(this, MainActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                            }
                            startActivity(launch)
                        } else {
                            lastTapAt = now
                            handler.postDelayed({ if (lastTapAt == now) showAssistantOverlay() }, 370L)
                        }
                    }
                    true
                }
                else -> false
            }
        }
        try { windowManager.addView(view, lp); bubble = view; params = lp } catch (_: Exception) { stopSelf() }
    }

    private fun showAssistantOverlay(command: String = "ask") {
        if (assistantPanel != null) {
            assistantPanel?.visibility = View.VISIBLE
            if (command == "question") speak("ما أكثر شيء يشغل وقتك الآن؟")
            selectOverlaySection(command)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("openAssistant", true)
            }
            startActivity(launch)
            return
        }
        val density = resources.displayMetrics.density
        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val panelWidth = (screenWidth - 82 * density).toInt().coerceAtLeast((245 * density).toInt())
        val panelHeight = (250 * density).toInt().coerceAtMost((screenHeight * 0.42f).toInt())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            elevation = 18 * density
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = 18 * density
                setStroke((1 * density).toInt(), Color.rgb(220, 231, 226))
            }
            clipToOutline = true
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((12*density).toInt(), (5*density).toInt(), (8*density).toInt(), (5*density).toInt())
            setBackgroundColor(Color.rgb(23, 107, 91))
        }
        val title = TextView(this).apply {
            text = "ALISLAH · اسألي هنا"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, (44*density).toInt(), 1f)
        }
        val close = TextView(this).apply {
            text = "×"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = "إغلاق نافذة المساعد"
            layoutParams = LinearLayout.LayoutParams((44*density).toInt(), (44*density).toInt())
            setOnClickListener { hideAssistantOverlay() }
        }
        bar.addView(title); bar.addView(close); root.addView(bar)
        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    val hasAudio = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    if (hasAudio && request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else request.deny()
                }
            }
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    val script = """(function(){
                      document.querySelector('header.top')?.style.setProperty('display','none','important');
                      document.querySelector('.hero')?.style.setProperty('display','none','important');
                      document.querySelector('.stats')?.style.setProperty('display','none','important');
                      document.querySelector('.tabs')?.style.setProperty('display','none','important');
                      const target = window.__alislahOverlayTarget || 'assistant';
                      document.querySelectorAll('.view').forEach(x=>{const show=x.id===target;x.classList.toggle('active',show);x.style.display=show?'block':'none'});
                      document.querySelectorAll('#alislahFloat,#alislahCheckin,.footer,#nativeOverlayControls').forEach(x=>x.style.display='none');
                      const app=document.querySelector('.app'); if(app){app.style.cssText='padding:0;margin:0;max-width:none;width:100%;';}
                      const chat=document.querySelector('#assistant .chat'); if(chat){chat.style.cssText='min-height:0;height:auto;padding:5px;margin:0;';}
                      const msgs=document.getElementById('messages'); if(msgs){msgs.style.cssText='min-height:45px;max-height:105px;overflow-y:auto;padding:5px;margin:0;';}
                      const form=document.getElementById('chatForm'); if(form){form.style.cssText='display:flex;gap:5px;margin:5px 0 0;';}
                      const input=document.getElementById('chatText'); if(input){input.placeholder='اكتبي سؤالك هنا…';input.style.minHeight='38px';}
                      const consent=document.getElementById('chatConsentWrap'); if(consent) consent.style.display='none';
                      const panel=document.querySelector('#assistant'); if(panel){panel.style.cssText='display:block;margin:0;padding:0;';}
                      document.body.style.cssText='margin:0;padding:0;background:#f3f7f5;overflow:hidden;';
                    })();"""
                    view?.evaluateJavascript(script, null)
                }
            }
        }
        assistantWebView = web
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val anchor = params
        val lp = WindowManager.LayoutParams(panelWidth, panelHeight, type, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (anchor?.x ?: 10).coerceAtMost((screenWidth - panelWidth).coerceAtLeast(0))
            y = ((anchor?.y ?: (screenHeight/3)) + (70*density).toInt()).coerceAtMost((screenHeight-panelHeight).coerceAtLeast(0))
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        try {
            windowManager.addView(root, lp)
            assistantPanel = root
            val target = when(command) {
                "settings" -> "settings"
                "behavior" -> "behavior"
                "plan" -> "tasks"
                "family" -> "family"
                "prayer" -> "prayer"
                "habits" -> "habits"
                else -> "assistant"
            }
            web.loadUrl("file:///android_asset/index.html")
            web.postVisualStateCallback(0L, object : WebView.VisualStateCallback() {
                override fun onComplete(requestId: Long) {
                    web.evaluateJavascript("window.__alislahOverlayTarget='$target';document.querySelectorAll('.view').forEach(x=>{const show=x.id==='$target';x.classList.toggle('active',show);x.style.display=show?'block':'none'});", null)
                    if (target == "assistant") { handler.removeCallbacks(pollReply); handler.postDelayed(pollReply, 2500L) }
                    selectOverlaySection(command)
                }
            })
        } catch (_: Exception) {
            assistantPanel = null
            assistantWebView = null
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("openAssistant", true)
            }
            startActivity(launch)
        }
    }

    private fun selectOverlaySection(command: String) {
        val js = when(command) {
            "settings" -> "document.querySelector('[data-tab=\"settings\"]')?.click();"
            "behavior" -> "document.querySelector('[data-tab=\"behavior\"]')?.click();"
            "plan" -> "document.querySelector('[data-tab=\"tasks\"]')?.click();"
            "family" -> "document.querySelector('[data-tab=\"family\"]')?.click();"
            "question" -> "var q=document.getElementById('chatText');if(q){q.value='سؤال سريع: ما أكثر شيء يشغل وقتك الآن؟';q.focus();}"
            else -> "document.querySelector('[data-tab=\"assistant\"]')?.click();document.getElementById('chatText')?.focus();"
        }
        assistantWebView?.evaluateJavascript(js, null)
    }

    private fun hideAssistantOverlay() {
        handler.removeCallbacks(pollReply)
        assistantWebView?.stopLoading()
        assistantWebView?.destroy()
        assistantWebView = null
        assistantPanel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        assistantPanel = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel("alislah_bubble", "فقاعة ALISLAH", NotificationManager.IMPORTANCE_LOW).apply { description = "إبقاء الفقاعة العائمة متاحة فوق التطبيقات" })
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "alislah_bubble").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("فقاعة ALISLAH مفعّلة").setContentText("اضغطي على الفقاعة لفتح المساعد الذكي").setContentIntent(open).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("فقاعة ALISLAH مفعّلة").setContentText("اضغطي على الفقاعة لفتح المساعد الذكي").setContentIntent(open).setOngoing(true).build()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(reshowBubble)
        handler.removeCallbacks(pollReply)
        hideCloseButton()
        hideQuickMenu()
        hideAssistantOverlay()
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_ANSWERED = "dz.alislah.app.ACTION_ASSISTANT_ANSWERED"
        const val ACTION_SHOW_FOR_EVENT = "dz.alislah.app.ACTION_SHOW_BUBBLE_FOR_EVENT"
    }
}
