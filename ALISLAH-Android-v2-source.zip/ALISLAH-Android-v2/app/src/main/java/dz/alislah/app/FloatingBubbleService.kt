package dz.alislah.app

import android.app.Notification
import org.json.JSONObject
import org.json.JSONArray
import java.util.Calendar
import android.os.Process
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.app.usage.UsageStats
import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.PermissionRequest
import android.Manifest
import android.content.pm.PackageManager
import android.webkit.WebView
import android.webkit.JavascriptInterface
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.view.WindowManager
import android.widget.TextView
import android.speech.tts.TextToSpeech
import java.util.Locale

class FloatingBubbleService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f
    private var dragged = false
    private var downAt = 0L
    private var closeButton: TextView? = null
    private var closeParams: WindowManager.LayoutParams? = null
    private var quickMenu: View? = null
    private var tts: TextToSpeech? = null
    private var lastSpokenReply = ""
    private val pollReply = object : Runnable { override fun run() { speakLatestReply(); if (assistantPanel != null) handler.postDelayed(this, 1800L) } }
    private var assistantPanel: View? = null
    private var assistantWebView: WebView? = null
    private var assistantOverlayTitle: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val reshowBubble = Runnable { showBubble() }
    private var pendingBubbleTap: Runnable? = null
    private val bubbleDoubleTapWindowMs = 280L

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) { tts?.language = Locale("ar"); applySavedAssistantVoice() } }
        startForeground(4107, buildNotification())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) showBubble() else stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ANSWERED -> {
                handler.removeCallbacks(reshowBubble)
                hideBubble()
            }
            ACTION_SHOW_FOR_EVENT -> {
                handler.removeCallbacks(reshowBubble)
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) showBubble()
            }
            else -> if (bubble == null && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))) showBubble()
        }
        return START_STICKY
    }

    private fun hideBubble() {
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        params = null
        hideCloseButton()
        hideQuickMenu()
    }

    private fun hideQuickMenu() {
        quickMenu?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        quickMenu = null
    }

    private fun showQuickMenu(anchor: WindowManager.LayoutParams) {
        if (quickMenu != null) { hideQuickMenu(); return }
        val d = resources.displayMetrics.density
        val orbit = (280 * d).toInt()
        val item = (48 * d).toInt()
        val menu = FrameLayout(this).apply { elevation = 24 * d }

        data class BubbleAction(val icon: String, val label: String, val command: String, val color: Int)
        val actions = listOf(
            BubbleAction("💬", "المساعد", "ask", Color.rgb(23,107,91)),
            BubbleAction("📋", "المهام", "plan", Color.rgb(43,112,190)),
            BubbleAction("✓", "العادات", "habits", Color.rgb(42,132,94)),
            BubbleAction("🕌", "الصلاة", "prayer", Color.rgb(30,112,145)),
            BubbleAction("👨‍👩‍👧", "الأسرة", "family", Color.rgb(191,113,36)),
            BubbleAction("📊", "التحليل", "behavior", Color.rgb(117,76,175)),
            BubbleAction("👁", "راحة العين", "eye", Color.rgb(55,125,119)),
            BubbleAction("🔐", "الأذونات", "permissions", Color.rgb(82,98,105)),
            BubbleAction("⚙", "الإعدادات", "settings", Color.rgb(90,90,100)),
            BubbleAction("🔊", "صوت المساعد", "voice", Color.rgb(32,128,145)),
            BubbleAction("✕", "إغلاق", "close", Color.rgb(190,55,55))
        )
        val sideViews = mutableListOf<TextView>()
        // The orbit is centered on the main bubble at the screen edge. The window is
        // intentionally allowed to extend beyond the display: Android clips the outer
        // half, while rotating the ring brings hidden actions into the visible half.
        var rotation = 0f
        var downAngle = 0f
        var downRotation = rotation
        var moved = false
        val center = orbit / 2f
        val radius = orbit * 0.41f
        menu.clipChildren = true
        menu.clipToPadding = true
        fun placeSideBubbles() {
            sideViews.forEachIndexed { i, v ->
                v.visibility = View.VISIBLE
                val angle = Math.toRadians((rotation + i * (360f / actions.size)).toDouble())
                val cx = center + kotlin.math.cos(angle) * radius
                val cy = center + kotlin.math.sin(angle) * radius
                val lp = (v.layoutParams as? FrameLayout.LayoutParams) ?: FrameLayout.LayoutParams(item, item)
                lp.leftMargin = (cx - item / 2f).toInt()
                lp.topMargin = (cy - item / 2f).toInt()
                v.layoutParams = lp
            }
        }
        actions.forEach { a ->
            val b = TextView(this).apply {
                text = a.icon
                textSize = 21f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                contentDescription = a.label
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(a.color)
                    setStroke((2*d).toInt(), Color.WHITE)
                }
                elevation = 8*d
                isClickable = true
                isFocusable = false
            }
            b.setOnTouchListener { v, event ->
                val rawX = event.rawX
                val rawY = event.rawY
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        moved = false
                        val centerX = anchor.x + anchor.width / 2f
                        val centerY = anchor.y + anchor.height / 2f
                        downAngle = Math.toDegrees(kotlin.math.atan2((rawY-centerY).toDouble(), (rawX-centerX).toDouble())).toFloat()
                        downRotation = rotation
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val centerX = anchor.x + anchor.width / 2f
                        val centerY = anchor.y + anchor.height / 2f
                        val nowAngle = Math.toDegrees(kotlin.math.atan2((rawY-centerY).toDouble(), (rawX-centerX).toDouble())).toFloat()
                        var delta = nowAngle - downAngle
                        if (delta > 180f) delta -= 360f
                        if (delta < -180f) delta += 360f
                        if (kotlin.math.abs(delta) > 5f) moved = true
                        if (moved) { rotation = downRotation + delta; placeSideBubbles() }
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (!moved && event.actionMasked == MotionEvent.ACTION_UP) {
                            hideQuickMenu()
                            if (a.command == "close") {
                                prefs().edit().putBoolean("overlayEnabled", false).apply()
                                stopSelf()
                            } else showAssistantOverlay(a.command)
                        }
                        true
                    }
                    else -> true
                }
            }
            sideViews.add(b)
            menu.addView(b, FrameLayout.LayoutParams(item, item))
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        // Keep the orbit centered on the main bubble; allowing negative offsets makes part of the semicircle start off-screen.
        // Keep the orbit center exactly over the main bubble. Do not clamp it to the screen:
        // the off-screen half is intentional and becomes visible as the user rotates the orbit.
        val x = anchor.x + anchor.width / 2 - orbit / 2
        val y = anchor.y + anchor.height / 2 - orbit / 2
        val lp = WindowManager.LayoutParams(orbit, orbit, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }
        try { windowManager.addView(menu, lp); quickMenu = menu; placeSideBubbles() } catch (_: Exception) {}
    }

    private fun prefs() = getSharedPreferences("alislah_native", MODE_PRIVATE)

    private fun applySavedAssistantVoice() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return
        val wanted = prefs().getString("assistantVoiceName", "").orEmpty()
        if (wanted.isBlank()) return
        try {
            val match = tts?.voices?.firstOrNull { it.name == wanted && it.locale.language == "ar" }
            if (match != null) tts?.voice = match
        } catch (_: Exception) { }
    }

    private fun speak(text: String) {
        val clean = text.trim().take(700)
        if (clean.isNotBlank()) { applySavedAssistantVoice(); tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "alislah_voice") }
    }

    private fun speakLatestReply() {
        val web = assistantWebView ?: return
        web.evaluateJavascript("(function(){var x=document.querySelector('#messages .bubble.assistant:last-child');return x?(x.innerText||x.textContent||''):''})()") { raw ->
            val value = try { org.json.JSONTokener(raw ?: "").nextValue() as? String ?: "" } catch (_: Exception) { "" }
            if (value.isNotBlank() && value != lastSpokenReply && !value.contains("أحاول الاتصال")) { lastSpokenReply = value; if (prefs().getString("voiceMode", "both") != "text") speak(value) }
        }
    }

    private fun showCloseButton(anchor: WindowManager.LayoutParams) {
        if (closeButton != null) return
        val size = (38 * resources.displayMetrics.density).toInt()
        val xButton = TextView(this).apply {
            text = "×"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(180, 35, 24))
                setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
            }
            contentDescription = "إغلاق الفقاعة العائمة"
            setOnClickListener {
                getSharedPreferences("alislah_native", MODE_PRIVATE).edit().putBoolean("overlayEnabled", false).apply()
                handler.removeCallbacks(reshowBubble)
                stopSelf()
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val cp = WindowManager.LayoutParams(size, size, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (anchor.x + 42 * resources.displayMetrics.density).toInt()
            y = (anchor.y - 12 * resources.displayMetrics.density).toInt().coerceAtLeast(0)
        }
        try { windowManager.addView(xButton, cp); closeButton = xButton; closeParams = cp } catch (_: Exception) {}
    }

    private fun hideCloseButton() {
        closeButton?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        closeButton = null
        closeParams = null
    }

    private fun showBubble() {
        if (bubble != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = (58 * resources.displayMetrics.density).toInt()
        val view = TextView(this).apply {
            text = "✦"
            textSize = 23f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(23, 107, 91))
            elevation = 12f
            contentDescription = "فقاعة ALISLAH: ضغطة لإظهار الفقاعات الجانبية، وضغطتان لفتح التطبيق، واسحبيها لتغيير موضعها"
            // Rounded drawable without external assets.
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(23, 107, 91))
                setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(size, size, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = -(size / 2)
            y = (220 * resources.displayMetrics.density).toInt()
        }
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragged = false; downAt = System.currentTimeMillis(); startX = lp.x; startY = lp.y; touchX = event.rawX; touchY = event.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt(); val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 6 || kotlin.math.abs(dy) > 6) dragged = true
                    if (dragged && quickMenu != null) hideQuickMenu()
                    val screenW = resources.displayMetrics.widthPixels
                    val maxY = (resources.displayMetrics.heightPixels - lp.height).coerceAtLeast(0)
                    // Keep the bubble half-hidden at either vertical edge while remaining draggable.
                    lp.x = (startX + dx).coerceIn(-lp.width / 2, screenW - lp.width / 2)
                    lp.y = (startY + dy).coerceIn(0, maxY)
                    try { windowManager.updateViewLayout(v, lp) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragged) {
                        val screenW = resources.displayMetrics.widthPixels
                        val maxY = (resources.displayMetrics.heightPixels - lp.height).coerceAtLeast(0)
                        val leftDistance = kotlin.math.abs(lp.x + lp.width / 2)
                        val rightDistance = kotlin.math.abs(screenW - (lp.x + lp.width / 2))
                        // Prefer a side edge so the main bubble is tucked halfway off-screen.
                        if (leftDistance <= rightDistance) lp.x = -lp.width / 2 else lp.x = screenW - lp.width / 2
                        lp.y = lp.y.coerceIn(0, maxY)
                        try { windowManager.updateViewLayout(v, lp) } catch (_: Exception) {}
                    } else {
                        if (pendingBubbleTap != null) {
                            handler.removeCallbacks(pendingBubbleTap!!)
                            pendingBubbleTap = null
                            hideQuickMenu()
                            val launch = Intent(this@FloatingBubbleService, MainActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            }
                            try { startActivity(launch) } catch (_: Exception) { showAssistantOverlay() }
                        } else {
                            val tap = Runnable {
                                pendingBubbleTap = null
                                if (quickMenu != null) hideQuickMenu() else params?.let { showQuickMenu(it) }
                            }
                            pendingBubbleTap = tap
                            handler.postDelayed(tap, bubbleDoubleTapWindowMs)
                        }
                    }
                    true
                }
                else -> false
            }
        }
        try { windowManager.addView(view, lp); bubble = view; params = lp } catch (_: Exception) { stopSelf() }
    }

    private fun showAssistantOverlay(command: String = "ask") {
        if (assistantPanel != null) {
            assistantPanel?.visibility = View.VISIBLE
            if (command == "question") speak("ما أكثر شيء يشغل وقتك الآن؟")
            selectOverlaySection(command)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("openAssistant", true)
            }
            startActivity(launch)
            return
        }
        val density = resources.displayMetrics.density
        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val panelWidth = (screenWidth - 82 * density).toInt().coerceAtLeast((245 * density).toInt())
        val panelHeight = (250 * density).toInt().coerceAtMost((screenHeight * 0.42f).toInt())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            elevation = 18 * density
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = 18 * density
                setStroke((1 * density).toInt(), Color.rgb(220, 231, 226))
            }
            clipToOutline = true
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((12*density).toInt(), (5*density).toInt(), (8*density).toInt(), (5*density).toInt())
            setBackgroundColor(Color.rgb(23, 107, 91))
        }
        val title = TextView(this).apply {
            text = "ALISLAH · اسألي هنا"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, (44*density).toInt(), 1f)
        }
        val close = TextView(this).apply {
            text = "×"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = "إغلاق نافذة المساعد"
            layoutParams = LinearLayout.LayoutParams((44*density).toInt(), (44*density).toInt())
            setOnClickListener { hideAssistantOverlay() }
        }
        bar.addView(title); bar.addView(close); root.addView(bar)
        assistantOverlayTitle = title
        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            addJavascriptInterface(OverlayBridge(), "AndroidUsage")
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    val hasAudio = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    if (hasAudio && request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else request.deny()
                }
            }
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    val initialView = overlayViewFor(command)
                    val script = """(function(){
                      const target='$initialView';
                      document.querySelectorAll('.view').forEach(x=>{x.classList.toggle('active',x.id===target);x.style.removeProperty('display');x.style.margin='0';x.style.padding='5px';x.style.maxHeight='100%';x.style.overflowY='auto';});
                      document.querySelectorAll('header.top,.hero,.stats,.tabs,#alislahFloat,#alislahCheckin,.footer,#nativeOverlayControls').forEach(x=>x.style.setProperty('display','none','important'));
                      const app=document.querySelector('.app'); if(app){app.style.cssText='padding:0;margin:0;max-width:none;width:100%;';}
                      const chat=document.querySelector('#assistant .chat'); if(chat){chat.style.cssText='min-height:0;height:auto;padding:5px;margin:0;';}
                      const msgs=document.getElementById('messages'); if(msgs){msgs.style.cssText='min-height:45px;max-height:105px;overflow-y:auto;padding:5px;margin:0;';}
                      const form=document.getElementById('chatForm'); if(form){form.style.cssText='display:flex;gap:5px;margin:5px 0 0;';}
                      const input=document.getElementById('chatText'); if(input){input.placeholder='اكتبي سؤالك هنا…';input.style.minHeight='38px';}
                      document.body.style.cssText='margin:0;padding:0;background:#f3f7f5;overflow:auto;';
                    })();"""
                    view?.evaluateJavascript(script, null)
                }
            }
        }
        assistantWebView = web
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val anchor = params
        val lp = WindowManager.LayoutParams(panelWidth, panelHeight, type, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (anchor?.x ?: 10).coerceAtMost((screenWidth - panelWidth).coerceAtLeast(0))
            y = ((anchor?.y ?: (screenHeight/3)) + (70*density).toInt()).coerceAtMost((screenHeight-panelHeight).coerceAtLeast(0))
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        try {
            windowManager.addView(root, lp)
            assistantPanel = root
            web.loadUrl("file:///android_asset/index.html")
            handler.removeCallbacks(pollReply); handler.postDelayed(pollReply, 2500L)
            web.postDelayed({ selectOverlaySection(command) }, 1400L)
        } catch (_: Exception) {
            assistantPanel = null
            assistantWebView = null
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("openAssistant", true)
            }
            startActivity(launch)
        }
    }

    private fun overlayViewFor(command: String): String = when(command) {
        "settings", "eye" -> "settings"
        "permissions" -> "permissions"
        "behavior" -> "behavior"
        "plan" -> "tasks"
        "habits" -> "habits"
        "prayer" -> "prayer"
        "family" -> "family"
        else -> "assistant"
    }

    private fun selectOverlaySection(command: String) {
        assistantOverlayTitle?.text = when(command) {
            "settings" -> "ALISLAH · الإعدادات"
            "permissions" -> "ALISLAH · الأذونات"
            "behavior" -> "ALISLAH · تحليل العادات"
            "plan" -> "ALISLAH · المهام والخطة"
            "habits" -> "ALISLAH · العادات"
            "prayer" -> "ALISLAH · الصلاة"
            "family" -> "ALISLAH · الأسرة"
            "eye" -> "ALISLAH · راحة العين"
            "voice" -> "ALISLAH · صوت المساعد"
            else -> "ALISLAH · المساعد الذكي"
        }
        val js = when(command) {
            "settings" -> "document.querySelector('[data-tab=\"settings\"]')?.click();"
            "permissions" -> "document.querySelector('[data-tab=\"permissions\"]')?.click();"
            "behavior" -> "document.querySelector('[data-tab=\"behavior\"]')?.click();"
            "plan" -> "document.querySelector('[data-tab=\"tasks\"]')?.click();"
            "habits" -> "document.querySelector('[data-tab=\"habits\"]')?.click();"
            "prayer" -> "document.querySelector('[data-tab=\"prayer\"]')?.click();"
            "family" -> "document.querySelector('[data-tab=\"family\"]')?.click();"
            "eye" -> "document.querySelector('[data-tab=\"settings\"]')?.click();document.getElementById('eyeBreakEnabled')?.scrollIntoView({block:'center'});"
            "voice" -> "document.querySelector('[data-tab=\"assistant\"]')?.click();setTimeout(()=>document.getElementById('alislahVoiceChoice')?.scrollIntoView({block:'center'}),250);"
            "question" -> "var q=document.getElementById('chatText');if(q){q.value='سؤال سريع: ما أكثر شيء يشغل وقتك الآن؟';q.focus();}"
            else -> "document.querySelector('[data-tab=\"assistant\"]')?.click();document.getElementById('chatText')?.focus();"
        }
        assistantWebView?.evaluateJavascript(js, null)
    }

    private fun hideAssistantOverlay() {
        handler.removeCallbacks(pollReply)
        assistantWebView?.stopLoading()
        assistantWebView?.destroy()
        assistantWebView = null
        assistantPanel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        assistantPanel = null
        assistantOverlayTitle = null
    }

    private fun hasOverlayUsagePermission(): Boolean {
        val appOps = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun overlayTodayStartMillis(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun readOverlayUsageJson(): String {
        val allowed = hasOverlayUsagePermission()
        val result = JSONObject().put("permission", allowed)
        val apps = JSONArray()
        var foreground = JSONObject().put("name", "غير متاح").put("packageName", "").put("approximate", true)
        if (allowed) {
            val manager = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
            val stats: List<UsageStats> = manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, overlayTodayStartMillis(), System.currentTimeMillis()) ?: emptyList()
            val grouped = stats.filter { it.totalTimeInForeground > 0 && it.packageName != packageName }
                .groupBy { it.packageName }
                .map { (pkg, rows) -> pkg to rows.sumOf { it.totalTimeInForeground } }
                .sortedByDescending { it.second }.take(20)
            for ((pkg, millis) in grouped) {
                val appName = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
                apps.put(JSONObject().put("packageName", pkg).put("name", appName).put("minutes", (millis / 60000.0).toInt()))
            }
            try {
                val now = System.currentTimeMillis(); val events = manager.queryEvents(now - 2 * 60 * 60 * 1000L, now); val event = UsageEvents.Event()
                var latestTime = 0L; var latestPackage = ""
                while (events.hasNextEvent()) {
                    events.getNextEvent(event)
                    val isForeground = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) event.eventType == UsageEvents.Event.ACTIVITY_RESUMED else @Suppress("DEPRECATION") (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND)
                    if (isForeground && event.timeStamp >= latestTime) { latestTime = event.timeStamp; latestPackage = event.packageName ?: "" }
                }
                if (latestPackage.isNotBlank()) {
                    val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(latestPackage, 0)).toString() } catch (_: Exception) { latestPackage }
                    foreground = JSONObject().put("name", label).put("packageName", latestPackage).put("lastSeenAt", latestTime).put("approximate", true)
                }
            } catch (_: Exception) { }
        }
        return result.put("apps", apps).put("foreground", foreground).put("collectedAt", System.currentTimeMillis()).toString()
    }

    private inner class OverlayBridge {
        @JavascriptInterface fun setAssistantVoiceName(name: String) { prefs().edit().putString("assistantVoiceName", name.take(128)).apply() }
        @JavascriptInterface fun setAssistantVoiceMode(mode: String) { prefs().edit().putString("voiceMode", if (mode == "text" || mode == "voice") mode else "both").apply() }
        @JavascriptInterface fun assistantAnswered() { handler.post { handler.removeCallbacks(reshowBubble); hideBubble() } }
        @JavascriptInterface fun showBubbleForEvent() { handler.post { if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this@FloatingBubbleService)) showBubble() } }
        @JavascriptInterface fun scheduleTaskReminder(id: String, title: String, atMillis: Long) { TaskReminderScheduler.schedule(this@FloatingBubbleService, id, title, atMillis) }
        @JavascriptInterface fun cancelTaskReminder(id: String) { TaskReminderScheduler.cancel(this@FloatingBubbleService, id) }
        @JavascriptInterface fun schedulePrayerAlarms(json: String, before: Int, after: Int, adhan: Boolean) { PrayerScheduler.schedule(this@FloatingBubbleService, json, before, after, adhan) }
        @JavascriptInterface fun stopAdhan() {
            val i = Intent(this@FloatingBubbleService, AdhanService::class.java).setAction(AdhanService.ACTION_STOP)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
        }
        @JavascriptInterface fun testAdhan() {
            val i = Intent(this@FloatingBubbleService, AdhanService::class.java).putExtra("message", "تجربة الأذان").putExtra("adhan", true)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
        }
        @JavascriptInterface fun getUsageStatsJson(): String = readOverlayUsageJson()
        @JavascriptInterface fun requestUsagePermission() { try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply { data = android.net.Uri.parse("package:$packageName"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }) } catch (_: Exception) {} }
        @JavascriptInterface fun requestRuntimePermissions() {
            val i = Intent(this@FloatingBubbleService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("requestRuntimePermissions", true).putExtra("openTab", "permissions")
            startActivity(i)
        }
        @JavascriptInterface fun requestExactAlarmPermission() {
            try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, android.net.Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }
        @JavascriptInterface fun enableOverlay() {
            prefs().edit().putBoolean("overlayEnabled", true).apply()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@FloatingBubbleService)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        @JavascriptInterface fun disableOverlay() { prefs().edit().putBoolean("overlayEnabled", false).apply(); stopSelf() }
        @JavascriptInterface fun enableEyeFilter() {
            prefs().edit().putBoolean("eyeFilterEnabled", true).apply()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@FloatingBubbleService)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            else startService(Intent(this@FloatingBubbleService, EyeFilterService::class.java))
        }
        @JavascriptInterface fun disableEyeFilter() { prefs().edit().putBoolean("eyeFilterEnabled", false).apply(); stopService(Intent(this@FloatingBubbleService, EyeFilterService::class.java)) }
        @JavascriptInterface fun configureEyeBreak(enabled: Boolean, minutes: Int, seconds: Int) {
            prefs().edit().putBoolean("eyeBreakServiceEnabled", enabled).putInt("eyeBreakMinutes", minutes.coerceIn(1,180)).putInt("eyeBreakSeconds", seconds.coerceIn(5,120)).apply()
            if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@FloatingBubbleService)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } else if (enabled) {
                val i = Intent(this@FloatingBubbleService, EyeBreakService::class.java).putExtra("minutes", minutes).putExtra("seconds", seconds)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
            } else stopService(Intent(this@FloatingBubbleService, EyeBreakService::class.java))
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel("alislah_bubble", "فقاعة ALISLAH", NotificationManager.IMPORTANCE_LOW).apply { description = "إبقاء الفقاعة العائمة متاحة فوق التطبيقات" })
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "alislah_bubble").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("فقاعة ALISLAH مفعّلة").setContentText("اضغطي على الفقاعة لفتح المساعد الذكي").setContentIntent(open).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("فقاعة ALISLAH مفعّلة").setContentText("اضغطي على الفقاعة لفتح المساعد الذكي").setContentIntent(open).setOngoing(true).build()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(reshowBubble)
        pendingBubbleTap?.let { handler.removeCallbacks(it) }
        pendingBubbleTap = null
        handler.removeCallbacks(pollReply)
        hideCloseButton()
        hideQuickMenu()
        hideAssistantOverlay()
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_ANSWERED = "dz.alislah.app.ACTION_ASSISTANT_ANSWERED"
        const val ACTION_SHOW_FOR_EVENT = "dz.alislah.app.ACTION_SHOW_BUBBLE_FOR_EVENT"
    }
}
