package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.PermissionRequest
import android.Manifest
import android.content.pm.PackageManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.view.WindowManager
import android.widget.TextView
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class FloatingBubbleService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f
    private var dragged = false
    private var downAt = 0L
    private var lastTapAt = 0L
    private var orbitRotation = 0.0
    private var closeButton: TextView? = null
    private var closeParams: WindowManager.LayoutParams? = null
    private var quickMenu: View? = null
    private var tts: TextToSpeech? = null
    private var lastSpokenReply = ""
    private var networkArabicVoice: android.speech.tts.Voice? = null
    private var localArabicVoice: android.speech.tts.Voice? = null
    private var pendingFallbackText = ""
    private var fallbackAttempted = false
    private var ttsReady = false
    private val pollReply = object : Runnable { override fun run() { speakLatestReply(); if (assistantPanel != null) handler.postDelayed(this, 1800L) } }
    private var assistantPanel: View? = null
    private var assistantWebView: WebView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val reshowBubble = Runnable { showBubble() }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                configureAssistantVoice()
                if (pendingFallbackText.isNotBlank()) speak(pendingFallbackText)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { }
                    override fun onDone(utteranceId: String?) { fallbackAttempted = false; pendingFallbackText = "" }
                    override fun onError(utteranceId: String?) { retryWithLocalArabicVoice() }
                    override fun onError(utteranceId: String?, errorCode: Int) { retryWithLocalArabicVoice() }
                })
            }
        }
        startForeground(4107, buildNotification())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) showBubble() else stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ANSWERED -> {
                handler.removeCallbacks(reshowBubble)
                hideBubble()
            }
            ACTION_HIDE_PANEL -> hideAssistantOverlay()
            ACTION_SPEAK_TEST -> speak("مرحبًا بك في الإصلاح. صوت المساعد يعمل الآن.")
            ACTION_SHOW_FOR_EVENT -> {
                handler.removeCallbacks(reshowBubble)
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) showBubble()
            }
            else -> if (bubble == null && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))) showBubble()
        }
        return START_STICKY
    }

    private fun hideBubble() {
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        params = null
        hideCloseButton()
        hideQuickMenu()
    }

    private fun hideQuickMenu() {
        quickMenu?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        quickMenu = null
    }

    private fun showQuickMenu(anchor: WindowManager.LayoutParams) {
        if (quickMenu != null) { hideQuickMenu(); return }
        val d = resources.displayMetrics.density
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val item = (52 * d).toInt()
        val radius = (94 * d).toInt()
        val size = (radius * 2 + item + 12*d).toInt()
        val menu = FrameLayout(this).apply { elevation = 24*d }
        data class BubbleAction(val icon: String, val label: String, val command: String, val color: Int)
        val actions = listOf(
            BubbleAction("💬", "المساعد", "ask", Color.rgb(23,107,91)),
            BubbleAction("📋", "الخطة", "plan", Color.rgb(43,112,190)),
            BubbleAction("📊", "التحليل", "behavior", Color.rgb(117,76,175)),
            BubbleAction("⚙", "الإعدادات", "settings", Color.rgb(82,98,105)),
            BubbleAction("👨‍👩‍👧", "الأسرة", "family", Color.rgb(190,117,47)),
            BubbleAction("🕌", "الصلاة", "prayer", Color.rgb(16,130,100)),
            BubbleAction("✓", "العادات", "habits", Color.rgb(40,130,145)),
            BubbleAction("🔊", "صوت المساعد", "voice", Color.rgb(32,128,145)),
            BubbleAction("👁", "راحة العين", "eye", Color.rgb(55,125,119)),
            BubbleAction("✕", "إغلاق", "close", Color.rgb(190,55,55))
        )
        val buttons = mutableListOf<TextView>()
        actions.forEach { a ->
            val b = TextView(this).apply {
                text = a.icon; textSize = 21f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                contentDescription = a.label
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(a.color); setStroke((2*d).toInt(), Color.WHITE)
                }
                elevation = 8*d
                setOnClickListener {
                    hideQuickMenu()
                    if (a.command == "close") { prefs().edit().putBoolean("overlayEnabled", false).apply(); stopSelf() }
                    else showAssistantOverlay(a.command)
                }
            }
            buttons.add(b); menu.addView(b, FrameLayout.LayoutParams(item,item))
        }
        fun placeButtons(rotation: Double) {
            val centerX = size/2.0
            val centerY = size/2.0
            // Full circular orbit centered exactly on the screen edge. The screen clips half the orbit; rotating reveals the hidden half.
            buttons.forEachIndexed { i,b ->
                val angle = (-Math.PI/2.0) + (2.0*Math.PI * i/buttons.size) + rotation
                val x = (centerX + radius*kotlin.math.cos(angle) - item/2).toInt()
                val y = (centerY + radius*kotlin.math.sin(angle) - item/2).toInt()
                val lp = b.layoutParams as FrameLayout.LayoutParams
                lp.leftMargin=x; lp.topMargin=y; b.layoutParams=lp
            }
        }
        placeButtons(orbitRotation)
        // Rotate by the actual polar angle around the main bubble, not a dx/dy approximation.
        buttons.forEach { button ->
            var downAngle = 0f
            var downRotation = orbitRotation
            var sideDragged = false
            button.setOnTouchListener { v, ev ->
                val centerX = anchor.x + anchor.width / 2f
                val centerY = anchor.y + anchor.height / 2f
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sideDragged = false
                        downAngle = Math.toDegrees(kotlin.math.atan2((ev.rawY-centerY).toDouble(), (ev.rawX-centerX).toDouble())).toFloat()
                        downRotation = orbitRotation
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val nowAngle = Math.toDegrees(kotlin.math.atan2((ev.rawY-centerY).toDouble(), (ev.rawX-centerX).toDouble())).toFloat()
                        var delta = nowAngle - downAngle
                        if (delta > 180f) delta -= 360f
                        if (delta < -180f) delta += 360f
                        if (kotlin.math.abs(delta) > 5f) sideDragged = true
                        if (sideDragged) { orbitRotation = downRotation + Math.toRadians(delta.toDouble()); placeButtons(orbitRotation) }
                        true
                    }
                    MotionEvent.ACTION_UP -> { if (!sideDragged) v.performClick(); true }
                    MotionEvent.ACTION_CANCEL -> true
                    else -> true
                }
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        // Put the orbit center on the same edge as the main bubble. The off-screen half is naturally clipped.
        val x = (anchor.x + anchor.width/2 - size/2).coerceIn(-(size/2), screenW-(size/2))
        val y = (anchor.y + anchor.height/2 - size/2).coerceIn(-(size/2),(screenH-size/2))
        val lp = WindowManager.LayoutParams(size,size,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT).apply {
            gravity=Gravity.TOP or Gravity.LEFT; this.x=x; this.y=y
        }
        try {
            windowManager.addView(menu, lp)
            quickMenu = menu
            // Keep the main bubble above the menu window so it remains clickable.
            // Otherwise the transparent center of the menu window intercepts taps.
            bubble?.let { main ->
                val mainLp = params
                if (mainLp != null) {
                    try { windowManager.removeView(main) } catch (_: Exception) {}
                    try { windowManager.addView(main, mainLp) } catch (_: Exception) {}
                }
            }
        } catch (_: Exception) {}
    }

    private fun prefs() = getSharedPreferences("alislah_native", MODE_PRIVATE)

    /** Prefer a natural network Arabic voice; retain an installed offline Arabic voice as a real fallback. */
    private fun configureAssistantVoice() {
        val engine = tts ?: return
        try {
            val voices = engine.voices.orEmpty().filter { it.locale.language.equals("ar", true) }
            val wantedFemale = prefs().getString("assistantVoiceGender", "female") != "male"
            val hints = if (wantedFemale) listOf("female", "woman", "amira", "salma", "hoda", "laila", "sara") else listOf("male", "man", "ahmed", "hamza", "omar")
            fun score(v: android.speech.tts.Voice) = hints.any { v.name.contains(it, true) }
            networkArabicVoice = voices.filter { it.isNetworkConnectionRequired }
                .sortedWith(compareByDescending<android.speech.tts.Voice> { score(it) }.thenByDescending { it.quality }).firstOrNull()
            localArabicVoice = voices.filter { !it.isNetworkConnectionRequired }
                .sortedWith(compareByDescending<android.speech.tts.Voice> { score(it) }.thenByDescending { it.quality }).firstOrNull()
            // Network voice first for natural speech; if unavailable, use local Arabic immediately.
            val preferred = networkArabicVoice ?: localArabicVoice
            if (preferred != null) engine.voice = preferred else engine.language = Locale("ar")
            engine.setPitch(1.0f)
            engine.setSpeechRate(0.96f)
        } catch (_: Exception) {
            try { engine.language = Locale("ar"); engine.setPitch(1.0f) } catch (_: Exception) { }
        }
    }

    private fun speak(text: String) {
        val clean = text.trim().take(700)
        if (clean.isBlank()) return
        pendingFallbackText = clean
        fallbackAttempted = false
        if (!ttsReady) return
        configureAssistantVoice()
        try {
            tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "alislah_voice")
        } catch (_: Exception) { retryWithLocalArabicVoice() }
    }

    /** A failed/missing online voice never silences the assistant: retry once with offline Arabic TTS. */
    private fun retryWithLocalArabicVoice() {
        if (fallbackAttempted) return
        val text = pendingFallbackText
        val local = localArabicVoice
        if (text.isBlank() || local == null) return
        fallbackAttempted = true
        try {
            tts?.voice = local
            tts?.setPitch(1.0f)
            tts?.setSpeechRate(0.96f)
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "alislah_voice_local_fallback")
        } catch (_: Exception) { }
    }

    private fun speakLatestReply() {
        val web = assistantWebView ?: return
        web.evaluateJavascript("(function(){var x=document.querySelector('#messages .bubble.assistant:last-child');return x?(x.innerText||x.textContent||''):''})()") { raw ->
            val value = try { org.json.JSONTokener(raw ?: "").nextValue() as? String ?: "" } catch (_: Exception) { "" }
            if (value.isNotBlank() && value != lastSpokenReply && !value.contains("أحاول الاتصال")) { lastSpokenReply = value; if (prefs().getString("voiceMode", "both") != "text") speak(value) }
        }
    }

    private fun showCloseButton(anchor: WindowManager.LayoutParams) {
        if (closeButton != null) return
        val size = (38 * resources.displayMetrics.density).toInt()
        val xButton = TextView(this).apply {
            text = "×"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.rgb(180, 35, 24))
                setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
            }
            contentDescription = "إغلاق الفقاعة العائمة"
            setOnClickListener {
                getSharedPreferences("alislah_native", MODE_PRIVATE).edit().putBoolean("overlayEnabled", false).apply()
                handler.removeCallbacks(reshowBubble)
                stopSelf()
            }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val cp = WindowManager.LayoutParams(size, size, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (anchor.x + 42 * resources.displayMetrics.density).toInt()
            y = (anchor.y - 12 * resources.displayMetrics.density).toInt().coerceAtLeast(0)
        }
        try { windowManager.addView(xButton, cp); closeButton = xButton; closeParams = cp } catch (_: Exception) {}
    }

    private fun hideCloseButton() {
        closeButton?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        closeButton = null
        closeParams = null
    }

    /** Draws the same green main bubble as a circle on the side, and as a camera-hugging U when docked at the top. */
    private inner class MainBubbleView(context: android.content.Context) : View(context) {
        var dockedAtCamera: Boolean = true
        private val fill = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(23, 107, 91)
            style = android.graphics.Paint.Style.FILL
        }
        private val stroke = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(75, 205, 165)
            style = android.graphics.Paint.Style.STROKE
            strokeWidth = (1.5f * resources.displayMetrics.density).coerceAtLeast(1f)
        }
        private val markPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = android.graphics.Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        override fun onDraw(canvas: android.graphics.Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            if (!dockedAtCamera) {
                val r = minOf(w, h) / 2f - stroke.strokeWidth
                canvas.drawCircle(w / 2f, h / 2f, r, fill)
                canvas.drawCircle(w / 2f, h / 2f, r, stroke)
                markPaint.textSize = 25f * resources.displayMetrics.density
                canvas.drawText("✦", w / 2f, h / 2f - (markPaint.ascent() + markPaint.descent()) / 2f, markPaint)
            } else {
                // Open at the top center so the camera remains visible inside the U.
                val d = resources.displayMetrics.density
                val leg = 15f * d
                val bottom = 11f * d
                val radius = 7f * d
                val path = android.graphics.Path().apply {
                    moveTo(0f, 0f)
                    lineTo(leg, 0f)
                    lineTo(leg, h - radius)
                    quadTo(leg, h, leg + radius, h)
                    lineTo(w - leg - radius, h)
                    quadTo(w - leg, h, w - leg, h - radius)
                    lineTo(w - leg, 0f)
                    lineTo(w, 0f)
                    lineTo(w, h - radius)
                    quadTo(w, h, w - radius, h)
                    lineTo(radius, h)
                    quadTo(0f, h, 0f, h - radius)
                    close()
                }
                canvas.drawPath(path, fill)
                canvas.drawPath(path, stroke)
                markPaint.textSize = 16f * d
                canvas.drawText("✦", w / 2f, h - bottom / 2f - (markPaint.ascent() + markPaint.descent()) / 2f, markPaint)
            }
        }
    }

    private fun cameraCenterX(screenWidth: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                val cutout = windowManager.defaultDisplay.cutout
                val rect = cutout?.boundingRects?.maxByOrNull { it.width() * it.height() }
                if (rect != null && rect.width() > 0) return rect.centerX().coerceIn(0, screenWidth)
            } catch (_: Exception) { }
        }
        // Android 8.0/8.1 and devices without cutout metadata: use the conventional centered camera position.
        return screenWidth / 2
    }

    private fun showBubble() {
        if (bubble != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        val screenW = resources.displayMetrics.widthPixels
        val circleSize = (58 * d).toInt()
        val cameraX = cameraCenterX(screenW)
        val cutoutWidth = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try { windowManager.defaultDisplay.cutout?.boundingRects?.maxByOrNull { it.width() * it.height() }?.width() ?: 0 } catch (_: Exception) { 0 }
        } else 0
        val opening = (cutoutWidth + (24 * d).toInt()).coerceIn((42*d).toInt(), (78*d).toInt())
        val dockWidth = opening + (30 * d).toInt()
        val dockHeight = (40 * d).toInt()
        val view = MainBubbleView(this).apply {
            dockedAtCamera = true
            contentDescription = "فقاعة ALISLAH الخضراء؛ اضغطي لفتح الفقاعات الجانبية"
            elevation = 18 * d
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(dockWidth, dockHeight, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = (cameraX - dockWidth / 2).coerceIn(0, (screenW - dockWidth).coerceAtLeast(0))
            y = 0
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragged = false; downAt = System.currentTimeMillis(); startX = lp.x; startY = lp.y; touchX = event.rawX; touchY = event.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt(); val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) dragged = true
                    if (dragged) {
                        val currentW = resources.displayMetrics.widthPixels
                        val currentH = resources.displayMetrics.heightPixels
                        lp.x = (startX + dx).coerceIn(-(lp.width / 2), currentW - (lp.width / 2))
                        lp.y = (startY + dy).coerceIn(0, (currentH-lp.height).coerceAtLeast(0))
                        try { windowManager.updateViewLayout(v, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val heldLong = System.currentTimeMillis() - downAt >= 650L
                    if (dragged) {
                        val currentW = resources.displayMetrics.widthPixels
                        val currentH = resources.displayMetrics.heightPixels
                        val density = resources.displayMetrics.density
                        val centerX = lp.x + lp.width / 2
                        val topZone = (76 * density).toInt()
                        val targetCameraX = cameraCenterX(currentW)
                        val nearTopCamera = lp.y <= topZone && kotlin.math.abs(centerX - targetCameraX) <= (90 * density).toInt()
                        if (nearTopCamera) {
                            view.dockedAtCamera = true
                            lp.width = dockWidth; lp.height = dockHeight
                            lp.x = (targetCameraX - dockWidth / 2).coerceIn(0, (currentW - dockWidth).coerceAtLeast(0))
                            lp.y = 0
                        } else {
                            view.dockedAtCamera = false
                            lp.width = circleSize; lp.height = circleSize
                            val onLeft = centerX < currentW / 2
                            lp.x = if (onLeft) -(circleSize / 2) else currentW - (circleSize / 2)
                            lp.y = lp.y.coerceIn(0, (currentH-circleSize).coerceAtLeast(0))
                        }
                        v.requestLayout()
                        try { windowManager.updateViewLayout(v, lp) } catch (_: Exception) {}
                    } else if (heldLong) {
                        showQuickMenu(lp)
                    } else {
                        if (quickMenu != null) hideQuickMenu() else showQuickMenu(lp)
                    }
                    true
                }
                else -> false
            }
        }
        try { windowManager.addView(view, lp); bubble = view; params = lp } catch (_: Exception) { stopSelf() }
    }

    private fun showAssistantOverlay(command: String = "ask") {
        lastSpokenReply = ""
        if (assistantPanel != null) {
            assistantPanel?.visibility = View.VISIBLE
            if (command == "question") speak("ما أكثر شيء يشغل وقتك الآن؟")
            selectOverlaySection(command)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("openAssistant", true)
            }
            startActivity(launch)
            return
        }
        val density = resources.displayMetrics.density
        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val panelWidth = (screenWidth - 82 * density).toInt().coerceAtLeast((245 * density).toInt())
        val panelHeight = (screenHeight * 0.72f).toInt().coerceAtMost((screenHeight - 28 * density).toInt()).coerceAtLeast((360 * density).toInt())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            elevation = 18 * density
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = 18 * density
                setStroke((1 * density).toInt(), Color.rgb(220, 231, 226))
            }
            clipToOutline = true
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((12*density).toInt(), (5*density).toInt(), (8*density).toInt(), (5*density).toInt())
            setBackgroundColor(Color.rgb(23, 107, 91))
        }
        val title = TextView(this).apply {
            text = "ALISLAH · اسألي هنا"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, (44*density).toInt(), 1f)
        }
        val close = TextView(this).apply {
            text = "×"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            contentDescription = "إغلاق نافذة المساعد"
            layoutParams = LinearLayout.LayoutParams((44*density).toInt(), (44*density).toInt())
            setOnClickListener { hideAssistantOverlay() }
        }
        bar.addView(title); bar.addView(close); root.addView(bar)
        // A distinct tool ribbon belongs to the selected side bubble; the circular bubble layout remains unchanged.
        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((7*density).toInt(), (6*density).toInt(), (7*density).toInt(), (6*density).toInt())
            setBackgroundColor(Color.rgb(231, 242, 237))
        }
        fun addTool(label: String, js: String) {
            val button = TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(Color.rgb(20, 91, 76))
                setPadding((8*density).toInt(), (8*density).toInt(), (8*density).toInt(), (8*density).toInt())
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.WHITE); cornerRadius = 11*density
                    setStroke((1*density).toInt(), Color.rgb(195, 219, 208))
                }
                setOnClickListener { assistantWebView?.evaluateJavascript(js, null) }
            }
            tools.addView(button, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = (3*density).toInt(); marginEnd = (3*density).toInt()
            })
        }
        when (command) {
            "prayer" -> {
                title.text = "ALISLAH · الصلاة والأذان"
                addTool("تحديث المواقيت", "document.getElementById('prayerRefresh')?.click()")
                addTool("تشغيل/إيقاف الصوت", "document.getElementById('prayerAdhanEnabled')?.click()")
                addTool("اختبار الصوت", "document.getElementById('prayerAdhanTest')?.click()")
            }
            "plan" -> {
                title.text = "ALISLAH · المهام والخطة"
                addTool("المهام", "document.querySelector('[data-tab=\"tasks\"]')?.click()")
                addTool("إضافة مهمة", "document.getElementById('taskText')?.focus()")
                addTool("المساعد", "document.querySelector('[data-tab=\"assistant\"]')?.click()")
            }
            "behavior" -> {
                title.text = "ALISLAH · تحليل العادات"
                addTool("تحليل الآن", "document.getElementById('analyzeBehavior')?.click()")
                addTool("العادات", "document.querySelector('[data-tab=\"habits\"]')?.click()")
            }
            "habits" -> {
                title.text = "ALISLAH · العادات"
                addTool("إضافة عادة", "document.getElementById('habitText')?.focus()")
                addTool("تحليل", "document.querySelector('[data-tab=\"behavior\"]')?.click()")
            }
            "family" -> {
                title.text = "ALISLAH · الأسرة"
                addTool("المساعد", "document.querySelector('[data-tab=\"assistant\"]')?.click()")
                addTool("المهام", "document.querySelector('[data-tab=\"tasks\"]')?.click()")
            }
            "settings" -> {
                title.text = "ALISLAH · الإعدادات"
                addTool("حفظ الإعدادات", "document.getElementById('saveSettings')?.click()")
                addTool("الصلاة", "document.querySelector('[data-tab=\"prayer\"]')?.click()")
            }
            else -> {
                title.text = "ALISLAH · المساعد الذكي"
                addTool("سؤال جديد", "document.getElementById('chatText')?.focus()")
                addTool("الخطة", "document.querySelector('[data-tab=\"tasks\"]')?.click()")
                addTool("تحليل", "document.querySelector('[data-tab=\"behavior\"]')?.click()")
            }
        }
        root.addView(tools)
        val web = WebView(this).apply {
            addJavascriptInterface(object {
                @JavascriptInterface fun getAppDataJson(): String = prefs().getString("alislah_app_data", "{}") ?: "{}"
                @JavascriptInterface fun getEyeBreakContentCache(): String = prefs().getString("eyeBreakContentCache", "{}") ?: "{}"
                @JavascriptInterface fun saveAppDataJson(json: String) { if (json.length <= 2_000_000) prefs().edit().putString("alislah_app_data", json).apply() }
                @JavascriptInterface fun saveEyeBreakContentCache(json: String) { if (json.length <= 1_000_000) prefs().edit().putString("eyeBreakContentCache", json).apply() }
            }, "ALISLAHStore")
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    val hasAudio = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                    if (hasAudio && request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else request.deny()
                }
            }
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    val script = """(function(){
                      document.querySelector('header.top')?.style.setProperty('display','none','important');
                      document.querySelector('.hero')?.style.setProperty('display','none','important');
                      document.querySelector('.stats')?.style.setProperty('display','none','important');
                      document.querySelector('.tabs')?.style.setProperty('display','none','important');
                      const target = window.__alislahOverlayTarget || 'assistant';
                      document.querySelectorAll('.view').forEach(x=>{const show=x.id===target;x.classList.toggle('active',show);x.style.display=show?'block':'none'});
                      document.querySelectorAll('#alislahFloat,#alislahCheckin,.footer,#nativeOverlayControls').forEach(x=>x.style.display='none');
                      const app=document.querySelector('.app'); if(app){app.style.cssText='padding:0;margin:0;max-width:none;width:100%;';}
                      const chat=document.querySelector('#assistant .chat'); if(chat){chat.style.cssText='min-height:0;height:auto;padding:5px;margin:0;';}
                      const msgs=document.getElementById('messages'); if(msgs){msgs.style.cssText='min-height:45px;max-height:105px;overflow-y:auto;padding:5px;margin:0;';}
                      const form=document.getElementById('chatForm'); if(form){form.style.cssText='display:flex;gap:5px;margin:5px 0 0;';}
                      const input=document.getElementById('chatText'); if(input){input.placeholder='اكتبي سؤالك هنا…';input.style.minHeight='38px';}
                      const consent=document.getElementById('chatConsentWrap'); if(consent) consent.style.display='none';
                      const panel=document.getElementById(target); if(panel){panel.style.setProperty('display','block','important');panel.style.setProperty('margin','0','important');panel.style.setProperty('padding','8px','important');panel.style.setProperty('overflow-y','auto','important');}
                      document.querySelectorAll('.view').forEach(x=>{if(x.id!==target)x.style.setProperty('display','none','important')});
                      document.body.style.cssText='margin:0;padding:0;background:#f3f7f5;overflow-y:auto;overflow-x:hidden;';
                      document.documentElement.style.cssText='height:100%;overflow:auto;';
                    })();"""
                    view?.evaluateJavascript(script, null)
                }
            }
        }
        assistantWebView = web
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val anchor = params
        val lp = WindowManager.LayoutParams(panelWidth, panelHeight, type, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (anchor?.x ?: 10).coerceAtMost((screenWidth - panelWidth).coerceAtLeast(0))
            y = ((anchor?.y ?: (screenHeight/3)) + (70*density).toInt()).coerceAtMost((screenHeight-panelHeight).coerceAtLeast(0))
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        try {
            windowManager.addView(root, lp)
            assistantPanel = root
            val target = when(command) {
                "settings" -> "settings"
                "behavior" -> "behavior"
                "plan" -> "tasks"
                "family" -> "family"
                "prayer" -> "prayer"
                "habits" -> "habits"
                "eye" -> "settings"
                "voice" -> "assistant"
                else -> "assistant"
            }
            web.loadUrl("file:///android_asset/index.html")
            web.postVisualStateCallback(0L, object : WebView.VisualStateCallback() {
                override fun onComplete(requestId: Long) {
                    web.evaluateJavascript("window.__alislahOverlayTarget='$target';document.querySelectorAll('.view').forEach(x=>{const show=x.id==='$target';x.classList.toggle('active',show);x.style.display=show?'block':'none'});", null)
                    if (target == "assistant") { handler.removeCallbacks(pollReply); handler.postDelayed(pollReply, 2500L) }
                    selectOverlaySection(command)
                }
            })
        } catch (_: Exception) {
            assistantPanel = null
            assistantWebView = null
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("openAssistant", true)
            }
            startActivity(launch)
        }
    }

    private fun selectOverlaySection(command: String) {
        val js = when(command) {
            "settings" -> "document.querySelector('[data-tab=\"settings\"]')?.click();"
            "behavior" -> "document.querySelector('[data-tab=\"behavior\"]')?.click();"
            "plan" -> "document.querySelector('[data-tab=\"tasks\"]')?.click();"
            "family" -> "document.querySelector('[data-tab=\"family\"]')?.click();"
            "prayer" -> "document.querySelector('[data-tab=\"prayer\"]')?.click();"
            "habits" -> "document.querySelector('[data-tab=\"habits\"]')?.click();"
            "eye" -> "document.querySelector('[data-tab=\"settings\"]')?.click();setTimeout(()=>document.getElementById('eyeBreakEnabled')?.scrollIntoView({block:'center'}),180);"
            "voice" -> "document.querySelector('[data-tab=\"assistant\"]')?.click();setTimeout(()=>document.getElementById('alislahVoiceGender')?.scrollIntoView({block:'center'}),180);"
            "question" -> "var q=document.getElementById('chatText');if(q){q.value='سؤال سريع: ما أكثر شيء يشغل وقتك الآن؟';q.focus();}"
            else -> "document.querySelector('[data-tab=\"assistant\"]')?.click();document.getElementById('chatText')?.focus();"
        }
        assistantWebView?.evaluateJavascript(js, null)
    }

    private fun hideAssistantOverlay() {
        handler.removeCallbacks(pollReply)
        assistantWebView?.stopLoading()
        assistantWebView?.destroy()
        assistantWebView = null
        assistantPanel?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        assistantPanel = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel("alislah_bubble", "فقاعة ALISLAH", NotificationManager.IMPORTANCE_LOW).apply { description = "إبقاء الفقاعة العائمة متاحة فوق التطبيقات" })
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "alislah_bubble").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("فقاعة ALISLAH مفعّلة").setContentText("اضغطي على الفقاعة لفتح المساعد الذكي").setContentIntent(open).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("فقاعة ALISLAH مفعّلة").setContentText("اضغطي على الفقاعة لفتح المساعد الذكي").setContentIntent(open).setOngoing(true).build()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(reshowBubble)
        handler.removeCallbacks(pollReply)
        hideCloseButton()
        hideQuickMenu()
        hideAssistantOverlay()
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        tts = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_ANSWERED = "dz.alislah.app.ACTION_ASSISTANT_ANSWERED"
        const val ACTION_SHOW_FOR_EVENT = "dz.alislah.app.ACTION_SHOW_BUBBLE_FOR_EVENT"
        const val ACTION_HIDE_PANEL = "dz.alislah.app.ACTION_HIDE_PANEL"
        const val ACTION_SPEAK_TEST = "dz.alislah.app.ACTION_SPEAK_TEST"
    }
}
