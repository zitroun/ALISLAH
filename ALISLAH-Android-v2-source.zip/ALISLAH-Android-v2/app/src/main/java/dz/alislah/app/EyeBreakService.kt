package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.speech.tts.TextToSpeech
import java.util.Locale
import org.json.JSONObject
import org.json.JSONArray

/** User-enabled 20-20-20 reminder. Uses a black overlay; Android apps cannot power off the display without device-admin privileges. */
class EyeBreakService : Service(), TextToSpeech.OnInitListener {
    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var overlay: LinearLayout? = null
    private var tts: TextToSpeech? = null
    private var elapsedMs = 0L
    private var lastTick = 0L
    private var breakUntil = 0L
    private var minutes = 20
    private var seconds = 20
    private var initialized = false
    private var currentContent = "انظري بعيدًا عن الشاشة قليلًا"
    private var currentSource = "تذكير لراحة العين"
    private data class SavedContent(val id: String, val text: String, val source: String, val type: String)
    private fun nextSavedContent(): SavedContent? {
        return try {
            val raw = getSharedPreferences("alislah_native", MODE_PRIVATE).getString("eyeBreakContentCache", "{}") ?: "{}"
            val root = JSONObject(raw)
            val used = root.optJSONObject("used") ?: JSONObject()
            val order = listOf("verses", "hadith", "benefits")
            val start = getSharedPreferences("alislah_native", MODE_PRIVATE).getInt("eyeBreakContentCursor", 0).let { ((it % order.size) + order.size) % order.size }
            for (offset in order.indices) {
                val type = order[(start + offset) % order.size]
                val list = root.optJSONArray(type) ?: JSONArray()
                val seen = used.optJSONArray(type) ?: JSONArray()
                val usedIds = (0 until seen.length()).map { seen.optString(it) }.toSet()
                for (i in 0 until list.length()) {
                    val item = list.optJSONObject(i) ?: continue
                    val id = item.optString("id")
                    val text = item.optString("text").trim()
                    if (id.isNotBlank() && text.isNotBlank() && id !in usedIds) {
                        val nextUsed = JSONArray(); for (v in 0 until seen.length()) nextUsed.put(seen.optString(v)); nextUsed.put(id)
                        used.put(type, nextUsed)
                        root.put("used", used)
                        getSharedPreferences("alislah_native", MODE_PRIVATE).edit()
                            .putString("eyeBreakContentCache", root.toString())
                            .putInt("eyeBreakContentCursor", (start + offset + 1) % order.size).apply()
                        return SavedContent(id, text.take(900), item.optString("source", "محتوى محفوظ"), type)
                    }
                }
            }
            null
        } catch (_: Exception) { null }
    }
    private val ticker = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val screenOn = pm.isInteractive
            if (breakUntil > now) {
                showBreak((breakUntil - now + 999) / 1000, currentContent, currentSource)
            } else if (breakUntil != 0L) {
                hideBreak(); breakUntil = 0L; elapsedMs = 0L; lastTick = now
            } else if (screenOn) {
                if (lastTick > 0L) elapsedMs += (now - lastTick).coerceAtMost(2500L)
                lastTick = now
                if (elapsedMs >= minutes.coerceIn(1, 180) * 60_000L) beginBreak()
            } else {
                lastTick = 0L
            }
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("alislah_eye_break", "استراحة العين 20-20-20", NotificationManager.IMPORTANCE_LOW))
            startForeground(9442, Notification.Builder(this, "alislah_eye_break").setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("استراحة العين مفعّلة").setContentText("تذكير اختياري عند استخدام الشاشة").setOngoing(true).build())
        }
        tts = TextToSpeech(this, this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        handler.post(ticker)
    }

    override fun onInit(status: Int) { initialized = status == TextToSpeech.SUCCESS; if (initialized) tts?.language = Locale("ar") }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        minutes = intent?.getIntExtra("minutes", getSharedPreferences("alislah_native", MODE_PRIVATE).getInt("eyeBreakMinutes", 20)) ?: 20
        seconds = intent?.getIntExtra("seconds", getSharedPreferences("alislah_native", MODE_PRIVATE).getInt("eyeBreakSeconds", 20)) ?: 20
        return START_STICKY
    }

    private fun beginBreak() {
        elapsedMs = 0L
        breakUntil = System.currentTimeMillis() + seconds.coerceIn(5, 120) * 1000L
        val saved = nextSavedContent()
        val fact = saved?.text ?: "أبعدي نظرك عن الشاشة وانظري إلى شيء بعيد لإراحة العينين."
        val source = saved?.source ?: "تذكير لراحة العين"
        currentContent = fact
        currentSource = source
        if (initialized) tts?.speak(fact, TextToSpeech.QUEUE_FLUSH, null, "eye_break_saved_content")
        showBreak(seconds.toLong(), fact, source)
    }

    private fun showBreak(left: Long, content: String = "انظري بعيدًا عن الشاشة قليلًا", source: String = "") {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) return
        try {
            if (overlay == null) {
                val density = resources.displayMetrics.density
                val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding((24*density).toInt(), (24*density).toInt(), (24*density).toInt(), (24*density).toInt()); setBackgroundColor(Color.BLACK) }
                val title = TextView(this).apply { text = "استراحة العين"; textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
                val msg = TextView(this).apply { tag = "message"; text = content; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, (16*density).toInt(), 0, (16*density).toInt()) }
                val counter = TextView(this).apply { tag = "counter"; textSize = 32f; setTextColor(Color.rgb(155,229,197)); gravity = Gravity.CENTER }
                val sourceView = TextView(this).apply { tag = "source"; text = source; textSize = 12f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER }; root.addView(title); root.addView(msg); root.addView(sourceView); root.addView(counter)
                val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
                val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.OPAQUE).apply { gravity = Gravity.TOP or Gravity.START }
                wm?.addView(root, lp); overlay = root
            }
            overlay?.findViewWithTag<TextView>("message")?.text = content
            overlay?.findViewWithTag<TextView>("source")?.text = source
            overlay?.findViewWithTag<TextView>("counter")?.text = "${left.coerceAtLeast(0)}"
        } catch (_: Exception) { }
    }

    private fun hideBreak() { try { overlay?.let { wm?.removeView(it) } } catch (_: Exception) {}; overlay = null; if (initialized) tts?.stop() }
    override fun onDestroy() { handler.removeCallbacks(ticker); hideBreak(); tts?.stop(); tts?.shutdown(); (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(9442); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
    companion object { const val ACTION_STOP = "dz.alislah.app.STOP_EYE_BREAK" }
}
