package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

/**
 * User-enabled 20-20-20 reminder. Shows a calm full-screen rest card with a "skip" button.
 * It never interrupts calls or media playback, and only speaks when the ringer is on.
 */
class EyeBreakService : Service(), TextToSpeech.OnInitListener {
    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var overlay: LinearLayout? = null
    private var counterView: TextView? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var elapsedMs = 0L
    private var lastTick = 0L
    private var breakUntil = 0L
    private var minutes = 20
    private var seconds = 20
    private val facts = listOf(
        "معلومة: الرمش المتكرر وإبعاد النظر عن الشاشة يريحان العينين.",
        "معلومة: المشي القصير بين المهام يساعدك على تغيير وضعية الجسم.",
        "تذكير: ارخِ كتفيك وخذ نفسًا عميقًا، ثم عُد إلى عملك.",
        "قال رسول الله صلى الله عليه وسلم: الكلمة الطيبة صدقة. متفق عليه."
    )

    private val ticker = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (breakUntil > now) {
                updateCounter((breakUntil - now + 999L) / 1000L)
            } else if (breakUntil != 0L) {
                hideBreak()
                breakUntil = 0L
                elapsedMs = 0L
                lastTick = now
            } else {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                if (pm.isInteractive) {
                    if (lastTick > 0L) elapsedMs += (now - lastTick).coerceAtMost(12_000L)
                    lastTick = now
                    val limit = minutes.coerceIn(1, 180) * 60_000L
                    if (elapsedMs >= limit) {
                        if (shouldPostpone()) {
                            elapsedMs = (limit - 60_000L).coerceAtLeast(0L) // ask again in about a minute
                        } else {
                            beginBreak()
                        }
                    }
                } else {
                    lastTick = 0L
                }
            }
            handler.postDelayed(this, if (breakUntil != 0L) 1000L else 5000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("alislah_eye_break", "استراحة العين 20-20-20", NotificationManager.IMPORTANCE_LOW))
        startForeground(
            9442,
            Notification.Builder(this, "alislah_eye_break")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("استراحة العين مفعّلة")
                .setContentText("تذكير اختياري عند استخدام الشاشة")
                .setOngoing(true)
                .build()
        )
        tts = TextToSpeech(this, this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        handler.post(ticker)
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale("ar")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val prefs = getSharedPreferences("alislah_native", MODE_PRIVATE)
        minutes = intent?.getIntExtra("minutes", prefs.getInt("eyeBreakMinutes", 20)) ?: prefs.getInt("eyeBreakMinutes", 20)
        seconds = intent?.getIntExtra("seconds", prefs.getInt("eyeBreakSeconds", 20)) ?: prefs.getInt("eyeBreakSeconds", 20)
        return START_STICKY
    }

    /** Never cover a call, a video call, or media that is playing. */
    private fun shouldPostpone(): Boolean {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val mode = audio.mode
        return mode == AudioManager.MODE_IN_CALL ||
            mode == AudioManager.MODE_IN_COMMUNICATION ||
            mode == AudioManager.MODE_RINGTONE ||
            audio.isMusicActive
    }

    private fun beginBreak() {
        elapsedMs = 0L
        breakUntil = System.currentTimeMillis() + seconds.coerceIn(5, 120) * 1000L
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (ttsReady && audio.ringerMode == AudioManager.RINGER_MODE_NORMAL) {
            val fact = facts[(System.currentTimeMillis() / 1000L % facts.size).toInt()]
            tts?.speak(fact, TextToSpeech.QUEUE_FLUSH, null, "eye_break_fact")
        }
        showBreak(seconds.toLong())
    }

    private fun endBreakNow() {
        breakUntil = 0L
        elapsedMs = 0L
        lastTick = System.currentTimeMillis()
        hideBreak()
    }

    private fun buildOverlay(): LinearLayout {
        val d = resources.displayMetrics.density
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val pad = (28 * d).toInt()
        root.setPadding(pad, pad, pad, pad)
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.rgb(8, 36, 30), Color.rgb(15, 79, 67)))

        val title = TextView(this)
        title.text = "استراحة العين"
        title.textSize = 26f
        title.setTextColor(Color.WHITE)
        title.gravity = Gravity.CENTER

        val msg = TextView(this)
        msg.text = "انظري إلى شيء بعيد (نحو 6 أمتار) وأرخي كتفيك"
        msg.textSize = 18f
        msg.setTextColor(Color.rgb(214, 240, 230))
        msg.gravity = Gravity.CENTER
        msg.setPadding(0, (16 * d).toInt(), 0, (8 * d).toInt())

        val counter = TextView(this)
        counter.textSize = 64f
        counter.setTextColor(Color.rgb(155, 229, 197))
        counter.gravity = Gravity.CENTER
        counterView = counter

        val skip = Button(this)
        skip.text = "تخطي"
        skip.textSize = 16f
        skip.setTextColor(Color.rgb(18, 61, 50))
        val bg = GradientDrawable()
        bg.setColor(Color.rgb(217, 246, 233))
        bg.cornerRadius = 28 * d
        skip.background = bg
        skip.setOnClickListener { endBreakNow() }
        val lpBtn = LinearLayout.LayoutParams((200 * d).toInt(), (52 * d).toInt())
        lpBtn.topMargin = (24 * d).toInt()

        root.addView(title)
        root.addView(msg)
        root.addView(counter)
        root.addView(skip, lpBtn)
        return root
    }

    private fun showBreak(left: Long) {
        if (!Settings.canDrawOverlays(this)) return
        try {
            if (overlay == null) {
                val root = buildOverlay()
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.OPAQUE
                )
                lp.gravity = Gravity.TOP or Gravity.START
                wm?.addView(root, lp)
                overlay = root
            }
            updateCounter(left)
        } catch (_: Exception) { }
    }

    private fun updateCounter(left: Long) {
        counterView?.text = left.coerceAtLeast(0L).toString()
    }

    private fun hideBreak() {
        try { overlay?.let { wm?.removeView(it) } } catch (_: Exception) { }
        overlay = null
        counterView = null
        if (ttsReady) tts?.stop()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        hideBreak()
        tts?.stop()
        tts?.shutdown()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(9442)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "dz.alislah.app.STOP_EYE_BREAK"
    }
}
