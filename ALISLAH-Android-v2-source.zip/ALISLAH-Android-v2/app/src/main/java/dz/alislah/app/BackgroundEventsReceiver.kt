package dz.alislah.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Alarms for the optional follow-up question, the daily digest and the weekly backup reminder. */
object BackgroundScheduler {
    private const val PREFS = "alislah_native"
    private const val QUESTION_REQUEST = 91001
    private const val LEGACY_PRAYER_REQUEST = 91002
    private const val DIGEST_MORNING_REQUEST = 91011
    private const val DIGEST_EVENING_REQUEST = 91012
    private const val BACKUP_REQUEST = 91013
    private const val QUIET_START_HOUR = 22
    private const val QUIET_END_HOUR = 8

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun pending(context: Context, request: Int, action: String): PendingIntent {
        val i = Intent(context, BackgroundEventsReceiver::class.java).setAction(action)
        return PendingIntent.getBroadcast(context, request, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun alarmManager(context: Context) = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun arm(context: Context, at: Long, request: Int, action: String) {
        try { alarmManager(context).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(context, request, action)) } catch (_: Exception) { }
    }

    private fun disarm(context: Context, request: Int, action: String) {
        try { alarmManager(context).cancel(pending(context, request, action)) } catch (_: Exception) { }
    }

    /** Moves a time that falls in quiet hours (22:00–08:00) to 08:00 so questions never wake the user. */
    fun avoidQuietHours(at: Long): Long {
        val c = Calendar.getInstance().apply { timeInMillis = at }
        val h = c.get(Calendar.HOUR_OF_DAY)
        if (h >= QUIET_START_HOUR) c.add(Calendar.DAY_OF_YEAR, 1)
        if (h >= QUIET_START_HOUR || h < QUIET_END_HOUR) {
            c.set(Calendar.HOUR_OF_DAY, QUIET_END_HOUR)
            c.set(Calendar.MINUTE, 0)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
        }
        return c.timeInMillis
    }

    fun scheduleQuestion(context: Context, at: Long) {
        arm(context, avoidQuietHours(at), QUESTION_REQUEST, BackgroundEventsReceiver.ACTION_QUESTION)
    }

    fun cancelQuestion(context: Context) {
        disarm(context, QUESTION_REQUEST, BackgroundEventsReceiver.ACTION_QUESTION)
    }

    /** Old versions scheduled one repeating "next prayer" alarm; PrayerScheduler replaces it. */
    fun cancelLegacyPrayer(context: Context) {
        try { prefs(context).edit().remove("backgroundAdhanEnabled").remove("backgroundPrayerTimes").apply() } catch (_: Exception) { }
        disarm(context, LEGACY_PRAYER_REQUEST, BackgroundEventsReceiver.ACTION_PRAYER)
    }

    fun questionsEnabled(context: Context): Boolean = prefs(context).getBoolean("backgroundQuestionsEnabled", false)

    fun scheduleQuestionIfEnabled(context: Context) {
        if (questionsEnabled(context)) scheduleQuestion(context, System.currentTimeMillis() + 4 * 60 * 60 * 1000L)
    }

    /** Next occurrence of "HH:mm" after [from]. */
    private fun nextAt(time: String, from: Long): Long {
        val parts = time.split(":")
        val h = (parts.getOrNull(0)?.toIntOrNull() ?: 8).coerceIn(0, 23)
        val m = (parts.getOrNull(1)?.toIntOrNull() ?: 0).coerceIn(0, 59)
        val c = Calendar.getInstance().apply {
            timeInMillis = from
            set(Calendar.HOUR_OF_DAY, h)
            set(Calendar.MINUTE, m)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis <= from + 1000L) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    /** Reads the saved digest configuration ({"morning":{"on":bool,"time":"HH:mm"},"evening":{...}}) and arms the alarms. */
    fun scheduleDigest(context: Context) {
        disarm(context, DIGEST_MORNING_REQUEST, BackgroundEventsReceiver.ACTION_DIGEST_MORNING)
        disarm(context, DIGEST_EVENING_REQUEST, BackgroundEventsReceiver.ACTION_DIGEST_EVENING)
        val raw = prefs(context).getString("digestConfig", null) ?: return
        try {
            val cfg = JSONObject(raw)
            val now = System.currentTimeMillis()
            val morning = cfg.optJSONObject("morning")
            if (morning != null && morning.optBoolean("on", false)) {
                arm(context, nextAt(morning.optString("time", "07:30"), now), DIGEST_MORNING_REQUEST, BackgroundEventsReceiver.ACTION_DIGEST_MORNING)
            }
            val evening = cfg.optJSONObject("evening")
            if (evening != null && evening.optBoolean("on", false)) {
                arm(context, nextAt(evening.optString("time", "21:00"), now), DIGEST_EVENING_REQUEST, BackgroundEventsReceiver.ACTION_DIGEST_EVENING)
            }
        } catch (_: Exception) { }
    }

    /** Weekly reminder every Friday at 17:00 while enabled. */
    fun scheduleBackupReminder(context: Context) {
        disarm(context, BACKUP_REQUEST, BackgroundEventsReceiver.ACTION_BACKUP_REMINDER)
        if (!prefs(context).getBoolean("backupReminder", false)) return
        val c = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_WEEK, Calendar.FRIDAY)
            set(Calendar.HOUR_OF_DAY, 17)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis <= System.currentTimeMillis() + 1000L) c.add(Calendar.DAY_OF_YEAR, 7)
        arm(context, c.timeInMillis, BACKUP_REQUEST, BackgroundEventsReceiver.ACTION_BACKUP_REMINDER)
    }

    fun rescheduleAll(context: Context) {
        cancelLegacyPrayer(context)
        scheduleQuestionIfEnabled(context)
        scheduleDigest(context)
        scheduleBackupReminder(context)
    }
}

class BackgroundEventsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        when (action) {
            ACTION_QUESTION -> {
                if (!BackgroundScheduler.questionsEnabled(context)) return
                showNotification(context, CHANNEL, "أسئلة المتابعة", "سؤال متابعة من ALISLAH", "كيف كان تركيزك وطاقتك خلال الساعات الماضية؟", 9201, "assistant", true)
                BackgroundScheduler.scheduleQuestionIfEnabled(context)
            }
            ACTION_DIGEST_MORNING -> {
                showDigest(context, true)
                BackgroundScheduler.scheduleDigest(context)
            }
            ACTION_DIGEST_EVENING -> {
                showDigest(context, false)
                BackgroundScheduler.scheduleDigest(context)
            }
            ACTION_BACKUP_REMINDER -> {
                showNotification(context, CHANNEL_DIGEST, "الملخص اليومي والتذكيرات", "نسخة احتياطية", "احفظي نسخة من مهامك وعاداتك الآن لتبقى بياناتك في أمان.", 9203, "settings", false)
                BackgroundScheduler.scheduleBackupReminder(context)
            }
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> {
                BackgroundScheduler.rescheduleAll(context)
                ReminderStore.rescheduleAll(context)
                PrayerScheduler.rescheduleAll(context)
                AlislahWidgetProvider.refreshAll(context)
            }
            // ACTION_PRAYER: legacy alarm from older versions, ignored on purpose.
        }
    }

    private fun showDigest(context: Context, morning: Boolean) {
        val snap = Snapshot.read(context)
        val fresh = snap.optString("date") == Snapshot.todayKey()
        val name = snap.optString("name", "").trim()
        val greet = (if (morning) "صباح الخير" else "مساء الخير") + (if (name.isNotEmpty()) " يا $name" else "")
        val pending = snap.optInt("pending", 0)
        val done = snap.optInt("done", 0)
        val sb = StringBuilder()
        if (morning) {
            if (fresh) {
                if (pending == 0) sb.append("لا مهام متبقية اليوم.") else sb.append("لديك ").append(pending).append(" مهام اليوم.")
                val top = snap.optJSONArray("top")
                if (top != null && top.length() > 0 && pending > 0) sb.append(" أولها: ").append(top.optString(0)).append(".")
            } else {
                sb.append("افتحي ALISLAH لمراجعة مهام يومك.")
            }
            val next = Snapshot.nextPrayer(context)
            if (next != null) {
                sb.append("\nالصلاة القادمة: ").append(next.first).append(" الساعة ").append(SimpleDateFormat("HH:mm", Locale.US).format(Date(next.second))).append(".")
            }
        } else {
            if (fresh) {
                sb.append("أنجزتِ ").append(done).append(" مهام اليوم")
                if (pending > 0) sb.append(" وبقي ").append(pending) else sb.append("، أحسنتِ")
                sb.append(".")
            } else {
                sb.append("افتحي ALISLAH لمراجعة ما أنجزتِه اليوم.")
            }
        }
        showNotification(context, CHANNEL_DIGEST, "الملخص اليومي والتذكيرات", greet, sb.toString(), if (morning) 9204 else 9205, "tasks", false)
    }

    private fun showNotification(context: Context, channel: String, channelName: String, title: String, body: String, id: Int, openTab: String, backgroundQuestion: Boolean) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(channel, channelName, NotificationManager.IMPORTANCE_DEFAULT))
        val open = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (openTab == "assistant") putExtra("openAssistant", true) else putExtra("openTab", openTab)
            if (backgroundQuestion) putExtra("backgroundQuestion", true)
        }
        val pi = PendingIntent.getActivity(context, id, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(context, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try { nm.notify(id, n) } catch (_: SecurityException) { }
    }

    companion object {
        const val ACTION_QUESTION = "dz.alislah.app.BACKGROUND_QUESTION"
        const val ACTION_PRAYER = "dz.alislah.app.BACKGROUND_PRAYER"
        const val ACTION_DIGEST_MORNING = "dz.alislah.app.DIGEST_MORNING"
        const val ACTION_DIGEST_EVENING = "dz.alislah.app.DIGEST_EVENING"
        const val ACTION_BACKUP_REMINDER = "dz.alislah.app.BACKUP_REMINDER"
        const val EXTRA_PRAYER = "prayer_name"
        const val CHANNEL = "alislah_background_events"
        const val CHANNEL_DIGEST = "alislah_digest"
    }
}
