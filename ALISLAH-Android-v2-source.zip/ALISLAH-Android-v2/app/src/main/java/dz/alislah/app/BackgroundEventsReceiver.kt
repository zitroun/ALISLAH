package dz.alislah.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject
import java.util.Calendar

object BackgroundScheduler {
    private const val QUESTION_REQUEST = 91001
    private const val PRAYER_REQUEST = 91002

    private fun pending(context: Context, request: Int, action: String): PendingIntent {
        val i = Intent(context, BackgroundEventsReceiver::class.java).setAction(action)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        return PendingIntent.getBroadcast(context, request, i, flags)
    }
    fun scheduleQuestion(context: Context, at: Long) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try { alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(context, QUESTION_REQUEST, BackgroundEventsReceiver.ACTION_QUESTION)) } catch (_: Exception) {}
    }
    fun cancelQuestion(context: Context) {
        try { (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(context, QUESTION_REQUEST, BackgroundEventsReceiver.ACTION_QUESTION)) } catch (_: Exception) {}
    }
    fun scheduleNextPrayer(context: Context) {
        val prefs = context.getSharedPreferences("alislah_native", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("backgroundAdhanEnabled", false)) {
            try { (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(context, PRAYER_REQUEST, BackgroundEventsReceiver.ACTION_PRAYER)) } catch (_: Exception) {}
            return
        }
        val raw = prefs.getString("backgroundPrayerTimes", "{}") ?: "{}"
        val times = try { JSONObject(raw) } catch (_: Exception) { JSONObject() }
        val prayerNames = linkedMapOf("Fajr" to "الفجر", "Dhuhr" to "الظهر", "Asr" to "العصر", "Maghrib" to "المغرب", "Isha" to "العشاء")
        val now = System.currentTimeMillis()
        var best = Long.MAX_VALUE
        var bestName = ""
        for ((key, label) in prayerNames) {
            val hm = times.optString(key, "").take(5).split(":")
            if (hm.size != 2) continue
            val hour = hm[0].toIntOrNull() ?: continue
            val minute = hm[1].toIntOrNull() ?: continue
            val c = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= now + 15000) add(Calendar.DAY_OF_YEAR, 1)
            }
            if (c.timeInMillis < best) { best = c.timeInMillis; bestName = label }
        }
        if (best == Long.MAX_VALUE || bestName.isBlank()) return
        prefs.edit().putString("nextPrayerName", bestName).apply()
        val i = Intent(context, BackgroundEventsReceiver::class.java).setAction(BackgroundEventsReceiver.ACTION_PRAYER).putExtra(BackgroundEventsReceiver.EXTRA_PRAYER, bestName)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val pi = PendingIntent.getBroadcast(context, PRAYER_REQUEST, i, flags)
        try { (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best, pi) } catch (_: Exception) {}
    }
    fun scheduleQuestionIfEnabled(context: Context) {
        val p = context.getSharedPreferences("alislah_native", Context.MODE_PRIVATE)
        if (p.getBoolean("backgroundQuestionsEnabled", true)) scheduleQuestion(context, System.currentTimeMillis() + 4 * 60 * 60 * 1000L)
    }
}

class BackgroundEventsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        when (action) {
            ACTION_QUESTION -> {
                val prefs = context.getSharedPreferences("alislah_native", Context.MODE_PRIVATE)
                if (!prefs.getBoolean("backgroundQuestionsEnabled", true)) return
                showNotification(context, "سؤال متابعة من ALISLAH", "كيف كان تركيزك وطاقتك خلال الساعات الماضية؟", 9201, true)
                BackgroundScheduler.scheduleQuestionIfEnabled(context)
            }
            ACTION_PRAYER -> {
                val prefs = context.getSharedPreferences("alislah_native", Context.MODE_PRIVATE)
                if (prefs.getBoolean("backgroundAdhanEnabled", false)) {
                    val name = intent.getStringExtra(EXTRA_PRAYER) ?: prefs.getString("nextPrayerName", "الصلاة") ?: "الصلاة"
                    showNotification(context, "حان وقت صلاة $name", "افتحي ALISLAH لمتابعة سجل الصلاة.", 9202, false)
                    val play = Intent(context, PrayerVoiceService::class.java).putExtra(EXTRA_PRAYER, name)
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(play) else context.startService(play)
                    } catch (_: Exception) { }
                }
                BackgroundScheduler.scheduleNextPrayer(context)
            }
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> {
                BackgroundScheduler.scheduleQuestionIfEnabled(context)
                BackgroundScheduler.scheduleNextPrayer(context)
            }
        }
    }
    private fun showNotification(context: Context, title: String, body: String, id: Int, question: Boolean) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "تنبيهات ALISLAH", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "أسئلة متابعة وتنبيهات الصلاة بعد إغلاق التطبيق"
            })
        }
        val open = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("openAssistant", question)
            putExtra("backgroundQuestion", question)
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val pi = PendingIntent.getActivity(context, id, open, flags)
        val n = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context, CHANNEL) else @Suppress("DEPRECATION") Notification.Builder(context)
        nm.notify(id, n.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body)).setContentIntent(pi).setAutoCancel(true).build())
    }
    companion object {
        const val ACTION_QUESTION = "dz.alislah.app.BACKGROUND_QUESTION"
        const val ACTION_PRAYER = "dz.alislah.app.BACKGROUND_PRAYER"
        const val EXTRA_PRAYER = "prayer_name"
        const val CHANNEL = "alislah_background_events"
    }
}
