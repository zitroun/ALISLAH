package dz.alislah.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

/** Follow-up question notifications (opt-in) + rescheduling of everything after reboot/update. */
object BackgroundScheduler {
    private const val QUESTION_REQUEST = 91001
    private const val LEGACY_PRAYER_REQUEST = 91002
    private const val QUIET_START_HOUR = 22
    private const val QUIET_END_HOUR = 8

    private fun pending(context: Context, request: Int, action: String): PendingIntent {
        val i = Intent(context, BackgroundEventsReceiver::class.java).setAction(action)
        return PendingIntent.getBroadcast(context, request, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    /** Moves a time that falls in quiet hours (22:00–08:00) to 08:00 so questions never wake the user. */
    fun avoidQuietHours(at: Long): Long {
        val c = Calendar.getInstance().apply { timeInMillis = at }
        val h = c.get(Calendar.HOUR_OF_DAY)
        if (h >= QUIET_START_HOUR) c.add(Calendar.DAY_OF_YEAR, 1)
        if (h >= QUIET_START_HOUR || h < QUIET_END_HOUR) {
            c.set(Calendar.HOUR_OF_DAY, QUIET_END_HOUR); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        }
        return c.timeInMillis
    }

    fun scheduleQuestion(context: Context, at: Long) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, avoidQuietHours(at), pending(context, QUESTION_REQUEST, BackgroundEventsReceiver.ACTION_QUESTION))
        } catch (_: Exception) { }
    }

    fun cancelQuestion(context: Context) {
        try { (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(context, QUESTION_REQUEST, BackgroundEventsReceiver.ACTION_QUESTION)) } catch (_: Exception) { }
    }

    /** Old versions scheduled one repeating "next prayer" alarm; PrayerScheduler replaces it. */
    fun cancelLegacyPrayer(context: Context) {
        try { (context.getSharedPreferences("alislah_native", Context.MODE_PRIVATE)).edit().remove("backgroundAdhanEnabled").remove("backgroundPrayerTimes").apply() } catch (_: Exception) { }
        try { (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(context, LEGACY_PRAYER_REQUEST, BackgroundEventsReceiver.ACTION_PRAYER)) } catch (_: Exception) { }
    }

    fun questionsEnabled(context: Context): Boolean =
        context.getSharedPreferences("alislah_native", Context.MODE_PRIVATE).getBoolean("backgroundQuestionsEnabled", false)

    fun scheduleQuestionIfEnabled(context: Context) {
        if (questionsEnabled(context)) scheduleQuestion(context, System.currentTimeMillis() + 4 * 60 * 60 * 1000L)
    }
}

class BackgroundEventsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        when (action) {
            ACTION_QUESTION -> {
                if (!BackgroundScheduler.questionsEnabled(context)) return
                showNotification(context, "سؤال متابعة من ALISLAH", "كيف كان تركيزك وطاقتك خلال الساعات الماضية؟", 9201)
                BackgroundScheduler.scheduleQuestionIfEnabled(context)
            }
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> {
                BackgroundScheduler.cancelLegacyPrayer(context)
                BackgroundScheduler.scheduleQuestionIfEnabled(context)
                ReminderStore.rescheduleAll(context)
                PrayerScheduler.rescheduleAll(context)
            }
            // ACTION_PRAYER: legacy alarm from older versions, ignored on purpose.
        }
    }

    private fun showNotification(context: Context, title: String, body: String, id: Int) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "أسئلة المتابعة", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "أسئلة متابعة اختيارية يمكن إيقافها من الإعدادات"
        })
        val open = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("openAssistant", true)
            putExtra("backgroundQuestion", true)
        }
        val pi = PendingIntent.getActivity(context, id, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body)).setContentIntent(pi).setAutoCancel(true).build()
        try { nm.notify(id, n) } catch (_: SecurityException) { }
    }

    companion object {
        const val ACTION_QUESTION = "dz.alislah.app.BACKGROUND_QUESTION"
        const val ACTION_PRAYER = "dz.alislah.app.BACKGROUND_PRAYER"
        const val EXTRA_PRAYER = "prayer_name"
        const val CHANNEL = "alislah_background_events"
    }
}
