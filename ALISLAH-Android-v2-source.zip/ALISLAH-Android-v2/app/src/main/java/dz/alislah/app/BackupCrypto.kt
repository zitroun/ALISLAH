package dz.alislah.app

import android.util.Base64
import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** AES-256-GCM with a PBKDF2-HMAC-SHA256 key derived from the user's passphrase. */
object BackupCrypto {
    private const val FORMAT = "alislah-enc-v1"
    private const val ITERATIONS = 150_000

    private fun key(pass: CharArray, salt: ByteArray, iterations: Int): SecretKeySpec {
        val spec = PBEKeySpec(pass, salt, iterations, 256)
        val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        return SecretKeySpec(raw, "AES")
    }

    fun encrypt(plain: String, pass: String): String {
        val rnd = SecureRandom()
        val salt = ByteArray(16)
        rnd.nextBytes(salt)
        val iv = ByteArray(12)
        rnd.nextBytes(iv)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key(pass.toCharArray(), salt, ITERATIONS), GCMParameterSpec(128, iv))
        val ct = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return JSONObject()
            .put("_enc", FORMAT)
            .put("kdf", "PBKDF2-SHA256")
            .put("iter", ITERATIONS)
            .put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .put("iv", Base64.encodeToString(iv, Base64.NO_WRAP))
            .put("ct", Base64.encodeToString(ct, Base64.NO_WRAP))
            .toString()
    }

    /** Returns null when the passphrase is wrong or the file is damaged. */
    fun decrypt(envelope: String, pass: String): String? {
        return try {
            val o = JSONObject(envelope)
            if (o.optString("_enc") != FORMAT) {
                null
            } else {
                val iterations = o.optInt("iter", ITERATIONS).coerceIn(10_000, 1_000_000)
                val salt = Base64.decode(o.getString("salt"), Base64.NO_WRAP)
                val iv = Base64.decode(o.getString("iv"), Base64.NO_WRAP)
                val ct = Base64.decode(o.getString("ct"), Base64.NO_WRAP)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, key(pass.toCharArray(), salt, iterations), GCMParameterSpec(128, iv))
                String(cipher.doFinal(ct), Charsets.UTF_8)
            }
        } catch (_: Exception) {
            null
        }
    }
}
