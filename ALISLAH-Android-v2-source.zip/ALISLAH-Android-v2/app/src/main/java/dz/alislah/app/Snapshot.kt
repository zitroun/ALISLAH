package dz.alislah.app

import android.content.Context
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

/** Small summary of today's tasks pushed from the web layer (used by the widget and the daily digest). */
object Snapshot {
    private const val PREFS = "alislah_native"
    private const val KEY = "snapshot"

    fun save(context: Context, json: String) {
        try {
            JSONObject(json) // validate
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json.take(4000)).apply()
        } catch (_: Exception) { }
    }

    fun read(context: Context): JSONObject =
        try { JSONObject(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }

    fun todayKey(): String {
        val c = Calendar.getInstance()
        return String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    /** Name and time of the next prayer from the latest local app snapshot. */
    fun nextPrayer(context: Context): Pair<String, Long>? {
        val planned = PrayerScheduler.nextAdhan(context)
        if (planned != null) return planned
        val np = read(context).optJSONObject("np") ?: return null
        val at = np.optLong("at", 0L)
        val name = np.optString("name", "")
        return if (name.isNotEmpty() && at > System.currentTimeMillis()) Pair(name, at) else null
    }
}
