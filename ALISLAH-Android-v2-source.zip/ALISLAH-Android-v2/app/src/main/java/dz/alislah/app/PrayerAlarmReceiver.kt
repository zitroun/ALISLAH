package dz.alislah.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != PrayerScheduler.ACTION_PRAYER) return
        val kind = intent.getStringExtra("k") ?: return
        val name = (intent.getStringExtra("n") ?: "").take(30)
        val at = intent.getLongExtra("at", 0L)
        // Ignore alarms delivered very late (for example right after the phone was off).
        val late = at > 0L && System.currentTimeMillis() - at > 10 * 60 * 1000L
        if (!late) {
            when (kind) {
                "adhan" -> PrayerScheduler.playAdhan(context, name)
                "before" -> PrayerScheduler.postBefore(context, name)
                "after" -> PrayerScheduler.postAfter(context, name, intent.getBooleanExtra("q", true))
            }
        }
        if (kind == "adhan") {
            // Top up the alarm window and refresh the widget off the main thread.
            val pending = goAsync()
            Thread {
                try {
                    PrayerScheduler.refill(context)
                    AlislahWidgetProvider.refreshAll(context)
                } catch (_: Exception) {
                } finally {
                    pending.finish()
                }
            }.start()
        }
    }
}
