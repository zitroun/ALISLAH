package dz.alislah.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Notification
import android.app.PendingIntent
import android.os.Build

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val name = intent.getStringExtra("name") ?: "الصلاة"
        val message = intent.getStringExtra("message") ?: "تذكير بالصلاة"
        val isAdhan = intent.getBooleanExtra("adhan", false) && context.getSharedPreferences("alislah_native", Context.MODE_PRIVATE).getBoolean("adhanEnabled", true)
        val service = Intent(context, AdhanService::class.java).putExtra("name", name).putExtra("message", message).putExtra("adhan", isAdhan)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service) else context.startService(service)
    }
}
