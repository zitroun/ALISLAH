package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/** Plays the recorded adhan as a media-playback foreground service so it works with the app closed. */
class PrayerVoiceService : Service() {
    private var player: MediaPlayer? = null
    private var focusRequest: AudioFocusRequest? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            endAdhan()
            return START_NOT_STICKY
        }
        val name = (intent?.getStringExtra(EXTRA_NAME) ?: "").take(30)
        if (!goForeground(name)) {
            PrayerScheduler.postAdhanFallback(this, name)
            stopSelf()
            return START_NOT_STICKY
        }
        startPlayback()
        return START_NOT_STICKY
    }

    private fun goForeground(name: String): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "الأذان", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 7501,
            Intent(this, PrayerVoiceService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val open = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("openTab", "prayer")
        }
        val openPi = PendingIntent.getActivity(this, 7502, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val title = if (name == "اختبار") "اختبار صوت الأذان" else "حان وقت صلاة $name"
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_pause), "إيقاف الأذان", stopPi
        ).build()
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText("اضغطي «إيقاف الأذان» لإنهاء الصوت")
            .setContentIntent(openPi)
            .addAction(stopAction)
            .setOngoing(true)
            .build()
        return try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(NOTIF_ID, n)
            true
        } catch (_: Exception) { false }
    }

    private fun startPlayback() {
        try { player?.release() } catch (_: Exception) { }
        player = null
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT).setAudioAttributes(attrs).build()
        focusRequest = request
        try { audio.requestAudioFocus(request) } catch (_: Exception) { }
        val p = MediaPlayer.create(this, R.raw.adhan, attrs, AudioManager.AUDIO_SESSION_ID_GENERATE)
        if (p == null) { endAdhan(); return }
        player = p
        try { p.setWakeMode(applicationContext, PowerManager.PARTIAL_WAKE_LOCK) } catch (_: Exception) { }
        p.setOnCompletionListener { endAdhan() }
        p.setOnErrorListener { _, _, _ -> endAdhan(); true }
        p.start()
        publishAdhanState(true)
        handler.postDelayed({ endAdhan() }, 5 * 60 * 1000L)
    }

    private fun publishAdhanState(playing: Boolean) {
        getSharedPreferences("alislah_native", MODE_PRIVATE).edit().putBoolean("adhanPlaying", playing).apply()
        sendBroadcast(Intent(FloatingBubbleService.ACTION_ADHAN_STATE).setPackage(packageName).putExtra("playing", playing))
    }

    private fun endAdhan() {
        publishAdhanState(false)
        handler.removeCallbacksAndMessages(null)
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
        focusRequest?.let {
            try { (getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocusRequest(it) } catch (_: Exception) { }
        }
        focusRequest = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) { }
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { player?.release() } catch (_: Exception) { }
        player = null
        publishAdhanState(false)
        super.onDestroy()
    }

    companion object {
        const val EXTRA_NAME = "prayer_name"
        const val ACTION_STOP = "dz.alislah.app.ACTION_STOP_ADHAN"
        private const val CHANNEL = "alislah_adhan_playing"
        private const val NOTIF_ID = 4108
    }
}
