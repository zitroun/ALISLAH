package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder

class PrayerVoiceService : Service() {
    private var player: MediaPlayer? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("alislah_prayer_voice", "صوت الصلاة", NotificationManager.IMPORTANCE_LOW)
            )
            startForeground(
                9301,
                Notification.Builder(this, "alislah_prayer_voice")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("ALISLAH")
                    .setContentText("تشغيل الأذان")
                    .setOngoing(false)
                    .build()
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopPlayback()
        try {
            player = MediaPlayer.create(this, R.raw.adhan)?.apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setOnCompletionListener {
                    stopPlayback()
                    stopSelf()
                }
                setOnErrorListener { _, _, _ ->
                    stopPlayback()
                    stopSelf()
                    true
                }
                start()
            }
            if (player == null) stopSelf()
        } catch (_: Exception) {
            stopPlayback()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun stopPlayback() {
        try { player?.setOnCompletionListener(null); player?.setOnErrorListener(null); player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    override fun onDestroy() {
        stopPlayback()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
