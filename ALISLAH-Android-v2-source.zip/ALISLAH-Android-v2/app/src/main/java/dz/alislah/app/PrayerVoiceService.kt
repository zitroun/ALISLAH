package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import java.util.Locale

class PrayerVoiceService : Service(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var prayer = "الصلاة"
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("alislah_prayer_voice", "صوت الصلاة", NotificationManager.IMPORTANCE_LOW))
            startForeground(9301, Notification.Builder(this, "alislah_prayer_voice")
                .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("ALISLAH")
                .setContentText("تنبيه الصلاة").setOngoing(false).build())
        }
        tts = TextToSpeech(this, this)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        prayer = intent?.getStringExtra(BackgroundEventsReceiver.EXTRA_PRAYER) ?: "الصلاة"
        if (tts != null) speakIfReady()
        return START_NOT_STICKY
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("ar")
            speakIfReady()
        } else stopSelf()
    }
    private fun speakIfReady() {
        val engine = tts ?: return
        engine.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { stopSelf() }
            @Deprecated("Deprecated in Java") override fun onError(utteranceId: String?) { stopSelf() }
            override fun onError(utteranceId: String?, errorCode: Int) { stopSelf() }
        })
        val fajr = if (prayer.contains("الفجر")) "الصلاة خير من النوم، الصلاة خير من النوم. " else ""
        val adhanText = "الله أكبر، الله أكبر. الله أكبر، الله أكبر. أشهد أن لا إله إلا الله، أشهد أن لا إله إلا الله. أشهد أن محمدًا رسول الله، أشهد أن محمدًا رسول الله. ${fajr}حي على الصلاة، حي على الصلاة. حي على الفلاح، حي على الفلاح. الله أكبر، الله أكبر. لا إله إلا الله."
        engine.speak(adhanText, TextToSpeech.QUEUE_FLUSH, null, "alislah_background_prayer")
    }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); tts = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
