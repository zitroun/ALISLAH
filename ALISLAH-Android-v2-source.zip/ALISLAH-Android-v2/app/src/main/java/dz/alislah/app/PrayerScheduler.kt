package dz.alislah.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

object PrayerScheduler {
    fun schedule(context: Context, json: String, beforeMinutes: Int, afterMinutes: Int, adhan: Boolean) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val rows = try { JSONArray(json) } catch (_: Exception) { return }
        val prefs = context.getSharedPreferences("alislah_native", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("adhanEnabled", adhan).apply()
        for (i in 0 until rows.length()) {
            val row = rows.optJSONObject(i) ?: continue
            val name = row.optString("name", "الصلاة")
            val at = row.optLong("at", 0L)
            if (at <= System.currentTimeMillis()) continue
            if (beforeMinutes > 0) scheduleOne(context, alarm, at - beforeMinutes.coerceIn(0,120)*60000L, name, "قبل الصلاة بـ $beforeMinutes دقائق", false, i*3)
            scheduleOne(context, alarm, at, name, "حان وقت صلاة $name", adhan, i*3+1)
            if (afterMinutes > 0) scheduleOne(context, alarm, at + afterMinutes.coerceIn(0,180)*60000L, name, "تذكير بعد صلاة $name", false, i*3+2)
        }
    }
    private fun scheduleOne(context: Context, alarm: AlarmManager, at: Long, name: String, message: String, adhan: Boolean, id: Int) {
        if (at <= System.currentTimeMillis()) return
        val intent = Intent(context, PrayerAlarmReceiver::class.java).putExtra("name", name).putExtra("message", message).putExtra("adhan", adhan).putExtra("id", id)
        val pi = PendingIntent.getBroadcast(context, 9100+id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else alarm.set(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: Exception) { alarm.set(AlarmManager.RTC_WAKEUP, at, pi) }
    }
}
