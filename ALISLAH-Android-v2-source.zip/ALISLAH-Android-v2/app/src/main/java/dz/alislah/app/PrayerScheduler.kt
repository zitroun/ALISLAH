package dz.alislah.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Prayer alarms. The web layer computes the next ~30 days offline and sends them here as
 * [{k: adhan|before|after, n: name, at: epoch ms}]. The plan lives in a small file (not in
 * SharedPreferences) and only the next ACTIVE_WINDOW alarms are armed; the window is topped up
 * whenever an adhan fires. No work happens per alarm except re-arming that small window.
 */
object PrayerScheduler {
    const val ACTION_PRAYER = "dz.alislah.app.ACTION_PRAYER_ALARM"
    const val CHANNEL_REMIND = "alislah_prayer_reminders"
    const val CHANNEL_ADHAN_ALERT = "alislah_adhan_alert"
    private const val PLAN_FILE = "prayer_plan.json"
    private const val LEGACY_PREFS = "alislah_prayer"
    private const val MAX_ITEMS = 700
    private const val ACTIVE_WINDOW = 60
    private const val HORIZON_MS = 35L * 24L * 60L * 60L * 1000L
    private val KINDS = setOf("adhan", "before", "after")
    private val lock = Any()

    private fun planFile(context: Context) = File(context.filesDir, PLAN_FILE)

    private fun readPlan(context: Context): JSONArray {
        return try {
            val f = planFile(context)
            if (f.exists()) JSONArray(f.readText()) else JSONArray()
        } catch (_: Exception) {
            JSONArray()
        }
    }

    private fun writePlan(context: Context, plan: JSONArray) {
        try {
            val f = planFile(context)
            val tmp = File(context.filesDir, "$PLAN_FILE.tmp")
            tmp.writeText(plan.toString())
            if (!tmp.renameTo(f)) {
                f.writeText(plan.toString())
                tmp.delete()
            }
        } catch (_: Exception) { }
    }

    private fun pendingFor(context: Context, kind: String, name: String, at: Long, flags: Int, followup: Boolean = true): PendingIntent? {
        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            action = ACTION_PRAYER
            putExtra("k", kind)
            putExtra("n", name)
            putExtra("at", at)
            putExtra("q", followup)
        }
        val code = ("p|" + kind + "|" + at).hashCode() and 0x7fffffff
        return PendingIntent.getBroadcast(context, code, intent, flags or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun scheduleOne(context: Context, item: JSONObject) {
        val kind = item.optString("k")
        val name = item.optString("n")
        val at = item.optLong("at")
        if (kind !in KINDS || at <= System.currentTimeMillis()) return
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingFor(context, kind, name, at, PendingIntent.FLAG_UPDATE_CURRENT, item.optBoolean("q", true)) ?: return
        try {
            if (kind == "adhan") {
                // setAlarmClock is exact, survives Doze and needs no special permission.
                val show = PendingIntent.getActivity(
                    context, 7300, Intent(context, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (_: Exception) { }
    }

    private fun cancelItems(context: Context, items: JSONArray) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (i in 0 until items.length()) {
            val o = items.optJSONObject(i) ?: continue
            try {
                val pi = pendingFor(context, o.optString("k"), o.optString("n"), o.optLong("at"), PendingIntent.FLAG_NO_CREATE)
                if (pi != null) {
                    am.cancel(pi)
                    pi.cancel()
                }
            } catch (_: Exception) { }
        }
    }

    /** Alarms armed by the previous implementation (SharedPreferences based) are cancelled and removed. */
    private fun cancelLegacy(context: Context) {
        try {
            val p = context.getSharedPreferences(LEGACY_PREFS, Context.MODE_PRIVATE)
            val armed = p.getString("items", null)
            if (armed != null) cancelItems(context, JSONArray(armed))
            if (p.contains("items") || p.contains("annual_plan")) p.edit().remove("items").remove("annual_plan").apply()
        } catch (_: Exception) { }
    }

    /** First run after an update: keep the old plan (next 35 days) so no adhan is missed before the app is opened. */
    private fun migrateLegacy(context: Context) {
        synchronized(lock) {
            try {
                val p = context.getSharedPreferences(LEGACY_PREFS, Context.MODE_PRIVATE)
                val raw = p.getString("annual_plan", null)
                if (raw != null) {
                    val armed = p.getString("items", null)
                    if (armed != null) cancelItems(context, JSONArray(armed))
                    if (!planFile(context).exists()) {
                        val old = JSONArray(raw)
                        val now = System.currentTimeMillis()
                        val list = ArrayList<JSONObject>()
                        for (i in 0 until old.length()) {
                            val o = old.optJSONObject(i) ?: continue
                            val at = o.optLong("at")
                            if (at > now && at < now + HORIZON_MS && o.optString("k") in KINDS) list.add(o)
                        }
                        list.sortBy { it.optLong("at") }
                        val plan = JSONArray()
                        for (o in list.take(MAX_ITEMS)) plan.put(o)
                        writePlan(context, plan)
                    }
                    p.edit().remove("items").remove("annual_plan").apply()
                }
            } catch (_: Exception) { }
        }
    }

    fun sync(context: Context, itemsJson: String, enabled: Boolean) {
        val parsed: JSONArray = try { JSONArray(itemsJson) } catch (_: Exception) { return }
        synchronized(lock) {
            cancelItems(context, readPlan(context))
            cancelLegacy(context)
            if (!enabled) {
                planFile(context).delete()
                AlislahWidgetProvider.refreshAll(context)
                return
            }
            val now = System.currentTimeMillis()
            val list = ArrayList<JSONObject>()
            for (i in 0 until minOf(parsed.length(), 2000)) {
                val o = parsed.optJSONObject(i) ?: continue
                val k = o.optString("k")
                val at = o.optLong("at", 0L)
                if (k !in KINDS || at <= now || at > now + HORIZON_MS) continue
                list.add(JSONObject().put("k", k).put("n", o.optString("n").take(30)).put("at", at).put("q", o.optBoolean("q", true)))
            }
            list.sortBy { it.optLong("at") }
            val plan = JSONArray()
            for (o in list.take(MAX_ITEMS)) plan.put(o)
            writePlan(context, plan)
            refillLocked(context)
        }
        AlislahWidgetProvider.refreshAll(context)
    }

    private fun refillLocked(context: Context) {
        val plan = readPlan(context)
        val now = System.currentTimeMillis()
        var armed = 0
        for (i in 0 until plan.length()) {
            if (armed >= ACTIVE_WINDOW) break
            val o = plan.optJSONObject(i) ?: continue
            if (o.optLong("at") <= now) continue
            scheduleOne(context, o)
            armed++
        }
    }

    fun refill(context: Context) {
        synchronized(lock) { refillLocked(context) }
    }

    fun rescheduleAll(context: Context) {
        migrateLegacy(context)
        refill(context)
    }

    fun nextAdhan(context: Context): Pair<String, Long>? {
        val plan = readPlan(context)
        val now = System.currentTimeMillis()
        for (i in 0 until plan.length()) {
            val o = plan.optJSONObject(i) ?: continue
            if (o.optString("k") == "adhan" && o.optLong("at") > now) return Pair(o.optString("n"), o.optLong("at"))
        }
        return null
    }

    fun playAdhan(context: Context, name: String) {
        val i = Intent(context, PrayerVoiceService::class.java).putExtra(PrayerVoiceService.EXTRA_NAME, name)
        try { context.startForegroundService(i) } catch (_: Exception) { postAdhanFallback(context, name) }
    }

    private fun ensureChannel(context: Context, id: String, name: String, importance: Int, adhanSound: Boolean) {
        val nm = context.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(id) != null) return
        val ch = NotificationChannel(id, name, importance)
        if (adhanSound) {
            val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            ch.setSound(Uri.parse("android.resource://" + context.packageName + "/" + R.raw.adhan), attrs)
        }
        nm.createNotificationChannel(ch)
    }

    private fun notifyEvent(context: Context, channel: String, title: String, text: String) {
        val open = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("openTab", "prayer")
        }
        val pi = PendingIntent.getActivity(context, 7401, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(context, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try {
            context.getSystemService(NotificationManager::class.java).notify((channel + title).hashCode() and 0x7fffffff, n)
        } catch (_: SecurityException) { }
    }

    /** Used when a foreground service cannot be started: a notification that plays the adhan itself. */
    fun postAdhanFallback(context: Context, name: String) {
        ensureChannel(context, CHANNEL_ADHAN_ALERT, "تنبيه الأذان", NotificationManager.IMPORTANCE_HIGH, true)
        notifyEvent(context, CHANNEL_ADHAN_ALERT, "حان وقت صلاة $name", "حيّ على الصلاة")
    }

    fun postBefore(context: Context, name: String) {
        ensureChannel(context, CHANNEL_REMIND, "تذكيرات الصلاة", NotificationManager.IMPORTANCE_DEFAULT, false)
        notifyEvent(context, CHANNEL_REMIND, "اقترب وقت صلاة $name", "استعدّي للصلاة")
    }

    fun postAfter(context: Context, name: String, askFollowup: Boolean = true) {
        ensureChannel(context, CHANNEL_REMIND, "تذكيرات الصلاة", NotificationManager.IMPORTANCE_DEFAULT, false)
        if (askFollowup) notifyEvent(context, CHANNEL_REMIND, "هل صلّيتِ $name؟", "افتحي التطبيق وسجّلي صلاتك")
        else notifyEvent(context, CHANNEL_REMIND, "تذكير صلاة $name", "إذا أديتِ الصلاة، سجّلي إنجازها في ALISLAH")
    }
}
