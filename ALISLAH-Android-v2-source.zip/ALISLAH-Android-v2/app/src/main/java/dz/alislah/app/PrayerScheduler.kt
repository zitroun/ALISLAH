package dz.alislah.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/**
 * Native prayer schedule: the web page computes the times and sends a list of
 * {k: adhan|before|after, n: prayer name, at: epoch millis}. Everything is stored so it
 * can be rebuilt after a reboot / time change.
 */
object PrayerScheduler {
    const val ACTION_PRAYER = "dz.alislah.app.ACTION_PRAYER_ALARM"
    const val CHANNEL_REMIND = "alislah_prayer_reminders"
    const val CHANNEL_ADHAN_ALERT = "alislah_adhan_alert"
    private const val PREFS = "alislah_prayer"
    private const val KEY_ITEMS = "items"
    private const val MAX_ITEMS = 180
    private val KINDS = setOf("adhan", "before", "after")

    private fun loadItems(context: Context): JSONArray =
        try { JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ITEMS, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }

    private fun storeItems(context: Context, items: JSONArray) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ITEMS, items.toString()).apply()
    }

    private fun pendingFor(context: Context, kind: String, name: String, at: Long, flags: Int): PendingIntent? {
        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            action = ACTION_PRAYER
            putExtra("k", kind)
            putExtra("n", name)
            putExtra("at", at)
        }
        val code = ("p|" + kind + "|" + at).hashCode() and 0x7fffffff
        return PendingIntent.getBroadcast(context, code, intent, flags or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun scheduleOne(context: Context, kind: String, name: String, at: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingFor(context, kind, name, at, PendingIntent.FLAG_UPDATE_CURRENT) ?: return
        try {
            if (kind == "adhan") {
                // setAlarmClock is exact, survives Doze and needs no special permission.
                val show = PendingIntent.getActivity(
                    context, 7300, Intent(context, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (_: Exception) { }
    }

    private fun cancelAll(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val items = loadItems(context)
        for (i in 0 until items.length()) {
            val o = items.optJSONObject(i) ?: continue
            try {
                val pi = pendingFor(context, o.optString("k"), o.optString("n"), o.optLong("at"), PendingIntent.FLAG_NO_CREATE)
                if (pi != null) { am.cancel(pi); pi.cancel() }
            } catch (_: Exception) { }
        }
        storeItems(context, JSONArray())
    }

    fun sync(context: Context, itemsJson: String, enabled: Boolean) {
        val parsed: JSONArray = try { JSONArray(itemsJson) } catch (_: Exception) { return }
        cancelAll(context)
        if (!enabled) return
        val now = System.currentTimeMillis()
        val list = ArrayList<JSONObject>()
        for (i in 0 until minOf(parsed.length(), 600)) {
            val o = parsed.optJSONObject(i) ?: continue
            val k = o.optString("k")
            val at = o.optLong("at", 0L)
            if (k !in KINDS || at <= now) continue
            list.add(JSONObject().put("k", k).put("n", o.optString("n").take(30)).put("at", at))
        }
        list.sortBy { it.optLong("at") }
        val out = JSONArray()
        for (o in list.take(MAX_ITEMS)) {
            out.put(o)
            scheduleOne(context, o.getString("k"), o.getString("n"), o.getLong("at"))
        }
        storeItems(context, out)
    }

    fun rescheduleAll(context: Context) {
        val items = loadItems(context)
        val now = System.currentTimeMillis()
        val keep = JSONArray()
        for (i in 0 until items.length()) {
            val o = items.optJSONObject(i) ?: continue
            val at = o.optLong("at", 0L)
            if (at <= now) continue
            keep.put(o)
            scheduleOne(context, o.optString("k"), o.optString("n"), at)
        }
        storeItems(context, keep)
    }

    fun markFired(context: Context, kind: String, at: Long) {
        val items = loadItems(context)
        val keep = JSONArray()
        for (i in 0 until items.length()) {
            val o = items.optJSONObject(i) ?: continue
            if (o.optString("k") == kind && o.optLong("at") == at) continue
            keep.put(o)
        }
        storeItems(context, keep)
    }

    fun playAdhan(context: Context, name: String) {
        val i = Intent(context, PrayerVoiceService::class.java).putExtra(PrayerVoiceService.EXTRA_NAME, name)
        try { context.startForegroundService(i) } catch (_: Exception) { postAdhanFallback(context, name) }
    }

    private fun ensureChannel(context: Context, id: String, name: String, importance: Int, adhanSound: Boolean) {
        val nm = context.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(id) != null) return
        val ch = NotificationChannel(id, name, importance)
        if (adhanSound) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            ch.setSound(Uri.parse("android.resource://" + context.packageName + "/" + R.raw.adhan), attrs)
        }
        nm.createNotificationChannel(ch)
    }

    private fun notifyEvent(context: Context, channel: String, title: String, text: String) {
        val open = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("openTab", "prayer")
        }
        val pi = PendingIntent.getActivity(context, 7401, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(context, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try {
            context.getSystemService(NotificationManager::class.java).notify((channel + title).hashCode() and 0x7fffffff, n)
        } catch (_: SecurityException) { }
    }

    /** Used when a foreground service cannot be started: a notification that plays the adhan itself. */
    fun postAdhanFallback(context: Context, name: String) {
        ensureChannel(context, CHANNEL_ADHAN_ALERT, "تنبيه الأذان", NotificationManager.IMPORTANCE_HIGH, true)
        notifyEvent(context, CHANNEL_ADHAN_ALERT, "حان وقت صلاة $name", "حيّ على الصلاة")
    }

    fun postBefore(context: Context, name: String) {
        ensureChannel(context, CHANNEL_REMIND, "تذكيرات الصلاة", NotificationManager.IMPORTANCE_DEFAULT, false)
        notifyEvent(context, CHANNEL_REMIND, "اقترب وقت صلاة $name", "استعدّي للصلاة")
    }

    fun postAfter(context: Context, name: String) {
        ensureChannel(context, CHANNEL_REMIND, "تذكيرات الصلاة", NotificationManager.IMPORTANCE_DEFAULT, false)
        notifyEvent(context, CHANNEL_REMIND, "هل صلّيتِ $name؟", "افتحي التطبيق وسجّلي صلاتك ضمن عاداتك")
    }
}
