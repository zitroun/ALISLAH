package dz.alislah.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** Annual prayer plan stored locally; Android alarms are kept in a rolling queue. */
object PrayerScheduler {
    const val ACTION_PRAYER = "dz.alislah.app.ACTION_PRAYER_ALARM"
    const val CHANNEL_REMIND = "alislah_prayer_reminders"
    const val CHANNEL_ADHAN_ALERT = "alislah_adhan_alert"
    private const val PREFS = "alislah_prayer"
    private const val KEY_ITEMS = "items"       // currently armed alarms
    private const val KEY_PLAN = "annual_plan"   // complete upcoming plan
    private const val MAX_ACTIVE = 180           // safe rolling batch; replenished on every event
    private val KINDS = setOf("adhan", "before", "after")

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun load(context: Context, key: String): JSONArray =
        try { JSONArray(prefs(context).getString(key, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
    private fun store(context: Context, key: String, items: JSONArray) {
        prefs(context).edit().putString(key, items.toString()).apply()
    }
    private fun pendingFor(context: Context, kind: String, name: String, at: Long, flags: Int, followup: Boolean = true): PendingIntent? {
        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            action = ACTION_PRAYER; putExtra("k", kind); putExtra("n", name); putExtra("at", at); putExtra("q", followup)
        }
        val code = ("p|" + kind + "|" + at).hashCode() and 0x7fffffff
        return PendingIntent.getBroadcast(context, code, intent, flags or PendingIntent.FLAG_IMMUTABLE)
    }
    private fun scheduleOne(context: Context, item: JSONObject) {
        val kind = item.optString("k"); val name = item.optString("n"); val at = item.optLong("at")
        if (kind !in KINDS || at <= System.currentTimeMillis()) return
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingFor(context, kind, name, at, PendingIntent.FLAG_UPDATE_CURRENT, item.optBoolean("q", true)) ?: return
        try {
            if (kind == "adhan") {
                val show = PendingIntent.getActivity(context, 7300, Intent(context, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi)
            } else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: Exception) { }
    }
    private fun cancelActive(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val active = load(context, KEY_ITEMS)
        for (i in 0 until active.length()) {
            val o = active.optJSONObject(i) ?: continue
            try {
                val pi = pendingFor(context, o.optString("k"), o.optString("n"), o.optLong("at"), PendingIntent.FLAG_NO_CREATE)
                if (pi != null) { am.cancel(pi); pi.cancel() }
            } catch (_: Exception) { }
        }
        store(context, KEY_ITEMS, JSONArray())
    }

    /** Receives all future prayer events from the year cache; only the next batch is armed. */
    fun sync(context: Context, itemsJson: String, enabled: Boolean) {
        val parsed = try { JSONArray(itemsJson) } catch (_: Exception) { return }
        cancelActive(context)
        if (!enabled) { store(context, KEY_PLAN, JSONArray()); return }
        val now = System.currentTimeMillis()
        val list = ArrayList<JSONObject>()
        for (i in 0 until minOf(parsed.length(), 6000)) {
            val o = parsed.optJSONObject(i) ?: continue
            val k = o.optString("k"); val at = o.optLong("at", 0L)
            if (k !in KINDS || at <= now) continue
            list.add(JSONObject().put("k", k).put("n", o.optString("n").take(30)).put("at", at).put("q", o.optBoolean("q", true)))
        }
        list.sortBy { it.optLong("at") }
        val plan = JSONArray(); list.forEach { plan.put(it) }
        store(context, KEY_PLAN, plan)
        refill(context)
    }

    /** Re-arm the next 180 future events without discarding the rest of the annual plan. */
    fun refill(context: Context) {
        cancelActive(context)
        val plan = load(context, KEY_PLAN)
        val now = System.currentTimeMillis()
        val future = ArrayList<JSONObject>()
        for (i in 0 until plan.length()) {
            val o = plan.optJSONObject(i) ?: continue
            if (o.optLong("at", 0L) > now && o.optString("k") in KINDS) future.add(o)
        }
        future.sortBy { it.optLong("at") }
        val active = JSONArray()
        for (item in future.take(MAX_ACTIVE)) { active.put(item); scheduleOne(context, item) }
        store(context, KEY_ITEMS, active)
    }

    fun rescheduleAll(context: Context) = refill(context)
    fun markFired(context: Context, kind: String, at: Long) {
        val plan = load(context, KEY_PLAN)
        val keep = JSONArray()
        for (i in 0 until plan.length()) {
            val item = plan.optJSONObject(i) ?: continue
            if (item.optString("k") == kind && item.optLong("at") == at) continue
            keep.put(item)
        }
        store(context, KEY_PLAN, keep)
        refill(context)
    }
    fun playAdhan(context: Context, name: String) {
        val i = Intent(context, PrayerVoiceService::class.java).putExtra(PrayerVoiceService.EXTRA_NAME, name)
        try { context.startForegroundService(i) } catch (_: Exception) { postAdhanFallback(context, name) }
    }
    private fun ensureChannel(context: Context, id: String, name: String, importance: Int, adhanSound: Boolean) {
        val nm = context.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(id) != null) return
        val ch = NotificationChannel(id, name, importance)
        if (adhanSound) {
            val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            ch.setSound(Uri.parse("android.resource://" + context.packageName + "/" + R.raw.adhan), attrs)
        }
        nm.createNotificationChannel(ch)
    }
    private fun notifyEvent(context: Context, channel: String, title: String, text: String) {
        val open = Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP; putExtra("openTab", "prayer") }
        val pi = PendingIntent.getActivity(context, 7401, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(context, channel).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title)
            .setContentText(text).setStyle(Notification.BigTextStyle().bigText(text)).setContentIntent(pi).setAutoCancel(true).build()
        try { context.getSystemService(NotificationManager::class.java).notify((channel + title).hashCode() and 0x7fffffff, n) } catch (_: SecurityException) { }
    }
    fun postAdhanFallback(context: Context, name: String) {
        ensureChannel(context, CHANNEL_ADHAN_ALERT, "تنبيه الأذان", NotificationManager.IMPORTANCE_HIGH, true)
        notifyEvent(context, CHANNEL_ADHAN_ALERT, "حان وقت صلاة $name", "حيّ على الصلاة")
    }
    private fun prayerReminderText(at: Long): String {
        // Authentic short reminders; each quotation is accompanied by its exact source.
        val reminders = listOf(
            "﴿حَافِظُوا عَلَى الصَّلَوَاتِ وَالصَّلَاةِ الْوُسْطَىٰ﴾ — البقرة: 238",
            "﴿وَاسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ﴾ — البقرة: 45",
            "قال رسول الله ﷺ: «الصلاة نور» — صحيح مسلم (223)"
        )
        val index = ((at / 60000L) % reminders.size).toInt().coerceAtLeast(0)
        return reminders[index]
    }

    fun postBefore(context: Context, name: String) {
        ensureChannel(context, CHANNEL_REMIND, "تذكيرات الصلاة", NotificationManager.IMPORTANCE_DEFAULT, false)
        notifyEvent(context, CHANNEL_REMIND, "اقترب وقت صلاة $name", "تهيأ للصلاة 🌿\n" + prayerReminderText(System.currentTimeMillis()))
    }
    fun postAfter(context: Context, name: String, askFollowup: Boolean = true) {
        ensureChannel(context, CHANNEL_REMIND, "تذكيرات الصلاة", NotificationManager.IMPORTANCE_DEFAULT, false)
        if (askFollowup) notifyEvent(context, CHANNEL_REMIND, "هل صليت $name؟", "افتح التطبيق وسجّل الصلاة ضمن عاداتك")
        else notifyEvent(context, CHANNEL_REMIND, "تذكير صلاة $name", "إذا أديت الصلاة، سجّل إنجازها في ALISLAH")
    }
}
