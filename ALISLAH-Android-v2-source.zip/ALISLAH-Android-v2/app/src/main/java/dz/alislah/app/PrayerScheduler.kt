package dz.alislah.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray

object PrayerScheduler {
    private const val PREFS = "alislah_native"
    fun schedule(context: Context, json: String, beforeMinutes: Int, afterMinutes: Int, adhan: Boolean) {
        val rows = try { JSONArray(json) } catch (_: Exception) { return }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("adhanEnabled", adhan).putString("prayerRows", json)
            .putInt("prayerBefore", beforeMinutes).putInt("prayerAfter", afterMinutes).apply()
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        // Clear older slots first so a failed/shorter refresh cannot leave stale prayer alarms behind.
        for (id in 0 until 256) {
            val oldIntent = Intent(context, PrayerAlarmReceiver::class.java)
            val old = PendingIntent.getBroadcast(context, 9100 + id, oldIntent, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
            if (old != null) { alarm.cancel(old); old.cancel() }
        }
        for (i in 0 until rows.length()) {
            val row = rows.optJSONObject(i) ?: continue
            val name = row.optString("name", "الصلاة"); val at = row.optLong("at", 0L)
            if (at <= System.currentTimeMillis()) continue
            if (beforeMinutes > 0) scheduleOne(context, alarm, at - beforeMinutes.coerceIn(0,120)*60000L, name, "بقي $beforeMinutes دقائق على صلاة $name", false, i*3)
            scheduleOne(context, alarm, at, name, "حان وقت صلاة $name", adhan, i*3+1)
            if (afterMinutes > 0) scheduleOne(context, alarm, at + afterMinutes.coerceIn(0,180)*60000L, name, "تذكير بعد صلاة $name", false, i*3+2)
        }
    }
    fun restore(context: Context) {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val json = p.getString("prayerRows", null) ?: return
        schedule(context, json, p.getInt("prayerBefore", 0), p.getInt("prayerAfter", 0), p.getBoolean("adhanEnabled", true))
    }
    private fun scheduleOne(context: Context, alarm: AlarmManager, at: Long, name: String, message: String, adhan: Boolean, id: Int) {
        if (at <= System.currentTimeMillis()) return
        val intent = Intent(context, PrayerAlarmReceiver::class.java).putExtra("name", name).putExtra("message", message).putExtra("adhan", adhan).putExtra("id", id)
        val pi = PendingIntent.getBroadcast(context, 9100+id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarm.canScheduleExactAlarms()) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else alarm.setExact(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: Exception) { try { alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) } catch (_: Exception) {} }
    }
}
