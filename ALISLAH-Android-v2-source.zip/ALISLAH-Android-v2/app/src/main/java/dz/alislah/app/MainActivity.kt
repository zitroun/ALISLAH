package dz.alislah.app

import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import java.util.Calendar

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("alislah_native", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = false
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return url == null || !url.startsWith("file:///android_asset/")
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectNativeControls()
                openAssistantIfRequested()
            }
        }
        webView.addJavascriptInterface(NativeBridge(), "AndroidUsage")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        if (prefs.getBoolean("overlayEnabled", false) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
            startBubbleService()
        }
        if (::webView.isInitialized) webView.postDelayed({
            if (!isFinishing) webView.evaluateJavascript("document.getElementById('refreshUsage')?.click();", null)
        }, 400)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) setIntent(intent)
        webView.postDelayed({ openAssistantIfRequested() }, 350)
    }

    private fun openAssistantIfRequested() {
        val currentIntent = intent ?: return
        if (currentIntent.getBooleanExtra("openAssistant", false) && ::webView.isInitialized) {
            webView.evaluateJavascript("document.querySelector('[data-tab=\\\"assistant\\\"]')?.click();", null)
            currentIntent.removeExtra("openAssistant")
        }
    }

    private fun injectNativeControls() {
        val js = """(function(){
          const root=document.getElementById('settings'); if(!root||document.getElementById('nativeOverlayControls')) return;
          const box=document.createElement('div'); box.id='nativeOverlayControls';
          box.style.cssText='margin:12px 0;padding:12px;border:1px solid #dce7e2;border-radius:12px;background:#fff';
          const title=document.createElement('strong'); title.textContent='الفقاعة العائمة خارج التطبيق'; box.appendChild(title);
          const p=document.createElement('p'); p.textContent='فعّلي الإذن ليظهر زر ALISLAH فوق التطبيقات الأخرى. عند الضغط عليه يفتح المساعد الذكي.'; p.style.cssText='margin:6px 0;font-size:14px;color:#66766f'; box.appendChild(p);
          const on=document.createElement('button'); on.type='button'; on.textContent='تفعيل الفقاعة العائمة'; on.style.cssText='padding:9px 12px;margin:4px;border:0;border-radius:10px;background:#176b5b;color:white'; on.onclick=()=>AndroidUsage.enableOverlay(); box.appendChild(on);
          const off=document.createElement('button'); off.type='button'; off.textContent='إيقاف الفقاعة'; off.style.cssText='padding:9px 12px;margin:4px;border:1px solid #dce7e2;border-radius:10px;background:#fff;color:#18312b'; off.onclick=()=>AndroidUsage.disableOverlay(); box.appendChild(off);
          root.prepend(box);
        })();"""
        webView.evaluateJavascript(js, null)
    }

    private fun startBubbleService() {
        val i = Intent(this, FloatingBubbleService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    private fun enableOverlay() {
        prefs.edit().putBoolean("overlayEnabled", true).apply()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else startBubbleService()
    }

    private fun disableOverlay() {
        prefs.edit().putBoolean("overlayEnabled", false).apply()
        stopService(Intent(this, FloatingBubbleService::class.java))
    }

    private fun hasUsagePermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun todayStartMillis(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun readUsageJson(): String {
        val result = JSONObject().put("permission", hasUsagePermission())
        val apps = JSONArray()
        if (hasUsagePermission()) {
            val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val stats: List<UsageStats> = manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, todayStartMillis(), System.currentTimeMillis()) ?: emptyList()
            val grouped = stats.filter { it.totalTimeInForeground > 0 && it.packageName != packageName }
                .groupBy { it.packageName }
                .map { (pkg, rows) -> pkg to rows.sumOf { it.totalTimeInForeground } }
                .sortedByDescending { it.second }.take(20)
            for ((pkg, millis) in grouped) {
                val appName = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
                apps.put(JSONObject().put("packageName", pkg).put("name", appName).put("minutes", (millis / 60000.0).toInt()))
            }
        }
        return result.put("apps", apps).put("collectedAt", System.currentTimeMillis()).toString()
    }

    inner class NativeBridge {
        @JavascriptInterface fun getUsageStatsJson(): String = readUsageJson()
        @JavascriptInterface fun requestUsagePermission() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply { data = Uri.parse("package:$packageName") }) }
        }
        @JavascriptInterface fun enableOverlay() { runOnUiThread { this@MainActivity.enableOverlay() } }
        @JavascriptInterface fun disableOverlay() { runOnUiThread { this@MainActivity.disableOverlay() } }
    }
}
