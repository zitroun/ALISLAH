package dz.alislah.app

import android.app.Activity
import android.app.PendingIntent
import android.Manifest
import android.content.pm.PackageManager
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.PermissionRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.app.NotificationManager
import android.content.res.Configuration
import android.graphics.drawable.ColorDrawable
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import android.view.View
import org.json.JSONArray
import org.json.JSONObject
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.app.usage.UsageEvents
import java.util.Calendar

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("alislah_native", Context.MODE_PRIVATE) }
    private var pendingWebPermission: PermissionRequest? = null
    private val AUDIO_PERMISSION_REQUEST = 7801
    private val NOTIFICATION_PERMISSION_REQUEST = 7802
    private var recognizer: SpeechRecognizer? = null
    private var assistantTts: TextToSpeech? = null
    @Volatile private var assistantTtsReady = false
    private var lastAssistantSpeech: String? = null
    private var lastSpeechUsedNetworkVoice = false
    private var lastUsageRefresh = 0L
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingBackup: String? = null
    private val FILE_CHOOSER_REQUEST = 7803
    private val BACKUP_SAVE_REQUEST = 7804

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        assistantTts = TextToSpeech(this) { status ->
            assistantTtsReady = status == TextToSpeech.SUCCESS
            if (assistantTtsReady) {
                assistantTts?.setLanguage(Locale("ar"))
                selectAssistantTtsVoice(hasValidatedInternet())
                assistantTts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { }
                    override fun onDone(utteranceId: String?) { }
                    override fun onError(utteranceId: String?) {
                        runOnUiThread {
                            val retryText = lastAssistantSpeech
                            if (lastSpeechUsedNetworkVoice && !retryText.isNullOrBlank()) {
                                lastSpeechUsedNetworkVoice = false
                                selectAssistantTtsVoice(false)
                                try { assistantTts?.speak(retryText, TextToSpeech.QUEUE_FLUSH, null, "alislah-local-fallback-${System.currentTimeMillis()}") } catch (_: Exception) { }
                            }
                        }
                    }
                })
            }
        }

        // Match the system bars and the page background to the light/dark theme (no white flash).
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val bg = if (night) 0xFF0E1A17.toInt() else 0xFFF3F7F5.toInt()
        window.setBackgroundDrawable(ColorDrawable(bg))
        window.statusBarColor = if (night) 0xFF0A1412.toInt() else 0xFF0F4F43.toInt()
        window.navigationBarColor = bg
        if (!night && Build.VERSION.SDK_INT >= 26) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        webView = WebView(this)
        webView.setBackgroundColor(bg)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        // The page is loaded from file:///android_asset, which stays readable with these disabled.
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.allowFileAccessFromFileURLs = false
        webView.settings.allowUniversalAccessFromFileURLs = false
        webView.webChromeClient = object : WebChromeClient() {
            // Without this the <input type="file"> used by "restore backup" never opens in a WebView.
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    val chooser = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    startActivityForResult(chooser, FILE_CHOOSER_REQUEST)
                    true
                } catch (_: Exception) {
                    fileCallback = null
                    callback?.onReceiveValue(null)
                    false
                }
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val wantsAudio = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    if (wantsAudio && Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        pendingWebPermission = request
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_REQUEST)
                    } else {
                        val allowed = request.resources.filter { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }
                        if (allowed.isNotEmpty() && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) request.grant(allowed.toTypedArray()) else request.deny()
                    }
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return url == null || !url.startsWith("file:///android_asset/")
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                BackgroundScheduler.cancelLegacyPrayer(this@MainActivity)
                openAssistantIfRequested()
            }
            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                runOnUiThread { recreate() }
                return true
            }
        }
        webView.addJavascriptInterface(NativeBridge(), "AndroidUsage")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        try { recognizer?.destroy() } catch (_: Exception) { }
        recognizer = null
        try { assistantTts?.stop(); assistantTts?.shutdown() } catch (_: Exception) { }
        assistantTts = null
        assistantTtsReady = false
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        if (prefs.getBoolean("overlayEnabled", false) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
            startBubbleService()
            hideBubblePanel() // never keep two editors of the same data alive
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
            if (prefs.getBoolean("eyeBreakServiceEnabled", false)) {
                val eye = Intent(this, EyeBreakService::class.java)
                    .putExtra("minutes", prefs.getInt("eyeBreakMinutes", 20))
                    .putExtra("seconds", prefs.getInt("eyeBreakSeconds", 20))
                try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(eye) else startService(eye) } catch (_: Exception) { }
            }
            if (prefs.getBoolean("eyeFilterEnabled", false)) {
                try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(Intent(this, EyeFilterService::class.java)) else startService(Intent(this, EyeFilterService::class.java)) } catch (_: Exception) { }
            }
        }
        if (::webView.isInitialized) webView.postDelayed({
            if (!isFinishing) {
                webView.evaluateJavascript("window.__alislahSync && window.__alislahSync();", null)
                val nowMs = System.currentTimeMillis()
                if (nowMs - lastUsageRefresh > 60_000L) {
                    lastUsageRefresh = nowMs
                    webView.evaluateJavascript("document.getElementById('refreshUsage')?.click();", null)
                }
            }
        }, 400)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) setIntent(intent)
        webView.postDelayed({ openAssistantIfRequested() }, 350)
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!::webView.isInitialized) { super.onBackPressed(); return }
        webView.evaluateJavascript("(window.__alislahBack && window.__alislahBack()) ? '1' : '0'") { result ->
            if (result == "\"1\"" || result == "1") return@evaluateJavascript
            super.onBackPressed()
        }
    }

    private fun openAssistantIfRequested() {
        val currentIntent = intent ?: return
        if (!::webView.isInitialized) return
        if (currentIntent.getBooleanExtra("openAssistant", false)) {
            webView.evaluateJavascript("document.querySelector('[data-tab=assistant]')?.click();", null)
            if (currentIntent.getBooleanExtra("backgroundQuestion", false)) {
                webView.postDelayed({
                    webView.evaluateJavascript("(function(){var x=document.getElementById('chatText');if(x){x.value='متابعة سريعة: كيف كان تركيزي وطاقتي خلال الساعات الماضية؟ وما أهم شيء أريد تحسينه الآن؟';x.focus();} })();", null)
                }, 700)
                currentIntent.removeExtra("backgroundQuestion")
            }
            currentIntent.removeExtra("openAssistant")
        }
        if (currentIntent.getStringExtra("openTab") == "prayer") {
            webView.evaluateJavascript("document.querySelector('[data-tab=prayer]')?.click();", null)
            currentIntent.removeExtra("openTab")
        }
    }

    private fun hideBubblePanel() {
        val i = Intent(this, FloatingBubbleService::class.java).apply { action = FloatingBubbleService.ACTION_HIDE_PANEL }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    private fun sendSpeech(kind: String, value: String) {
        if (!::webView.isInitialized) return
        webView.evaluateJavascript("window.__alislahSpeech && window.__alislahSpeech(" + JSONObject.quote(kind) + "," + JSONObject.quote(value) + ");", null)
    }

    private fun startNativeListening() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_REQUEST)
            sendSpeech("error", "not-allowed"); sendSpeech("end", "")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { sendSpeech("error", "unavailable"); sendSpeech("end", ""); return }
        try { recognizer?.destroy() } catch (_: Exception) { }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) { sendSpeech("error", error.toString()); sendSpeech("end", "") }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                sendSpeech("result", text); sendSpeech("end", "")
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-DZ")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try { r.startListening(i) } catch (_: Exception) { sendSpeech("error", "failed"); sendSpeech("end", "") }
    }

    private fun jsToast(message: String) {
        if (!::webView.isInitialized) return
        webView.evaluateJavascript("window.__toast && window.__toast(" + JSONObject.quote(message) + ");", null)
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            FILE_CHOOSER_REQUEST -> {
                fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
                fileCallback = null
            }
            BACKUP_SAVE_REQUEST -> {
                val json = pendingBackup
                pendingBackup = null
                val uri = data?.data
                if (resultCode == RESULT_OK && uri != null && json != null) {
                    val ok = try {
                        contentResolver.openOutputStream(uri, "wt")?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                        true
                    } catch (_: Exception) { false }
                    jsToast(if (ok) "تم حفظ النسخة الاحتياطية" else "تعذر حفظ الملف")
                }
            }
        }
    }

    private fun openAppSettingsScreen() {
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (_: Exception) { }
    }

    private fun startBubbleService() {
        val i = Intent(this, FloatingBubbleService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    private fun enableOverlay() {
        prefs.edit().putBoolean("overlayEnabled", true).apply()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else startBubbleService()
    }

    private fun disableOverlay() {
        prefs.edit().putBoolean("overlayEnabled", false).apply()
        stopService(Intent(this, FloatingBubbleService::class.java))
    }

    private fun requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_REQUEST)
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == AUDIO_PERMISSION_REQUEST) {
            val request = pendingWebPermission
            pendingWebPermission = null
            if (request != null) {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else request.deny()
            }
        }
    }

    private fun hasUsagePermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun todayStartMillis(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun readUsageJson(): String {
        val result = JSONObject().put("permission", hasUsagePermission())
        val apps = JSONArray()
        if (hasUsagePermission()) {
            val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val stats: List<UsageStats> = manager.queryAndAggregateUsageStats(todayStartMillis(), System.currentTimeMillis())?.values?.toList() ?: emptyList()
            val grouped = stats.filter { it.totalTimeInForeground > 0 && it.packageName != packageName }
                .groupBy { it.packageName }
                .map { (pkg, rows) -> pkg to rows.sumOf { it.totalTimeInForeground } }
                .sortedByDescending { it.second }.take(20)
            for ((pkg, millis) in grouped) {
                val appName = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
                apps.put(JSONObject().put("packageName", pkg).put("name", appName).put("minutes", (millis / 60000.0).toInt()))
            }
        }
        var foreground = JSONObject().put("name", "غير متاح").put("packageName", "").put("approximate", true)
        if (hasUsagePermission()) {
            try {
                val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                val now = System.currentTimeMillis()
                val events = manager.queryEvents(now - 2 * 60 * 60 * 1000L, now)
                val event = UsageEvents.Event()
                var latestTime = 0L
                var latestPackage = ""
                while (events.hasNextEvent()) {
                    events.getNextEvent(event)
                    val isForeground = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
                    } else {
                        @Suppress("DEPRECATION") event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
                    }
                    if (isForeground && event.timeStamp >= latestTime) {
                        latestTime = event.timeStamp
                        latestPackage = event.packageName ?: ""
                    }
                }
                if (latestPackage.isNotBlank()) {
                    val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(latestPackage, 0)).toString() } catch (_: Exception) { latestPackage }
                    foreground = JSONObject().put("name", label).put("packageName", latestPackage)
                        .put("lastSeenAt", latestTime).put("approximate", true)
                }
            } catch (_: Exception) { }
        }
        return result.put("apps", apps).put("foreground", foreground).put("collectedAt", System.currentTimeMillis()).toString()
    }

    private fun hasValidatedInternet(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (_: Exception) { false }
    }

    /** Use an Arabic network voice online and a local Arabic voice offline. */
    private fun selectAssistantTtsVoice(preferNetwork: Boolean = hasValidatedInternet()): Boolean {
        val engine = assistantTts ?: return false
        if (!assistantTtsReady) return false
        try {
            val gender = prefs.getString("assistantVoiceGender", "female") ?: "female"
            val arabic = engine.voices.orEmpty().filter { it.locale?.language == "ar" }
            val genderPattern = if (gender == "male") Regex("male|man|ahmed|hamza|omar|ذكر|رجل", RegexOption.IGNORE_CASE)
                else Regex("female|woman|salma|amira|hoda|laila|sara|أنثى|امرأة", RegexOption.IGNORE_CASE)
            val genderMatches = arabic.filter { genderPattern.containsMatchIn(it.name) }
            val pool = if (genderMatches.isNotEmpty()) genderMatches else arabic
            val networkVoice = pool.firstOrNull { it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NETWORK_SYNTHESIS) == true }
            val localVoice = pool.firstOrNull { it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NETWORK_SYNTHESIS) != true }
            val chosen: Voice? = if (preferNetwork) networkVoice ?: localVoice else localVoice ?: networkVoice
            if (chosen != null) engine.voice = chosen else engine.setLanguage(Locale("ar"))
            engine.setSpeechRate(0.94f)
            return chosen != null && chosen.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NETWORK_SYNTHESIS) == true
        } catch (_: Exception) {
            try { engine.setLanguage(Locale("ar")) } catch (_: Exception) { }
            return false
        }
    }

    inner class NativeBridge {
        @JavascriptInterface fun getUsageStatsJson(): String = readUsageJson()
        @JavascriptInterface fun setAssistantVoice(gender: String) {
            prefs.edit().putString("assistantVoiceGender", if (gender == "male") "male" else "female").apply()
            runOnUiThread { selectAssistantTtsVoice() }
        }
        @JavascriptInterface fun speakAssistant(text: String): Boolean {
            if (!assistantTtsReady || text.isBlank()) return false
            val safeText = text.take(5000)
            runOnUiThread {
                lastAssistantSpeech = safeText
                lastSpeechUsedNetworkVoice = selectAssistantTtsVoice(hasValidatedInternet())
                try { assistantTts?.speak(safeText, TextToSpeech.QUEUE_FLUSH, null, "alislah-assistant-${System.currentTimeMillis()}") } catch (_: Exception) { }
            }
            return true
        }
        @JavascriptInterface fun stopAssistantSpeech() {
            runOnUiThread { try { assistantTts?.stop() } catch (_: Exception) { } }
        }
        @JavascriptInterface fun playAdhanTest() { runOnUiThread { PrayerScheduler.playAdhan(this@MainActivity, "اختبار") } }
        @JavascriptInterface fun stopAdhan() {
            runOnUiThread {
                try { startService(Intent(this@MainActivity, PrayerVoiceService::class.java).apply { action = PrayerVoiceService.ACTION_STOP }) } catch (_: Exception) { }
            }
        }
        @JavascriptInterface fun enableEyeFilter() {
            runOnUiThread {
                prefs.edit().putBoolean("eyeFilterEnabled", true).apply()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else { val i = Intent(this@MainActivity, EyeFilterService::class.java); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) }
            }
        }
        @JavascriptInterface fun disableEyeFilter() {
            runOnUiThread { prefs.edit().putBoolean("eyeFilterEnabled", false).apply(); stopService(Intent(this@MainActivity, EyeFilterService::class.java)) }
        }
        @JavascriptInterface fun configureEyeBreak(enabled: Boolean, minutes: Int, seconds: Int) {
            runOnUiThread {
                prefs.edit().putBoolean("eyeBreakServiceEnabled", enabled)
                    .putInt("eyeBreakMinutes", minutes.coerceIn(1,180)).putInt("eyeBreakSeconds", seconds.coerceIn(5,120)).apply()
                if (!enabled) { stopService(Intent(this@MainActivity, EyeBreakService::class.java)); return@runOnUiThread }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    val i = Intent(this@MainActivity, EyeBreakService::class.java).putExtra("minutes", minutes).putExtra("seconds", seconds)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
                }
            }
        }
        @JavascriptInterface fun syncPrayerPlan(itemsJson: String, enabled: Boolean) {
            PrayerScheduler.sync(this@MainActivity, itemsJson.take(700000), enabled)
        }
        @JavascriptInterface fun enableBackgroundQuestions(enabled: Boolean) {
            prefs.edit().putBoolean("backgroundQuestionsEnabled", enabled).putBoolean("backgroundQuestionsConfigured", true).apply()
            if (enabled) BackgroundScheduler.scheduleQuestion(this@MainActivity, System.currentTimeMillis() + 4 * 60 * 60 * 1000L)
            else BackgroundScheduler.cancelQuestion(this@MainActivity)
        }
        @JavascriptInterface fun getNativeStatus(): String {
            val power = getSystemService(Context.POWER_SERVICE) as PowerManager
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notif = nm.areNotificationsEnabled() &&
                (Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
            val mic = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            return JSONObject()
                .put("native", true)
                .put("version", try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (_: Exception) { "" })
                .put("notifications", notif)
                .put("microphone", mic)
                .put("overlayEnabled", prefs.getBoolean("overlayEnabled", false))
                .put("overlayPermission", Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this@MainActivity))
                .put("usage", hasUsagePermission())
                .put("battery", power.isIgnoringBatteryOptimizations(packageName))
                .put("questions", prefs.getBoolean("backgroundQuestionsEnabled", false))
                .toString()
        }
        @JavascriptInterface fun requestNotificationPermission() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST)
                } else {
                    try { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)) } catch (_: Exception) { openAppSettingsScreen() }
                }
            }
        }
        @JavascriptInterface fun openBatterySettings() {
            runOnUiThread { try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) { openAppSettingsScreen() } }
        }
        @JavascriptInterface fun openAppSettings() { runOnUiThread { openAppSettingsScreen() } }
        @JavascriptInterface fun saveBackup(filename: String, json: String) {
            runOnUiThread {
                pendingBackup = json.take(5_000_000)
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, filename.take(80))
                }
                try { startActivityForResult(i, BACKUP_SAVE_REQUEST) } catch (_: Exception) {
                    pendingBackup = null
                    jsToast("تعذر فتح نافذة الحفظ")
                }
            }
        }
        @JavascriptInterface fun isSpeechAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(this@MainActivity)
        @JavascriptInterface fun startListening() { runOnUiThread { this@MainActivity.startNativeListening() } }
        @JavascriptInterface fun stopListening() { runOnUiThread { try { recognizer?.stopListening() } catch (_: Exception) { } } }
        @JavascriptInterface fun requestUsagePermission() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply { data = Uri.parse("package:$packageName") }) }
        }
        @JavascriptInterface fun requestRuntimePermissions() { runOnUiThread { this@MainActivity.requestRuntimePermissions() } }
        @JavascriptInterface fun enableOverlay() { runOnUiThread { this@MainActivity.enableOverlay() } }
        @JavascriptInterface fun disableOverlay() { runOnUiThread { this@MainActivity.disableOverlay() } }
        @JavascriptInterface fun scheduleTaskReminder(id: String, title: String, atMillis: Long) {
            if (id.isBlank()) return
            ReminderStore.schedule(this@MainActivity, id.take(120), title.take(180), atMillis)
        }
        @JavascriptInterface fun cancelTaskReminder(id: String) {
            if (id.isBlank()) return
            ReminderStore.cancel(this@MainActivity, id.take(120))
        }
        @JavascriptInterface fun assistantAnswered() {
            runOnUiThread {
                val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply {
                    action = FloatingBubbleService.ACTION_ANSWERED
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
            }
        }
        @JavascriptInterface fun showBubbleForEvent() {
            runOnUiThread {
                val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply {
                    action = FloatingBubbleService.ACTION_SHOW_FOR_EVENT
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
            }
        }
    }
}
