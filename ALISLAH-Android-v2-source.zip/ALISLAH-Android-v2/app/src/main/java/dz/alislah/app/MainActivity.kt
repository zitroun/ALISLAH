package dz.alislah.app

import android.app.Activity
import android.app.KeyguardManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Color
import android.graphics.drawable.Icon
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.app.PendingIntent
import android.Manifest
import android.content.pm.PackageManager
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.PermissionRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.app.NotificationManager
import android.content.res.Configuration
import android.graphics.drawable.ColorDrawable
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.View
import org.json.JSONArray
import org.json.JSONObject
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.app.usage.UsageEvents
import java.util.Calendar

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("alislah_native", Context.MODE_PRIVATE) }
    private var pendingWebPermission: PermissionRequest? = null
    private val AUDIO_PERMISSION_REQUEST = 7801
    private val NOTIFICATION_PERMISSION_REQUEST = 7802
    private var recognizer: SpeechRecognizer? = null
    private var lastUsageRefresh = 0L
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingBackup: String? = null
    private val FILE_CHOOSER_REQUEST = 7803
    private val BACKUP_SAVE_REQUEST = 7804
    private val LOCK_REQUEST = 7805
    private lateinit var cover: LinearLayout
    private var locked = false
    private var authInProgress = false
    private var skipAutoPrompt = false
    private var lastPausedAt = 0L
    private var pageLoaded = false
    private var pendingShared: String? = null
    private fun dispatchMixerVoiceStatus(ok: Boolean, detail: String) {
        val safe = JSONObject.quote(detail.take(300))
        runOnUiThread {
            try {
                if (::webView.isInitialized) webView.evaluateJavascript(
                    "window.dispatchEvent(new CustomEvent('alislah:neural-voice',{detail:{ok:$ok,detail:$safe}}));", null
                )
            } catch (_: Exception) { }
        }
    }

    private fun speakWithLegacyTts(text: String) {
        val clean = text.trim().take(700)
        if (clean.isBlank()) return
        try {
            val intent = Intent(this, FloatingBubbleService::class.java).apply {
                action = FloatingBubbleService.ACTION_SPEAK_TEXT
                putExtra(FloatingBubbleService.EXTRA_SPEAK_TEXT, clean)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        } catch (_: Exception) {
            dispatchMixerVoiceStatus(false, "تعذر تشغيل الصوت القديم على هذا الجهاز")
        }
    }

    private fun speakWithMixerTts(text: String) {
        val clean = text.trim().take(700)
        if (clean.isBlank()) return
        if (OptionalVoicePackBridge.speak(this, clean)) {
            dispatchMixerVoiceStatus(true, "تم إرسال النص إلى حزمة الصوت العصبي الاختيارية")
        } else {
            dispatchMixerVoiceStatus(false, "حزمة Mixer-TTS الاختيارية غير مثبتة؛ سيُستخدم الصوت القديم")
            speakWithLegacyTts(clean)
        }
    }

    private fun stopMixerTts() {
        OptionalVoicePackBridge.stop(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Match the system bars and the page background to the light/dark theme (no white flash).
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val bg = if (night) 0xFF0E1A17.toInt() else 0xFFF3F7F5.toInt()
        window.setBackgroundDrawable(ColorDrawable(bg))
        window.statusBarColor = if (night) 0xFF0A1412.toInt() else 0xFF0F4F43.toInt()
        window.navigationBarColor = bg
        if (!night && Build.VERSION.SDK_INT >= 26) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        webView = WebView(this)
        webView.setBackgroundColor(bg)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        // The page is loaded from file:///android_asset, which stays readable with these disabled.
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.settings.allowFileAccessFromFileURLs = false
        webView.settings.allowUniversalAccessFromFileURLs = false
        webView.webChromeClient = object : WebChromeClient() {
            // Without this the <input type="file"> used by "restore backup" never opens in a WebView.
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    val chooser = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                    }
                    startActivityForResult(chooser, FILE_CHOOSER_REQUEST)
                    true
                } catch (_: Exception) {
                    fileCallback = null
                    callback?.onReceiveValue(null)
                    false
                }
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val wantsAudio = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    if (wantsAudio && Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        pendingWebPermission = request
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_REQUEST)
                    } else {
                        val allowed = request.resources.filter { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }
                        if (allowed.isNotEmpty() && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) request.grant(allowed.toTypedArray()) else request.deny()
                    }
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return url == null || !url.startsWith("file:///android_asset/")
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                BackgroundScheduler.cancelLegacyPrayer(this@MainActivity)
                pageLoaded = true
                openAssistantIfRequested()
                deliverShared()
            }
            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                runOnUiThread { recreate() }
                return true
            }
        }
        webView.addJavascriptInterface(NativeBridge(), "AndroidUsage")
        val root = FrameLayout(this)
        root.addView(webView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        cover = buildLockCover(bg)
        root.addView(cover, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        locked = lockEnabled()
        cover.visibility = if (locked) View.VISIBLE else View.GONE
        applySecureFlag(lockEnabled())
        webView.loadUrl("file:///android_asset/index.html")
        handleIncomingIntent(intent)
        publishShortcuts()
    }

    override fun onDestroy() {
        try { recognizer?.destroy() } catch (_: Exception) { }
        recognizer = null
        try { stopMixerTts() } catch (_: Exception) { }
        super.onDestroy()
    }

    override fun onPause() {
        if (!authInProgress) lastPausedAt = System.currentTimeMillis()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (lockEnabled()) {
            val now = System.currentTimeMillis()
            if (!locked && lastPausedAt > 0L && now - lastPausedAt > 30_000L) locked = true
            if (locked) {
                cover.visibility = View.VISIBLE
                if (!skipAutoPrompt) promptUnlock()
                skipAutoPrompt = false
            }
        } else {
            locked = false
            cover.visibility = View.GONE
        }
        if (prefs.getBoolean("overlayEnabled", false) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
            startBubbleService()
            hideBubblePanel() // never keep two editors of the same data alive
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
            if (prefs.getBoolean("eyeBreakServiceEnabled", false)) {
                val eye = Intent(this, EyeBreakService::class.java)
                    .putExtra("minutes", prefs.getInt("eyeBreakMinutes", 20))
                    .putExtra("seconds", prefs.getInt("eyeBreakSeconds", 20))
                try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(eye) else startService(eye) } catch (_: Exception) { }
            }
            if (prefs.getBoolean("eyeFilterEnabled", false)) {
                try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(Intent(this, EyeFilterService::class.java)) else startService(Intent(this, EyeFilterService::class.java)) } catch (_: Exception) { }
            }
        }
        if (::webView.isInitialized) webView.postDelayed({
            if (!isFinishing) {
                webView.evaluateJavascript("window.__alislahSync && window.__alislahSync();", null)
                val nowMs = System.currentTimeMillis()
                if (nowMs - lastUsageRefresh > 60_000L) {
                    lastUsageRefresh = nowMs
                    webView.evaluateJavascript("document.getElementById('refreshUsage')?.click();", null)
                }
            }
        }, 400)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) setIntent(intent)
        handleIncomingIntent(intent)
        webView.postDelayed({ openAssistantIfRequested() }, 350)
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!::webView.isInitialized) { super.onBackPressed(); return }
        webView.evaluateJavascript("(window.__alislahBack && window.__alislahBack()) ? '1' : '0'") { result ->
            if (result == "\"1\"" || result == "1") return@evaluateJavascript
            super.onBackPressed()
        }
    }

    private fun openAssistantIfRequested() {
        val currentIntent = intent ?: return
        if (!::webView.isInitialized) return
        if (currentIntent.getBooleanExtra("openAssistant", false)) {
            webView.evaluateJavascript("document.querySelector('[data-tab=assistant]')?.click();", null)
            if (currentIntent.getBooleanExtra("backgroundQuestion", false)) {
                webView.postDelayed({
                    webView.evaluateJavascript("(function(){var x=document.getElementById('chatText');if(x){x.value='متابعة سريعة: كيف كان تركيزي وطاقتي خلال الساعات الماضية؟ وما أهم شيء أريد تحسينه الآن؟';x.focus();} })();", null)
                }, 700)
                currentIntent.removeExtra("backgroundQuestion")
            }
            currentIntent.removeExtra("openAssistant")
        }
        val tab = currentIntent.getStringExtra("openTab")
        if (tab != null) {
            val allowed = setOf("tasks", "habits", "prayer", "family", "more", "assistant", "settings", "adhkar", "calendar", "qibla", "worship", "report", "focustimer")
            if (tab in allowed) webView.evaluateJavascript("window.ALI && ALI.tab(" + JSONObject.quote(tab) + ");", null)
            currentIntent.removeExtra("openTab")
        }
        if (currentIntent.getBooleanExtra("focusAddTask", false)) {
            webView.evaluateJavascript("setTimeout(function(){var x=document.getElementById('taskText');if(x)x.focus()},500);", null)
            currentIntent.removeExtra("focusAddTask")
        }
        handleOverlayBridgeAction(currentIntent)
    }

    private fun handleOverlayBridgeAction(source: Intent) {
        when (source.getStringExtra("overlayBridgeAction")) {
            "startListening" -> webView.postDelayed({ if (!isFinishing) startNativeListening() }, 300)
            "stopListening" -> stopNativeListening()
            "requestRuntimePermissions" -> requestRuntimePermissions()
            "requestNotifications" -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST)
                } else {
                    try { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)) } catch (_: Exception) { openAppSettingsScreen() }
                }
            }
            "saveBackup" -> {
                val shared = getSharedPreferences("alislah_native", MODE_PRIVATE)
                val json = shared.getString("overlay_backup_pending", null)
                val filename = shared.getString("overlay_backup_name", "alislah-backup.json") ?: "alislah-backup.json"
                if (!json.isNullOrBlank()) {
                    shared.edit().remove("overlay_backup_pending").remove("overlay_backup_name").apply()
                    requestBackupSave(filename, json)
                }
            }
        }
        source.removeExtra("overlayBridgeAction")
    }

    private fun hideBubblePanel() {
        val i = Intent(this, FloatingBubbleService::class.java).apply { action = FloatingBubbleService.ACTION_HIDE_PANEL }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    private fun stopNativeListening() {
        try { recognizer?.stopListening() } catch (_: Exception) { }
        sendSpeech("end", "")
    }

    private fun sendSpeech(kind: String, value: String) {
        if (!::webView.isInitialized) return
        webView.evaluateJavascript("window.__alislahSpeech && window.__alislahSpeech(" + JSONObject.quote(kind) + "," + JSONObject.quote(value) + ");", null)
    }

    private fun startNativeListening() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_REQUEST)
            sendSpeech("error", "not-allowed"); sendSpeech("end", "")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { sendSpeech("error", "unavailable"); sendSpeech("end", ""); return }
        try { recognizer?.destroy() } catch (_: Exception) { }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) { sendSpeech("error", error.toString()); sendSpeech("end", "") }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                sendSpeech("result", text); sendSpeech("end", "")
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-DZ")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try { r.startListening(i) } catch (_: Exception) { sendSpeech("error", "failed"); sendSpeech("end", "") }
    }

    private fun lockEnabled(): Boolean = prefs.getBoolean("appLockEnabled", false)

    private fun applySecureFlag(on: Boolean) {
        if (on) window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun buildLockCover(bg: Int): LinearLayout {
        val d = resources.displayMetrics.density
        val dark = Color.red(bg) < 100
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setBackgroundColor(bg); isClickable = true }
        val icon = TextView(this).apply { text = "🔒"; textSize = 54f; gravity = Gravity.CENTER }
        val msg = TextView(this).apply { text = "ALISLAH مقفل"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(if (dark) Color.WHITE else Color.rgb(18,48,42)); setPadding(0,(12*d).toInt(),0,0) }
        val btn = Button(this).apply { text = "فتح"; setOnClickListener { promptUnlock() } }
        val lp = LinearLayout.LayoutParams((200*d).toInt(),(52*d).toInt()).apply { topMargin=(20*d).toInt() }
        c.addView(icon); c.addView(msg); c.addView(btn,lp)
        return c
    }

    private fun promptUnlock() {
        if (authInProgress) return
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isDeviceSecure) {
            prefs.edit().putBoolean("appLockEnabled", false).apply(); locked=false; cover.visibility=View.GONE; applySecureFlag(false); return
        }
        val i = km.createConfirmDeviceCredentialIntent("ALISLAH", "أكّدي هويتك لفتح التطبيق")
        if (i == null) { locked=false; cover.visibility=View.GONE; return }
        authInProgress=true
        try { startActivityForResult(i, LOCK_REQUEST) } catch (_: Exception) { authInProgress=false }
    }

    private fun handleIncomingIntent(i: Intent?) {
        if (i == null) return
        if (i.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            val t=i.getStringExtra(Intent.EXTRA_TEXT); if (!t.isNullOrBlank()) pendingShared=t.take(500); i.action=null
        }
        deliverShared()
    }

    private fun deliverShared() {
        val t=pendingShared ?: return
        if (!pageLoaded || locked || !::webView.isInitialized) return
        pendingShared=null
        webView.evaluateJavascript("window.__alislahShared && window.__alislahShared("+JSONObject.quote(t)+");",null)
    }

    private fun publishShortcuts() {
        try {
            val sm=getSystemService(ShortcutManager::class.java) ?: return
            fun make(id:String,label:String,tab:String,focus:Boolean):ShortcutInfo {
                val i=Intent(this,MainActivity::class.java).apply { action=Intent.ACTION_VIEW; putExtra("openTab",tab); if(focus) putExtra("focusAddTask",true) }
                return ShortcutInfo.Builder(this,id).setShortLabel(label).setIcon(Icon.createWithResource(this,R.mipmap.ic_launcher)).setIntent(i).build()
            }
            sm.setDynamicShortcuts(listOf(make("add_task","مهمة جديدة","tasks",true),make("prayer","الصلاة","prayer",false),make("assistant","المساعد","assistant",false)))
        } catch (_: Exception) { }
    }

    private fun jsToast(message: String) {
        if (!::webView.isInitialized) return
        webView.evaluateJavascript("window.__toast && window.__toast(" + JSONObject.quote(message) + ");", null)
    }

    @Suppress("DEPRECATION")
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            LOCK_REQUEST -> {
                authInProgress = false
                if (resultCode == RESULT_OK) {
                    locked = false
                    cover.visibility = View.GONE
                    lastPausedAt = System.currentTimeMillis()
                    deliverShared()
                } else {
                    locked = true
                    cover.visibility = View.VISIBLE
                    skipAutoPrompt = true
                }
            }
            FILE_CHOOSER_REQUEST -> {
                fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
                fileCallback = null
            }
            BACKUP_SAVE_REQUEST -> {
                val json = pendingBackup
                pendingBackup = null
                val uri = data?.data
                if (resultCode == RESULT_OK && uri != null && json != null) {
                    val ok = try {
                        contentResolver.openOutputStream(uri, "wt")?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                        true
                    } catch (_: Exception) { false }
                    jsToast(if (ok) "تم حفظ النسخة الاحتياطية" else "تعذر حفظ الملف")
                }
            }
        }
    }

    private fun requestBackupSave(filename: String, json: String) {
        pendingBackup = json.take(5_000_000)
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, filename.take(80))
        }
        try { startActivityForResult(i, BACKUP_SAVE_REQUEST) } catch (_: Exception) {
            pendingBackup = null
            jsToast("تعذر فتح نافذة الحفظ")
        }
    }

    private fun openAppSettingsScreen() {
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (_: Exception) { }
    }

    private fun startBubbleService() {
        val i = Intent(this, FloatingBubbleService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    private fun enableOverlay() {
        prefs.edit().putBoolean("overlayEnabled", true).apply()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else startBubbleService()
    }

    private fun disableOverlay() {
        prefs.edit().putBoolean("overlayEnabled", false).apply()
        stopService(Intent(this, FloatingBubbleService::class.java))
    }

    private fun requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_REQUEST)
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == AUDIO_PERMISSION_REQUEST) {
            val request = pendingWebPermission
            pendingWebPermission = null
            if (request != null) {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else request.deny()
            }
        }
    }

    private fun hasUsagePermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun todayStartMillis(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun readUsageJson(): String {
        val result = JSONObject().put("permission", hasUsagePermission())
        val apps = JSONArray()
        if (hasUsagePermission()) {
            val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val stats: List<UsageStats> = manager.queryAndAggregateUsageStats(todayStartMillis(), System.currentTimeMillis())?.values?.toList() ?: emptyList()
            val grouped = stats.filter { it.totalTimeInForeground > 0 && it.packageName != packageName }
                .groupBy { it.packageName }
                .map { (pkg, rows) -> pkg to rows.sumOf { it.totalTimeInForeground } }
                .sortedByDescending { it.second }.take(20)
            for ((pkg, millis) in grouped) {
                val appName = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
                apps.put(JSONObject().put("packageName", pkg).put("name", appName).put("minutes", (millis / 60000.0).toInt()))
            }
        }
        var foreground = JSONObject().put("name", "غير متاح").put("packageName", "").put("approximate", true)
        if (hasUsagePermission()) {
            try {
                val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                val now = System.currentTimeMillis()
                val events = manager.queryEvents(now - 2 * 60 * 60 * 1000L, now)
                val event = UsageEvents.Event()
                var latestTime = 0L
                var latestPackage = ""
                while (events.hasNextEvent()) {
                    events.getNextEvent(event)
                    val isForeground = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
                    } else {
                        @Suppress("DEPRECATION") event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
                    }
                    if (isForeground && event.timeStamp >= latestTime) {
                        latestTime = event.timeStamp
                        latestPackage = event.packageName ?: ""
                    }
                }
                if (latestPackage.isNotBlank()) {
                    val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(latestPackage, 0)).toString() } catch (_: Exception) { latestPackage }
                    foreground = JSONObject().put("name", label).put("packageName", latestPackage)
                        .put("lastSeenAt", latestTime).put("approximate", true)
                }
            } catch (_: Exception) { }
        }
        return result.put("apps", apps).put("foreground", foreground).put("collectedAt", System.currentTimeMillis()).toString()
    }

    inner class NativeBridge {
        @JavascriptInterface fun getAppDataJson(): String = prefs.getString("alislah_app_data", "{}") ?: "{}"
        @JavascriptInterface fun saveAppDataJson(json: String) { if (json.length <= 2_000_000) prefs.edit().putString("alislah_app_data", json).apply() }
        @JavascriptInterface fun getEyeBreakContentCache(): String = prefs.getString("eyeBreakContentCache", "{}") ?: "{}"
        @JavascriptInterface fun saveEyeBreakContentCache(json: String) { if (json.length <= 1_000_000) prefs.edit().putString("eyeBreakContentCache", json).apply() }
        @JavascriptInterface fun getUsageStatsJson(): String = readUsageJson()
        @JavascriptInterface fun setAssistantVoice(gender: String) { prefs.edit().putString("assistantVoiceGender", if (gender == "male") "male" else "female").apply() }
        @JavascriptInterface fun setAssistantVoiceEngine(engine: String) {
            val selected = if (engine == "old") "old" else "neural"
            prefs.edit().putString("assistantVoiceEngine", selected).apply()
            if (selected == "neural" && !OptionalVoicePackBridge.isInstalled(this@MainActivity)) {
                dispatchMixerVoiceStatus(false, "حزمة الصوت العصبي الاختيارية غير مثبتة؛ سيُستخدم الصوت القديم حتى تثبيتها")
            }
        }
        @JavascriptInterface fun isMixerTtsInstalled(): Boolean = OptionalVoicePackBridge.isInstalled(this@MainActivity)
        @JavascriptInterface fun speakDisplayedAyah(text: String) { runOnUiThread {
            val clean = text.trim().take(700)
            if (clean.isBlank()) return@runOnUiThread
            if (prefs.getString("assistantVoiceEngine", "old") == "neural") {
                try { webView.evaluateJavascript("(function(){if(window.AlishlahNeuralVoice){window.AlishlahNeuralVoice.speak(" + JSONObject.quote(clean) + ");return true;}return false;})()", null) } catch (_: Exception) { }
            } else {
                try { val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply { action = FloatingBubbleService.ACTION_SPEAK_TEXT; putExtra(FloatingBubbleService.EXTRA_SPEAK_TEXT, clean) }; if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } catch (_: Exception) { }
            }
        } }
        @JavascriptInterface fun speakMixerTts(text: String) { runOnUiThread { speakWithMixerTts(text) } }
        @JavascriptInterface fun speakAssistantText(text: String) { runOnUiThread {
            val clean = text.trim().take(700)
            if (clean.isBlank()) return@runOnUiThread
            if (prefs.getString("assistantVoiceEngine", "old") == "neural") speakWithMixerTts(clean)
            else { val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply { action = FloatingBubbleService.ACTION_SPEAK_TEXT; putExtra(FloatingBubbleService.EXTRA_SPEAK_TEXT, clean) }; if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) }
        } }
        @JavascriptInterface fun stopMixerTts() { runOnUiThread { this@MainActivity.stopMixerTts() } }
        @JavascriptInterface fun stopAssistantSpeech() { runOnUiThread { stopMixerTts(); try { webView.evaluateJavascript("window.AlishlahNeuralVoice&&window.AlishlahNeuralVoice.stop()", null) } catch (_: Exception) { }; try { val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply { action = FloatingBubbleService.ACTION_STOP_SPEECH }; if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } catch (_: Exception) { } } }
        @JavascriptInterface fun setAssistantVoiceMode(mode: String) { prefs.edit().putString("voiceMode", if (mode == "text" || mode == "voice" || mode == "both") mode else "both").apply() }
        @JavascriptInterface fun testAssistantVoice() { runOnUiThread { if (prefs.getString("assistantVoiceEngine", "old") == "neural") speakWithMixerTts("مرحبًا بك في الإصلاح. أنا مساعدك العربي الجديد، وأعمل محليًا دون اتصال بالإنترنت.") else { val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply { action = FloatingBubbleService.ACTION_SPEAK_TEST }; if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } } }
        @JavascriptInterface fun playAdhanTest() { runOnUiThread { PrayerScheduler.playAdhan(this@MainActivity, "اختبار") } }
        @JavascriptInterface fun stopAdhan() {
            runOnUiThread {
                try { startService(Intent(this@MainActivity, PrayerVoiceService::class.java).apply { action = PrayerVoiceService.ACTION_STOP }) } catch (_: Exception) { }
            }
        }
        @JavascriptInterface fun enableEyeFilter() {
            runOnUiThread {
                prefs.edit().putBoolean("eyeFilterEnabled", true).apply()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else { val i = Intent(this@MainActivity, EyeFilterService::class.java); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) }
            }
        }
        @JavascriptInterface fun disableEyeFilter() {
            runOnUiThread { prefs.edit().putBoolean("eyeFilterEnabled", false).apply(); stopService(Intent(this@MainActivity, EyeFilterService::class.java)) }
        }
        @JavascriptInterface fun configureEyeBreak(enabled: Boolean, minutes: Int, seconds: Int) {
            runOnUiThread {
                prefs.edit().putBoolean("eyeBreakServiceEnabled", enabled)
                    .putInt("eyeBreakMinutes", minutes.coerceIn(1,180)).putInt("eyeBreakSeconds", seconds.coerceIn(5,120)).apply()
                if (!enabled) { stopService(Intent(this@MainActivity, EyeBreakService::class.java)); return@runOnUiThread }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    val i = Intent(this@MainActivity, EyeBreakService::class.java).putExtra("minutes", minutes).putExtra("seconds", seconds)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
                }
            }
        }
        @JavascriptInterface fun syncPrayerPlan(itemsJson: String, enabled: Boolean) {
            PrayerScheduler.sync(this@MainActivity, itemsJson.take(700000), enabled)
        }
        @JavascriptInterface fun enableBackgroundQuestions(enabled: Boolean) {
            prefs.edit().putBoolean("backgroundQuestionsEnabled", enabled).putBoolean("backgroundQuestionsConfigured", true).apply()
            if (enabled) BackgroundScheduler.scheduleQuestion(this@MainActivity, System.currentTimeMillis() + 4 * 60 * 60 * 1000L)
            else BackgroundScheduler.cancelQuestion(this@MainActivity)
        }
        @JavascriptInterface fun getNativeStatus(): String {
            val power = getSystemService(Context.POWER_SERVICE) as PowerManager
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notif = nm.areNotificationsEnabled() &&
                (Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
            val mic = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            return JSONObject()
                .put("native", true)
                .put("version", try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (_: Exception) { "" })
                .put("notifications", notif)
                .put("microphone", mic)
                .put("overlayEnabled", prefs.getBoolean("overlayEnabled", false))
                .put("overlayPermission", Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this@MainActivity))
                .put("usage", hasUsagePermission())
                .put("battery", power.isIgnoringBatteryOptimizations(packageName))
                .put("questions", prefs.getBoolean("backgroundQuestionsEnabled", false))
                .toString()
        }
        @JavascriptInterface fun requestNotificationPermission() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST)
                } else {
                    try { startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)) } catch (_: Exception) { openAppSettingsScreen() }
                }
            }
        }
        @JavascriptInterface fun openBatterySettings() {
            runOnUiThread { try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) { openAppSettingsScreen() } }
        }
        @JavascriptInterface fun openAppSettings() { runOnUiThread { openAppSettingsScreen() } }
        @JavascriptInterface fun saveBackup(filename: String, json: String) {
            runOnUiThread { requestBackupSave(filename, json) }
        }
        @JavascriptInterface fun setAppLock(on: Boolean): String {
            if (on) { val km=getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager; if(!km.isDeviceSecure) return "no-secure" }
            prefs.edit().putBoolean("appLockEnabled",on).apply()
            runOnUiThread { applySecureFlag(on); if(!on){locked=false;cover.visibility=View.GONE} }
            return "ok"
        }
        @JavascriptInterface fun setDigest(json: String) { prefs.edit().putString("digestConfig",json.take(500)).apply(); BackgroundScheduler.scheduleDigest(this@MainActivity) }
        @JavascriptInterface fun setBackupReminder(on: Boolean) { prefs.edit().putBoolean("backupReminder",on).apply(); BackgroundScheduler.scheduleBackupReminder(this@MainActivity) }
        @JavascriptInterface fun setEyeFilterLevel(level: Int) { prefs.edit().putInt("eyeFilterLevel",level.coerceIn(5,60)).apply(); if(prefs.getBoolean("eyeFilterEnabled",false)) runOnUiThread { try { startForegroundService(Intent(this@MainActivity,EyeFilterService::class.java)) } catch (_:Exception){} } }
        @JavascriptInterface fun updateSnapshot(json: String) { Snapshot.save(this@MainActivity,json); AlislahWidgetProvider.refreshAll(this@MainActivity) }
        @JavascriptInterface fun encryptBackup(json: String, pass: String): String = try { BackupCrypto.encrypt(json,pass) } catch (_:Exception) { "" }
        @JavascriptInterface fun decryptBackup(envelope: String, pass: String): String = try { BackupCrypto.decrypt(envelope,pass) ?: "" } catch (_:Exception) { "" }
        @JavascriptInterface fun shareText(text: String) { runOnUiThread { try { val send=Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT,text.take(4000)) }; startActivity(Intent.createChooser(send,"مشاركة")) } catch (_:Exception){} } }
        @JavascriptInterface fun copyText(text: String) { runOnUiThread { try { val cm=getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager; cm.setPrimaryClip(ClipData.newPlainText("ALISLAH",text.take(4000))) } catch (_:Exception){} } }
        @JavascriptInterface fun isSpeechAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(this@MainActivity)
        @JavascriptInterface fun startListening() { runOnUiThread { this@MainActivity.startNativeListening() } }
        @JavascriptInterface fun stopListening() { runOnUiThread { stopNativeListening() } }
        @JavascriptInterface fun requestUsagePermission() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply { data = Uri.parse("package:$packageName") }) }
        }
        @JavascriptInterface fun requestRuntimePermissions() { runOnUiThread { this@MainActivity.requestRuntimePermissions() } }
        @JavascriptInterface fun enableOverlay() { runOnUiThread { this@MainActivity.enableOverlay() } }
        @JavascriptInterface fun disableOverlay() { runOnUiThread { this@MainActivity.disableOverlay() } }
        @JavascriptInterface fun scheduleTaskReminder(id: String, title: String, atMillis: Long) {
            if (id.isBlank()) return
            ReminderStore.schedule(this@MainActivity, id.take(120), title.take(180), atMillis)
        }
        @JavascriptInterface fun cancelTaskReminder(id: String) {
            if (id.isBlank()) return
            ReminderStore.cancel(this@MainActivity, id.take(120))
        }
        @JavascriptInterface fun assistantAnswered() {
            runOnUiThread {
                val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply {
                    action = FloatingBubbleService.ACTION_ANSWERED
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
            }
        }
        @JavascriptInterface fun showBubbleForEvent() {
            runOnUiThread {
                val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply {
                    action = FloatingBubbleService.ACTION_SHOW_FOR_EVENT
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
            }
        }
    }
}
