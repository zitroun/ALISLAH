package dz.alislah.app

import android.app.Activity
import android.Manifest
import android.content.pm.PackageManager
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.PermissionRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.app.usage.UsageEvents
import java.util.Calendar

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("alislah_native", Context.MODE_PRIVATE) }
    private var pendingWebPermission: PermissionRequest? = null
    private val AUDIO_PERMISSION_REQUEST = 7801
    private val NOTIFICATION_PERMISSION_REQUEST = 7802

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = false
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val wantsAudio = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    if (wantsAudio && Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        pendingWebPermission = request
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_REQUEST)
                    } else {
                        val allowed = request.resources.filter { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE }
                        if (allowed.isNotEmpty() && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) request.grant(allowed.toTypedArray()) else request.deny()
                    }
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return url == null || !url.startsWith("file:///android_asset/")
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                injectNativeControls()
                openAssistantIfRequested()
            }
        }
        webView.addJavascriptInterface(NativeBridge(), "AndroidUsage")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        if (prefs.getBoolean("overlayEnabled", false) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
            startBubbleService()
        }
        if (prefs.getBoolean("eyeFilterEnabled", false) && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))) {
            startService(Intent(this, EyeFilterService::class.java))
        }
        if (prefs.getBoolean("eyeBreakServiceEnabled", false) && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))) { val i=Intent(this, EyeBreakService::class.java).putExtra("minutes", prefs.getInt("eyeBreakMinutes",20)).putExtra("seconds",prefs.getInt("eyeBreakSeconds",20)); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) }
        if (::webView.isInitialized) webView.postDelayed({
            if (!isFinishing) webView.evaluateJavascript("document.getElementById('refreshUsage')?.click();", null)
        }, 400)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) setIntent(intent)
        webView.postDelayed({ openAssistantIfRequested() }, 350)
    }

    private fun openAssistantIfRequested() {
        val currentIntent = intent ?: return
        if (currentIntent.getBooleanExtra("openAssistant", false) && ::webView.isInitialized) {
            webView.evaluateJavascript("document.querySelector('[data-tab=\\\"assistant\\\"]')?.click();", null)
            currentIntent.removeExtra("openAssistant")
        }
    }

    private fun injectNativeControls() {
        val js = """(function(){
          const root=document.getElementById('settings'); if(!root||document.getElementById('nativeOverlayControls')) return;
          const box=document.createElement('div'); box.id='nativeOverlayControls';
          box.style.cssText='margin:12px 0;padding:12px;border:1px solid #dce7e2;border-radius:12px;background:#fff';
          const title=document.createElement('strong'); title.textContent='الفقاعة العائمة خارج التطبيق'; box.appendChild(title);
          const p=document.createElement('p'); p.textContent='فعّلي الإذن ليظهر زر ALISLAH فوق التطبيقات الأخرى. عند الضغط عليه يفتح المساعد الذكي.'; p.style.cssText='margin:6px 0;font-size:14px;color:#66766f'; box.appendChild(p);
          const on=document.createElement('button'); on.type='button'; on.textContent='تفعيل الفقاعة العائمة'; on.style.cssText='padding:9px 12px;margin:4px;border:0;border-radius:10px;background:#176b5b;color:white'; on.onclick=()=>AndroidUsage.enableOverlay(); box.appendChild(on);
          const perms=document.createElement('button'); perms.type='button'; perms.textContent='تفعيل إذن الصوت والتنبيهات'; perms.style.cssText='padding:9px 12px;margin:4px;border:0;border-radius:10px;background:#e8f2ee;color:#18312b'; perms.onclick=()=>AndroidUsage.requestRuntimePermissions(); box.appendChild(perms);
          const off=document.createElement('button'); off.type='button'; off.textContent='إيقاف الفقاعة'; off.style.cssText='padding:9px 12px;margin:4px;border:1px solid #dce7e2;border-radius:10px;background:#fff;color:#18312b'; off.onclick=()=>AndroidUsage.disableOverlay(); box.appendChild(off);
          const eye=document.createElement('div'); eye.style.cssText='margin-top:10px;padding-top:10px;border-top:1px solid #dce7e2';
          const eyeTitle=document.createElement('strong'); eyeTitle.textContent='حماية الشاشة خارج التطبيق'; eye.appendChild(eyeTitle);
          const eyeNote=document.createElement('p'); eyeNote.textContent='فلتر لوني خفيف فوق التطبيقات. يحتاج إذن الظهور فوق التطبيقات، ويمكن إيقافه من هنا أو من إشعار ALISLAH.'; eyeNote.style.cssText='font-size:13px;color:#66766f'; eye.appendChild(eyeNote);
          const eyeOn=document.createElement('button'); eyeOn.type='button'; eyeOn.textContent='تفعيل فلتر الشاشة'; eyeOn.style.cssText=on.style.cssText; eyeOn.onclick=()=>AndroidUsage.enableEyeFilter(); eye.appendChild(eyeOn);
          const eyeOff=document.createElement('button'); eyeOff.type='button'; eyeOff.textContent='إيقاف فلتر الشاشة'; eyeOff.style.cssText=off.style.cssText; eyeOff.onclick=()=>AndroidUsage.disableEyeFilter(); eye.appendChild(eyeOff); box.appendChild(eye);
          root.prepend(box);
        })();"""
        webView.evaluateJavascript(js, null)
    }

    private fun startBubbleService() {
        val i = Intent(this, FloatingBubbleService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
    }

    private fun enableOverlay() {
        prefs.edit().putBoolean("overlayEnabled", true).apply()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else startBubbleService()
    }

    private fun disableOverlay() {
        prefs.edit().putBoolean("overlayEnabled", false).apply()
        stopService(Intent(this, FloatingBubbleService::class.java))
    }

    private fun requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), AUDIO_PERMISSION_REQUEST)
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_REQUEST)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == AUDIO_PERMISSION_REQUEST) {
            val request = pendingWebPermission
            pendingWebPermission = null
            if (request != null) {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else request.deny()
            }
        }
    }

    private fun hasUsagePermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun todayStartMillis(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun readUsageJson(): String {
        val result = JSONObject().put("permission", hasUsagePermission())
        val apps = JSONArray()
        if (hasUsagePermission()) {
            val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val stats: List<UsageStats> = manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, todayStartMillis(), System.currentTimeMillis()) ?: emptyList()
            val grouped = stats.filter { it.totalTimeInForeground > 0 && it.packageName != packageName }
                .groupBy { it.packageName }
                .map { (pkg, rows) -> pkg to rows.sumOf { it.totalTimeInForeground } }
                .sortedByDescending { it.second }.take(20)
            for ((pkg, millis) in grouped) {
                val appName = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
                apps.put(JSONObject().put("packageName", pkg).put("name", appName).put("minutes", (millis / 60000.0).toInt()))
            }
        }
        var foreground = JSONObject().put("name", "غير متاح").put("packageName", "").put("approximate", true)
        if (hasUsagePermission()) {
            try {
                val manager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                val now = System.currentTimeMillis()
                val events = manager.queryEvents(now - 2 * 60 * 60 * 1000L, now)
                val event = UsageEvents.Event()
                var latestTime = 0L
                var latestPackage = ""
                while (events.hasNextEvent()) {
                    events.getNextEvent(event)
                    val isForeground = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
                    } else {
                        @Suppress("DEPRECATION") event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
                    }
                    if (isForeground && event.timeStamp >= latestTime) {
                        latestTime = event.timeStamp
                        latestPackage = event.packageName ?: ""
                    }
                }
                if (latestPackage.isNotBlank()) {
                    val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(latestPackage, 0)).toString() } catch (_: Exception) { latestPackage }
                    foreground = JSONObject().put("name", label).put("packageName", latestPackage)
                        .put("lastSeenAt", latestTime).put("approximate", true)
                }
            } catch (_: Exception) { }
        }
        return result.put("apps", apps).put("foreground", foreground).put("collectedAt", System.currentTimeMillis()).toString()
    }

    inner class NativeBridge {
        @JavascriptInterface fun getUsageStatsJson(): String = readUsageJson()
        @JavascriptInterface fun requestUsagePermission() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply { data = Uri.parse("package:$packageName") }) }
        }
        @JavascriptInterface fun requestRuntimePermissions() { runOnUiThread { this@MainActivity.requestRuntimePermissions() } }
        @JavascriptInterface fun enableOverlay() { runOnUiThread { this@MainActivity.enableOverlay() } }
        @JavascriptInterface fun disableOverlay() { runOnUiThread { this@MainActivity.disableOverlay() } }
        @JavascriptInterface fun enableEyeFilter() { runOnUiThread { prefs.edit().putBoolean("eyeFilterEnabled", true).apply(); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) else startService(Intent(this@MainActivity, EyeFilterService::class.java)) } }
        @JavascriptInterface fun disableEyeFilter() { runOnUiThread { prefs.edit().putBoolean("eyeFilterEnabled", false).apply(); stopService(Intent(this@MainActivity, EyeFilterService::class.java)) } }
        @JavascriptInterface fun schedulePrayerAlarms(json: String, before: Int, after: Int, adhan: Boolean) { runOnUiThread { PrayerScheduler.schedule(this@MainActivity, json, before, after, adhan) } }
        @JavascriptInterface fun stopAdhan() { runOnUiThread { stopService(Intent(this@MainActivity, AdhanService::class.java).setAction(AdhanService.ACTION_STOP)) } }
        @JavascriptInterface fun testAdhan() { runOnUiThread { val i = Intent(this@MainActivity, AdhanService::class.java).putExtra("name", "تجربة الأذان").putExtra("message", "تجربة الأذان").putExtra("adhan", true); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } }
        @JavascriptInterface fun configureEyeBreak(enabled: Boolean, minutes: Int, seconds: Int) { runOnUiThread { prefs.edit().putBoolean("eyeBreakServiceEnabled", enabled).putInt("eyeBreakMinutes", minutes.coerceIn(1,180)).putInt("eyeBreakSeconds", seconds.coerceIn(5,120)).apply(); if (enabled) { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } else { val i=Intent(this@MainActivity, EyeBreakService::class.java).putExtra("minutes", minutes).putExtra("seconds", seconds); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i) } } else stopService(Intent(this@MainActivity, EyeBreakService::class.java)) } }
        @JavascriptInterface fun requestExactAlarmPermission() { runOnUiThread { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) { try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } } else { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } } }
        @JavascriptInterface fun assistantAnswered() {
            runOnUiThread {
                val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply {
                    action = FloatingBubbleService.ACTION_ANSWERED
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
            }
        }
        @JavascriptInterface fun showBubbleForEvent() {
            runOnUiThread {
                val i = Intent(this@MainActivity, FloatingBubbleService::class.java).apply {
                    action = FloatingBubbleService.ACTION_SHOW_FOR_EVENT
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
            }
        }
    }
}
