package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class TaskReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_TASK_REMINDER) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "تذكيرات المهام", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "تذكيرات المهام التي يحدد المستخدم موعدها داخل ALISLAH"
            })
        }
        val open = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("openAssistant", false)
        }
        val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val pi = PendingIntent.getActivity(context, 7201, open, piFlags)
        val title = intent.getStringExtra(EXTRA_TITLE)?.take(180)?.ifBlank { "لديك مهمة مستحقة" } ?: "لديك مهمة مستحقة"
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, CHANNEL_ID).setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("تذكير من ALISLAH").setContentText(title).setStyle(Notification.BigTextStyle().bigText(title))
                .setContentIntent(pi).setAutoCancel(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(context).setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("تذكير من ALISLAH").setContentText(title).setContentIntent(pi).setAutoCancel(true).build()
        }
        val taskId = intent.getStringExtra(EXTRA_TASK_ID)
        try { manager.notify((taskId ?: title).hashCode(), notification) } catch (_: SecurityException) { }
        if (taskId != null) ReminderStore.remove(context, taskId)
    }
    companion object {
        const val ACTION_TASK_REMINDER = "dz.alislah.app.ACTION_TASK_REMINDER"
        const val EXTRA_TASK_ID = "task_id"
        const val EXTRA_TITLE = "task_title"
        const val CHANNEL_ID = "alislah_task_reminders"
    }
}
