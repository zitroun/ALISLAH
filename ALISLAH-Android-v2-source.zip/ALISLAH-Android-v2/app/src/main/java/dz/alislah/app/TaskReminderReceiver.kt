package dz.alislah.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class TaskReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("taskTitle")?.take(160)?.takeIf { it.isNotBlank() } ?: "مهمة مجدولة"
        val message = "حان موعد المهمة: $title"
        val service = Intent(context, AdhanService::class.java)
            .putExtra("message", message)
            .putExtra("adhan", false)
            .putExtra("taskReminder", true)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service)
            else context.startService(service)
        } catch (_: Exception) {
            // If the device blocks background service starts, the scheduled alarm is still safely handled.
        }
    }
}
