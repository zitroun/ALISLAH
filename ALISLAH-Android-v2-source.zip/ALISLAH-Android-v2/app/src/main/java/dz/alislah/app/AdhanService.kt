package dz.alislah.app

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class AdhanService : Service(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var player: MediaPlayer? = null
    private var ttsReady = false
    private var message = "حان وقت الصلاة"
    private var isAdhan = false
    private var isTaskReminder = false
    private var commandStarted = false
    override fun onCreate() { super.onCreate(); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel("alislah_adhan", "الأذان", NotificationManager.IMPORTANCE_HIGH)); tts = TextToSpeech(this, this) }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        message = intent?.getStringExtra("message") ?: "حان وقت الصلاة"
        isAdhan = intent?.getBooleanExtra("adhan", false) ?: false
        isTaskReminder = intent?.getBooleanExtra("taskReminder", false) ?: false
        commandStarted = true
        val stop = PendingIntent.getService(this, 9331, Intent(this, AdhanService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, "alislah_adhan") else @Suppress("DEPRECATION") Notification.Builder(this)
        startForeground(9330, builder.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(if (isAdhan) "ALISLAH · الأذان" else if (isTaskReminder) "ALISLAH · تذكير مهمة" else "ALISLAH · تذكير صوتي").setContentText(if (isTaskReminder) message else "اضغطي إيقاف لإيقاف الصوت").addAction(android.R.drawable.ic_media_pause, "إيقاف الأذان", stop).setOngoing(true).build())
        if (intent?.action == ACTION_STOP) { stopVoice(); stopSelf(); return START_NOT_STICKY }
        if (isAdhan) playHumanAdhan() else if (ttsReady) speakReminder()
        return START_NOT_STICKY
    }
    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts?.language = Locale("ar")
            tts?.setSpeechRate(0.82f)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onError(id: String?) { stopSelf() }
                override fun onDone(id: String?) { stopSelf() }
            })
            if (commandStarted) {
                if (isAdhan && player == null) speakAdhanFallback() else if (!isAdhan) speakReminder()
            }
        }
    }

    private fun playHumanAdhan() {
        try {
            val resourceId = resources.getIdentifier("adhan_4001", "raw", packageName)
            if (resourceId == 0) { speakAdhanFallback(); return }
            player?.release()
            player = MediaPlayer.create(this, resourceId)
            if (player == null) { speakAdhanFallback(); return }
            player?.setWakeMode(applicationContext, android.os.PowerManager.PARTIAL_WAKE_LOCK)
            player?.setOnCompletionListener { stopSelf() }
            player?.setOnErrorListener { mp, _, _ ->
                try { mp.reset(); mp.release() } catch (_: Exception) {}
                player = null
                speakAdhanFallback()
                true
            }
            player?.start()
        } catch (_: Exception) { speakAdhanFallback() }
    }

    private fun speakAdhanFallback() {
        if (!ttsReady) return
        val text = "الله أكبر، الله أكبر. الله أكبر، الله أكبر. أشهد أن لا إله إلا الله. أشهد أن لا إله إلا الله. أشهد أن محمدًا رسول الله. أشهد أن محمدًا رسول الله. حي على الصلاة. حي على الصلاة. حي على الفلاح. حي على الفلاح. الله أكبر، الله أكبر. لا إله إلا الله."
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "alislah_adhan_fallback")
    }

    private fun speakReminder() {
        if (!ttsReady) return
        val text = if (isTaskReminder) message else "$message. قال الله تعالى: وأقم الصلاة لذكري. وقال رسول الله صلى الله عليه وسلم: أحب الأعمال إلى الله الصلاة على وقتها، متفق عليه."
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "alislah_reminder")
    }

    private fun stopVoice() { try { player?.stop() } catch (_: Exception) {}; try { player?.release() } catch (_: Exception) {}; player = null; try { tts?.stop() } catch (_: Exception) {} }
    override fun onDestroy() { stopVoice(); tts?.shutdown(); (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(9330); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
    companion object { const val ACTION_STOP = "dz.alislah.app.STOP_ADHAN" }
}
