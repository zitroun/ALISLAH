package dz.alislah.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmRestoreReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == "android.intent.action.MY_PACKAGE_REPLACED" || intent?.action == AlarmManagerCompat.ACTION_EXACT_ALARM_PERMISSION_STATE_CHANGED) {
            TaskReminderScheduler.restore(context)
            PrayerScheduler.restore(context)
        }
    }
    private object AlarmManagerCompat { const val ACTION_EXACT_ALARM_PERMISSION_STATE_CHANGED = "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED" }
}
