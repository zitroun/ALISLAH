package dz.alislah.app

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.view.View

class EyeFilterService : Service() {
    private var filter: View? = null
    private var wm: WindowManager? = null
    override fun onCreate() { super.onCreate(); if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager; nm.createNotificationChannel(NotificationChannel("alislah_eye", "فلتر راحة العين", NotificationManager.IMPORTANCE_LOW)); startForeground(9440, Notification.Builder(this,"alislah_eye").setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("فلتر راحة العين مفعّل").setContentText("أوقفيه من إعدادات ALISLAH").setOngoing(true).build()) }; showFilter() }
    private fun showFilter() { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) { stopSelf(); return }; try { wm=getSystemService(WINDOW_SERVICE) as WindowManager; val v=View(this); v.setBackgroundColor(Color.argb(24,255,190,90)); v.isClickable=false; v.isFocusable=false; val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE; val flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN; val lp=WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,type,flags,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START}; wm?.addView(v,lp); filter=v } catch (_: Exception) { stopSelf() } }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() { try { filter?.let { wm?.removeView(it) } } catch (_: Exception) {}; (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(9440); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
