package dz.alislah.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/** Warm, non-touchable colour layer over the screen. Intensity comes from the "eyeFilterLevel" preference. */
class EyeFilterService : Service() {
    private var filter: View? = null
    private var wm: WindowManager? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("alislah_eye", "فلتر راحة العين", NotificationManager.IMPORTANCE_LOW))
        startForeground(
            9440,
            Notification.Builder(this, "alislah_eye")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("فلتر راحة العين مفعّل")
                .setContentText("أوقفيه من إعدادات ALISLAH")
                .setOngoing(true)
                .build()
        )
        showFilter()
    }

    private fun level(): Int =
        getSharedPreferences("alislah_native", MODE_PRIVATE).getInt("eyeFilterLevel", 24).coerceIn(5, 60)

    private fun showFilter() {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        try {
            if (filter == null) {
                wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val v = View(this)
                v.isClickable = false
                v.isFocusable = false
                val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    flags,
                    PixelFormat.TRANSLUCENT
                )
                lp.gravity = Gravity.TOP or Gravity.START
                wm?.addView(v, lp)
                filter = v
            }
            filter?.setBackgroundColor(Color.argb(level(), 255, 170, 70))
        } catch (_: Exception) {
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        showFilter() // re-applies the intensity when the user moves the slider
        return START_STICKY
    }

    override fun onDestroy() {
        try { filter?.let { wm?.removeView(it) } } catch (_: Exception) { }
        filter = null
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(9440)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
