/* Settings extras: font size, app lock, daily digest, backup options, snapshot for widget/digest, share target. */
(function(){
  'use strict';
  var A=window.ALI,$=function(s){return document.querySelector(s)};
  if(!A)return;
  var S=function(){return A.data.settings};
  var FS={small:'90%',normal:'100%',large:'115%',xlarge:'130%'};
  function applyFont(){document.documentElement.style.fontSize=FS[S().fontScale]||'100%'}
  function ensureNotif(){
    if(!A.NATIVE)return;var st=A.nativeStatus();
    if(st&&st.notifications===false){A.toast('اسمحي بالإشعارات لتصلك التنبيهات');setTimeout(function(){A.nat('requestNotificationPermission')},1000)}
  }
  function digestObj(){
    var d=S().digest;if(!d||typeof d!=='object')d=S().digest={};
    d.morning=d.morning&&typeof d.morning==='object'?d.morning:{on:false,time:'07:30'};
    d.evening=d.evening&&typeof d.evening==='object'?d.evening:{on:false,time:'21:00'};
    return d;
  }
  var timeRe=/^\d{2}:\d{2}$/;
  function saveDigest(turnedOn){
    var d=digestObj();
    d.morning.on=$('#digestMorningOn').checked;d.evening.on=$('#digestEveningOn').checked;
    d.morning.time=timeRe.test($('#digestMorningTime').value)?$('#digestMorningTime').value:'07:30';
    d.evening.time=timeRe.test($('#digestEveningTime').value)?$('#digestEveningTime').value:'21:00';
    A.save();A.nat('setDigest',JSON.stringify(d));
    if(turnedOn)ensureNotif();
    if(!A.NATIVE&&turnedOn)A.toast('الملخص اليومي يعمل في نسخة أندرويد');
  }
  function fillControls(){
    var s=S(),d=digestObj();
    $('#fontScale').value=s.fontScale||'normal';
    $('#appLockEnabled').checked=!!s.appLock;
    $('#digestMorningOn').checked=!!d.morning.on;$('#digestEveningOn').checked=!!d.evening.on;
    $('#digestMorningTime').value=d.morning.time||'07:30';$('#digestEveningTime').value=d.evening.time||'21:00';
    $('#backupReminder').checked=!!s.backupReminder;$('#encryptBackup').checked=!!s.encryptBackup;
    try{var raw=JSON.parse(localStorage.getItem('alislah_v2')||'{}').settings||{};$('#eyeFilterLevel').value=Math.max(5,Math.min(60,Number(raw.eyeFilterLevel)||24))}catch(e){}
  }
  function bind(){
    $('#fontScale').onchange=function(e){S().fontScale=e.target.value;A.save();applyFont()};
    $('#appLockEnabled').onchange=function(e){
      var on=e.target.checked;
      if(!A.NATIVE){e.target.checked=false;A.toast('قفل التطبيق متاح في نسخة أندرويد');return}
      var res=A.nat('setAppLock',on);
      if(on&&res!=='ok'){e.target.checked=false;A.toast(res==='no-secure'?'فعّلي قفل الشاشة (بصمة أو رمز) في الهاتف أولًا':'تعذر تفعيل القفل');return}
      S().appLock=on;A.save();A.toast(on?'تم تفعيل قفل التطبيق':'تم إيقاف قفل التطبيق');
    };
    ['#digestMorningOn','#digestEveningOn'].forEach(function(id){$(id).onchange=function(e){saveDigest(e.target.checked)}});
    ['#digestMorningTime','#digestEveningTime'].forEach(function(id){$(id).onchange=function(){saveDigest(false)}});
    $('#backupReminder').onchange=function(e){S().backupReminder=e.target.checked;A.save();A.nat('setBackupReminder',e.target.checked);if(e.target.checked){ensureNotif();if(!A.NATIVE)A.toast('التذكير يعمل في نسخة أندرويد')}};
    $('#encryptBackup').onchange=function(e){
      if(e.target.checked&&!(A.NATIVE&&window.AndroidUsage&&typeof AndroidUsage.encryptBackup==='function')){e.target.checked=false;A.toast('التشفير متاح في نسخة أندرويد');return}
      S().encryptBackup=e.target.checked;A.save();
    };
    $('#eyeFilterLevel').oninput=function(e){
      var n=Math.max(5,Math.min(60,Number(e.target.value)||24));
      try{var d=JSON.parse(localStorage.getItem('alislah_v2')||'{}');d.settings=d.settings||{};d.settings.eyeFilterLevel=n;d._rev=(Number(d._rev)||0)+1;localStorage.setItem('alislah_v2',JSON.stringify(d))}catch(x){}
      A.nat('setEyeFilterLevel',n);
    };
  }

  /* ---- snapshot for widget + digest notifications ---- */
  var snapTimer=null;
  function snapshot(){
    var d=A.data,t=A.today();
    var pend=d.tasks.filter(function(x){return !x.done&&(x.date||t)<=t}).sort(function(a,b){return String(a.date).localeCompare(String(b.date))||String(a.time||'99:99').localeCompare(String(b.time||'99:99'))});
    var done=d.tasks.filter(function(x){return x.done&&(x.doneAt===t||(!x.doneAt&&x.date===t))}).length;
    var np=null;try{np=window.ALI_NEXT_PRAYER?window.ALI_NEXT_PRAYER():null}catch(e){}
    return{date:t,pending:pend.length,done:done,top:pend.slice(0,3).map(function(x){return String(x.text).slice(0,40)}),name:String(d.settings.name||''),np:np};
  }
  function pushSnapshot(){try{A.nat('updateSnapshot',JSON.stringify(snapshot()))}catch(e){}}
  window.__alislahAfterSave=function(){clearTimeout(snapTimer);snapTimer=setTimeout(pushSnapshot,1500)};
  document.addEventListener('visibilitychange',function(){if(document.hidden)pushSnapshot()});

  /* ---- share target: text sent from other apps becomes a task ---- */
  window.__alislahShared=async function(text){
    text=String(text||'').replace(/\s+/g,' ').trim().slice(0,180);if(!text)return;
    var ok=await A.ui.confirm('إضافة مهمة؟','إضافة',false,text);if(!ok)return;
    var task={id:A.uid(),text:text,date:A.today(),time:'',priority:'عادية',cat:'',repeat:'',done:false};
    A.data.tasks.push(task);A.save();A.renderTasks();A.tab('tasks');A.toast('أُضيفت المهمة');
  };

  function init(){applyFont();fillControls();bind();pushSnapshot();if(A.NATIVE&&S().appLock)A.nat('setAppLock',true)}
  init();
  window.__alislahResync=(function(prev){return function(){try{prev&&prev()}catch(e){}applyFont();fillControls()}})(window.__alislahResync);
})();
