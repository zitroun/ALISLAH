/* Prayer times screen: offline calculation, adhan scheduling (native) and daily log. */
(function(){
  'use strict';
  var KEY='alislah_v2',P=window.ALI_PRAYER,H=window.ALI_HIJRI;
  var $=function(s){return document.querySelector(s)};
  var NAMES={Fajr:'الفجر',Dhuhr:'الظهر',Asr:'العصر',Maghrib:'المغرب',Isha:'العشاء'};
  var ORDER=['Fajr','Dhuhr','Asr','Maghrib','Isha'];
  var DEFAULTS={wilaya:'14',lat:35.37,lon:1.32,method:'algeria',adj:{Fajr:0,Dhuhr:0,Asr:0,Maghrib:0,Isha:0},before:10,after:20,followup:true,adhanEnabled:false};
  var HORIZON_DAYS=365;
  var syncTimer=null,syncing=false,syncAgain=false,lastDayKey='',firedMinute='';

  var hasNative=function(){return !!(window.AndroidUsage&&typeof AndroidUsage.syncPrayerPlan==='function')};
  var say=function(m){(window.__toast||function(x){alert(x)})(m)};
  var pad=function(n){return String(n).padStart(2,'0')};
  var dayKey=function(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())};
  var hhmm=function(d){return pad(d.getHours())+':'+pad(d.getMinutes())};

  function readState(){try{return JSON.parse(localStorage.getItem(KEY)||'{}')||{}}catch(e){return {}}}
  function cfg(){
    var st=readState(),p=(st.settings&&st.settings.prayer)||{};
    var c=Object.assign({},DEFAULTS,p);c.adj=Object.assign({},DEFAULTS.adj,p.adj||{});
    // migrate the old free-text city setting
    if(p.wilaya===undefined&&typeof p.city==='string'&&p.city.trim()){
      var q=p.city.trim().toLowerCase();
      var w=P.WILAYAS.find(function(x){return x.en.toLowerCase()===q||x.ar===p.city.trim()});
      if(w){c.wilaya=String(w.id);c.lat=w.lat;c.lon=w.lon}
    }
    if(!P.METHODS[c.method])c.method='algeria';
    c.lat=Number(c.lat);c.lon=Number(c.lon);
    if(!isFinite(c.lat)||!isFinite(c.lon)){c.lat=DEFAULTS.lat;c.lon=DEFAULTS.lon}
    return c;
  }
  function persist(c){
    try{var st=readState();st.settings=st.settings||{};st.settings.prayer=c;st._rev=(Number(st._rev)||0)+1;localStorage.setItem(KEY,JSON.stringify(st))}catch(e){}
  }
  function timesFor(date,c){return P.compute(date,c.lat,c.lon,c.method,c.adj)}

  /* ---------- daily log ("تمت الصلاة") ---------- */
  function logToday(){
    var d=readState(),k=dayKey(new Date());
    return (Array.isArray(d.prayerLog)?d.prayerLog:[]).filter(function(x){return x&&(x.day===k||(!x.day&&String(x.date||'').slice(0,10)===k))}).map(function(x){return x.name});
  }
  function toggleLog(name){
    try{
      var d=readState(),k=dayKey(new Date());d.prayerLog=Array.isArray(d.prayerLog)?d.prayerLog:[];
      var had=d.prayerLog.some(function(x){return x&&x.name===name&&(x.day===k||(!x.day&&String(x.date||'').slice(0,10)===k))});
      if(had)d.prayerLog=d.prayerLog.filter(function(x){return !(x&&x.name===name&&(x.day===k||(!x.day&&String(x.date||'').slice(0,10)===k)))});
      else d.prayerLog.push({name:name,date:new Date().toISOString(),day:k,done:true});
      d.prayerLog=d.prayerLog.slice(-1500);
      localStorage.setItem(KEY,JSON.stringify(d));
      return !had;
    }catch(e){return false}
  }

  /* ---------- rendering ---------- */
  function wilayaLabel(c){
    if(String(c.wilaya)==='0')return 'إحداثيات مخصصة';
    var w=P.WILAYAS.find(function(x){return String(x.id)===String(c.wilaya)});
    return w?w.ar:'الموقع المحفوظ';
  }
  function ensureRows(box){
    if(box.querySelector('.prayer-row'))return;
    box.innerHTML=ORDER.map(function(k){return '<div class="prayer-row" data-key="'+k+'"><div class="pr-name">'+NAMES[k]+'</div><div class="pr-time"></div><button type="button" class="pr-check" data-name="'+NAMES[k]+'"></button></div>'}).join('');
    if(!box.dataset.bound){
      box.dataset.bound='1';
      box.addEventListener('click',function(e){
        var b=e.target.closest&&e.target.closest('.pr-check');if(!b)return;
        var on=toggleLog(b.dataset.name);render();if(on)say('تم تسجيل الصلاة. أحسنتِ الاستمرار.');
      });
    }
  }
  function render(){
    var c=cfg(),now=new Date(),t=timesFor(now,c);lastDayKey=dayKey(now);
    var lab=$('#prayerLocationLabel');
    if(lab)lab.textContent=wilayaLabel(c)+' · '+(H?H.text(now):'')+' · '+now.toLocaleDateString('ar',{weekday:'long',day:'numeric',month:'long'});
    var box=$('#prayerTimes');if(!box)return;
    if(!t){box.innerHTML='<div class="empty">تعذّر حساب المواقيت لهذا الموقع. جرّبي موقعًا آخر.</div>';return}
    ensureRows(box);
    var done=new Set(logToday());
    ORDER.forEach(function(k){
      var row=box.querySelector('.prayer-row[data-key="'+k+'"]');if(!row)return;
      var isDone=done.has(NAMES[k]);
      row.classList.toggle('done',isDone);
      row.querySelector('.pr-time').textContent=hhmm(t[k]);
      var b=row.querySelector('.pr-check');
      b.setAttribute('aria-pressed',String(isDone));
      b.setAttribute('aria-label',(isDone?'إلغاء تسجيل صلاة ':'تسجيل صلاة ')+NAMES[k]);
      b.textContent=isDone?'✓':'';
    });
    var sr=$('#prayerSunrise');if(sr)sr.textContent='🌅 الشروق: '+hhmm(t.Sunrise);
    updateNext();
  }
  function nextPrayer(){
    var c=cfg(),now=new Date(),t=timesFor(now,c),best=null;
    if(t)ORDER.forEach(function(k){if(t[k]>now&&(!best||t[k]<best.at))best={key:k,name:NAMES[k],at:t[k],tomorrow:false}});
    if(!best){
      var tm=new Date(now.getFullYear(),now.getMonth(),now.getDate()+1,12),tt=timesFor(tm,c);
      if(tt)best={key:'Fajr',name:NAMES.Fajr,at:tt.Fajr,tomorrow:true};
    }
    return best;
  }
  window.ALI_NEXT_PRAYER=function(){var n=nextPrayer();return n?{name:n.name,at:n.at.getTime()}:null};
  function updateNext(){
    var n=nextPrayer(),nm=$('#prayerNextName'),inn=$('#prayerNextIn');if(!nm||!inn)return;
    if(!n){nm.textContent='—';inn.textContent='—';return}
    nm.textContent=n.name+(n.tomorrow?' (غدًا)':'')+' · '+hhmm(n.at);
    var mins=Math.max(0,Math.round((n.at-new Date())/60000)),h=Math.floor(mins/60),m=mins%60;
    inn.textContent='بعد '+(h?h+' س ':'')+m+' د';
    document.querySelectorAll('#prayerTimes .prayer-row').forEach(function(el){el.classList.toggle('next',!n.tomorrow&&el.dataset.key===n.key)});
  }

  /* ---------- settings UI ---------- */
  function buildControls(){
    var sel=$('#prayerWilaya');if(!sel)return;
    sel.innerHTML=P.WILAYAS.map(function(w){return '<option value="'+w.id+'">'+w.id+' - '+w.ar+'</option>'}).join('')+'<option value="0">إحداثيات مخصصة…</option>';
    var adj=$('#prayerAdj');
    adj.innerHTML=ORDER.map(function(k){return '<label class="fld" style="margin:0"><span>'+NAMES[k]+'</span><input type="number" inputmode="numeric" step="1" min="-30" max="30" data-k="'+k+'" aria-label="تصحيح '+NAMES[k]+' بالدقائق" dir="ltr"></label>'}).join('');
    fillControls();
    sel.onchange=function(){
      var c=cfg();c.wilaya=sel.value;
      if(sel.value!=='0'){var w=P.WILAYAS.find(function(x){return String(x.id)===sel.value});if(w){c.lat=w.lat;c.lon=w.lon}}
      persist(c);fillControls();render();scheduleSync();
    };
    ['#prayerLat','#prayerLon'].forEach(function(id){$(id).onchange=collect});
    $('#prayerMethod').onchange=collect;
    adj.querySelectorAll('input').forEach(function(i){i.onchange=collect});
    ['#prayerBefore','#prayerAfter','#prayerFollowup','#prayerAdhanEnabled'].forEach(function(id){$(id).addEventListener('change',collect)});
    $('#prayerAdhanEnabled').addEventListener('change',function(e){
      if(!e.target.checked||!hasNative())return;
      try{var st=JSON.parse(AndroidUsage.getNativeStatus()||'{}');if(st.notifications===false){say('اسمحي بالإشعارات ليصلك الأذان والتنبيهات');AndroidUsage.requestNotificationPermission()}}catch(e2){}
    });
    $('#prayerAdhanTest').onclick=function(){
      if(window.AndroidUsage&&typeof AndroidUsage.playAdhanTest==='function'){try{AndroidUsage.playAdhanTest()}catch(e){say('تعذر تشغيل الأذان')}return}
      say('اختبار الأذان متاح في نسخة أندرويد فقط.');
    };
    var stop=$('#prayerAdhanStop');
    if(hasNative()){stop.classList.remove('hidden');stop.onclick=function(){try{AndroidUsage.stopAdhan()}catch(e){}}}
    else setStatus('في المتصفح يظهر تنبيه نصي عند دخول الوقت أثناء فتح الصفحة فقط.');
  }
  function fillControls(){
    var c=cfg();
    $('#prayerWilaya').value=String(c.wilaya);
    $('#prayerCustom').classList.toggle('hidden',String(c.wilaya)!=='0');
    $('#prayerLat').value=c.lat;$('#prayerLon').value=c.lon;
    $('#prayerMethod').value=c.method;
    document.querySelectorAll('#prayerAdj input').forEach(function(i){i.value=c.adj[i.dataset.k]||0});
    $('#prayerBefore').value=c.before;$('#prayerAfter').value=c.after;
    $('#prayerFollowup').checked=!!c.followup;$('#prayerAdhanEnabled').checked=!!c.adhanEnabled;
  }
  function clamp(v,a,b,d){v=Number(v);return isFinite(v)?Math.min(b,Math.max(a,v)):d}
  function collect(){
    var c=cfg();
    c.wilaya=$('#prayerWilaya').value;
    if(c.wilaya==='0'){c.lat=clamp($('#prayerLat').value,-90,90,c.lat);c.lon=clamp($('#prayerLon').value,-180,180,c.lon)}
    c.method=$('#prayerMethod').value;
    document.querySelectorAll('#prayerAdj input').forEach(function(i){c.adj[i.dataset.k]=Math.round(clamp(i.value,-30,30,0))});
    c.before=Math.round(clamp($('#prayerBefore').value,0,120,10));c.after=Math.round(clamp($('#prayerAfter').value,0,180,20));
    c.followup=$('#prayerFollowup').checked;c.adhanEnabled=$('#prayerAdhanEnabled').checked;
    persist(c);render();scheduleSync();
  }

  /* ---------- native scheduling (30 days) ---------- */
  function setStatus(t){var el=$('#prayerNativeStatus');if(el)el.textContent=t||''}
  function buildPlan(c){
    var items=[],t0=Date.now(),today=new Date();
    for(var i=0;i<HORIZON_DAYS;i++){
      var d=new Date(today.getFullYear(),today.getMonth(),today.getDate()+i,12),t=timesFor(d,c);
      if(!t)continue;
      ORDER.forEach(function(k){
        var at=t[k].getTime();if(at<=t0)return;
        items.push({k:'adhan',n:NAMES[k],at:at});
        if(c.before>0)items.push({k:'before',n:NAMES[k],at:at-c.before*60000});
        if(c.followup&&c.after>0)items.push({k:'after',n:NAMES[k],at:at+c.after*60000});
      });
    }
    return items;
  }
  function syncNative(){
    if(!hasNative())return;
    if(syncing){syncAgain=true;return}
    syncing=true;
    try{
      var c=cfg();
      if(!c.adhanEnabled){AndroidUsage.syncPrayerPlan('[]',false);setStatus('الأذان وتنبيهات الصلاة متوقفة.');return}
      var items=buildPlan(c);
      if(!items.length){setStatus('تعذّر حساب المواقيت لهذا الموقع.');return}
      AndroidUsage.syncPrayerPlan(JSON.stringify(items),true);
      var n=items.filter(function(x){return x.k==='adhan'}).length;
      setStatus('جُدولت '+n+' أذانًا للأيام الثلاثين القادمة، ويتجدد الجدول كلما فتحتِ التطبيق.');
    }catch(e){setStatus('تعذر تحديث الجدولة؛ حاولي مجددًا.')}
    finally{syncing=false;if(syncAgain){syncAgain=false;scheduleSync()}}
  }
  function scheduleSync(){if(!hasNative())return;clearTimeout(syncTimer);syncTimer=setTimeout(syncNative,600)}

  /* ---------- in-page reminder (browser only) ---------- */
  function tick(){
    var now=new Date();
    if(dayKey(now)!==lastDayKey)render();else updateNext();
    if(hasNative())return;
    var c=cfg();if(!c.adhanEnabled)return;
    var t=timesFor(now,c);if(!t)return;
    var key=dayKey(now)+' '+hhmm(now);
    for(var i=0;i<ORDER.length;i++){var k=ORDER[i];if(hhmm(t[k])===hhmm(now)&&firedMinute!==key){firedMinute=key;say('حان وقت صلاة '+NAMES[k]);break}}
  }

  function init(){
    if(!$('#prayer')||!P)return;
    buildControls();render();
    setInterval(tick,20000);
    document.addEventListener('visibilitychange',function(){if(!document.hidden){render();scheduleSync()}});
    document.addEventListener('alislah:tab',function(e){if(e.detail==='prayer')render()});
    if(hasNative())setTimeout(scheduleSync,1200);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
