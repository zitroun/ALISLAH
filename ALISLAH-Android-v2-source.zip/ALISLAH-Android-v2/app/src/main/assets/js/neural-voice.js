/* ALISLAH Arabic neural voice (Nabra-7M Distill)
 * Lazy-loaded on first assistant speech. The model is cached by Nabra in Cache Storage.
 * Android TextToSpeech remains the fallback and the male voice path because this model
 * currently ships with one MSA voice only.
 */
(function () {
  'use strict';
  let enginePromise = null;
  let engine = null;
  let audioContext = null;
  let activeSource = null;
  let activeGeneration = 0;
  let lastError = '';

  function notify(ok, detail) {
    try {
      const message = String(detail || '').slice(0, 300);
      window.dispatchEvent(new CustomEvent('alislah:neural-voice', { detail: { ok: !!ok, detail: message } }));
      if (window.AndroidUsage && typeof window.AndroidUsage.onNeuralSpeechResult === 'function') {
        window.AndroidUsage.onNeuralSpeechResult(!!ok, message);
      }
    } catch (_) {}
  }

  async function loadEngine() {
    if (engine) return engine;
    if (!enginePromise) {
      enginePromise = (async function () {
        // The small JS package is loaded on demand; the 16 MB FP16 model and voice
        // are cached by the package after their first successful download.
        const pkg = await import('https://cdn.jsdelivr.net/npm/nabra-tts@0/+esm');
        const NabraTTS = pkg.NabraTTS || (pkg.default && pkg.default.NabraTTS);
        if (!NabraTTS || typeof NabraTTS.load !== 'function') throw new Error('تعذر تحميل مكتبة النطق');
        engine = await NabraTTS.load({ dtype: 'fp16', device: 'wasm', worker: true, cache: true, numThreads: 1 });
        return engine;
      })().catch(function (e) {
        lastError = String(e && (e.message || e) || 'load failed');
        enginePromise = null;
        throw e;
      });
    }
    return enginePromise;
  }

  async function speak(text) {
    const clean = String(text || '').trim().slice(0, 700);
    if (!clean) throw new Error('empty text');
    const generation = ++activeGeneration;
    try {
      const tts = await loadEngine();
      if (generation !== activeGeneration) return false;
      const result = await tts.generate(clean);
      if (generation !== activeGeneration) return false;
      const pcm = result && result.audio;
      const rate = Number(result && result.sampleRate) || 24000;
      if (!pcm || !pcm.length) throw new Error('لم ينتج المحرك صوتًا');
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) throw new Error('الصوت غير مدعوم في هذا الإصدار من WebView');
      if (!audioContext) audioContext = new Ctx();
      if (audioContext.state === 'suspended') await audioContext.resume();
      const buffer = audioContext.createBuffer(1, pcm.length, rate);
      buffer.copyToChannel(pcm, 0);
      if (activeSource) { try { activeSource.stop(); } catch (_) {} }
      activeSource = audioContext.createBufferSource();
      activeSource.buffer = buffer;
      activeSource.connect(audioContext.destination);
      activeSource.onended = function () { if (generation === activeGeneration) activeSource = null; };
      activeSource.start(0);
      notify(true, 'neural-ready');
      return true;
    } catch (e) {
      lastError = String(e && (e.message || e) || 'speech failed');
      notify(false, lastError);
      return false;
    }
  }

  function stop() {
    activeGeneration++;
    if (activeSource) { try { activeSource.stop(); } catch (_) {} activeSource = null; }
  }

  window.AlishlahNeuralVoice = {
    speak: speak,
    stop: stop,
    status: function () { return { ready: !!engine, loading: !!enginePromise, error: lastError }; }
  };
})();
