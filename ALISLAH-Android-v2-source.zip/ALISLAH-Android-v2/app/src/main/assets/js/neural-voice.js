/* ALISLAH local Arabic neural voice: MixerTTS speaker 0 + Vocos 22 kHz.
 * The model assets are bundled in the APK; after installation synthesis is offline.
 */
(function () {
  'use strict';
  let speaking = false;
  let lastError = '';
  function notify(ok, detail) {
    try { window.dispatchEvent(new CustomEvent('alislah:neural-voice', { detail: { ok: !!ok, detail: String(detail || '').slice(0, 300) } })); } catch (_) {}
  }
  async function speak(text) {
    const clean = String(text || '').trim().slice(0, 700);
    if (!clean) return false;
    if (!window.AndroidUsage || typeof AndroidUsage.speakMixerTts !== 'function') {
      lastError = 'واجهة المحرك المحلي غير متاحة'; notify(false, lastError); return false;
    }
    try {
      speaking = true;
      notify(true, 'بدء تشغيل محرك Mixer-TTS المحلي…');
      AndroidUsage.speakMixerTts(clean);
      return true;
    } catch (e) {
      speaking = false; lastError = String(e && (e.message || e) || 'speech failed'); notify(false, lastError); return false;
    }
  }
  function stop() {
    speaking = false;
    try { if (window.AndroidUsage && AndroidUsage.stopMixerTts) AndroidUsage.stopMixerTts(); } catch (_) {}
  }
  window.AlishlahNeuralVoice = { speak, stop, status: () => ({ ready: false, loading: speaking, error: lastError }) };
})();
