(()=>{'use strict';
const $=s=>document.querySelector(s), KEY='alislah_v2', STORE='alislah_checkins_v1', ENDPOINT='https://alislah-ai.zitroun2222.workers.dev/';
const questions=[
{q:'ما أهم شيء تريد تحسينه أولًا؟',a:['تنظيم الوقت','الصحة والراحة','التعلم أو العمل','العائلة والعلاقات']},
{q:'ما هدفك الأهم خلال الشهر القادم؟',a:['إنجاز هدف مؤجل','بناء عادة جيدة','تقليل التشتت','تحقيق توازن أفضل']},
{q:'ما الذي يعرقل يومك غالبًا؟',a:['الهاتف والتطبيقات','قلة الطاقة','عدم وضوح الأولويات','المقاطعات والمسؤوليات']},
{q:'متى يكون تركيزك أفضل عادة؟',a:['الصباح','منتصف اليوم','المساء','يتغير يوميًا']},
{q:'كيف تصف نومك في الأيام الأخيرة؟',a:['مريح وكافٍ','متوسط','متقطع','غير كافٍ']},
{q:'كيف كانت طاقتك اليوم؟',a:['عالية','مقبولة','منخفضة','متقلبة']},
{q:'ما نوع الخطة الأنسب لك؟',a:['خطوات صغيرة جدًا','جدول واضح بالساعات','قائمة مرنة','تذكيرات عند الحاجة']},
{q:'كيف تفضّل أن يشجعك المساعد؟',a:['بلطف وتشجيع','بخطوات مباشرة','بمتابعة التقدم','باقتراحات قصيرة']},
{q:'ما مقدار الوقت الذي تريد تخصيصه يوميًا لهدفك؟',a:['5–10 دقائق','15–30 دقيقة','30–60 دقيقة','حسب اليوم']},
{q:'ما أكثر شيء تحتاجه الآن؟',a:['خطة عملية','فهم عادتي','تقليل ضغط المهام','تذكير في الوقت المناسب']},
{q:'هل تريد إدخال مسؤوليات الأسرة في خطتك؟',a:['نعم','لا','أحيانًا','أفضل أن أقرر لاحقًا']},
{q:'ما وتيرة الأسئلة التي تناسبك بعد التعارف؟',a:['عند الحاجة فقط','سؤال يومي كحد أقصى','عدة مرات عند التغيير','دع التطبيق يقدّر الحاجة']},
{q:'كيف كان تركيزك اليوم؟',a:['ممتاز','جيد','متوسط','متشتت']},
{q:'ما أكثر شيء استنزف وقتك اليوم؟',a:['الهاتف','العمل أو الدراسة','مسؤوليات الأسرة','أمور أخرى']},
{q:'ما الذي تود تحسينه غدًا؟',a:['تنظيم الوقت','تقليل الهاتف','العناية بنفسي','الوقت مع الأسرة']}
];
let answered={},idx=0,onboarding=false;
try{answered=JSON.parse(localStorage.getItem(STORE)||'{}')||{}}catch{}
const btn=$('#alislahFloat'),panel=$('#alislahCheckin'),q=$('#alislahCheckinQuestion'),answers=$('#alislahCheckinAnswers'),status=$('#alislahCheckinStatus');
if(!btn||!panel||!q||!answers)return;
const fresh=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'{}')||{}}catch{return {}}};const cloudAllowed=()=>fresh().settings?.questionCloudEnabled===true;function markOnboardingDone(){try{const cur=fresh();cur.profileOnboardingDone=true;cur._rev=(Number(cur._rev)||0)+1;localStorage.setItem(KEY,JSON.stringify(cur))}catch{}}
function save(){try{localStorage.setItem(STORE,JSON.stringify(answered));const v=JSON.parse(localStorage.getItem(STORE)||'null');if(!v||typeof v!=='object')throw Error();return true}catch{return false}}
function tell(t){status.textContent=t}
async function sendAnswer(item,answer){if(!cloudAllowed()){tell('حُفظت محليًا؛ الإرسال السحابي متوقف من الإعدادات.');return}tell('حُفظت محليًا. يجري إرسال هذه الإجابة للتحليل…');try{const r=await fetch(ENDPOINT,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:'حلّل إجابة اختيارية لبناء ملف عادات وخطة عملية، ولا تشخّص ولا تستنتج ما لم يُذكر. السؤال: '+item.q+'\nالإجابة: '+answer+'\nأعطني توصية قصيرة فقط.',history:[]}),signal:AbortSignal.timeout?AbortSignal.timeout(12000):undefined,cache:'no-store'});const j=await r.json();if(!r.ok||typeof j.reply!=='string')throw Error('bad response');tell('وصلت الإجابة للتحليل. يمكن متابعة الأسئلة أو طلب خطة من المساعد.')}catch(e){tell('حُفظت الإجابة محليًا، لكن تعذّر الاتصال الآن. سيبقى بإمكانك المحاولة لاحقًا من المساعد.')}}
function render(){const item=questions[idx];q.textContent=(onboarding?'التعارف الأولي · ':'')+item.q;answers.innerHTML='';item.a.forEach(label=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.onclick=()=>record(label);answers.appendChild(b)});tell(cloudAllowed()?(onboarding?'اختيارك يوافق على إرسال هذه الإجابة وحدها للتحليل عبر الإنترنت. التخطي لا يرسل شيئًا.':'إجابتك اختيارية؛ لا نرسلها إذا تخطّيت السؤال.'):'إجاباتك تُحفظ على جهازك فقط. يمكنك تفعيل إرسالها للتحليل من الإعدادات.');}
function next(){if(onboarding){idx++;if(idx>=questions.length){onboarding=false;markOnboardingDone();closePanel();const t=$('#toast');if(t){t.textContent='اكتمل التعارف الأولي؛ يمكنك طلب خطتك من المساعد.';t.classList.remove('hidden');setTimeout(()=>t.classList.add('hidden'),3000)}return}render();return}
 const records=Object.values(answered).filter(x=>x&&x.question&&x.answer);const unanswered=questions.map((x,i)=>i).filter(i=>!records.some(r=>r.qid===i));if(unanswered.length){idx=unanswered[0];render();return}const day=new Date().toISOString().slice(0,10);const todayCount=records.filter(x=>String(x.at||'').startsWith(day)).length;idx=(todayCount%questions.length);render();}
function record(answer){const item=questions[idx],at=new Date().toISOString(),id=at+'_'+idx;answered[id]={qid:idx,question:item.q,answer,at};const ok=save();if(!ok){tell('تعذر حفظ الإجابة. لم تُرسل إلى الإنترنت.');return}answers.querySelectorAll('button').forEach(b=>b.disabled=true);sendAnswer(item,answer);setTimeout(()=>{if(panel.classList.contains('open'))next()},1000)}
function skip(){if(onboarding){idx++;if(idx>=questions.length){onboarding=false;markOnboardingDone();closePanel();return}render()}else{idx=(idx+1)%questions.length;render()}tell('تم تخطي السؤال دون حفظ إجابة أو إرسالها.')}
function openPanel(){panel.classList.add('open');btn.setAttribute('aria-expanded','true');onboarding=fresh().profileOnboardingDone!==true&&Object.keys(answered).length===0;idx=0;render();if(onboarding)tell(cloudAllowed()?'قبل البدء: كل إجابة تختارينها تُرسل وحدها إلى خدمة الذكاء الاصطناعي للتحليل. يمكنك تخطي أي سؤال، وإيقاف الإرسال من الإعدادات.':'تعارف سريع: إجاباتك تُحفظ على جهازك فقط، ويمكنك تخطي أي سؤال.')}
function closePanel(){panel.classList.remove('open');btn.setAttribute('aria-expanded','false')}
const skipBtn=document.createElement('button');skipBtn.type='button';skipBtn.textContent='تخطي السؤال';skipBtn.style.cssText='border:1px solid var(--line);border-radius:10px;padding:8px 12px;background:var(--card);color:var(--ink);margin-top:10px';skipBtn.onclick=skip;answers.insertAdjacentElement('afterend',skipBtn);
btn.addEventListener('click',()=>panel.classList.contains('open')?closePanel():openPanel());$('#alislahCheckinClose').onclick=closePanel;$('#alislahCheckinLater').textContent='إغلاق الآن';$('#alislahCheckinLater').onclick=closePanel;
$('#alislahCheckinPlan').onclick=()=>{const records=Object.values(answered).filter(x=>x&&x.question&&x.answer).sort((a,b)=>String(a.at).localeCompare(String(b.at))).slice(-20);if(!records.length){tell('أجيبي عن سؤال أو تخطيه؛ يمكنك البدء متى شئت.');return}const prompt='ابنِ لي خطة شخصية صغيرة اعتمادًا فقط على الإجابات التالية، وحدد خطوة واحدة الآن ومؤشر تقدم بسيطًا. لا تفترض معلومات أخرى.\n'+records.map(x=>'• '+x.question+' — '+x.answer).join('\n');closePanel();const tabBtn=document.querySelector('[data-tab="assistant"]');if(tabBtn)tabBtn.click();const chat=$('#chatText');if(chat){chat.value=prompt;chat.dataset.includesPersonalAnalysis='false';chat.focus();tell('أُعدّت الخطة من الإجابات المحفوظة. أرسليها للمساعد عند رغبتك.')}};
// First-run onboarding is shown on the first visit after a short delay, only while this page is open.

})();
