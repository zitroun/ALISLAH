/* Qibla compass: great-circle bearing + device orientation (absolute) when available. */
(function(){
  'use strict';
  var A=window.ALI,P=window.ALI_PRAYER,host=document.getElementById('qibla');
  if(!A||!P||!host)return;
  var heading=null,bearing=0,active=false,gotEvent=false,lastBuzz=0,timer=null;
  function loc(){
    try{var s=JSON.parse(localStorage.getItem('alislah_v2')||'{}').settings||{},p=s.prayer||{};
      var lat=Number(p.lat),lon=Number(p.lon);
      if(isFinite(lat)&&isFinite(lon)&&(p.lat!==undefined))return{lat:lat,lon:lon,name:p.wilaya==='0'?'إحداثيات مخصصة':((P.WILAYAS.find(function(w){return String(w.id)===String(p.wilaya)})||{}).ar||'الموقع المحفوظ')};
    }catch(e){}
    return{lat:35.37,lon:1.32,name:'تيارت'};
  }
  function build(){
    var l=loc();bearing=P.qibla(l.lat,l.lon);
    host.innerHTML='<div class="panel"><h3>🧭 اتجاه القبلة</h3>'+
      '<div class="compass-wrap"><div class="compass-top" aria-hidden="true">▲</div><svg id="compass" viewBox="-110 -110 220 220" role="img" aria-label="بوصلة القبلة"><g id="dial"><circle r="100" fill="var(--soft-2)" stroke="var(--line-strong)" stroke-width="2"/>'+
      [0,90,180,270].map(function(a,i){return '<g transform="rotate('+a+') translate(0,-78) rotate('+(-a)+')"><text x="0" y="6" text-anchor="middle" font-size="16" font-weight="800" fill="var(--muted)">'+['N','E','S','W'][i]+'</text></g>'}).join('')+
      Array.from({length:36},function(_,i){return '<line x1="0" y1="-100" x2="0" y2="'+(i%9===0?-90:-95)+'" stroke="var(--line-strong)" stroke-width="'+(i%9===0?2:1)+'" transform="rotate('+(i*10)+')"/>'}).join('')+
      '<g id="qmark" transform="rotate('+bearing.toFixed(1)+')"><line x1="0" y1="0" x2="0" y2="-66" stroke="var(--brand)" stroke-width="4" stroke-linecap="round"/><text x="0" y="-70" text-anchor="middle" font-size="26">🕋</text></g></g><circle r="5" fill="var(--brand)"/></svg></div>'+
      '<div class="qibla-deg" id="qdeg">'+Math.round(bearing)+'°</div><div class="muted" id="qinfo" style="text-align:center">من الشمال الحقيقي، حسب موقعك: '+A.esc(l.name)+'</div>'+
      '<div class="notice info" id="qstate" style="text-align:center;margin-top:12px">ضعي الهاتف أفقيًا ودوّريه حتى يصبح 🕋 في أعلى الدائرة.</div>'+
      '<p class="muted" style="margin:12px 0 0;font-size:.85rem">للمعايرة حرّكي الهاتف على شكل الرقم 8 وابتعدي عن المعادن والمغناطيس. البوصلة تقريبية؛ تأكدي من اتجاه المسجد القريب إن أمكن. يمكنك تغيير الموقع من تبويب «الصلاة».</p></div>';
    update();
  }
  function update(){
    var dial=document.getElementById('dial');if(!dial)return;
    var st=document.getElementById('qstate');
    if(heading==null){dial.setAttribute('transform','rotate(0)');return}
    dial.setAttribute('transform','rotate('+(-heading).toFixed(1)+')');
    var diff=((bearing-heading+540)%360)-180;
    if(Math.abs(diff)<4){
      st.textContent='✓ أنتِ تواجهين القبلة';st.classList.remove('info');
      var now=Date.now();if(now-lastBuzz>4000&&navigator.vibrate){lastBuzz=now;try{navigator.vibrate(60)}catch(e){}}
    }else{st.classList.add('info');st.textContent='دوّري '+(diff>0?'يمينًا':'يسارًا')+' نحو '+Math.round(Math.abs(diff))+'°'}
  }
  function onOrient(e){
    var h=null;
    if(typeof e.webkitCompassHeading==='number')h=e.webkitCompassHeading;
    else if(e.absolute&&typeof e.alpha==='number')h=(360-e.alpha)%360;
    else if(typeof e.alpha==='number'&&e.type==='deviceorientationabsolute')h=(360-e.alpha)%360;
    if(h==null||!isFinite(h))return;
    gotEvent=true;heading=h;update();
  }
  function start(){
    if(active)return;active=true;gotEvent=false;heading=null;
    window.addEventListener('deviceorientationabsolute',onOrient,true);
    window.addEventListener('deviceorientation',onOrient,true);
    clearTimeout(timer);timer=setTimeout(function(){
      var st=document.getElementById('qstate');
      if(!gotEvent&&st)st.textContent='لا تتوفر بوصلة في هذا الجهاز. اتجاه القبلة نحو '+Math.round(bearing)+'° من الشمال.';
    },2500);
  }
  function stop(){active=false;window.removeEventListener('deviceorientationabsolute',onOrient,true);window.removeEventListener('deviceorientation',onOrient,true);clearTimeout(timer)}
  document.addEventListener('alislah:tab',function(e){if(e.detail==='qibla'){build();start()}else stop()});
  document.addEventListener('visibilitychange',function(){if(document.hidden)stop();else if(document.body.dataset.view==='qibla')start()});
})();
