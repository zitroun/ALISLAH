/* Prayer-time calculation (no network). Based on the standard solar-position
   method used by PrayTimes.org, validated against an independent NOAA
   implementation in tests/. Coordinates of the 58 Algerian wilayas are approximate. */
(function(root){
  var WILAYAS=[
    [1,'أدرار','Adrar',27.87,-0.29],[2,'الشلف','Chlef',36.16,1.33],[3,'الأغواط','Laghouat',33.80,2.88],[4,'أم البواقي','Oum El Bouaghi',35.88,7.11],
    [5,'باتنة','Batna',35.56,6.17],[6,'بجاية','Bejaia',36.75,5.08],[7,'بسكرة','Biskra',34.85,5.73],[8,'بشار','Bechar',31.62,-2.22],
    [9,'البليدة','Blida',36.47,2.83],[10,'البويرة','Bouira',36.37,3.90],[11,'تمنراست','Tamanrasset',22.79,5.53],[12,'تبسة','Tebessa',35.40,8.12],
    [13,'تلمسان','Tlemcen',34.88,-1.32],[14,'تيارت','Tiaret',35.37,1.32],[15,'تيزي وزو','Tizi Ouzou',36.72,4.05],[16,'الجزائر','Algiers',36.75,3.06],
    [17,'الجلفة','Djelfa',34.67,3.25],[18,'جيجل','Jijel',36.82,5.77],[19,'سطيف','Setif',36.19,5.41],[20,'سعيدة','Saida',34.83,0.15],
    [21,'سكيكدة','Skikda',36.88,6.91],[22,'سيدي بلعباس','Sidi Bel Abbes',35.19,-0.63],[23,'عنابة','Annaba',36.90,7.77],[24,'قالمة','Guelma',36.46,7.43],
    [25,'قسنطينة','Constantine',36.36,6.61],[26,'المدية','Medea',36.27,2.75],[27,'مستغانم','Mostaganem',35.93,0.09],[28,'المسيلة','M\'Sila',35.70,4.54],
    [29,'معسكر','Mascara',35.40,0.14],[30,'ورقلة','Ouargla',31.95,5.32],[31,'وهران','Oran',35.70,-0.63],[32,'البيض','El Bayadh',33.68,1.02],
    [33,'إليزي','Illizi',26.51,8.48],[34,'برج بوعريريج','Bordj Bou Arreridj',36.07,4.77],[35,'بومرداس','Boumerdes',36.76,3.48],[36,'الطارف','El Tarf',36.77,8.31],
    [37,'تندوف','Tindouf',27.67,-8.15],[38,'تيسمسيلت','Tissemsilt',35.61,1.81],[39,'الوادي','El Oued',33.37,6.87],[40,'خنشلة','Khenchela',35.43,7.14],
    [41,'سوق أهراس','Souk Ahras',36.29,7.95],[42,'تيبازة','Tipaza',36.59,2.45],[43,'ميلة','Mila',36.45,6.26],[44,'عين الدفلى','Ain Defla',36.26,2.22],
    [45,'النعامة','Naama',33.27,-0.31],[46,'عين تموشنت','Ain Temouchent',35.30,-1.14],[47,'غرداية','Ghardaia',32.49,3.67],[48,'غليزان','Relizane',35.74,0.56],
    [49,'تيميمون','Timimoun',29.26,0.23],[50,'برج باجي مختار','Bordj Badji Mokhtar',21.33,0.95],[51,'أولاد جلال','Ouled Djellal',34.43,5.07],[52,'بني عباس','Beni Abbes',30.13,-2.17],
    [53,'عين صالح','In Salah',27.20,2.47],[54,'عين قزام','In Guezzam',19.57,5.77],[55,'تقرت','Touggourt',33.10,6.07],[56,'جانت','Djanet',24.55,9.48],
    [57,'المغير','El M\'Ghair',33.95,5.92],[58,'المنيعة','El Meniaa',30.58,2.88]
  ].map(function(w){return{id:w[0],ar:w[1],en:w[2],lat:w[3],lon:w[4]}});

  var METHODS={
    algeria:{name:'الجزائر',fajr:18,isha:17},
    mwl:{name:'رابطة العالم الإسلامي',fajr:18,isha:17},
    makkah:{name:'أم القرى',fajr:18.5,ishaMin:90},
    egypt:{name:'مصر',fajr:19.5,isha:17.5},
    tunisia:{name:'تونس',fajr:18,isha:18},
    morocco:{name:'المغرب',fajr:19,isha:17},
    isna:{name:'أمريكا الشمالية',fajr:15,isha:15},
    france:{name:'فرنسا',fajr:12,isha:12},
    karachi:{name:'كراتشي',fajr:18,isha:18}
  };

  var rad=function(d){return d*Math.PI/180},deg=function(r){return r*180/Math.PI};
  var sin=function(d){return Math.sin(rad(d))},cos=function(d){return Math.cos(rad(d))},tan=function(d){return Math.tan(rad(d))};
  var asin=function(x){return deg(Math.asin(x))},acos=function(x){return deg(Math.acos(x))},atan2=function(y,x){return deg(Math.atan2(y,x))},acot=function(x){return deg(Math.atan(1/x))};
  var fixAngle=function(a){return a-360*Math.floor(a/360)},fixHour=function(a){return a-24*Math.floor(a/24)};

  function julian(y,m,d){
    if(m<=2){y-=1;m+=12}
    var A=Math.floor(y/100),B=2-A+Math.floor(A/4);
    return Math.floor(365.25*(y+4716))+Math.floor(30.6001*(m+1))+d+B-1524.5;
  }
  function sunPosition(jd){
    var D=jd-2451545.0;
    var g=fixAngle(357.529+0.98560028*D),q=fixAngle(280.459+0.98564736*D);
    var L=fixAngle(q+1.915*sin(g)+0.020*sin(2*g)),e=23.439-0.00000036*D;
    var RA=atan2(cos(e)*sin(L),cos(L))/15;
    return{decl:asin(sin(e)*sin(L)),eqt:q/15-fixHour(RA)};
  }

  /* hours (local clock, fractional) for one calendar day */
  function hoursFor(y,m,d,lat,lon,tz,method){
    var jd=julian(y,m,d)-lon/(15*24);
    var mid=function(t){return fixHour(12-sunPosition(jd+t).eqt)};
    var angleTime=function(angle,t,ccw){
      var decl=sunPosition(jd+t).decl,noon=mid(t);
      var v=(-sin(angle)-sin(decl)*sin(lat))/(cos(decl)*cos(lat));
      if(v<-1||v>1)return NaN;
      var h=acos(v)/15;return noon+(ccw?-h:h);
    };
    var asrTime=function(factor,t){
      var decl=sunPosition(jd+t).decl;
      return angleTime(-acot(factor+tan(Math.abs(lat-decl))),t,false);
    };
    var T={fajr:5,sunrise:6,dhuhr:12,asr:13,maghrib:18,isha:18};
    for(var i=0;i<3;i++){
      var t={};for(var k in T)t[k]=T[k]/24;
      T={
        fajr:angleTime(method.fajr,t.fajr,true),
        sunrise:angleTime(0.833,t.sunrise,true),
        dhuhr:mid(t.dhuhr),
        asr:asrTime(1,t.asr),
        maghrib:angleTime(0.833,t.maghrib,false),
        isha:method.ishaMin?0:angleTime(method.isha,t.isha,false)
      };
      for(var key in T){if(!isNaN(T[key]))T[key]+=tz-lon/15}
    }
    if(method.ishaMin)T.isha=T.maghrib+method.ishaMin/60;
    return T;
  }

  /* Returns {Fajr,Sunrise,Dhuhr,Asr,Maghrib,Isha} as Date objects (nearest minute), or null if undefined (polar). */
  function compute(date,lat,lon,methodKey,adj){
    var method=METHODS[methodKey]||METHODS.algeria;
    adj=adj||{};
    var y=date.getFullYear(),m=date.getMonth()+1,d=date.getDate();
    var tz=-new Date(y,m-1,d,12).getTimezoneOffset()/60;
    var h=hoursFor(y,m,d,lat,lon,tz,method);
    var base=new Date(y,m-1,d,0,0,0,0).getTime();
    var out={},ok=true;
    var map={Fajr:'fajr',Sunrise:'sunrise',Dhuhr:'dhuhr',Asr:'asr',Maghrib:'maghrib',Isha:'isha'};
    Object.keys(map).forEach(function(name){
      var v=h[map[name]];
      if(isNaN(v)){ok=false;return}
      var mins=Math.round(v*60)+(Number(adj[name])||0);
      out[name]=new Date(base+mins*60000);
    });
    return ok?out:null;
  }

  /* Qibla bearing in degrees from true north (great-circle initial bearing to the Kaaba) */
  function qibla(lat,lon){
    var kLat=21.4225,kLon=39.8262,dl=rad(kLon-lon);
    var y=Math.sin(dl)*Math.cos(rad(kLat));
    var x=Math.cos(rad(lat))*Math.sin(rad(kLat))-Math.sin(rad(lat))*Math.cos(rad(kLat))*Math.cos(dl);
    return (deg(Math.atan2(y,x))+360)%360;
  }

  var api={WILAYAS:WILAYAS,METHODS:METHODS,compute:compute,qibla:qibla,_hoursFor:hoursFor};
  root.ALI_PRAYER=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
