/* Worship tools: Quran wird (khatma), qada fasts, Hijri calendar and upcoming occasions. */
(function(){
  'use strict';
  var A=window.ALI,H=window.ALI_HIJRI,wHost=document.getElementById('worship'),cHost=document.getElementById('calendar');
  if(!A||!wHost||!cHost)return;
  var W=function(){return A.data.worship};
  var DAY=86400000;
  function dstr(s){var p=s.split('-').map(Number);return new Date(p[0],p[1]-1,p[2])}
  function daysBetween(a,b){return Math.round((Date.UTC(b.getFullYear(),b.getMonth(),b.getDate())-Date.UTC(a.getFullYear(),a.getMonth(),a.getDate()))/DAY)}

  /* ---------- khatma + qada ---------- */
  function renderWorship(){
    var k=W().khatma,q=W().qada,t=A.today(),todayPages=k.log[t]||0,total=k.total||604;
    var left=Math.max(0,total-k.pages),startD=k.start?dstr(k.start):new Date(),elapsed=Math.max(0,daysBetween(startD,new Date()));
    var daysLeft=Math.max(1,k.goalDays-elapsed),target=Math.ceil(left/daysLeft),pct=Math.round(Math.min(100,k.pages/total*100));
    var avg=elapsed>0?k.pages/(elapsed+1):k.pages,eta='';
    if(left>0&&avg>0){var d=new Date(Date.now()+Math.ceil(left/avg)*DAY);eta=d.toLocaleDateString('ar',{day:'numeric',month:'long',year:'numeric'})}
    wHost.innerHTML='<div class="panel"><h3>📖 ورد القرآن والختمة</h3>'+
      '<div class="row"><b>'+k.pages+' / '+total+' صفحة</b><span class="chip">'+pct+'%</span></div><div class="progress" style="margin:8px 0"><span style="width:'+pct+'%"></span></div>'+
      (left>0?'<p class="muted" style="margin:6px 0">الهدف: ختمة في '+k.goalDays+' يومًا · المتبقي '+left+' صفحة · وردك اليوم نحو <b>'+target+'</b> صفحة'+(eta?' · الانتهاء المتوقع '+A.esc(eta):'')+'</p>':'<div class="notice info">🎉 أتممتِ الختمة، تقبّل الله منكِ! يمكنك بدء ختمة جديدة.</div>')+
      '<div class="notice info" style="margin-top:8px">قرأتِ اليوم: <b>'+todayPages+'</b> صفحة</div>'+
      '<div class="field" style="margin-top:10px"><button class="btn soft" data-add="-1" type="button" style="flex:1" aria-label="إنقاص صفحة">−1</button><button class="btn primary" data-add="1" type="button" style="flex:1">+1</button><button class="btn primary" data-add="5" type="button" style="flex:1">+5</button><button class="btn primary" data-add="10" type="button" style="flex:1">+10</button></div>'+
      '<details class="opts"><summary>إعدادات الختمة</summary><div class="field two" style="margin-top:8px"><label class="fld" style="margin:0"><span>عدد أيام الختمة</span><input id="kDays" type="number" min="1" max="3650" value="'+k.goalDays+'"></label><label class="fld" style="margin:0"><span>الصفحة الحالية</span><input id="kPages" type="number" min="0" max="'+total+'" value="'+k.pages+'"></label></div><div class="field" style="margin-top:8px"><button class="btn soft" id="kSave" type="button" style="flex:1">حفظ</button><button class="btn" id="kNew" type="button" style="flex:1">ختمة جديدة</button></div></details></div>'+
      '<div class="panel"><h3>🌙 قضاء الصيام</h3><div class="row"><div><b style="font-size:1.6rem">'+q.owed+'</b> <span class="muted">يومًا متبقيًا</span></div><div style="display:flex;gap:8px"><button class="btn soft" id="qDone" type="button">صُمتُ يومًا</button><button class="btn" id="qAdd" type="button" aria-label="إضافة يوم">+1</button></div></div><p class="muted" style="margin:8px 0 0">سجّلي الأيام التي عليكِ قضاؤها وأنقصيها كلما صمتِ يومًا.</p></div>';
    wHost.querySelectorAll('[data-add]').forEach(function(b){b.onclick=function(){
      var n=Number(b.dataset.add),np=Math.max(0,Math.min(total,k.pages+n)),real=np-k.pages;if(!real)return;
      if(!k.start)k.start=t;k.pages=np;k.log[t]=Math.max(0,(k.log[t]||0)+real);
      var keys=Object.keys(k.log).sort();while(keys.length>400)delete k.log[keys.shift()];
      A.save();renderWorship();
    }});
    document.getElementById('kSave').onclick=function(){k.goalDays=Math.max(1,Math.min(3650,Number(document.getElementById('kDays').value)||30));k.pages=Math.max(0,Math.min(total,Number(document.getElementById('kPages').value)||0));if(!k.start)k.start=t;A.save();renderWorship();A.toast('تم الحفظ')};
    document.getElementById('kNew').onclick=async function(){if(!(await A.ui.confirm('بدء ختمة جديدة؟','ابدئي',false,'سيُصفَّر عدّاد الصفحات الحالي.')))return;k.pages=0;k.start=t;A.save();renderWorship()};
    document.getElementById('qDone').onclick=function(){if(q.owed>0){q.owed--;A.save();renderWorship();A.toast('تقبّل الله صيامك 🌿')}};
    document.getElementById('qAdd').onclick=function(){q.owed=Math.min(5000,q.owed+1);A.save();renderWorship()};
  }

  /* ---------- Hijri calendar ---------- */
  function occasions(from,limitDays){
    var out=[],seenBid=false;
    for(var i=0;i<limitDays;i++){
      var d=new Date(from.getFullYear(),from.getMonth(),from.getDate()+i,12),p=H.parts(d);if(!p)continue;
      var m=p.month,dd=p.day,add=function(t,note){out.push({date:d,title:t,note:note||'',off:i})};
      if(m===1&&dd===1)add('رأس السنة الهجرية '+p.year);
      if(m===1&&dd===9)add('تاسوعاء','يُستحب صيامه مع عاشوراء');
      if(m===1&&dd===10)add('يوم عاشوراء','يُستحب صيامه');
      if(m===9&&dd===1)add('بداية شهر رمضان','أعاننا الله وإياكم على صيامه وقيامه');
      if(m===9&&dd===21)add('العشر الأواخر من رمضان','تحرَّي ليلة القدر في الليالي الوتر');
      if(m===10&&dd===1)add('عيد الفطر المبارك');
      if(m===10&&dd===2)add('بداية صيام ست من شوال','يُستحب صيام ستة أيام من شوال');
      if(m===12&&dd===1)add('بداية العشر الأول من ذي الحجة','أيام العمل الصالح');
      if(m===12&&dd===9)add('يوم عرفة','يُستحب صيامه لغير الحاج');
      if(m===12&&dd===10)add('عيد الأضحى المبارك');
      if(m===12&&dd===11)add('أيام التشريق','أيام أكل وشرب وذكر لله');
      if(dd===13&&m!==12&&m!==9&&!seenBid){seenBid=true;add('الأيام البيض','صيام 13 و14 و15 من الشهر الهجري')}
    }
    return out;
  }
  function renderCalendar(){
    var now=new Date(),h=H.text(now),wd=now.toLocaleDateString('ar',{weekday:'long'}),greg=now.toLocaleDateString('ar',{day:'numeric',month:'long',year:'numeric'});
    var occ=occasions(now,420).slice(0,9),isMT=now.getDay()===1||now.getDay()===4;
    var evs=(window.ALI_FAMILY_EVENTS?window.ALI_FAMILY_EVENTS():[]).filter(function(e){return !e.done&&e.date>=A.today()}).sort(function(a,b){return (a.date+(a.time||'')).localeCompare(b.date+(b.time||''))}).slice(0,5);
    function rel(n){return n===0?'اليوم':n===1?'غدًا':'بعد '+n+' يومًا'}
    cHost.innerHTML='<div class="panel"><h3>🗓️ التقويم الهجري</h3><div class="cal-hero"><div class="cal-day">'+A.esc(h||'—')+'</div><div class="muted">'+A.esc(wd+' · '+greg)+'</div></div>'+
      (isMT?'<div class="notice info" style="margin-top:12px">اليوم '+(now.getDay()===1?'الاثنين':'الخميس')+': يُستحب الصيام فيه.</div>':'')+
      '<p class="muted" style="margin:10px 0 0;font-size:.85rem">التقويم بحسب أم القرى، وقد يختلف يومًا عن إعلان الجهة الرسمية في بلدك.</p></div>'+
      '<div class="panel"><h3>✨ المناسبات القادمة</h3><div class="list">'+(occ.length?occ.map(function(o,i){return '<div class="item"><div class="grow"><div class="title">'+A.esc(o.title)+'</div><div class="meta"><span class="chip gray">📅 '+A.esc(o.date.toLocaleDateString('ar',{weekday:'short',day:'numeric',month:'long'}))+'</span><span class="chip">'+rel(o.off)+'</span></div>'+(o.note?'<div class="muted" style="font-size:.85rem;margin-top:4px">'+A.esc(o.note)+'</div>':'')+'</div><button class="btn soft occ-rem" data-i="'+i+'" type="button" style="min-height:40px">ذكّريني</button></div>'}).join(''):'<div class="empty">تعذّر حساب التقويم الهجري على هذا الجهاز.</div>')+'</div></div>'+
      (evs.length?'<div class="panel"><h3>👨‍👩‍👧 مواعيد الأسرة القادمة</h3><div class="list">'+evs.map(function(e){return '<div class="item"><div class="grow"><div class="title">'+A.esc(e.title)+'</div><div class="meta"><span class="chip gray">📅 '+A.esc(e.date===A.today()?'اليوم':e.date)+'</span>'+(e.time?'<span class="chip gray">⏰ '+A.esc(e.time)+'</span>':'')+'</div></div></div>'}).join('')+'</div></div>':'');
    cHost.querySelectorAll('.occ-rem').forEach(function(b){b.onclick=function(){
      var o=occ[Number(b.dataset.i)];if(!o)return;
      var task={id:A.uid(),text:o.title,date:A.ymd(o.date),time:'08:00',priority:'عادية',cat:'عبادة',repeat:'',done:false};
      if(A.data.tasks.some(function(t){return t.text===task.text&&t.date===task.date&&!t.done})){A.toast('التذكير مضاف مسبقًا');return}
      A.data.tasks.push(task);A.scheduleTaskReminder(task);A.save();A.renderTasks();A.toast('أُضيف تذكير في '+task.date+' الساعة 08:00');
    }});
  }
  document.addEventListener('alislah:tab',function(e){if(e.detail==='worship')renderWorship();if(e.detail==='calendar')renderCalendar()});
})();
