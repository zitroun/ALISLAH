/* Focus (Pomodoro) timer. Uses timestamps so it survives the app going to the background. */
(function(){
  'use strict';
  var A=window.ALI,host=document.getElementById('focustimer');
  if(!A||!host)return;
  var SK='alislah_focus_state';
  var st=load(),tick=null;
  function load(){try{var s=JSON.parse(localStorage.getItem(SK)||'null');if(s&&typeof s==='object')return{mode:s.mode==='rest'?'rest':'work',running:!!s.running,endAt:Number(s.endAt)||0,left:Number(s.left)||0,taskId:String(s.taskId||'')}}catch(e){}return{mode:'work',running:false,endAt:0,left:0,taskId:''}}
  function persist(){try{localStorage.setItem(SK,JSON.stringify(st))}catch(e){}}
  function dur(mode){var f=A.data.focus;return (mode==='work'?f.work:f.rest)*60000}
  function remaining(){return st.running?Math.max(0,st.endAt-Date.now()):(st.left||dur(st.mode))}
  function fmt(ms){var s=Math.ceil(ms/1000),m=Math.floor(s/60);return String(m).padStart(2,'0')+':'+String(s%60).padStart(2,'0')}
  function todayStats(){var t=A.today(),s=A.data.focus.sessions.filter(function(x){return x.date===t});return{n:s.length,min:s.reduce(function(a,x){return a+x.minutes},0)}}
  function pendingTasks(){var t=A.today();return A.data.tasks.filter(function(x){return !x.done&&(x.date||t)<=t}).slice(0,30)}

  function render(){
    var f=A.data.focus,ts=todayStats(),tasks=pendingTasks(),total=dur(st.mode),rem=remaining(),pct=Math.max(0,Math.min(100,100-rem/total*100));
    if(st.taskId&&!tasks.some(function(x){return x.id===st.taskId}))st.taskId='';
    var R=88,C=2*Math.PI*R;
    host.innerHTML='<div class="panel"><h3>⏱️ مؤقت التركيز</h3>'+
      '<div class="focus-ring"><svg viewBox="0 0 200 200" role="img" aria-label="الوقت المتبقي"><circle cx="100" cy="100" r="'+R+'" fill="none" stroke="var(--soft)" stroke-width="12"/><circle id="fRing" cx="100" cy="100" r="'+R+'" fill="none" stroke="'+(st.mode==='work'?'var(--brand-2)':'var(--gold)')+'" stroke-width="12" stroke-linecap="round" stroke-dasharray="'+C.toFixed(1)+'" stroke-dashoffset="'+(C*(1-pct/100)).toFixed(1)+'" transform="rotate(-90 100 100)"/></svg><div class="focus-time"><div id="fTime">'+fmt(rem)+'</div><div class="muted">'+(st.mode==='work'?'وقت التركيز':'وقت الراحة')+'</div></div></div>'+
      '<label class="fld" style="margin-top:12px"><span>المهمة (اختياري)</span><select id="fTask"><option value="">بدون مهمة محددة</option>'+tasks.map(function(x){return '<option value="'+A.esc(x.id)+'"'+(x.id===st.taskId?' selected':'')+'>'+A.esc(x.text.slice(0,50))+'</option>'}).join('')+'</select></label>'+
      '<div class="field"><button class="btn primary" id="fStart" type="button" style="flex:2">'+(st.running?'⏸ إيقاف مؤقت':(st.left&&st.left<dur(st.mode)?'▶ متابعة':'▶ ابدئي'))+'</button><button class="btn" id="fReset" type="button" style="flex:1">إعادة</button><button class="btn" id="fSkip" type="button" style="flex:1">تخطي</button></div>'+
      '<div class="field two"><label class="fld" style="margin:0"><span>التركيز (دقائق)</span><select id="fWork">'+[15,25,35,45,60].map(function(n){return '<option value="'+n+'"'+(n===f.work?' selected':'')+'>'+n+'</option>'}).join('')+'</select></label><label class="fld" style="margin:0"><span>الراحة (دقائق)</span><select id="fRest">'+[3,5,10,15].map(function(n){return '<option value="'+n+'"'+(n===f.rest?' selected':'')+'>'+n+'</option>'}).join('')+'</select></label></div>'+
      '<div class="notice info" style="margin-top:12px">اليوم: <b>'+ts.n+'</b> جلسة · <b>'+ts.min+'</b> دقيقة تركيز</div>'+
      (st.taskId?'<button class="btn soft block" id="fDone" type="button" style="margin-top:10px">✓ أنجزتُ هذه المهمة</button>':'')+'</div>';
    document.getElementById('fTask').onchange=function(e){st.taskId=e.target.value;persist();render()};
    document.getElementById('fStart').onclick=function(){st.running?pause():start()};
    document.getElementById('fReset').onclick=reset;
    document.getElementById('fSkip').onclick=function(){finish(true)};
    document.getElementById('fWork').onchange=function(e){f.work=Number(e.target.value)||25;A.save();if(!st.running&&st.mode==='work'){st.left=0;persist()}render()};
    document.getElementById('fRest').onchange=function(e){f.rest=Number(e.target.value)||5;A.save();if(!st.running&&st.mode==='rest'){st.left=0;persist()}render()};
    var d=document.getElementById('fDone');if(d)d.onclick=function(){var t=A.data.tasks.find(function(x){return x.id===st.taskId});if(t){A.completeTask(t,true);A.save();A.renderTasks();st.taskId='';persist();A.toast('أحسنتِ! أُنجزت المهمة 🎉');render()}};
  }
  function update(){
    var rem=remaining(),t=document.getElementById('fTime');if(!t)return;
    t.textContent=fmt(rem);
    var ring=document.getElementById('fRing');if(ring){var R=88,C=2*Math.PI*R,pct=Math.max(0,Math.min(100,100-rem/dur(st.mode)*100));ring.setAttribute('stroke-dashoffset',(C*(1-pct/100)).toFixed(1))}
    if(st.running&&rem<=0)finish(false);
  }
  function start(){
    var rem=st.left&&st.left>0?st.left:dur(st.mode);
    st.running=true;st.endAt=Date.now()+rem;persist();
    A.nat('scheduleTaskReminder','focus-end',st.mode==='work'?'⏱️ انتهت جلسة التركيز، خذي استراحة':'⏱️ انتهت الراحة، هيا نركّز',st.endAt);
    clearInterval(tick);tick=setInterval(update,500);render();
  }
  function pause(){
    st.left=Math.max(0,st.endAt-Date.now());st.running=false;persist();A.cancelTaskReminder('focus-end');clearInterval(tick);render();
  }
  function reset(){st.running=false;st.left=0;persist();A.cancelTaskReminder('focus-end');clearInterval(tick);render()}
  function finish(skipped){
    A.cancelTaskReminder('focus-end');clearInterval(tick);
    if(st.mode==='work'&&!skipped){
      var f=A.data.focus;f.sessions.push({date:A.today(),minutes:f.work});if(f.sessions.length>600)f.sessions=f.sessions.slice(-600);A.save();
      A.toast('انتهت جلسة التركيز 🎯 خذي استراحة قصيرة');try{navigator.vibrate&&navigator.vibrate([120,80,120])}catch(e){}
    }else if(!skipped){A.toast('انتهت الراحة، هيا نبدأ جلسة جديدة');try{navigator.vibrate&&navigator.vibrate(80)}catch(e){}}
    st.mode=st.mode==='work'?'rest':'work';st.running=false;st.left=0;persist();render();
  }
  document.addEventListener('alislah:tab',function(e){
    if(e.detail==='focustimer'){render();clearInterval(tick);if(st.running)tick=setInterval(update,500)}else clearInterval(tick);
  });
  document.addEventListener('visibilitychange',function(){if(!document.hidden&&st.running&&document.body.dataset.view==='focustimer')update()});
})();
