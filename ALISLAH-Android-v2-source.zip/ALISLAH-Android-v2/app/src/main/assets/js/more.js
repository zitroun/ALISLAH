/* Navigation glue: "More" grid, back links, Hijri date, floating-button behaviour, row toggles. */
(function(){
  'use strict';
  var A=window.ALI,$=function(s){return document.querySelector(s)};
  if(!A)return;
  document.querySelectorAll('.more-card[data-go]').forEach(function(b){b.onclick=function(){A.tab(b.dataset.go)}});
  var os=$('#openSettings');if(os)os.onclick=function(){A.tab('settings')};
  ['adhkar','qibla','worship','calendar','report','focustimer','assistant','behavior','settings'].forEach(function(id){
    var v=document.getElementById(id);if(!v)return;
    var b=document.createElement('button');b.type='button';b.className='back-link';b.textContent='‹ المزيد';b.onclick=function(){A.tab('more')};
    v.insertBefore(b,v.firstChild);
  });
  var d=$('#date');
  if(d&&window.ALI_HIJRI){var h=ALI_HIJRI.text(new Date());if(h&&!d.dataset.h){d.dataset.h='1';d.textContent=d.textContent+' · '+h}}
  document.addEventListener('click',function(e){
    var row=e.target.closest&&e.target.closest('.toggle-row');
    if(!row||e.target.closest('input,button,a,select,label,textarea'))return;
    var i=row.querySelector('input[type=checkbox]');if(i&&!i.disabled)i.click();
  });
  var lastY=0;
  window.addEventListener('scroll',function(){
    var f=$('#alislahFloat');if(!f)return;var y=window.scrollY||0;
    if(y>lastY+8&&y>120)f.classList.add('fab-hide');else if(y<lastY-8)f.classList.remove('fab-hide');
    lastY=y;
  },{passive:true});
  document.addEventListener('alislah:tab',function(){var f=$('#alislahFloat');if(f)f.classList.remove('fab-hide')});
})();
