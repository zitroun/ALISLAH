/* "زادك اليوم": offline curated content (verse / hadith / tip) with copy & share. */
(function(){
  'use strict';
  var C=window.ALI_CONTENT,$=function(s){return document.querySelector(s)};
  if(!C||!$('#alislahContentPanel'))return;
  var kind='ayah',idx={ayah:0,hadith:0,tip:0};
  var LABEL={ayah:'آية',hadith:'حديث',tip:'فائدة'};
  function dayNumber(){var d=new Date();return Math.floor(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())/86400000)}
  function current(){
    var list=C[kind],i=(dayNumber()+idx[kind])%list.length,x=list[i];
    return kind==='tip'?{t:x,s:'فائدة عملية'}:x;
  }
  function render(){
    document.querySelectorAll('#contentTabs button').forEach(function(b){b.classList.toggle('on',b.dataset.k===kind)});
    var x=current(),t=$('#alislahContentText');
    t.textContent=(kind==='ayah'?'﴿ '+x.t+' ﴾':kind==='hadith'?'« '+x.t+' »':x.t);
    t.className='content-text'+(kind==='tip'?' tip':' quran');
    $('#alislahContentSource').textContent=x.s;
    if(kind==='ayah'&&window.AndroidUsage&&typeof AndroidUsage.speakDisplayedAyah==='function'){try{AndroidUsage.speakDisplayedAyah(x.t)}catch(_){}}
  }
  function plain(){var x=current();return (kind==='ayah'?'﴿'+x.t+'﴾':kind==='hadith'?'«'+x.t+'»':x.t)+'\n— '+x.s+'\n(ALISLAH)'}
  document.querySelectorAll('#contentTabs button').forEach(function(b){b.onclick=function(){kind=b.dataset.k;render()}});
  $('#alislahContentNext').onclick=function(){idx[kind]++;render()};
  $('#contentCopy').onclick=function(){
    var ok=false;
    if(window.AndroidUsage&&typeof AndroidUsage.copyText==='function'){try{AndroidUsage.copyText(plain());ok=true}catch(e){}}
    else if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(plain()).then(function(){window.__toast&&window.__toast('تم النسخ')},function(){});return}
    if(ok&&window.__toast)window.__toast('تم النسخ');
  };
  $('#contentShare').onclick=function(){
    if(window.AndroidUsage&&typeof AndroidUsage.shareText==='function'){try{AndroidUsage.shareText(plain())}catch(e){}}
    else if(navigator.share){navigator.share({text:plain()}).catch(function(){})}
    else if(window.__toast)window.__toast('المشاركة متاحة في نسخة أندرويد');
  };
  render();
})();
