(()=>{'use strict';const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)],KEY='alislah_v2',ENDPOINT='https://alislah-ai.zitroun2222.workers.dev/';const today=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));const uid=()=>globalThis.crypto?.randomUUID?.()||String(Date.now())+Math.random().toString(16).slice(2);const NATIVE=!!window.AndroidUsage,nat=(fn,...a)=>{try{return window.AndroidUsage&&typeof AndroidUsage[fn]==='function'?AndroidUsage[fn](...a):undefined}catch(_){return undefined}};const ymd=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');const O=v=>v&&typeof v==='object'&&!Array.isArray(v);
function ALI_norm(d){d.family=O(d.family)?d.family:{};const f=d.family;f.members=Array.isArray(f.members)?f.members:[];f.routines=O(f.routines)?f.routines:{};f.routineLog=O(f.routineLog)?f.routineLog:{};f.events=Array.isArray(f.events)?f.events:[];
d.worship=O(d.worship)?d.worship:{};const w=d.worship;w.khatma=O(w.khatma)?w.khatma:{};const k=w.khatma;k.pages=Math.max(0,Number(k.pages)||0);k.total=Number(k.total)||604;k.goalDays=Number(k.goalDays)||30;k.start=typeof k.start==='string'?k.start:'';k.log=O(k.log)?k.log:{};w.qada=O(w.qada)?w.qada:{};w.qada.owed=Math.max(0,Number(w.qada.owed)||0);w.dhikrDone=O(w.dhikrDone)?w.dhikrDone:{};
d.focus=O(d.focus)?d.focus:{};d.focus.sessions=Array.isArray(d.focus.sessions)?d.focus.sessions:[];d.focus.work=Number(d.focus.work)||25;d.focus.rest=Number(d.focus.rest)||5;
d.settings=O(d.settings)?d.settings:{};return d}
const blank=()=>({tasks:[],habits:[],checks:{},chat:[],behavior:{},usageProfile:{snapshots:[]},family:{members:[],routines:{},routineLog:{},events:[]},worship:{khatma:{pages:0,total:604,goalDays:30,start:'',log:{}},qada:{owed:0},dhikrDone:{}},focus:{sessions:[],work:25,rest:5},settings:{worker:ENDPOINT,name:'',autoShareUsage:false,questionCloudEnabled:false,theme:'auto',fontScale:'normal',appLock:false,encryptBackup:false,backupReminder:false,digest:{morning:{on:false,time:'07:30'},evening:{on:false,time:'21:00'}},welcomed:false,interactionMode:'both',voiceRead:false,assistantVoiceEngine:'old'},idea:0});const FIRST_RUN=!localStorage.getItem(KEY);let data;try{data={...blank(),...JSON.parse(localStorage.getItem(KEY)||'{}')};}catch{data=blank()}ALI_norm(data);data.tasks=Array.isArray(data.tasks)?data.tasks:[];data.habits=Array.isArray(data.habits)?data.habits:[];data.checks=data.checks&&typeof data.checks==='object'?data.checks:{};data.behavior=data.behavior&&typeof data.behavior==='object'?data.behavior:{};data.usageProfile=data.usageProfile&&typeof data.usageProfile==='object'?data.usageProfile:{snapshots:[]};data.usageProfile.snapshots=Array.isArray(data.usageProfile.snapshots)?data.usageProfile.snapshots.slice(-14):[];data.chat=Array.isArray(data.chat)?data.chat.slice(-30):[];data.settings={...blank().settings,...data.settings};let timer;function toast(t){$('#toast').textContent=t;$('#toast').classList.remove('hidden');clearTimeout(timer);timer=setTimeout(()=>$('#toast').classList.add('hidden'),2600)}function save(){try{let cur=null;try{cur=JSON.parse(localStorage.getItem(KEY)||'null')}catch{}
if(cur&&typeof cur==='object'){const M=['tasks','habits','checks','chat','behavior','usageProfile','family','worship','focus','idea','settings','_rev'],MS=['worker','name','autoShareUsage','questionCloudEnabled','theme','fontScale','appLock','encryptBackup','backupReminder','digest','welcomed','interactionMode','voiceRead','voiceGender','assistantVoiceEngine'],bad=k=>k==='__proto__'||k==='constructor'||k==='prototype';
Object.keys(cur).forEach(k=>{if(!M.includes(k)&&!bad(k))data[k]=cur[k]});
if(cur.settings&&typeof cur.settings==='object'){data.settings=data.settings||{};Object.keys(cur.settings).forEach(k=>{if(!MS.includes(k)&&!bad(k))data.settings[k]=cur.settings[k]})}}
data._rev=Math.max(Number(data._rev)||0,Number(cur&&cur._rev)||0)+1;
localStorage.setItem(KEY,JSON.stringify(data))}catch{toast('تعذر حفظ البيانات في المتصفح')}stats();try{window.__alislahAfterSave&&window.__alislahAfterSave()}catch(_){}}
window.__toast=toast;
window.__alislahSync=function(){try{if(document.getElementById('settings').classList.contains('active'))renderNative()}catch(_){}try{const cur=JSON.parse(localStorage.getItem(KEY)||'null');if(!cur||typeof cur!=='object'||(Number(cur._rev)||0)<=(Number(data._rev)||0))return;const nd={...blank(),...cur,settings:{...blank().settings,...(cur.settings&&typeof cur.settings==='object'?cur.settings:{})}};['tasks','habits','chat'].forEach(k=>{if(!Array.isArray(nd[k]))nd[k]=[]});['checks','behavior'].forEach(k=>{if(!nd[k]||typeof nd[k]!=='object')nd[k]={}});if(!nd.usageProfile||typeof nd.usageProfile!=='object')nd.usageProfile={snapshots:[]};if(!Array.isArray(nd.usageProfile.snapshots))nd.usageProfile.snapshots=[];ALI_norm(nd);data=nd;renderTasks();renderHabits();stats();drawChat();renderBehavior();renderUsage();try{window.__alislahResync&&window.__alislahResync()}catch(_){}}catch(_){}};const PRIMARY=['tasks','habits','prayer','family'];
function applyTabState(n){if(!document.getElementById(n))n='tasks';const prim=PRIMARY.includes(n)?n:'more';$$('.tab').forEach(b=>{const on=b.dataset.tab===prim&&!b.classList.contains('legacy');b.classList.toggle('active',on);if(on)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current')});$$('.view').forEach(v=>v.classList.toggle('active',v.id===n));document.body.dataset.view=n;if(n==='settings')renderNative();try{window.scrollTo({top:0})}catch(_){}document.dispatchEvent(new CustomEvent('alislah:tab',{detail:n}));return n}
function tab(n){n=applyTabState(n);try{localStorage.setItem('alislah_active_tab',n)}catch(_){} }
let lastSyncedTab='';function syncActiveTab(){try{const n=localStorage.getItem('alislah_active_tab');if(n&&n!==lastSyncedTab&&document.getElementById(n)){lastSyncedTab=n;if(document.body.dataset.view!==n)applyTabState(n)}else if(!n&&document.body.dataset.view)lastSyncedTab=document.body.dataset.view}catch(_){}}
setInterval(syncActiveTab,650);document.addEventListener('alislah:tab',e=>{lastSyncedTab=e.detail});
$$('.tab').forEach(b=>b.onclick=()=>{tab(b.dataset.tab);if(b.dataset.tab==='behavior')renderUsage()});$('#date').textContent=new Intl.DateTimeFormat('ar-DZ',{dateStyle:'full'}).format(new Date());$('#taskDate').value=today();

function currentBehavior(){
  return {
    mood:Number($('#mood').value||3),
    energy:Number($('#energy').value||3),
    focus:Number($('#focus').value||3),
    sleepHours:Math.max(0,Math.min(24,Number($('#sleepHours').value||0))),
    phoneMinutes:$('#phoneMinutes').value===''?null:Math.max(0,Math.min(1440,Number($('#phoneMinutes').value))),
    note:$('#behaviorNote').value.trim().slice(0,700),
    updatedAt:new Date().toISOString()
  };
}
function behaviorLabel(n,low,mid,high){return n<=2?low:(n===3?mid:high)}
function renderBehavior(){
  const keys=Object.keys(data.behavior||{}).sort().slice(-7).reverse();
  const todayEntry=data.behavior[today()];
  if(todayEntry){
    $('#mood').value=String(todayEntry.mood||3);
    $('#energy').value=String(todayEntry.energy||3);
    $('#focus').value=String(todayEntry.focus||3);
    $('#sleepHours').value=todayEntry.sleepHours??7;
    $('#phoneMinutes').value=todayEntry.phoneMinutes==null?'':todayEntry.phoneMinutes;
    $('#behaviorNote').value=todayEntry.note||'';
  }
  const summary=$('#behaviorSummary');
  if(!todayEntry){summary.innerHTML='<div class="empty">لم تحفظي مؤشرات اليوم بعد.</div>';}
  else {
    const phone=todayEntry.phoneMinutes==null?'لم يُسجّل':`${todayEntry.phoneMinutes} دقيقة`;
    summary.innerHTML=[
      `<div class="item"><div class="grow"><div class="title">المزاج</div><div class="muted">${behaviorLabel(todayEntry.mood,'صعب','عادي','جيد')}</div></div></div>`,
      `<div class="item"><div class="grow"><div class="title">الطاقة والتركيز</div><div class="muted">الطاقة ${todayEntry.energy}/5 · التركيز ${todayEntry.focus}/5</div></div></div>`,
      `<div class="item"><div class="grow"><div class="title">النوم واستعمال الهاتف</div><div class="muted">${todayEntry.sleepHours} ساعة نوم · ${phone}</div></div></div>`
    ].join('');
  }
  const hist=$('#behaviorHistory');
  hist.innerHTML=keys.length?keys.map(k=>{
    const b=data.behavior[k], phone=b.phoneMinutes==null?'غير مسجل':`${b.phoneMinutes} د`;
    return `<div class="item"><div class="grow"><div class="title">${esc(k)}</div><div class="muted">المزاج ${esc(b.mood)}/5 · الطاقة ${esc(b.energy)}/5 · التركيز ${esc(b.focus)}/5 · النوم ${esc(b.sleepHours)} س · الهاتف ${esc(phone)}</div>${b.note?`<div>${esc(b.note)}</div>`:''}</div></div>`;
  }).join(''):'<div class="empty">لا توجد سجلات بعد.</div>';
}

function getAutoContext(){
  if(!data.settings.autoShareUsage) return '';
  const u=getNativeUsage();
  const usage={permission:!!u.permission,apps:(u.apps||[]).slice(0,12).map(a=>({app:String(a.name||'').slice(0,80),minutes:Math.max(0,Math.min(1440,Number(a.minutes)||0))})),foreground:u.foreground&&u.foreground.name?String(u.foreground.name).slice(0,80):'غير متاح',days:(data.usageProfile.snapshots||[]).slice(-7).map(x=>({date:x.date,foreground:x.foreground,apps:(x.apps||[]).slice(0,8)}))};
  const tasks=Array.isArray(data.tasks)?{total:data.tasks.length,done:data.tasks.filter(t=>t.done||t.completed||t.status==='done').length}:{};
  return 'ملخص سلوكي اختياري وافق المستخدم على مشاركته تلقائيًا مع هذا الطلب: '+JSON.stringify({usage,tasks})+'. استخدمه لبناء نصيحة عملية، ولا تستنتج معلومات حساسة أو تشخّص المستخدم. إذا لم تتوفر الصلاحية فاذكر أن البيانات ناقصة.';
}
function getNativeUsage(){
  try{
    if(!window.AndroidUsage || typeof window.AndroidUsage.getUsageStatsJson!=='function') return {available:false,permission:false,apps:[],foreground:null};
    const raw=window.AndroidUsage.getUsageStatsJson();
    const parsed=JSON.parse(raw||'{}');
    return {available:true,permission:!!parsed.permission,apps:Array.isArray(parsed.apps)?parsed.apps:[],foreground:parsed.foreground||null,collectedAt:Number(parsed.collectedAt)||Date.now()};
  }catch(e){return {available:false,permission:false,apps:[],foreground:null,error:String(e)}}
}
function renderUsage(recordSnapshot=false){
  const target=$('#usageSummary'); if(!target)return;
  const u=getNativeUsage();
  if(!u.available){
    target.innerHTML='<div class="empty">إحصاءات التطبيقات متاحة داخل نسخة أندرويد الأصلية، وليست في صفحة الويب وحدها.</div>';
    return;
  }
  if(!u.permission){
    target.innerHTML='<div class="empty">لم تُمنح صلاحية إحصاءات الاستخدام بعد. اضغطي زر منح الصلاحية، ثم ارجعي للتطبيق.</div>';
    return;
  }
  const fg=u.foreground;
  const fgHtml=fg&&fg.name&&fg.name!=='غير متاح'?`<div class="item"><div class="grow"><div class="title">التطبيق النشط الأخير (تقديري)</div><div>${esc(fg.name)}</div><div class="muted">آخر انتقال مسجّل؛ قد لا يطابق التطبيق المفتوح في هذه اللحظة تمامًا.</div></div></div>`:'';
  if(recordSnapshot){
    const snap={date:today(),at:new Date(u.collectedAt||Date.now()).toISOString(),foreground:fg&&fg.name?fg.name:'غير متاح',apps:u.apps.slice(0,12).map(a=>({app:a.name||a.packageName,minutes:Math.max(0,Math.round(Number(a.minutes)||0))}))};
    const snapshots=data.usageProfile.snapshots.filter(x=>x.date!==snap.date);snapshots.push(snap);data.usageProfile.snapshots=snapshots.slice(-14);save();
  }
  if(!u.apps.length){
    target.innerHTML=fgHtml+'<div class="empty">لا توجد إحصاءات يومية كافية بعد. استخدمي الهاتف ثم اضغطي تحديث.</div>';
    return;
  }
  target.innerHTML=fgHtml+u.apps.slice(0,12).map(a=>{
    const mins=Math.max(0,Math.round(Number(a.minutes)||0));
    const label=esc(a.name||a.packageName||'تطبيق');
    return `<div class="item"><div class="grow"><div class="title">${label}</div><div class="muted">${mins>=60?Math.floor(mins/60)+' س ':''}${mins%60} د اليوم</div></div></div>`;
  }).join('');
}
$('#refreshUsage').onclick=()=>{renderUsage(true);toast('تم تحديث الإحصاءات وحفظ ملخص محلي لهذا اليوم')};
$('#grantUsage').onclick=()=>{
  try{
    if(window.AndroidUsage&&typeof window.AndroidUsage.requestUsagePermission==='function')window.AndroidUsage.requestUsagePermission();
    else toast('افتحي التطبيق الأصلي على أندرويد لمنح الصلاحية');
  }catch(e){toast('تعذر فتح إعدادات الصلاحية')}
};
$('#behaviorForm').onsubmit=e=>{
  e.preventDefault();
  data.behavior[today()]=currentBehavior();
  save();renderBehavior();toast('تم حفظ مؤشرات اليوم على هذا الجهاز');
};
function makeBehaviorPrompt(){
  const days=Object.keys(data.behavior||{}).sort().slice(-7).map(d=>({date:d,...data.behavior[d]}));
  const tasksToday=data.tasks.filter(t=>t.date===today());
  const habitsToday=data.habits.map(h=>({habit:h.text,done:!!(data.checks[today()]||{})[h.id]}));
  const nativeUsage=getNativeUsage();
  const appUsage=nativeUsage.available&&nativeUsage.permission?nativeUsage.apps.slice(0,12).map(a=>({app:a.name||a.packageName,minutes:Math.max(0,Math.round(Number(a.minutes)||0))})):[];
  const foreground=nativeUsage.available&&nativeUsage.permission&&nativeUsage.foreground?{app:nativeUsage.foreground.name||'غير متاح',approximate:true,lastSeenAt:nativeUsage.foreground.lastSeenAt||null}:null;
  const usageSnapshots=(data.usageProfile?.snapshots||[]).slice(-7);
  return `حلّل البيانات التالية التي اختار المستخدم تسجيلها في تطبيق ALISLAH، وقدّم إرشادًا عمليًا متوازنًا وخطة يومية قابلة للتنفيذ. لا تشخّص حالة صحية ولا تستنتج أكثر مما تدعمه البيانات. اذكر حدود البيانات واسأل سؤالًا توضيحيًا عند الحاجة. تعامل مع اسم التطبيق النشط على أنه تقديري وليس مراقبة دقيقة مستمرة، ولا تستنتج محتوى ما يفعله المستخدم داخل التطبيق.
سجلات المؤشرات اليومية لآخر 7 أيام: ${JSON.stringify(days)}
مهام اليوم: ${JSON.stringify(tasksToday.map(t=>({text:t.text,priority:t.priority,done:t.done})))}
العادات وحالة إنجازها اليوم: ${JSON.stringify(habitsToday)}
إحصاءات التطبيقات اليوم (محلية وتُضمّن فقط عند الموافقة على الإرسال): ${JSON.stringify(appUsage)}
التطبيق النشط الأخير وفق سجل أندرويد (تقديري): ${JSON.stringify(foreground)}
ملخصات استخدام محفوظة محليًا لآخر 7 أيام: ${JSON.stringify(usageSnapshots)}
المطلوب: 1) لخّص الأنماط الظاهرة بحذر واذكر ما البيانات الناقصة. 2) حدّد نقطة قوة ونقطة تحسين مدعومتين بالبيانات. 3) أنشئ خطة عملية لمدة 7 أيام، وكل يوم بعنوان مستقل «اليوم 1:» إلى «اليوم 7:». تحت كل يوم اكتب 2 إلى 4 مهام قابلة للقياس، كل مهمة في سطر مستقل يبدأ برقم ثم نقطة مثل «1. **اسم المهمة** — وصف عملي ومدة محددة». لا تضع العنوان العام أو النصائح كمهمة. 4) اجعل كل مهمة مستقلة قابلة للتأشير والإنجاز، مع اقتراح وقت مناسب. 5) لا تعتبر مدة الهاتف اليدوية قياسًا تلقائيًا ولا تخترع بيانات غير موجودة.`;
}
$('#analyzeBehavior').onclick=()=>{
  const usageNow=getNativeUsage();
  if(!Object.keys(data.behavior||{}).length && !(usageNow.permission&&usageNow.apps.length) && !(data.usageProfile?.snapshots||[]).length){toast('سجّلي مؤشرات يوم أو فعّلي إحصاءات التطبيقات واضغطي تحديث أولًا');return;}
  if(!$('#analysisConsent').checked){toast('فعّلي الموافقة أولًا للسماح بإرسال ملخص البيانات للتحليل');return;}
  tab('assistant');
  $('#chatText').value=makeBehaviorPrompt();
  $('#chatText').dataset.includesPersonalAnalysis='true';
  $('#chatText').focus();
  toast('راجعي النص؛ لن يُرسل إلا بعد ضغطك على إرسال');
};
$('#deleteBehavior').onclick=async()=>{
  if(await ui.confirm('حذف سجلات التحليل؟','حذف',true,'لا يمكن التراجع عن ذلك.')){
    data.behavior={};save();renderBehavior();toast('تم حذف سجلات التحليل');
  }
};

function scheduleTaskReminder(t){try{if(!t||!t.time||!t.date||t.done||!window.AndroidUsage||typeof AndroidUsage.scheduleTaskReminder!=='function')return;const when=new Date(t.date+'T'+t.time+':00').getTime();if(Number.isFinite(when)&&when>Date.now())AndroidUsage.scheduleTaskReminder(String(t.id),String(t.text).slice(0,160),when)}catch(_){}}
function extractPlanTasks(reply){
  const lines=String(reply||'').replace(/\r/g,'').split('\n').map(x=>x.trim()).filter(Boolean);
  const result=[]; let current=null; let inPlan=false;
  const cleanText=x=>String(x||'').replace(/^\s*#+\s*/,'').replace(/\*{1,2}/g,'').replace(/`/g,'').replace(/\s+/g,' ').trim();
  const isTitle=x=>/^(?:خطة\s*(?:يومية|شخصية|أسبوعية|مختصرة)?|ملخص الخطة|الخطة المقترحة)(?:\s*\([^)]*\))?\s*[:：-]?$/i.test(cleanText(x));
  const isDay=x=>/^(?:اليوم\s*(?:\d+|الأول|الأولى|الثاني|الثانية|الثالث|الثالثة|الرابع|الرابعة|الخامس|الخامسة|السادس|السادسة|السابع|السابعة))\s*[:：-]?/i.test(cleanText(x));
  const isBullet=x=>/^(?:[-*•▪◦]\s+|\d{1,3}\s*[.)、:：-]\s+)/.test(x);
  const strip=x=>cleanText(x.replace(/^(?:[-*•▪◦]\s+|\d{1,3}\s*[.)、:：-]\s+)/,''));
  const flush=()=>{if(current){let t=cleanText(current).replace(/^[—–:؛,\s]+|[—–:؛,\s]+$/g,'');if(t.length>=5&&t.length<=360&&!result.some(x=>x.toLocaleLowerCase('ar')===t.toLocaleLowerCase('ar')))result.push(t);current=null;}};
  for(let line of lines){
    line=line.replace(/^\s*#+\s*/,'').trim(); const plain=cleanText(line);
    if(!plain||/^[-*_]{3,}$/.test(line))continue;
    if(isTitle(line)){inPlan=true;flush();continue;}
    if(isDay(line)){inPlan=true;flush();continue;}
    if(/^(?:ملاحظة|نصائح عامة|الخلاصة|مؤشر التقدم|نقطة القوة|نقطة التحسين|تحليل البيانات|الأنماط الظاهرة)\b/i.test(plain)){flush();continue;}
    if(isBullet(line)){
      const numbered=/^\d{1,3}\s*[.)、:：-]\s+/.test(line);
      const content=strip(line);
      if(!content)continue;
      if(numbered){flush();current=content;inPlan=true;}
      else if(current){current+=' — '+content;}
      else {current=content;inPlan=true;}
      continue;
    }
    // Keep wrapped description lines with the current task, but do not turn explanatory prose into tasks.
    if(current && !/^(?:إذا|ملاحظة|تذكري|تذكّر|الهدف|لماذا|مؤشر النجاح)\b/i.test(plain))current+=' '+plain;
    else if(inPlan && /^(?:المهمة|نشاط|تمرين)\s*\d+/i.test(plain)){flush();current=plain;}
  }
  flush();
  return result;
}
function autoCreateTasksFromPlan(prompt,reply){
  if(!/خطة|خطّة|خطط|جدول يوم|نظّم لي يوم|نظم لي يوم|مهام اليوم|خطة يومية|خطة شخصية|خطة أسبوعية/i.test(String(prompt||'')))return 0;
  const clean=extractPlanTasks(reply);
  if(!clean.length)return 0;
  const norm=x=>String(x||'').toLocaleLowerCase('ar').replace(/[\s\u0640.,،؛:!?؟()\[\]{}'"ـ-]/g,'');
  const existing=new Set(data.tasks.filter(t=>!t.done).map(t=>norm(t.text)));
  const unique=clean.filter(t=>{const key=norm(t);if(!key||existing.has(key))return false;existing.add(key);return true;});
  if(!unique.length){toast('لم أضف مهامًا مكررة؛ لا توجد خطوات جديدة في الخطة.');return 0;}
  const now=new Date();let cursor=new Date(now);cursor.setSeconds(0,0);cursor.setMinutes(0);cursor.setHours(cursor.getHours()+1);
  if(cursor.getHours()<8)cursor.setHours(9,0,0,0);
  if(cursor.getHours()>21){cursor.setDate(cursor.getDate()+1);cursor.setHours(9,0,0,0);}
  unique.forEach((text,i)=>{
    if(cursor.getHours()>21){cursor.setDate(cursor.getDate()+1);cursor.setHours(9,0,0,0);}
    const date=cursor.getFullYear()+'-'+String(cursor.getMonth()+1).padStart(2,'0')+'-'+String(cursor.getDate()).padStart(2,'0');
    const time=String(cursor.getHours()).padStart(2,'0')+':'+String(cursor.getMinutes()).padStart(2,'0');
    const task={id:uid(),text,date,time,priority:i===0?'مهمة جدًا':'عادية',done:false,source:'assistant-plan'};
    data.tasks.push(task);scheduleTaskReminder(task);cursor=new Date(cursor.getTime()+90*60000);
  });
  save();renderTasks();toast('أُضيفت '+unique.length+' مهام عملية من الخطة دون حدّ ثابت.');return unique.length;
}

function cancelTaskReminder(id){try{if(window.AndroidUsage&&typeof AndroidUsage.cancelTaskReminder==='function')AndroidUsage.cancelTaskReminder(String(id))}catch(_){}}
const CATS=['عمل','بيت','أسرة','صحة','دراسة','عبادة','أخرى'],REPEATS={daily:'يوميًا',weekly:'أسبوعيًا',monthly:'شهريًا'};
let taskFilter='soon',taskCat='';
function nextDate(ds,rep){const p=ds.split('-').map(Number);if(rep==='daily')return ymd(new Date(p[0],p[1]-1,p[2]+1));if(rep==='weekly')return ymd(new Date(p[0],p[1]-1,p[2]+7));if(rep==='monthly'){const first=new Date(p[0],p[1],1),last=new Date(first.getFullYear(),first.getMonth()+1,0).getDate();return ymd(new Date(first.getFullYear(),first.getMonth(),Math.min(p[2],last)))}return ds}
function completeTask(t,done){t.done=done;if(done){t.doneAt=today();cancelTaskReminder(t.id);if(t.repeat&&REPEATS[t.repeat]&&!t.spawned){const base=(t.date||today())<today()?today():(t.date||today()),nd=nextDate(base,t.repeat);if(!data.tasks.some(x=>!x.done&&x.text===t.text&&x.repeat===t.repeat&&x.date===nd)){const n={id:uid(),text:t.text,date:nd,time:t.time||'',priority:t.priority||'عادية',cat:t.cat||'',repeat:t.repeat,done:false};data.tasks.push(n);scheduleTaskReminder(n)}t.spawned=true}}else{delete t.doneAt;scheduleTaskReminder(t)}}
function renderTasks(){const now=today();const maxDate=ymd(new Date(Date.now()+7*86400000));
let ts=data.tasks.slice();
if(taskCat)ts=ts.filter(t=>(t.cat||'')===taskCat);
if(taskFilter==='soon')ts=ts.filter(t=>String(t.date||now)<=maxDate&&(!t.done||t.date===now));else if(taskFilter==='done')ts=ts.filter(t=>t.done);
ts.sort(taskFilter==='done'?(a,b)=>String(b.doneAt||b.date||'').localeCompare(String(a.doneAt||a.date||'')):(a,b)=>Number(a.done)-Number(b.done)||String(a.date||now).localeCompare(String(b.date||now))||String(a.time||'99:99').localeCompare(String(b.time||'99:99')));
$('#count').textContent=ts.length+(ts.length===1?' مهمة':' مهام');
$$('#taskFilter button').forEach(b=>b.classList.toggle('on',b.dataset.f===taskFilter));
const empty={soon:'لا توجد مهام قريبة. أضيفي مهمة أو أنشئي خطة من المساعد',all:'لا توجد مهام بعد. ابدئي بإضافة أول مهمة',done:'لم تُنجزي مهامًا بعد، خطوة صغيرة تكفي'}[taskFilter];
$('#tasksList').innerHTML=ts.length?ts.map(t=>{const d=t.date||now,over=!t.done&&d<now,when=d===now?'اليوم':d===ymd(new Date(Date.now()+86400000))?'غدًا':d;const pr=t.priority||'عادية',pc=pr==='مهمة جدًا'?'gold':pr==='يمكن تأجيلها'?'gray':'';return `<div class="item ${t.done?'done':''} ${over?'overdue':''}"><input class="check tc" type="checkbox" data-id="${esc(t.id)}" ${t.done?'checked':''} aria-label="إنجاز: ${esc(t.text)}"><div class="grow"><div class="title">${esc(t.text)}</div><div class="meta"><span class="chip ${pc}">${esc(pr)}</span><span class="chip gray">📅 ${esc(when)}</span>${t.time?`<span class="chip gray">⏰ ${esc(t.time)}</span>`:''}${t.cat?`<span class="chip">🏷️ ${esc(t.cat)}</span>`:''}${REPEATS[t.repeat]?`<span class="chip gray">🔁 ${esc(REPEATS[t.repeat])}</span>`:''}${over?'<span class="chip red">متأخرة</span>':''}</div></div><button class="mini edittask" type="button" data-id="${esc(t.id)}" aria-label="تعديل المهمة">✏️</button><button class="mini del deltask" type="button" data-id="${esc(t.id)}" aria-label="حذف المهمة">🗑️</button></div>`}).join(''):`<div class="empty"><span class="ei">🌱</span>${empty}</div>`;
$('#clearDone').classList.toggle('hidden',!data.tasks.some(t=>t.done));
$$('.tc').forEach(c=>c.onchange=()=>{let t=data.tasks.find(x=>x.id===c.dataset.id);if(t)completeTask(t,c.checked);save();renderTasks();if(typeof renderHabits==='function')stats()});
$$('.deltask').forEach(b=>b.onclick=async()=>{const t=data.tasks.find(x=>x.id===b.dataset.id);if(!t)return;if(!(await ui.confirm('حذف المهمة؟','حذف',true,t.text)))return;cancelTaskReminder(t.id);data.tasks=data.tasks.filter(x=>x.id!==t.id);save();renderTasks()});
$$('.edittask').forEach(b=>b.onclick=()=>{const t=data.tasks.find(x=>x.id===b.dataset.id);if(t)openTaskSheet(t)});
const todayTasks=data.tasks.filter(t=>(t.date||now)===now);let done=todayTasks.filter(t=>t.done).length;const pct=todayTasks.length?done/todayTasks.length*100:0;$('#progress').style.width=pct+'%';$('#progress').parentNode.setAttribute('aria-valuenow',Math.round(pct));$('#progressText').textContent=todayTasks.length?`أنجزتِ ${done} من ${todayTasks.length} مهام اليوم.`:'أضيفي مهامًا بموعد واضح لتتابعي تقدمك اليوم.'}
function openTaskSheet(t){const sh=$('#taskSheet');$('#etText').value=t.text;$('#etDate').value=t.date||today();$('#etTime').value=t.time||'';$('#etPriority').value=t.priority||'عادية';$('#etCat').value=t.cat||'';$('#etRepeat').value=t.repeat||'';sh.dataset.id=t.id;sh.classList.add('open');setTimeout(()=>$('#etText').focus(),60)}
$('#etCancel').onclick=()=>$('#taskSheet').classList.remove('open');
$('#taskSheet').addEventListener('click',e=>{if(e.target.id==='taskSheet')e.target.classList.remove('open')});
$('#etSave').onclick=()=>{const sh=$('#taskSheet'),t=data.tasks.find(x=>x.id===sh.dataset.id);if(!t)return sh.classList.remove('open');const nt=$('#etText').value.trim().slice(0,180);if(!nt){toast('اكتبي نص المهمة');return}cancelTaskReminder(t.id);t.text=nt;t.date=$('#etDate').value||today();t.time=$('#etTime').value||'';t.priority=$('#etPriority').value;t.cat=$('#etCat').value;t.repeat=$('#etRepeat').value;t.spawned=false;scheduleTaskReminder(t);save();renderTasks();sh.classList.remove('open');toast('تم حفظ التعديل')};
$$('#taskFilter button').forEach(b=>b.onclick=()=>{taskFilter=b.dataset.f;renderTasks()});
$('#taskCatFilter').onchange=e=>{taskCat=e.target.value;renderTasks()};
$('#clearDone').onclick=async()=>{const n=data.tasks.filter(t=>t.done).length;if(!n)return;if(!(await ui.confirm('حذف المهام المنجزة؟','حذف',true,'سيتم حذف '+n+' مهام منجزة نهائيًا.')))return;data.tasks=data.tasks.filter(t=>!t.done);save();renderTasks();toast('تم الحذف')};

$('#taskForm').onsubmit=e=>{e.preventDefault();let text=$('#taskText').value.trim();if(!text)return;const task={id:uid(),text,date:$('#taskDate').value||today(),time:$('#taskTime').value||'',priority:$('#priority').value,cat:$('#taskCat').value||'',repeat:$('#taskRepeat').value||'',done:false};data.tasks.push(task);scheduleTaskReminder(task);$('#taskText').value='';$('#taskDate').value=today();$('#taskTime').value='';$('#priority').value='عادية';$('#taskCat').value='';$('#taskRepeat').value='';save();renderTasks();toast(task.time?'أضيفت المهمة مع تذكير مجدول':'تمت إضافة المهمة؛ أضيفي وقتًا إذا أردتِ تذكيرًا');if(task.time)ensureNotif()};
const ayyam=n=>n===1?'يوم':n===2?'يومان':(n>=3&&n<=10)?n+' أيام':n+' يومًا';
function streakOf(id){let n=0;const d=new Date();if(!(data.checks[today()]||{})[id])d.setDate(d.getDate()-1);while(n<3650){const k=ymd(d);if((data.checks[k]||{})[id]){n++;d.setDate(d.getDate()-1)}else break}return n}
function weekDots(id){const out=[];for(let i=6;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);const k=ymd(d);out.push('<i class="'+(((data.checks[k]||{})[id])?'on':'')+(i===0?' today':'')+'" title="'+k+'"></i>')}return out.join('')}
function renderHabits(){let c=data.checks[today()]||{};
$('#habitsList').innerHTML=data.habits.length?data.habits.map(h=>{const dn=!!c[h.id],st=streakOf(h.id);return `<div class="habit ${dn?'done':''}"><div class="row"><h4>${esc(h.text)}</h4><div style="display:flex"><button class="mini edithabit" type="button" data-id="${esc(h.id)}" aria-label="تعديل العادة">✏️</button><button class="mini del delhabit" type="button" data-id="${esc(h.id)}" aria-label="حذف العادة">🗑️</button></div></div><div class="streak">${st?'🔥 سلسلة: '+ayyam(st):'ابدئي سلسلتك اليوم'}</div><div class="dots" aria-label="آخر 7 أيام">${weekDots(h.id)}</div><button class="btn ${dn?'soft':'primary'} block togglehabit" type="button" data-id="${esc(h.id)}">${dn?'✓ تمّ اليوم — إلغاء':'أنجزتها اليوم'}</button></div>`}).join(''):'<div class="empty" style="grid-column:1/-1"><span class="ei">🔁</span>أضيفي عادة تريدين المحافظة عليها.</div>';
$$('.togglehabit').forEach(b=>b.onclick=()=>{data.checks[today()]=data.checks[today()]||{};data.checks[today()][b.dataset.id]=!data.checks[today()][b.dataset.id];save();renderHabits()});
$$('.delhabit').forEach(b=>b.onclick=async()=>{const h=data.habits.find(x=>x.id===b.dataset.id);if(!h)return;if(!(await ui.confirm('حذف العادة؟','حذف',true,h.text)))return;data.habits=data.habits.filter(x=>x.id!==h.id);save();renderHabits()});
$$('.edithabit').forEach(b=>b.onclick=async()=>{const h=data.habits.find(x=>x.id===b.dataset.id);if(!h)return;const v=await ui.prompt('تعديل العادة',h.text);if(v===null)return;const nt=String(v).trim().slice(0,100);if(!nt){toast('اكتبي اسم العادة');return}h.text=nt;save();renderHabits()})}$('#habitForm').onsubmit=e=>{
 e.preventDefault();
 let text=$('#habitText').value.trim();
 if(!text)return;
 if(data.habits.some(h=>String(h.text||'').trim().toLocaleLowerCase()===text.toLocaleLowerCase())){toast('هذه العادة موجودة بالفعل');return}
 if(data.habits.length>=40){toast('وصلتِ إلى الحد الأقصى للعادات');return}
 data.habits.push({id:uid(),text});$('#habitText').value='';save();renderHabits()
};function stats(){let ts=data.tasks.filter(t=>t.date===today()),done=ts.filter(t=>t.done).length,c=data.checks[today()]||{},hd=data.habits.filter(h=>c[h.id]).length;$('#doneN').textContent=done;$('#leftN').textContent=ts.length-done;$('#habitN').textContent=hd;$('#habitPct').textContent=(data.habits.length?Math.round(hd/data.habits.length*100):0)+'%';
const total=ts.length+data.habits.length,got=done+hd,pct=total?Math.round(got/total*100):0;const hp=$('#heroPct');if(hp){hp.textContent=pct+'%';$('#heroRing').style.setProperty('--p',pct);$('#heroSub').textContent=total?(pct>=100?'أحسنتِ! أنجزتِ كل شيء اليوم 🎉':pct>=60?'أنتِ في منتصف الطريق، واصلي 💪':pct>0?'بداية موفقة، واصلي 🌿':'ابدئي بخطوة صغيرة الآن 🌱'):'أضيفي مهمة أو عادة لتبدأي يومك'}}
const ideas=[['سؤال اليوم','ما أجمل شيء حدث لكل فرد اليوم؟'],['صيد الألوان','ابحثوا عن ثلاثة أشياء من اللون نفسه.'],['مساعدة صغيرة','رتّبوا ركنًا صغيرًا معًا لخمس دقائق.'],['قصة مشتركة','كل شخص يضيف جملة إلى قصة خيالية.'],['امتنان','اذكروا شيئًا جميلًا تقدّرونه اليوم.']];function idea(){let x=ideas[data.idea%ideas.length];$('#idea').innerHTML=`<div class="grow"><div class="title">${esc(x[0])}</div><div class="muted">${esc(x[1])}</div></div>`}$('#nextIdea').onclick=()=>{data.idea++;save();idea()};
function escHtml(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;')}
function formatAssistantText(text){
  let raw=String(text||'').replace(/\\\*\*/g,'**').replace(/\\\*/g,'*').replace(/\\#/g,'#').replace(/\\\|/g,'|');
  const lines=raw.split(/\r?\n/),out=[];let list=null,code=false,codeLines=[];
  const closeList=()=>{if(list){out.push(list==='ol'?'</ol>':'</ul>');list=null}};
  const inline=t=>escHtml(t).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/\*(.+?)\*/g,'<em>$1</em>');
  for(let line of lines){let t=line.trim();
    if(/^```/.test(t)){closeList();if(!code){code=true;codeLines=[]}else{out.push('<code>'+escHtml(codeLines.join('\n'))+'</code>');code=false}continue}
    if(code){codeLines.push(line);continue}
    if(!t){closeList();continue}
    if(/^\|?\s*[-:| ]+\|\s*$/.test(t))continue;
    if(t.includes('|') && /^\|/.test(t)){closeList();let cells=t.split('|').map(x=>x.trim()).filter(Boolean);if(cells.length)out.push('<p>'+cells.map(inline).join(' — ')+'</p>');continue}
    let m=t.match(/^(#{1,3})\s+(.+)$/);if(m){closeList();out.push('<h3>'+inline(m[2])+'</h3>');continue}
    m=t.match(/^>\s?(.*)$/);if(m){closeList();out.push('<p><em>'+inline(m[1])+'</em></p>');continue}
    m=t.match(/^[-*•]\s+(.+)$/);if(m){if(list!=='ul'){closeList();out.push('<ul>');list='ul'}out.push('<li>'+inline(m[1])+'</li>');continue}
    m=t.match(/^\d+[.)]\s+(.+)$/);if(m){if(list!=='ol'){closeList();out.push('<ol>');list='ol'}out.push('<li>'+inline(m[1])+'</li>');continue}
    closeList();out.push('<p>'+inline(t)+'</p>');
  }
  closeList();if(code)out.push('<code>'+escHtml(codeLines.join('\n'))+'</code>');return '<div class="md">'+out.join('')+'</div>';
}
function bubble(role,text,store=true,sensitive=false){let el=document.createElement('div');el.className='bubble '+role;if(role==='assistant')el.innerHTML=formatAssistantText(text);else el.textContent=text;$('#messages').append(el);$('#messages').scrollTop=$('#messages').scrollHeight;if(store){data.chat.push({role:role==='user'?'user':'assistant',content:text.slice(0,4000),sensitive:!!sensitive});data.chat=data.chat.slice(-30);save()}return el}function drawChat(){if(data.chat.length){$('#messages').innerHTML='';data.chat.forEach(x=>bubble(x.role==='user'?'user':'assistant',x.content,false))}}function localReply(m){if(/جدول|تنظيم|مهام|يوم/i.test(m))return 'لننظم اليوم ببساطة:\n1. اختاري أهم ثلاث مهام.\n2. ابدئي بمهمة صغيرة لمدة 20 دقيقة.\n3. ضعي وقتًا للراحة والأسرة.\n4. اجعلي المهام الإضافية اختيارية.';if(/طفل|بنت|ابنت|أسرة|عائلة/i.test(m))return 'جرّبي نشاطًا قصيرًا يناسب العمر، مثل قصة مشتركة أو البحث عن أشياء بلون واحد. اجعلي الوقت ممتعًا دون ضغط.';if(/عادة|التزام/i.test(m))return 'ابدئي بعادة صغيرة جدًا واربطِيها بروتين قائم، وسجّلي إنجازك. إذا فاتك يوم، عودي في اليوم التالي دون لوم.';return 'هذا رد محلي مبسّط، وليس ردًا من الذكاء الاصطناعي المتصل. تحققي من اتصال الإنترنت ورابط الخدمة في الإعدادات، ثم أعيدي المحاولة.'}
async function online(m){let raw=data.settings.worker.trim();let u;try{u=new URL(raw);if(u.protocol!=='https:')throw 0}catch{throw Error('رابط الخدمة غير صالح؛ افتحي الإعدادات وتحققي منه.')}let controller=new AbortController(),to=setTimeout(()=>controller.abort(),25000);try{let history=data.chat.filter(x=>!x.sensitive).slice(-8).map(x=>({role:x.role==='user'?'user':'assistant',content:x.content}));let r=await fetch(u.href,{method:'POST',mode:'cors',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:'أجب باللغة العربية الواضحة والمختصرة. خصّص النصيحة لما ذكره المستخدم فقط، ولا تفترض معلومات غير متاحة. '+getAutoContext()+' طلب المستخدم: '+m,history}),signal:controller.signal,cache:'no-store'});let j={};try{j=await r.json()}catch{}if(!r.ok)throw Error(j.error||`استجابة الخدمة ${r.status}`);if(typeof j.reply!=='string'||!j.reply.trim())throw Error('الخدمة لم ترجع إجابة صالحة');return j.reply.trim()}finally{clearTimeout(to)}}const consentMain=$('#analysisConsent'),consentChat=$('#chatAnalysisConsent');if(consentMain&&consentChat){consentMain.addEventListener('change',()=>{consentChat.checked=consentMain.checked});consentChat.addEventListener('change',()=>{consentMain.checked=consentChat.checked})}
$('#chatForm').onsubmit=async e=>{e.preventDefault();let m=$('#chatText').value.trim();if(!m)return;const sensitive=$('#chatText').dataset.includesPersonalAnalysis==='true';if(sensitive&&!($('#analysisConsent')?.checked||$('#chatAnalysisConsent')?.checked)){toast('فعّلي موافقة إرسال الملخص الظاهرة فوق زر الإرسال؛ لن يُرسل شيء دونها.');$('#chatConsentWrap').style.display='flex';return;}$('#chatText').dataset.includesPersonalAnalysis='false';$('#chatText').value='';bubble('user',m,true,sensitive);$('#send').disabled=true;$('#send').textContent='انتظري…';let w=bubble('system','أحاول الاتصال بالذكاء الاصطناعي عبر الإنترنت…',false);try{let answer=await online(m);w.remove();bubble('assistant',answer,true,sensitive);$('#aiStatus').textContent='تم الرد عبر الإنترنت';autoCreateTasksFromPlan(m,answer)}catch(err){w.remove();$('#aiStatus').textContent='تعذر الاتصال — مساعدة محلية';bubble('assistant','لم يصلني رد من خدمة الذكاء الاصطناعي. السبب: '+(err.name==='AbortError'?'انتهت مهلة الاتصال.':err.message)+'\n\nمساعدة محلية مؤقتة:\n'+localReply(m),true,sensitive)}finally{$('#send').disabled=false;$('#send').textContent='إرسال';try{if(window.AndroidUsage&&typeof AndroidUsage.assistantAnswered==='function')AndroidUsage.assistantAnswered();const last=$('#messages .bubble.assistant:last-child');const answerText=last?(last.textContent||''):'';const eventWords=/(هل\s|؟|\?|نصيح|أنصح|تذكير|ذكّ?ر|إرشاد|خطوة عملية|اقترح|جرّب|جرّبي|ابدأ|ابدئي|خطة|ينبغي|حاول|حاولي)/i;if(eventWords.test(answerText)&&window.AndroidUsage&&typeof AndroidUsage.showBubbleForEvent==='function')AndroidUsage.showBubbleForEvent()}catch(_){}}};$$('.quick').forEach(b=>b.onclick=()=>{$('#chatText').value=b.dataset.prompt;$('#chatText').focus()});$('#clearChat').onclick=async()=>{if(await ui.confirm('مسح المحادثة؟','مسح',true)){data.chat=[];save();$('#messages').innerHTML='';bubble('assistant','أهلًا بكِ، كيف أساعدك اليوم؟',false)}};
$('#worker').value=data.settings.worker;$('#questionCloudEnabled').checked=data.settings.questionCloudEnabled===true;$('#name').value=data.settings.name;$('#themeMode').value=data.settings.theme||'auto';$('#questionCloudEnabled').addEventListener('change',e=>{data.settings.questionCloudEnabled=e.target.checked;save();toast(e.target.checked?'تم تفعيل إرسال إجابات الأسئلة بعد اختيارها.':'تم إيقاف إرسال إجابات الأسئلة؛ ستبقى محلية.')});const autoShare=$('#autoShareUsage');if(autoShare){autoShare.checked=!!data.settings.autoShareUsage;autoShare.addEventListener('change',()=>{data.settings.autoShareUsage=autoShare.checked;save();toast(autoShare.checked?'فُعّلت المشاركة التلقائية بعد موافقتك':'أُوقفت المشاركة التلقائية')})}$('#saveSettings').onclick=()=>{let w=$('#worker').value.trim();try{if(w&&new URL(w).protocol!=='https:')throw 0}catch{toast('أدخلي رابط HTTPS صحيحًا');return}data.settings.worker=w;data.settings.name=$('#name').value.trim();data.settings.theme=$('#themeMode').value;save();applyTheme();applyGreeting();toast('تم حفظ الإعدادات')};$('#test').onclick=async()=>{let o=$('#testResult');o.textContent=' جارٍ الاختبار…';try{let r=await fetch($('#worker').value.trim(),{method:'GET',mode:'cors'});let t=await r.text();o.textContent=r.status===405&&/Use POST/i.test(t)?' الرابط يستجيب؛ جرّبي إرسال رسالة من المساعد.':` الاستجابة: ${r.status}`}catch{o.textContent=' تعذر اختبار الاتصال؛ جرّبي إرسال رسالة.'}};

/* ===== dialogs ===== */
const ui=(()=>{const dlg=$('#dlg'),t=$('#dlgTitle'),m=$('#dlgMsg'),inp=$('#dlgInput'),ok=$('#dlgOk'),cancel=$('#dlgCancel');let resolver=null,lastFocus=null;
function close(v){dlg.classList.remove('open');const r=resolver;resolver=null;try{lastFocus&&lastFocus.focus&&lastFocus.focus()}catch(_){}if(r)r(v)}
function open(o){return new Promise(res=>{if(resolver)close(null);resolver=res;lastFocus=document.activeElement;t.textContent=o.title||'';m.textContent=o.message||'';m.style.display=o.message?'':'none';inp.classList.toggle('hidden',!o.input);inp.type=o.password?'password':'text';inp.maxLength=o.password?64:180;if(o.input){inp.value=o.value||''}ok.textContent=o.ok||'موافق';ok.className='btn '+(o.danger?'danger':'primary');dlg.classList.add('open');setTimeout(()=>(o.input?inp:ok).focus(),60)})}
ok.onclick=()=>close(inp.classList.contains('hidden')?true:inp.value);
cancel.onclick=()=>close(inp.classList.contains('hidden')?false:null);
dlg.addEventListener('click',e=>{if(e.target===dlg)cancel.onclick()});
inp.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();ok.onclick()}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&dlg.classList.contains('open'))cancel.onclick()});
return{confirm:(title,okLabel,danger,message)=>open({title,message,ok:okLabel,danger}),prompt:(title,value,okLabel,opts)=>open({title,input:true,value,ok:okLabel||'حفظ',...(opts||{})}),isOpen:()=>dlg.classList.contains('open'),close:()=>cancel.onclick()}})();
window.__alislahBack=function(){if(ui.isOpen()){ui.close();return true}const sh=document.querySelector('.sheet-backdrop.open:not(#welcome)');if(sh){sh.classList.remove('open');return true}const w=$('#welcome');if(w&&w.classList.contains('open'))return true;const ck=$('#alislahCheckin');if(ck&&ck.classList.contains('open')){ck.classList.remove('open');const f=$('#alislahFloat');if(f)f.setAttribute('aria-expanded','false');return true}const eb=$('#eyeBreakOverlay');if(eb&&eb.classList.contains('open'))return true;const v=document.body.dataset.view||'tasks';if(v==='more'){tab('tasks');return true}if(!PRIMARY.includes(v)){tab(window.__alislahFrom==='more'||document.getElementById('more')?'more':'tasks');return true}if(v!=='tasks'){tab('tasks');return true}return false};

/* ===== theme / greeting ===== */
function applyTheme(){const th=data.settings.theme;if(th==='light'||th==='dark')document.documentElement.setAttribute('data-theme',th);else document.documentElement.removeAttribute('data-theme')}
function applyGreeting(){const n=String(data.settings.name||'').trim();$('#greeting').textContent=n?`أهلًا ${n}، خطوة صغيرة تصنع فرقًا 🌿`:'خطوة صغيرة تصنع فرقًا 🌿'}

/* ===== native (Android) status, permissions, welcome ===== */
function nativeStatus(){try{return NATIVE&&window.AndroidUsage.getNativeStatus?JSON.parse(AndroidUsage.getNativeStatus()||'{}'):null}catch(_){return null}}
function renderNative(){const box=$('#nativePanel'),rows=$('#nativeRows');if(!box||!rows)return;const st=nativeStatus();if(!st||!st.native){box.classList.add('hidden');return}box.classList.remove('hidden');
const ov=!!(st.overlayEnabled&&st.overlayPermission);
const row=(ic,title,desc,ok,btn,id)=>`<div class="perm"><span class="pi" aria-hidden="true">${ic}</span><div class="grow"><div class="ph"><strong>${title}</strong><span class="state ${ok?'ok':'off'}">${ok?'مفعّل':'غير مفعّل'}</span></div><small>${desc}</small></div>${btn?`<button class="btn soft" type="button" data-n="${id}">${btn}</button>`:''}</div>`;
rows.innerHTML=row('🔔','الإشعارات','تذكير المهام وتنبيهات الصلاة وأسئلة المتابعة',st.notifications,st.notifications?'إدارة':'السماح','notif')
+row('🔋','العمل في الخلفية','استثني التطبيق من توفير البطارية ليصل الأذان في وقته',st.battery,st.battery?'':'ضبط','battery')
+row('🫧','الفقاعة العائمة','زر ALISLAH فوق التطبيقات للوصول السريع للمساعد',ov,ov?'إيقاف':'تفعيل','overlay')
+row('🎙️','الميكروفون','للإملاء الصوتي في المساعد',st.microphone,st.microphone?'':'السماح','mic')
+row('📊','إحصاءات الاستخدام','تحليل وقت الشاشة على جهازك',st.usage,st.usage?'':'منح','usage')
+`<div class="perm"><span class="pi" aria-hidden="true">💬</span><div class="grow"><strong>أسئلة المتابعة</strong><small>سؤال خفيف كل بضع ساعات، ولا يصلك بين 10 مساءً و8 صباحًا</small></div><input id="nativeQuestions" class="switch" type="checkbox" ${st.questions?'checked':''} aria-label="أسئلة المتابعة"></div>`;
rows.querySelectorAll('[data-n]').forEach(b=>b.onclick=()=>{const k=b.dataset.n;if(k==='notif')nat('requestNotificationPermission');else if(k==='battery')nat('openBatterySettings');else if(k==='overlay'){if(ov)nat('disableOverlay');else nat('enableOverlay')}else if(k==='mic')nat('requestRuntimePermissions');else if(k==='usage')nat('requestUsagePermission');setTimeout(renderNative,700);setTimeout(renderNative,2500)});
const q=$('#nativeQuestions');if(q)q.onchange=()=>{nat('enableBackgroundQuestions',q.checked);toast(q.checked?'فُعّلت أسئلة المتابعة':'أُوقفت أسئلة المتابعة')};
if(st.version){const a=$('#appVersion'),b=$('#appVersion2');if(a)a.textContent=st.version;if(b)b.textContent=st.version}}
let notifAsked=false;
function ensureNotif(){if(!NATIVE||notifAsked)return;const st=nativeStatus();if(st&&st.notifications===false){notifAsked=true;toast('اسمحي بالإشعارات ليصلك التذكير');setTimeout(()=>nat('requestNotificationPermission'),1100)}}
function maybeWelcome(){if(!NATIVE||!FIRST_RUN||data.settings.welcomed)return;const w=$('#welcome');if(!w)return;$('#welcomeNative').classList.remove('hidden');const nb=$('#welcomeNotif');
const refresh=()=>{const s2=nativeStatus()||{};nb.textContent=s2.notifications?'مفعّل ✓':'السماح';nb.disabled=!!s2.notifications};refresh();
nb.onclick=()=>{nat('requestNotificationPermission');setTimeout(refresh,900);setTimeout(refresh,3000)};
$('#welcomeName').value=data.settings.name||'';
$('#welcomeStart').onclick=()=>{const n=$('#welcomeName').value.trim().slice(0,40);if(n){data.settings.name=n;$('#name').value=n;applyGreeting()}data.settings.welcomed=true;save();if($('#welcomeQuestions').checked)nat('enableBackgroundQuestions',true);w.classList.remove('open');toast('أهلًا بك! ابدئي بإضافة أول مهمة 🌿')};
w.classList.add('open')}

/* ===== backup / restore ===== */
const STORE_CHECKINS='alislah_checkins_v1';
function readJSON(k,def){try{const v=JSON.parse(localStorage.getItem(k)||'null');return v&&typeof v==='object'?v:def}catch{return def}}
async function exportBackup(){const payload={...data,checkins:readJSON(STORE_CHECKINS,{}),_format:'alislah-backup',exportedAt:new Date().toISOString()};let json=JSON.stringify(payload,null,2),name='alislah-backup-'+today()+'.json';
if(data.settings.encryptBackup){if(!(NATIVE&&window.AndroidUsage&&typeof AndroidUsage.encryptBackup==='function')){toast('التشفير متاح في نسخة أندرويد فقط');return}const pass=await ui.prompt('كلمة سر النسخة','','تشفير',{password:true,message:'احفظيها جيدًا؛ لا يمكن فتح النسخة بدونها.'});if(pass===null)return;if(String(pass).length<6){toast('كلمة السر يجب ألا تقل عن 6 أحرف');return}const env=AndroidUsage.encryptBackup(json,String(pass));if(!env){toast('تعذر تشفير النسخة');return}json=env;name=name.replace('.json','.enc.json')}
if(NATIVE&&window.AndroidUsage&&typeof AndroidUsage.saveBackup==='function'){nat('saveBackup',name,json);return}
try{const b=new Blob([json],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1500)}catch{toast('تعذر إنشاء النسخة الاحتياطية')}}
function cleanImport(x){const isObj=v=>v&&typeof v==='object'&&!Array.isArray(v),str=(v,n)=>String(v==null?'':v).slice(0,n),num=(v,a,b,d)=>{v=Number(v);return Number.isFinite(v)?Math.min(b,Math.max(a,v)):d};const dateRe=/^\d{4}-\d{2}-\d{2}$/,timeRe=/^\d{2}:\d{2}$/;
const tasks=(Array.isArray(x.tasks)?x.tasks:[]).filter(isObj).slice(0,3000).map(t=>({id:str(t.id||uid(),80),text:str(t.text,180).trim(),date:dateRe.test(t.date||'')?t.date:today(),time:timeRe.test(t.time||'')?t.time:'',priority:['عادية','مهمة جدًا','يمكن تأجيلها'].includes(t.priority)?t.priority:'عادية',done:!!t.done,...(CATS.includes(t.cat)?{cat:t.cat}:{}),...(REPEATS[t.repeat]?{repeat:t.repeat}:{}),...(dateRe.test(t.doneAt||'')?{doneAt:t.doneAt}:{}),...(t.source==='assistant-plan'?{source:'assistant-plan'}:{})})).filter(t=>t.text);
const habits=(Array.isArray(x.habits)?x.habits:[]).filter(isObj).slice(0,500).map(h=>({id:str(h.id||uid(),80),text:str(h.text,100).trim()})).filter(h=>h.text);
const checks={};if(isObj(x.checks))Object.keys(x.checks).slice(-800).forEach(k=>{if(!dateRe.test(k)||!isObj(x.checks[k]))return;const o={};Object.keys(x.checks[k]).slice(0,300).forEach(h=>{if(h.length<=80&&x.checks[k][h]===true)o[h]=true});checks[k]=o});
const chat=(Array.isArray(x.chat)?x.chat:[]).filter(m=>isObj(m)&&typeof m.content==='string').slice(-30).map(m=>({role:m.role==='user'?'user':'assistant',content:m.content.slice(0,4000),sensitive:m.sensitive===true}));
const behavior={};if(isObj(x.behavior))Object.keys(x.behavior).slice(-400).forEach(k=>{const b=x.behavior[k];if(!dateRe.test(k)||!isObj(b))return;behavior[k]={mood:num(b.mood,1,5,3),energy:num(b.energy,1,5,3),focus:num(b.focus,1,5,3),sleepHours:num(b.sleepHours,0,24,0),phoneMinutes:b.phoneMinutes==null||b.phoneMinutes===''?null:num(b.phoneMinutes,0,1440,0),note:str(b.note,700),updatedAt:str(b.updatedAt,40)}});
const snaps=(isObj(x.usageProfile)&&Array.isArray(x.usageProfile.snapshots)?x.usageProfile.snapshots:[]).filter(isObj).slice(-14).map(p=>({date:dateRe.test(p.date||'')?p.date:today(),apps:(Array.isArray(p.apps)?p.apps:[]).filter(isObj).slice(0,12).map(a=>({name:str(a.name,80),minutes:num(a.minutes,0,1440,0)})),...(typeof p.foreground==='string'?{foreground:p.foreground.slice(0,80)}:{}),capturedAt:num(p.capturedAt,0,4102444800000,0)}));
const sx=isObj(x.settings)?x.settings:{};const settings={name:str(sx.name,40),...(['text','voice','both'].includes(sx.interactionMode)?{interactionMode:sx.interactionMode}:{}),voiceRead:sx.voiceRead===true,...(['male','female'].includes(sx.voiceGender)?{voiceGender:sx.voiceGender}:{}),...(['old','neural'].includes(sx.assistantVoiceEngine)?{assistantVoiceEngine:sx.assistantVoiceEngine}:{}),...(['auto','light','dark'].includes(sx.theme)?{theme:sx.theme}:{}),...(['small','normal','large','xlarge'].includes(sx.fontScale)?{fontScale:sx.fontScale}:{})};
const px=isObj(sx.prayer)?sx.prayer:{};const adj={};['Fajr','Dhuhr','Asr','Maghrib','Isha'].forEach(k=>{adj[k]=num(isObj(px.adj)?px.adj[k]:0,-30,30,0)});const prayer={wilaya:/^\d{1,2}$/.test(String(px.wilaya))?String(px.wilaya):'14',lat:num(px.lat,-90,90,35.37),lon:num(px.lon,-180,180,1.32),method:['algeria','mwl','makkah','egypt','isna','france','karachi','tunisia','morocco'].includes(px.method)?px.method:'algeria',adj,before:num(px.before,0,120,10),after:num(px.after,0,180,20),followup:px.followup!==false};
const prayerLog=(Array.isArray(x.prayerLog)?x.prayerLog:[]).filter(isObj).slice(-1500).map(p=>({name:str(p.name,20),date:str(p.date,40),day:dateRe.test(p.day||'')?p.day:'',done:true}));
const checkins={};if(isObj(x.checkins))Object.keys(x.checkins).slice(-500).forEach(k=>{const c=x.checkins[k];if(k.length>80||!isObj(c)||typeof c.question!=='string'||typeof c.answer!=='string')return;checkins[k]={qid:num(c.qid,0,200,0),question:c.question.slice(0,200),answer:c.answer.slice(0,200),at:str(c.at,40)}});
const fx=isObj(x.family)?x.family:{};const members=(Array.isArray(fx.members)?fx.members:[]).filter(isObj).slice(0,12).map(m=>({id:str(m.id||uid(),40),name:str(m.name,30).trim(),emoji:str(m.emoji||'🙂',8),role:['parent','child'].includes(m.role)?m.role:'child',goal:num(m.goal,0,1000,20),reward:str(m.reward,60),base:num(m.base,0,100000,0)})).filter(m=>m.name);const mids=new Set(members.map(m=>m.id));
const routines={};if(isObj(fx.routines))Object.keys(fx.routines).filter(k=>mids.has(k)).forEach(k=>{const r=fx.routines[k];if(!isObj(r))return;routines[k]={morning:(Array.isArray(r.morning)?r.morning:[]).filter(isObj).slice(0,20).map(i=>({id:str(i.id||uid(),40),text:str(i.text,60).trim()})).filter(i=>i.text),evening:(Array.isArray(r.evening)?r.evening:[]).filter(isObj).slice(0,20).map(i=>({id:str(i.id||uid(),40),text:str(i.text,60).trim()})).filter(i=>i.text)}});
const routineLog={};if(isObj(fx.routineLog))Object.keys(fx.routineLog).slice(-200).forEach(k=>{if(!dateRe.test(k)||!isObj(fx.routineLog[k]))return;const o={};Object.keys(fx.routineLog[k]).slice(0,300).forEach(i=>{if(i.length<=90&&fx.routineLog[k][i]===true)o[i]=true});routineLog[k]=o});
const events=(Array.isArray(fx.events)?fx.events:[]).filter(isObj).slice(0,500).map(ev=>({id:str(ev.id||uid(),40),title:str(ev.title,80).trim(),date:dateRe.test(ev.date||'')?ev.date:today(),time:timeRe.test(ev.time||'')?ev.time:'',who:mids.has(ev.who)?ev.who:'',remind:['','15','60','1440'].includes(String(ev.remind))?String(ev.remind):'',done:!!ev.done})).filter(ev=>ev.title);
const family={members,routines,routineLog,events};
const wx=isObj(x.worship)?x.worship:{},kx=isObj(wx.khatma)?wx.khatma:{};const klog={};if(isObj(kx.log))Object.keys(kx.log).slice(-400).forEach(k=>{if(dateRe.test(k))klog[k]=num(kx.log[k],0,604,0)});
const dh={};if(isObj(wx.dhikrDone))Object.keys(wx.dhikrDone).slice(-120).forEach(k=>{if(!dateRe.test(k)||!isObj(wx.dhikrDone[k]))return;const o={};['morning','evening','afterPrayer','sleep'].forEach(s=>{if(wx.dhikrDone[k][s]===true)o[s]=true});dh[k]=o});
const worship={khatma:{pages:num(kx.pages,0,604,0),total:604,goalDays:num(kx.goalDays,1,3650,30),start:dateRe.test(kx.start||'')?kx.start:'',log:klog},qada:{owed:num(isObj(wx.qada)?wx.qada.owed:0,0,5000,0)},dhikrDone:dh};
const fox=isObj(x.focus)?x.focus:{};const focus={work:num(fox.work,5,120,25),rest:num(fox.rest,1,60,5),sessions:(Array.isArray(fox.sessions)?fox.sessions:[]).filter(isObj).slice(-600).map(p=>({date:dateRe.test(p.date||'')?p.date:today(),minutes:num(p.minutes,1,240,25)}))};
return{tasks,habits,checks,chat,behavior,snaps,settings,prayer,prayerLog,checkins,family,worship,focus,idea:num(x.idea,0,100000,0)}}
async function importText(text){let x;try{if(String(text).length>5*1024*1024)throw 0;x=JSON.parse(text);if(x&&x._enc==='alislah-enc-v1'){if(!(NATIVE&&window.AndroidUsage&&typeof AndroidUsage.decryptBackup==='function')){toast('فتح النسخ المشفّرة متاح في نسخة أندرويد فقط');return}const pass=await ui.prompt('كلمة سر النسخة','','فتح',{password:true});if(pass===null)return;const plain=AndroidUsage.decryptBackup(String(text),String(pass));if(!plain){toast('كلمة السر غير صحيحة أو الملف تالف');return}x=JSON.parse(plain)}if(!x||typeof x!=='object'||Array.isArray(x)||!Array.isArray(x.tasks)||!Array.isArray(x.habits))throw 0}catch{toast('الملف غير صالح أو ليس نسخة من ALISLAH');return}
const c=cleanImport(x);if(!(await ui.confirm('استعادة النسخة؟','استعادة',true,'ستحل المهام والعادات والسجلات في هذه النسخة (${t} مهمة، ${h} عادة) محل بياناتك الحالية. لا تُستورد عناوين الخدمات ولا إعدادات المشاركة لأسباب أمنية.'.replace('${t}',c.tasks.length).replace('${h}',c.habits.length))))return;
try{data.tasks.forEach(t=>cancelTaskReminder(t.id))}catch(_){}
const cur=readJSON(KEY,{});const curS=isObj0(cur.settings)?cur.settings:{};
const fin={...cur,tasks:c.tasks,habits:c.habits,checks:c.checks,chat:c.chat,behavior:c.behavior,usageProfile:{snapshots:c.snaps},idea:c.idea,prayerLog:c.prayerLog,settings:{...curS,...c.settings,prayer:{...(curS.prayer||{}),...c.prayer,adhanEnabled:!!(curS.prayer&&curS.prayer.adhanEnabled)}},family:c.family,worship:c.worship,focus:c.focus,_rev:(Number(cur._rev)||0)+1};
try{localStorage.setItem(KEY,JSON.stringify(fin));localStorage.setItem(STORE_CHECKINS,JSON.stringify(c.checkins))}catch{toast('تعذر حفظ البيانات المستعادة');return}
location.reload()}
function isObj0(v){return v&&typeof v==='object'&&!Array.isArray(v)}
window.__alislahImport=importText;
const bindClick=(sel,fn)=>{const e=$(sel);if(e)e.onclick=fn};bindClick('#export',exportBackup);bindClick('#export2',exportBackup);
const pickFile=()=>$('#file').click();bindClick('#import',pickFile);bindClick('#import2',pickFile);
$('#file').onchange=async e=>{const f=e.target.files&&e.target.files[0];e.target.value='';if(!f)return;if(f.size>5*1024*1024){toast('الملف كبير جدًا');return}try{await importText(await f.text())}catch{toast('تعذر قراءة الملف')}};
$('#reset').onclick=async()=>{if(!(await ui.confirm('مسح كل البيانات؟','مسح الكل',true,'سيتم حذف المهام والعادات والمحادثات والإجابات والإعدادات من هذا الجهاز نهائيًا. احفظي نسخة احتياطية أولًا إن رغبتِ.')))return;
try{data.tasks.forEach(t=>cancelTaskReminder(t.id))}catch(_){}nat('syncPrayerPlan','[]',false);nat('enableBackgroundQuestions',false);
try{Object.keys(localStorage).filter(k=>/^alislah/i.test(k)).forEach(k=>localStorage.removeItem(k))}catch(_){}location.reload()};

window.ALI={get data(){return data},save,toast,ui,tab,today,ymd,uid,esc,nat,NATIVE,stats,renderTasks,renderHabits,scheduleTaskReminder,cancelTaskReminder,completeTask,applyTheme,nativeStatus,renderNative,CATS,REPEATS,exportBackup,pickFile};
renderTasks();data.tasks.forEach(scheduleTaskReminder);renderHabits();stats();idea();drawChat();renderBehavior();renderUsage();applyTheme();applyGreeting();renderNative();maybeWelcome();document.dispatchEvent(new CustomEvent('alislah:ready'));
// Collect a lightweight local usage snapshot when Android grants Usage Access; never upload automatically.
try{if(window.AndroidUsage&&typeof AndroidUsage.getUsageStatsJson==='function'){const u=JSON.parse(AndroidUsage.getUsageStatsJson()||'{}');if(u.permission&&Array.isArray(u.apps)){const day=today();if(!data.usageProfile.snapshots.some(x=>x.date===day)){data.usageProfile.snapshots.push({date:day,apps:u.apps.slice(0,12).map(a=>({name:a.name||a.packageName,minutes:Math.max(0,Number(a.minutes)||0)})),capturedAt:Date.now()});data.usageProfile.snapshots=data.usageProfile.snapshots.slice(-14);save();}}} }catch(_){}if(data.settings.name)$('#greeting').textContent=`أهلًا ${data.settings.name}، خطوة صغيرة تصنع فرقًا 🌿`;

// ميزات صوتية اختيارية: لا يبدأ الميكروفون إلا عند الضغط على الزر.
(function addVoiceAndPlan(){
  const form=$('#chatForm'), text=$('#chatText');
  if(!form||!text)return;
  const row=document.createElement('div');
  row.className='field';row.style.marginTop='8px';
  row.innerHTML='<label style="display:flex;align-items:center;gap:6px;font-size:.9rem">طريقة المساعد: <select id="alislahMode" style="max-width:160px"><option value="text">كتابة فقط</option><option value="voice">صوت</option><option value="both">كتابة وصوت</option></select></label><button type="button" class="btn soft" id="alislahVoice">🎙️ تحدثي</button><button type="button" class="btn" id="alislahStop">إيقاف الصوت</button><button type="button" class="btn soft" id="alislahVoiceTest">اختبار الصوت</button><label style="display:flex;align-items:center;gap:6px;font-size:.9rem"><input id="alislahRead" type="checkbox" style="width:18px"> قراءة الردود بصوت</label><label style="display:flex;align-items:center;gap:6px;font-size:.9rem">جنس الصوت القديم: <select id="alislahVoiceGender" style="max-width:120px"><option value="female">أنثى</option><option value="male">ذكر</option></select></label><label style="display:flex;align-items:center;gap:6px;font-size:.9rem">محرك صوت المساعد: <select id="alislahVoiceEngine" style="max-width:190px"><option value="old">المساعد القديم (محلي)</option><option value="neural">المساعد العربي العصبي الجديد (محلي)</option></select></label><small id="alislahVoiceStatus" class="muted" aria-live="polite">حالة الصوت: لم يُختبر بعد</small>';
  form.parentNode.insertBefore(row,form);
  const voice=$('#alislahVoice'),stop=$('#alislahStop'),voiceTest=$('#alislahVoiceTest'),read=$('#alislahRead'),mode=$('#alislahMode'),gender=$('#alislahVoiceGender'),engineSelect=$('#alislahVoiceEngine'),voiceStatus=$('#alislahVoiceStatus');mode.value=data.settings.interactionMode||'both';gender.value=data.settings.voiceGender||'female';engineSelect.value=data.settings.assistantVoiceEngine||'old';gender.addEventListener('change',()=>{data.settings.voiceGender=gender.value;save();try{if(window.AndroidUsage&&AndroidUsage.setAssistantVoice)AndroidUsage.setAssistantVoice(gender.value)}catch(_){}});engineSelect.addEventListener('change',()=>{data.settings.assistantVoiceEngine=engineSelect.value;save();try{nat('setAssistantVoiceEngine',engineSelect.value)}catch(_){}const ready=!!(window.AndroidUsage&&typeof AndroidUsage.isMixerTtsInstalled==='function'&&AndroidUsage.isMixerTtsInstalled());voiceStatus.textContent=engineSelect.value==='neural'?(ready?'المحرك العصبي الاختياري مثبت — يعمل محليًا دون إنترنت':'حزمة الصوت العصبي غير مثبتة؛ سيُستخدم الصوت القديم. ثبّت ALISLAH-Voice-Pack عند الحاجة.'):'المحرك المختار: القديم — يعمل محليًا';});try{nat('setAssistantVoiceEngine',engineSelect.value);if(window.AndroidUsage&&AndroidUsage.setAssistantVoice)AndroidUsage.setAssistantVoice(gender.value);if(window.AndroidUsage&&AndroidUsage.setAssistantVoiceMode)AndroidUsage.setAssistantVoiceMode(mode.value);const ready=!!(window.AndroidUsage&&typeof AndroidUsage.isMixerTtsInstalled==='function'&&AndroidUsage.isMixerTtsInstalled());if(engineSelect.value==='neural'&&!ready)voiceStatus.textContent='حزمة الصوت العصبي الاختيارية غير مثبتة؛ سيُستخدم الصوت القديم حتى تثبيتها.';}catch(_){};read.checked=!!data.settings.voiceRead||mode.value==='voice';mode.addEventListener('change',()=>{data.settings.interactionMode=mode.value;if(mode.value==='voice')read.checked=true;if(mode.value==='text')read.checked=false;data.settings.voiceRead=read.checked;save();try{if(window.AndroidUsage&&AndroidUsage.setAssistantVoiceMode)AndroidUsage.setAssistantVoiceMode(mode.value)}catch(_){}voice.style.display=mode.value==='text'?'none':'inline-flex';text.placeholder=mode.value==='voice'?'اضغطي تحدثي ثم تكلمي...':'اكتبي سؤالك...';});read.addEventListener('change',()=>{data.settings.voiceRead=read.checked;save()});voice.style.display=mode.value==='text'?'none':'inline-flex';
  const Recognition=window.SpeechRecognition||window.webkitSpeechRecognition;let rec=null;
  function say(t){
    if(window.AndroidUsage&&typeof AndroidUsage.speakAssistantText==='function'){try{AndroidUsage.speakAssistantText(String(t||'').slice(0,700))}catch{}return;}
    if(!('speechSynthesis' in window)){toast('المتصفح لا يدعم قراءة الردود بالصوت');return;}
    speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang='ar';u.rate=.95;const voices=speechSynthesis.getVoices();const female=/female|woman|salma|amira|hoda|laila|sara|ar.*fem|أنثى|امرأة/i;const male=/male|man|ahmed|hamza|omar|ar.*male|ذكر|رجل/i;const wanted=gender.value==='male'?male:female;const chosen=voices.find(v=>/^ar/i.test(v.lang)&&wanted.test(v.name))||voices.find(v=>/^ar/i.test(v.lang));if(chosen)u.voice=chosen;speechSynthesis.speak(u);
  }
  voice.onclick=()=>{
    if(window.AndroidUsage&&typeof AndroidUsage.startListening==='function'){
      try{
        if(typeof AndroidUsage.isSpeechAvailable==='function'&&!AndroidUsage.isSpeechAvailable()){toast('خدمة التعرف على الكلام غير متوفرة على هذا الهاتف');return;}
        voice.disabled=true;voice.textContent='🎙️ أستمع…';
        window.__alislahSpeech=(kind,val)=>{
          if(kind==='result'&&val){text.value=(text.value.trim()?text.value.trim()+' ':'')+val;text.focus();if(mode.value==='voice'){form.requestSubmit();}}
          else if(kind==='error'){toast(val==='not-allowed'||val==='9'?'اسمحي للتطبيق باستخدام الميكروفون ثم أعيدي المحاولة':'لم أسمع بوضوح؛ أعيدي المحاولة')}
          else if(kind==='end'){voice.disabled=false;voice.textContent='🎙️ تحدثي'}
        };
        AndroidUsage.startListening();
      }catch{voice.disabled=false;voice.textContent='🎙️ تحدثي';toast('تعذّر تشغيل الميكروفون')}
      return;
    }
    if(!Recognition){toast('الإملاء الصوتي غير مدعوم في هذا المتصفح؛ جرّبي Chrome');return;}
    try{
      rec=new Recognition();rec.lang='ar-DZ';rec.interimResults=false;
      voice.disabled=true;voice.textContent='🎙️ أستمع…';
      rec.onresult=e=>{const t=e.results?.[0]?.[0]?.transcript;if(t){text.value=(text.value.trim()?text.value.trim()+' ':'')+t;text.focus();if(mode.value==='voice'){form.requestSubmit();}}};
      rec.onerror=e=>{if(e.error==='not-allowed')toast('اسمحي للمتصفح باستخدام الميكروفون');};
      rec.onend=()=>{voice.disabled=false;voice.textContent='🎙️ تحدثي';};
      rec.start();
    }catch{voice.disabled=false;voice.textContent='🎙️ تحدثي';toast('تعذّر تشغيل الميكروفون');}
  };
  voiceTest.onclick=()=>{try{if(window.AndroidUsage&&typeof AndroidUsage.testAssistantVoice==='function'){AndroidUsage.testAssistantVoice();toast('جارٍ اختبار صوت المساعد')}else{say('مرحبًا بك في الإصلاح. هذا اختبار لصوت المساعد العربي.')}}catch{toast('تعذّر بدء اختبار الصوت')}};
  stop.onclick=()=>{try{rec?.stop()}catch{}try{nat('stopListening');nat('stopAssistantSpeech')}catch{}if('speechSynthesis'in window)speechSynthesis.cancel();if(window.AlishlahNeuralVoice)window.AlishlahNeuralVoice.stop();};
  window.addEventListener('alislah:neural-voice',e=>{if(voiceStatus)voiceStatus.textContent=e.detail&&e.detail.ok?'حالة الصوت: المحرك العصبي جاهز ويعمل':'حالة الصوت: '+String(e.detail&&e.detail.detail||'تعذر تشغيل المحرك العصبي')+' — تحقق من ملفات المحرك أو اختر المساعد القديم';});
  const messages=$('#messages');
  if(messages)new MutationObserver(records=>{
    if(!(read.checked||mode.value==='voice'))return;
    for(const r of records)for(const n of r.addedNodes){
      if(n.nodeType===1&&n.classList.contains('bubble')&&n.classList.contains('assistant'))say(n.textContent||'');
    }
  }).observe(messages,{childList:true});
  const panel=document.createElement('div');panel.className='panel';panel.style.marginTop='12px';
  panel.innerHTML='<h3>✨ خطة ذكية</h3><p class="muted">تستخدم الخطة المهام والعادات ومؤشرات السلوك التي حفظتِها. راجعي الطلب قبل إرساله.</p><button type="button" class="btn primary" id="alislahPlan">إنشاء خطة شخصية</button>';
  const tasks=$('#tasks');if(tasks)tasks.appendChild(panel);
  const savePlan=document.createElement('button');savePlan.type='button';savePlan.className='btn soft';savePlan.textContent='تحويل آخر خطة إلى مهام مجدولة';savePlan.style.marginInlineStart='6px';panel.appendChild(savePlan);
  savePlan.onclick=async()=>{const last=$('#messages .bubble.assistant:last-child');const raw=(last?.innerText||last?.textContent||'').trim();if(!raw||raw.length<12){toast('اطلبي الخطة من المساعد أولًا ثم حوّلي الرد إلى مهام');return}const clean=extractPlanTasks(raw);if(!clean.length){toast('لم أجد مهامًا واضحة في آخر رد؛ اطلبي من المساعد كتابة كل مهمة في سطر مستقل');return}const norm=x=>String(x||'').toLocaleLowerCase('ar').replace(/[\s\u0640.,،؛:!?؟()\[\]{}'"ـ-]/g,'');const existing=new Set(data.tasks.filter(t=>!t.done).map(t=>norm(t.text)));const unique=clean.filter(t=>{const k=norm(t);if(!k||existing.has(k))return false;existing.add(k);return true;});if(!unique.length){toast('هذه المهام موجودة بالفعل؛ لم أكررها.');return}if(!(await ui.confirm('تحويل الخطة إلى مهام؟','تحويل',false,'سأحوّل '+unique.length+' مهام إلى مهام قابلة للتأشير مع مواعيد أولية. يمكنك تعديلها بعد ذلك.')))return;const now=new Date();let cursor=new Date(now);cursor.setMinutes(0,0,0);cursor.setHours(cursor.getHours()+1);if(cursor.getHours()<8)cursor.setHours(9,0,0,0);if(cursor.getHours()>21){cursor.setDate(cursor.getDate()+1);cursor.setHours(9,0,0,0)}unique.forEach((text,i)=>{if(cursor.getHours()>21){cursor.setDate(cursor.getDate()+1);cursor.setHours(9,0,0,0)}const date=cursor.getFullYear()+'-'+String(cursor.getMonth()+1).padStart(2,'0')+'-'+String(cursor.getDate()).padStart(2,'0');const time=String(cursor.getHours()).padStart(2,'0')+':'+String(cursor.getMinutes()).padStart(2,'0');const task={id:uid(),text,date,time,priority:i===0?'مهمة جدًا':'عادية',done:false,source:'assistant-plan'};data.tasks.push(task);scheduleTaskReminder(task);cursor=new Date(cursor.getTime()+90*60000)});save();renderTasks();tab('tasks');toast('تمت إضافة '+unique.length+' مهام كاملة؛ راجعي الأوقات الأولية قبل الاعتماد')};
  $('#alislahPlan').onclick=()=>{
    if(Object.keys(data.behavior||{}).length && !$('#analysisConsent').checked){tab('behavior');toast('فعّلي الموافقة قبل إعداد خطة تعتمد على بياناتك');return;}
    tab('assistant');
    text.value=makeBehaviorPrompt();
    text.dataset.includesPersonalAnalysis=Object.keys(data.behavior||{}).length?'true':'false';
    if(!Object.keys(data.behavior||{}).length)text.value='أنشئ لي خطة شخصية عملية لمدة 7 أيام اعتمادًا على البيانات المتاحة فقط. اكتب كل يوم بعنوان اليوم 1 إلى اليوم 7، وتحته 2 إلى 4 مهام مستقلة قابلة للتنفيذ، كل مهمة في سطر مستقل يبدأ برقم ونقطة. اجمع عنوان المهمة مع وصفها العملي في السطر نفسه، وحدد مدة أو وقتًا مقترحًا. لا تكتب نصائح عامة كأنها مهام ولا تخترع بيانات.';
    text.focus();
  };
})();

})();
