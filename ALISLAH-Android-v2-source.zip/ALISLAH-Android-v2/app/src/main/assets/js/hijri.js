/* Hijri (Umm al-Qura) helpers — uses the browser's Intl calendar, no network */
(function(root){
  var names=['محرم','صفر','ربيع الأول','ربيع الآخر','جمادى الأولى','جمادى الآخرة','رجب','شعبان','رمضان','شوال','ذو القعدة','ذو الحجة'];
  var fmt=null;
  try{fmt=new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn',{day:'numeric',month:'numeric',year:'numeric'})}catch(e){fmt=null}
  function parts(d){
    if(!fmt)return null;
    try{
      var o={};fmt.formatToParts(d).forEach(function(x){if(x.type==='day'||x.type==='month'||x.type==='year')o[x.type]=parseInt(x.value,10)});
      return(o.day&&o.month&&o.year)?o:null;
    }catch(e){return null}
  }
  function text(d){var p=parts(d);return p?(p.day+' '+names[p.month-1]+' '+p.year+'\u00A0هـ'):''}
  var api={parts:parts,text:text,names:names};
  root.ALI_HIJRI=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
