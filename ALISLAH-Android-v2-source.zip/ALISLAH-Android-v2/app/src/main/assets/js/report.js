/* Weekly report with SVG charts and cautious, local-only insights. */
(function(){
  'use strict';
  var A=window.ALI,host=document.getElementById('report');
  if(!A||!host)return;
  var DAYS=['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
  function day(offset){var d=new Date();d.setDate(d.getDate()-offset);return d}
  function prayersOn(k){
    try{var log=JSON.parse(localStorage.getItem('alislah_v2')||'{}').prayerLog||[],s=new Set();
      log.forEach(function(x){if(x&&(x.day===k||(!x.day&&String(x.date||'').slice(0,10)===k)))s.add(x.name)});return s.size}catch(e){return 0}
  }
  function stats(k){
    var d=A.data,tasksDone=d.tasks.filter(function(t){return t.done&&(t.doneAt===k||(!t.doneAt&&t.date===k))}).length;
    var c=d.checks[k]||{},hd=d.habits.filter(function(h){return c[h.id]}).length,hp=d.habits.length?Math.round(hd/d.habits.length*100):null;
    var focus=d.focus.sessions.filter(function(s){return s.date===k}).reduce(function(a,s){return a+s.minutes},0);
    var b=d.behavior[k]||null;
    return{k:k,tasks:tasksDone,habit:hp,prayers:prayersOn(k),focus:focus,b:b};
  }
  function week(start){var out=[];for(var i=6;i>=0;i--)out.push(stats(A.ymd(day(start+i))));return out}
  function sum(a,f){return a.reduce(function(x,y){return x+(f(y)||0)},0)}
  function bars(title,vals,labels,max,color,unit){
    var w=300,h=110,bw=26,gap=(w-bw*7)/8,top=14,base=h-18;
    var m=Math.max(max,1,Math.max.apply(null,vals));
    var s='<svg viewBox="0 0 '+w+' '+h+'" role="img" aria-label="'+A.esc(title+': '+vals.map(function(v,i){return labels[i]+' '+v+unit}).join('، '))+'" style="width:100%;height:auto">';
    vals.forEach(function(v,i){
      var x=w-gap-bw-i*(bw+gap),bh=Math.round((base-top)*v/m);
      s+='<rect x="'+x+'" y="'+(base-bh)+'" width="'+bw+'" height="'+Math.max(bh,v>0?3:1)+'" rx="6" fill="'+(v>0?color:'var(--line)')+'"/>';
      s+='<text x="'+(x+bw/2)+'" y="'+(base-bh-4)+'" text-anchor="middle" font-size="10" fill="var(--muted)">'+(v>0?v:'')+'</text>';
      s+='<text x="'+(x+bw/2)+'" y="'+(h-4)+'" text-anchor="middle" font-size="9" fill="var(--muted)">'+A.esc(labels[i])+'</text>';
    });
    return s+'</svg>';
  }
  function delta(cur,prev,unit){
    var d=cur-prev;if(d===0)return '<span class="muted">مثل الأسبوع الماضي</span>';
    return '<span class="'+(d>0?'up':'down')+'">'+(d>0?'▲ ':'▼ ')+Math.abs(d)+unit+' عن الأسبوع الماضي</span>';
  }
  function avg(a){return a.length?a.reduce(function(x,y){return x+y},0)/a.length:0}
  function insights(){
    var days=[];for(var i=0;i<60;i++){var k=A.ymd(day(i)),b=A.data.behavior[k];if(b){var s=stats(k);days.push({b:b,habit:s.habit})}}
    var out=[];if(days.length<5)return{list:out,n:days.length};
    function cmp(fa,fb,field,cond,labelHigh,labelLow,what){
      var hi=days.filter(function(x){return cond(x)===true}),lo=days.filter(function(x){return cond(x)===false});
      if(hi.length<2||lo.length<2)return;
      var a=avg(hi.map(function(x){return x.b[field]})),b=avg(lo.map(function(x){return x.b[field]})),d=a-b;
      if(Math.abs(d)>=0.5)out.push((d>0?'في الأيام التي '+labelHigh+' كان '+what+' أعلى':'في الأيام التي '+labelHigh+' كان '+what+' أقل')+' بنحو '+Math.abs(d).toFixed(1)+' من 5 مقارنةً بالأيام التي '+labelLow+'.');
    }
    var withSleep=days.filter(function(x){return x.b.sleepHours>0});
    if(withSleep.length>=5){
      var hi=withSleep.filter(function(x){return x.b.sleepHours>=7}),lo=withSleep.filter(function(x){return x.b.sleepHours<7});
      if(hi.length>=2&&lo.length>=2){
        [['focus','تركيزك'],['mood','مزاجك'],['energy','طاقتك']].forEach(function(p){
          var d=avg(hi.map(function(x){return x.b[p[0]]}))-avg(lo.map(function(x){return x.b[p[0]]}));
          if(d>=0.5)out.push('في الأيام التي نمتِ فيها 7 ساعات أو أكثر كان '+p[1]+' أعلى بنحو '+d.toFixed(1)+' من 5.');
        });
      }
    }
    var wh=days.filter(function(x){return x.habit!=null});
    if(wh.length>=5){
      var h2=wh.filter(function(x){return x.habit>=60}),l2=wh.filter(function(x){return x.habit<60});
      if(h2.length>=2&&l2.length>=2){
        [['mood','مزاجك'],['energy','طاقتك']].forEach(function(p){
          var d=avg(h2.map(function(x){return x.b[p[0]]}))-avg(l2.map(function(x){return x.b[p[0]]}));
          if(d>=0.5)out.push('في الأيام التي أنجزتِ فيها 60٪ أو أكثر من عاداتك كان '+p[1]+' أعلى بنحو '+d.toFixed(1)+' من 5.');
        });
      }
    }
    var wp=days.filter(function(x){return x.b.phoneMinutes!=null&&x.b.phoneMinutes>0});
    if(wp.length>=5){
      var med=wp.map(function(x){return x.b.phoneMinutes}).sort(function(a,b){return a-b})[Math.floor(wp.length/2)];
      var lowP=wp.filter(function(x){return x.b.phoneMinutes<=med}),highP=wp.filter(function(x){return x.b.phoneMinutes>med});
      if(lowP.length>=2&&highP.length>=2){var d=avg(lowP.map(function(x){return x.b.focus}))-avg(highP.map(function(x){return x.b.focus}));if(d>=0.5)out.push('في الأيام التي قلّ فيها وقت الهاتف كان تركيزك أعلى بنحو '+d.toFixed(1)+' من 5.')}
    }
    return{list:out,n:days.length};
  }
  function render(){
    var cur=week(0),prev=week(7),labels=cur.map(function(s){return DAYS[dstr(s.k).getDay()].slice(0,5)});
    function dstr(k){var p=k.split('-').map(Number);return new Date(p[0],p[1]-1,p[2])}
    labels=cur.map(function(s){return DAYS[dstr(s.k).getDay()]});
    var tT=sum(cur,function(s){return s.tasks}),pT=sum(prev,function(s){return s.tasks});
    var tP=sum(cur,function(s){return s.prayers}),pP=sum(prev,function(s){return s.prayers});
    var tF=sum(cur,function(s){return s.focus}),pF=sum(prev,function(s){return s.focus});
    var hv=cur.filter(function(s){return s.habit!=null}).map(function(s){return s.habit}),hp=hv.length?Math.round(avg(hv)):null;
    var hv2=prev.filter(function(s){return s.habit!=null}).map(function(s){return s.habit}),hpp=hv2.length?Math.round(avg(hv2)):null;
    var ins=insights();
    var summary='تقرير الأسبوع — ALISLAH\nمهام منجزة: '+tT+'\nصلوات مسجّلة: '+tP+' من 35\nدقائق التركيز: '+tF+(hp!=null?'\nمتوسط العادات: '+hp+'٪':'');
    host.innerHTML='<div class="panel"><h3>📈 تقرير الأسبوع</h3><div class="rep-cards">'+
      '<div class="rep-card"><div class="num">'+tT+'</div><div class="muted">مهام منجزة</div>'+delta(tT,pT,'')+'</div>'+
      '<div class="rep-card"><div class="num">'+tP+'<small>/35</small></div><div class="muted">صلوات مسجّلة</div>'+delta(tP,pP,'')+'</div>'+
      '<div class="rep-card"><div class="num">'+(hp==null?'—':hp+'%')+'</div><div class="muted">متوسط العادات</div>'+(hp!=null&&hpp!=null?delta(hp,hpp,'٪'):'<span class="muted">—</span>')+'</div>'+
      '<div class="rep-card"><div class="num">'+tF+'<small>د</small></div><div class="muted">وقت التركيز</div>'+delta(tF,pF,' د')+'</div></div></div>'+
      '<div class="panel"><h4>مهام منجزة يوميًا</h4>'+bars('المهام المنجزة',cur.map(function(s){return s.tasks}),labels,3,'var(--brand-2)','')+'</div>'+
      '<div class="panel"><h4>الصلوات المسجّلة يوميًا</h4>'+bars('الصلوات',cur.map(function(s){return s.prayers}),labels,5,'var(--brand)','')+'</div>'+
      '<div class="panel"><h4>إنجاز العادات (٪)</h4>'+bars('العادات',cur.map(function(s){return s.habit==null?0:s.habit}),labels,100,'var(--gold)','٪')+'</div>'+
      '<div class="panel"><h4>دقائق التركيز يوميًا</h4>'+bars('التركيز',cur.map(function(s){return s.focus}),labels,60,'var(--brand-2)',' د')+'</div>'+
      '<div class="panel"><h3>💡 ملاحظات من بياناتك</h3>'+(ins.list.length?'<ul class="ins">'+ins.list.map(function(t){return '<li>'+A.esc(t)+'</li>'}).join('')+'</ul>':'<div class="muted">'+(ins.n<5?'سجّلي مؤشرات يومك في «تحليل السلوك» خمسة أيام على الأقل لتظهر ملاحظات هنا. (سجّلتِ '+ins.n+')':'لا توجد فروق واضحة حتى الآن.')+'</div>')+'<p class="muted" style="margin:10px 0 0;font-size:.82rem">هذه ملاحظات إحصائية بسيطة من بياناتك على هذا الجهاز، وقد تكون محض صدفة؛ وليست تشخيصًا أو نصيحة طبية.</p></div>'+
      '<button class="btn soft block" id="repShare" type="button">مشاركة ملخص الأسبوع</button>';
    document.getElementById('repShare').onclick=function(){
      if(window.AndroidUsage&&typeof AndroidUsage.shareText==='function'){try{AndroidUsage.shareText(summary)}catch(e){}}
      else if(navigator.share){navigator.share({text:summary}).catch(function(){})}
      else A.toast('المشاركة متاحة في نسخة أندرويد');
    };
  }
  document.addEventListener('alislah:tab',function(e){if(e.detail==='report')render()});
})();
