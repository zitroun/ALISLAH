/* Adhkar screen (reading list + "done today" tracking). */
(function(){
  'use strict';
  var A=window.ALI,D=window.ALI_ADHKAR,host=document.getElementById('adhkar');
  if(!A||!D||!host)return;
  var cur='';
  function pick(){var h=new Date().getHours();return h<15?'morning':h<21?'evening':'sleep'}
  function done(set){var d=A.data.worship.dhikrDone[A.today()];return !!(d&&d[set])}
  function streak(set){
    var n=0,d=new Date();if(!done(set))d.setDate(d.getDate()-1);
    while(n<3650){var k=A.ymd(d),x=A.data.worship.dhikrDone[k];if(x&&x[set]){n++;d.setDate(d.getDate()-1)}else break}
    return n;
  }
  function render(){
    if(!cur)cur=pick();
    var set=D.sets[cur],ok=done(cur),st=streak(cur);
    host.innerHTML='<div class="panel"><h3>🤲 الأذكار</h3><div class="segmented" id="adhTabs" role="group" aria-label="مجموعات الأذكار" style="margin-top:0">'+D.order.map(function(k){return '<button type="button" data-k="'+k+'" class="'+(k===cur?'on':'')+'">'+D.sets[k].icon+' '+D.sets[k].name.replace('أذكار ','')+'</button>'}).join('')+'</div>'+
      '<div class="list" style="margin-top:12px">'+set.items.map(function(it){return '<div class="dhikr"><div class="dhikr-text" lang="ar">'+A.esc(it.t).replace(/\n/g,'<br>')+'</div><div class="meta"><span class="chip">🔁 '+A.esc(it.n)+'</span><span class="chip gray">'+A.esc(it.s)+'</span></div></div>'}).join('')+'</div>'+
      '<button class="btn '+(ok?'soft':'primary')+' block" id="adhDone" type="button" style="margin-top:14px">'+(ok?'✓ قرأتُ '+set.name+' اليوم — إلغاء':'تمت قراءة '+set.name+' اليوم')+'</button>'+
      '<p class="muted" style="margin:10px 0 0">'+(st?'🔥 سلسلة: '+st+(st===1?' يوم':' أيام')+' متتالية. ':'')+'النصوص منقولة من حصن المسلم وكتب السنة؛ راجعيها من مصدر موثوق عند الاقتباس.</p></div>';
    host.querySelectorAll('#adhTabs button').forEach(function(b){b.onclick=function(){cur=b.dataset.k;render();window.scrollTo({top:0})}});
    document.getElementById('adhDone').onclick=function(){
      var w=A.data.worship.dhikrDone,t=A.today();w[t]=w[t]||{};
      if(w[t][cur])delete w[t][cur];else w[t][cur]=true;
      var keys=Object.keys(w).sort();while(keys.length>120)delete w[keys.shift()];
      A.save();render();if(w[t][cur])A.toast('تقبّل الله منكِ 🌿');
    };
  }
  document.addEventListener('alislah:tab',function(e){if(e.detail==='adhkar'){cur='';render()}});
})();
