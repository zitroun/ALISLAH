import 'package:flutter/widgets.dart';
import 'package:flutter/services.dart';
import 'tts/model.dart';
import 'vowelizer/model.dart';

// Headless entry point used by ALISLAH's native Android host.
@pragma('vm:entry-point')
Future<void> alislahTtsEntryPoint() async {
  WidgetsFlutterBinding.ensureInitialized();
  const channel = MethodChannel('alislah/mixer_tts');
  TTS? engine;
  Shakkelha? vowelizer;
  bool vowelizerReady = false;
  bool loading = false;

  channel.setMethodCallHandler((call) async {
    if (call.method == 'stop') {
      await engine?.stop();
      return true;
    }
    if (call.method != 'speak') return null;

    final args = Map<String, dynamic>.from(call.arguments as Map);
    final text = (args['text'] ?? '').toString().trim();
    if (text.isEmpty) return false;
    if (loading) return false;
    loading = true;
    try {
      engine ??= TTS();
      if (!engine!.isInitialized) {
        await engine!.initSessions(
          modelPath: 'assets/models/mixer128.onnx',
          vocoderPath: 'assets/models/vocos22.onnx',
        );
      }
      var speechText = text;
      final hasArabicMarks = RegExp(r'[ًٌٍَُِّْٰ]').hasMatch(text);
      final hasArabicLetters = RegExp(r'[ء-ي]').hasMatch(text);
      if (!hasArabicMarks && hasArabicLetters) {
        try {
          vowelizer ??= Shakkelha();
          if (!vowelizerReady) {
            await vowelizer!.initSessions(modelPath: 'assets/models/shakkelha.onnx');
            vowelizerReady = true;
          }
          speechText = vowelizer!.vowelize(text);
        } catch (e) {
          // Never block speech if the optional automatic vowelizer fails.
          await channel.invokeMethod('onStatus', {
            'ok': true,
            'detail': 'تعذر التشكيل التلقائي؛ سأقرأ النص كما كُتب',
          });
        }
      }
      await engine!.tts(speechText, speaker: 0, pace: 0.96, pmul: 1, padd: 0, denoise: 0.005);
      await channel.invokeMethod('onStatus', {'ok': true, 'detail': 'Mixer-TTS جاهز ويعمل محليًا'});
      return true;
    } catch (e) {
      await channel.invokeMethod('onStatus', {'ok': false, 'detail': e.toString()});
      return false;
    } finally {
      loading = false;
    }
  });
  await channel.invokeMethod('onStatus', {
    'ok': true,
    'ready': true,
    'detail': 'محرك Mixer-TTS وShakkelha جاهزان؛ النماذج مضمّنة داخل التطبيق',
  });
}

// The host uses alislahTtsEntryPoint; main remains available for tooling.
void main() => alislahTtsEntryPoint();
