abstract class Vowelizer {
  String vowelize(String text);
  Future<void> initSessions({String modelPath});
  Future<void> release();
}
