from pathlib import Path

root = Path(__file__).resolve().parents[1]
activity = (root / 'app/src/main/java/dz/alislah/app/MainActivity.kt').read_text(encoding='utf-8')
bubble = (root / 'app/src/main/java/dz/alislah/app/FloatingBubbleService.kt').read_text(encoding='utf-8')
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
index = (root / 'app/src/main/assets/index.html').read_text(encoding='utf-8')
main_js = (root / 'app/src/main/assets/js/main.js').read_text(encoding='utf-8')
parser = (root / 'app/src/main/assets/js/voice-task-parser.js').read_text(encoding='utf-8')
gradle = (root / 'app/build.gradle').read_text(encoding='utf-8')

checks = {
    'runtime microphone permission': 'android.permission.RECORD_AUDIO' in manifest,
    'live partial speech results': 'RecognizerIntent.EXTRA_PARTIAL_RESULTS, true' in activity and 'onPartialResults' in activity,
    'Arabic-Algerian recognizer locale': 'RecognizerIntent.EXTRA_LANGUAGE, "ar-DZ"' in activity,
    'hold-to-record bubble timer': 'handler.postDelayed(longPress, 650L)' in bubble,
    'release stops bubble recording': 'stopVoiceTaskFromBubble()' in bubble and 'EXTRA_STOP_VOICE_TASK' in activity,
    'landscape navbar edge uses exposed half-circle': 'if (landscape && navigation.edge == edge)' in bubble and 'lp.y = boundary - circle/2' in bubble and 'lp.x = boundary - circle/2' in bubble,
    'microphone remains optional device hardware': 'android.hardware.microphone' in manifest and 'android:required=\"false\"' in manifest,
    'landscape side-navigation detection': 'config_navBarCanMove' in bubble and 'Surface.ROTATION_270' in bubble and 'navigation_bar_width' in bubble,
    'voice task entry in app': 'id="voiceTaskStart"' in index and 'AndroidUsage.startVoiceTask()' in main_js,
    'missing-time prompt': 'id="voiceTaskSheet"' in index and 'حددي وقت المهمة' in index,
    'prayer-relative scheduling hook': 'ALI_PRAYER_TASK_TIME' in parser and 'ALI_PRAYER_TASK_TIME=function' in (root / 'app/src/main/assets/js/prayer.js').read_text(encoding='utf-8'),
    'editable transcript continues receiving new words': 'voiceTaskLastRecognized' in activity and 'voiceTaskUserEdited' in activity,
    're-record button restarts recognition': 'voiceTaskRequiresHold = false' in activity,
    'shared task-list integration': 'addVoiceTask:addVoiceTaskFromTranscript' in main_js and 'scheduleTaskReminder(task)' in main_js,
    'voice parser loaded before main app': index.index('js/voice-task-parser.js') < index.index('js/main.js'),
    'version increment': "versionCode 43" in gradle and "versionName '2.1.4.13'" in gradle,
    'side assistant bubble starts Android recognizer': 'if (command == "ask") handler.postDelayed({ startAssistantListening() }' in bubble and 'ACTION_START_ASSISTANT_LISTENING' in bubble,
    'Arabic overlay speech recognizer with partial results': 'RecognizerIntent.EXTRA_LANGUAGE, "ar-DZ"' in bubble and 'override fun onPartialResults(partialResults: Bundle?)' in bubble,
    'speech recognizer code 5 has an explanatory Arabic message': 'SpeechRecognizer.ERROR_CLIENT' in bubble and 'الرمز 5' in bubble,
    'overlay speech callbacks reach the web assistant': '__alislahOverlaySpeechPartial' in bubble and '__alislahOverlaySpeechResult' in bubble and '__alislahOverlaySpeechStatus' in main_js,
    'overlay microphone asks Android permission': 'requestOverlayAssistantMic' in bubble and 'ASSISTANT_OVERLAY_MIC_PERMISSION_REQUEST' in activity,
    'side assistant bubble stays available after answering': 'isBubbleOverlay(): Boolean = true' in bubble and 'AndroidUsage.isBubbleOverlay()' in main_js,
    'voice assistant reads and completes actual task records': 'function handleVoiceTaskStatusCommand(transcript)' in main_js and 'completeTask(matches[0],true)' in main_js and 'data.tasks.filter(t=>(t.date||today())===today())' in main_js,
    'voice can add and check habits with explicit action': 'async function addVoiceHabitFromTranscript(transcript)' in main_js and "await ui.confirm('إضافة عادة جديدة؟'" in main_js and 'data.checks[today()][matches[0].id]=true' in main_js,
    'startup spoken welcome uses the legacy Android TTS': 'startupGreetingSent' in activity and 'speakWithLegacyTts(greeting' in activity,
    'live local usage insights shown on behavior screen': 'id="liveInsights"' in index and 'function renderLiveInsights()' in main_js and 'getProductivityMetrics()' in main_js,
    'voice advice uses live local data without cloud upload': 'renderLiveInsights();' in main_js and 'قدمت لك نصيحة اعتمادًا على بياناتك المحلية الحالية.' in main_js,
    'voice analysis composes a reviewable one-time data summary after consent': "input.value=text+'\\n\\n'+makeBehaviorPrompt()" in main_js and "input.dataset.includesPersonalAnalysis='true'" in main_js,
    'voice task requires explicit confirmation from overlay': 'function addVoiceTaskFromTranscript(raw,explicitlyConfirmed=false)' in main_js and 'explicitlyConfirmed&&parsed.hasTime' in main_js,
    'AI plan task conversion is automatic after an explicit plan request': "await autoCreateTasksFromPlan(m,answer)" in main_js and "سيحوّل التطبيق عناصر الخطة إلى مهام تلقائيًا" in main_js and "await ui.confirm('هل تريد تحويل الخطة إلى مهام؟'" not in main_js,
    'no Mixer-TTS model or binary payload added': not any((root / 'app/src/main').rglob('*.onnx')) and not any((root / 'app/src/main').rglob('*.tflite')),
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit('Voice-task integration checks failed: ' + ', '.join(failed))
